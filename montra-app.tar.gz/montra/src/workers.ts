/**
 * Background jobs and business clocks.
 * Document 03 §15: PM obligation evaluation, usage freshness, SLA clocks,
 * alerts and housekeeping.
 *
 * In production these belong in a separate worker process; here they run
 * in-process on a timer so a single Render service covers the whole system.
 */

import { pool, many, one, q, notify } from './lib/db.ts';
import { reevaluateObligations } from './domain/pm.ts';
import { markStaleFeeds } from './domain/usage.ts';

const PM_INTERVAL_MS = Number(process.env.WORKER_PM_INTERVAL_MS ?? 15 * 60 * 1000);
const SLA_INTERVAL_MS = Number(process.env.WORKER_SLA_INTERVAL_MS ?? 5 * 60 * 1000);

let timers: NodeJS.Timeout[] = [];

/** Re-evaluate every open PM obligation and refresh usage freshness. */
export async function runPmEvaluation(): Promise<{ vehicles: number; changed: number }> {
  const stale = await markStaleFeeds(pool);
  if (stale) console.log(`[worker] marked ${stale} vehicle feed(s) stale (BL-USG-003)`);

  const vehicles = await many<any>(pool, `
    SELECT DISTINCT v.vehicle_id FROM master.vehicle v
    JOIN pm.pm_obligation o ON o.vehicle_id = v.vehicle_id
    WHERE v.lifecycle_status = 'Active'
      AND o.status IN ('Upcoming','Due Soon','Due','Overdue')`);

  let changed = 0;
  for (const v of vehicles) {
    try {
      const r = await reevaluateObligations(pool, v.vehicle_id, 'worker');
      changed += r.changed;
    } catch (e) {
      console.error(`[worker] PM evaluation failed for vehicle ${v.vehicle_id}:`, e);
    }
  }
  return { vehicles: vehicles.length, changed };
}

/**
 * Evaluate SLA clocks against targets and the business calendar, recording
 * breaches with target, actual, variance, owner and reason (BL-SLA-002).
 */
export async function runSlaEvaluation(): Promise<number> {
  const open = await many<any>(pool, `
    SELECT se.service_event_id, se.service_event_no, se.priority, se.vehicle_id,
           be.reported_utc, be.accepted_utc, be.assigned_utc, be.on_site_utc,
           be.restored_operable_utc,
           s.sla_id, s.version_no, s.response_minutes, s.on_site_minutes, s.restore_minutes,
           COALESCE((SELECT SUM(EXTRACT(EPOCH FROM (COALESCE(cp.end_utc, now()) - cp.start_utc)))/60.0
                      FROM service.clock_pause cp
                      WHERE cp.service_event_id = se.service_event_id AND cp.exclude_from_net),0) AS paused_minutes
    FROM service.service_event se
    JOIN service.breakdown_event be ON be.service_event_id = se.service_event_id
    JOIN service.sla_master s ON s.sla_id = se.sla_id
    WHERE se.status NOT IN ('Closed','Cancelled')`);

  let breaches = 0;

  for (const e of open) {
    const paused = Number(e.paused_minutes ?? 0);
    const checks: { clock: string; targetMinutes: number | null; actual: Date | null }[] = [
      { clock: 'Response', targetMinutes: e.response_minutes, actual: e.accepted_utc ?? e.assigned_utc },
      { clock: 'OnSite',   targetMinutes: e.on_site_minutes,  actual: e.on_site_utc },
      { clock: 'Restore',  targetMinutes: e.restore_minutes,  actual: e.restored_operable_utc },
    ];

    for (const c of checks) {
      if (!c.targetMinutes) continue;
      const start = new Date(e.reported_utc).getTime();
      const targetUtc = new Date(start + (c.targetMinutes + paused) * 60_000);
      const actual = c.actual ? new Date(c.actual) : null;
      const isBreached = actual ? actual > targetUtc : new Date() > targetUtc;
      if (!isBreached) continue;

      const existing = await one<any>(pool, `
        SELECT breach_id FROM service.sla_breach
        WHERE service_event_id = $1 AND clock_type = $2`, [e.service_event_id, c.clock]);
      if (existing) continue;

      const variance = Math.round(
        ((actual ? actual.getTime() : Date.now()) - targetUtc.getTime()) / 60_000);

      await q(pool, `
        INSERT INTO service.sla_breach
          (service_event_id, sla_id, sla_version, clock_type, target_utc, actual_utc,
           variance_minutes, pause_minutes, reason, owner, status)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'Breached')`,
        [e.service_event_id, e.sla_id, e.version_no, c.clock, targetUtc, actual,
         variance, Math.round(paused),
         `${c.clock} target of ${c.targetMinutes} min exceeded by ${variance} min`,
         'Service Coordinator']);

      await notify(pool, {
        alertType: 'SLA_BREACH', severity: 'Critical',
        title: `SLA breach — ${e.service_event_no} (${c.clock})`,
        body: `${c.clock} target ${c.targetMinutes} min exceeded by ${variance} min ` +
              `(${Math.round(paused)} min paused and excluded).`,
        entityType: 'ServiceEvent', entityId: e.service_event_id, vehicleId: e.vehicle_id,
      });
      breaches++;
    }
  }

  // BL-ALR-006: parts waits beyond threshold.
  const stuck = await many<any>(pool, `
    SELECT jc.job_card_id, jc.job_card_no, jc.vehicle_id,
           EXTRACT(EPOCH FROM (now() - cp.start_utc))/3600.0 AS hours
    FROM service.job_card jc
    JOIN service.clock_pause cp ON cp.job_card_id = jc.job_card_id AND cp.end_utc IS NULL
    WHERE jc.status = 'Awaiting Parts'
      AND cp.start_utc < now() - interval '48 hours'
      AND NOT EXISTS (SELECT 1 FROM service.notification n
                       WHERE n.entity_type = 'JobCard' AND n.entity_id = jc.job_card_id
                         AND n.alert_type = 'WAITING_PARTS_ESCALATION'
                         AND n.created_at > now() - interval '24 hours')`);

  for (const s of stuck) {
    await notify(pool, {
      alertType: 'WAITING_PARTS_ESCALATION', severity: 'Warning',
      title: `Parts wait exceeded threshold — ${s.job_card_no}`,
      body: `Waiting ${Math.round(Number(s.hours))} hours for parts.`,
      entityType: 'JobCard', entityId: s.job_card_id, vehicleId: s.vehicle_id,
    });
  }

  // Expire concessions whose date or kilometre limit has passed (BL-CON-001).
  await q(pool, `
    UPDATE quality.concession c
    SET status = 'Expired'
    FROM master.vehicle v
    WHERE v.vehicle_id = c.vehicle_id AND c.status = 'Active'
      AND ((c.expiry_date IS NOT NULL AND c.expiry_date < CURRENT_DATE)
        OR (c.expiry_km IS NOT NULL AND v.current_odometer_km > c.expiry_km))`);

  // Statutory document expiry (FR-DOC-001).
  await q(pool, `
    UPDATE campaign.vehicle_document
    SET renewal_status = CASE
      WHEN expiry_date < CURRENT_DATE THEN 'Expired'
      WHEN expiry_date < CURRENT_DATE + interval '30 days' THEN 'Due Soon'
      ELSE 'Valid' END
    WHERE expiry_date IS NOT NULL`);

  return breaches;
}

export function startWorkers() {
  const runPm = () => runPmEvaluation()
    .then(r => { if (r.changed) console.log(`[worker] PM: ${r.changed} status change(s) across ${r.vehicles} vehicles`); })
    .catch(e => console.error('[worker] PM evaluation error:', e));

  const runSla = () => runSlaEvaluation()
    .then(n => { if (n) console.log(`[worker] SLA: ${n} new breach(es)`); })
    .catch(e => console.error('[worker] SLA evaluation error:', e));

  setTimeout(runPm, 5_000);
  setTimeout(runSla, 10_000);
  timers.push(setInterval(runPm, PM_INTERVAL_MS));
  timers.push(setInterval(runSla, SLA_INTERVAL_MS));
  console.log(`[worker] started — PM every ${PM_INTERVAL_MS / 60000} min, SLA every ${SLA_INTERVAL_MS / 60000} min`);
}

export function stopWorkers() {
  timers.forEach(clearInterval);
  timers = [];
}
