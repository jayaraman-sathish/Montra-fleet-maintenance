/**
 * Dashboard, KPI and integration endpoints.
 * FR-DASH-001..004 and the Document 02 §24.10 Final KPI Dictionary.
 * Every figure is derived from the persisted source rows named in
 * Document 04 §29 so a drill-down always reconciles to the tile.
 */

import { Router, badRequest } from '../lib/http.ts';
import type { Ctx } from '../lib/http.ts';
import { pool, one, many } from '../lib/db.ts';
import { authenticate, vehicleScopeClause, assertAuthorised } from '../lib/auth.ts';
import { reliabilityKpis, mttr } from '../domain/reliability.ts';
import { ingestTelematics, markStaleFeeds } from '../domain/usage.ts';

// ---------------------------------------------------------------------
// Dashboard
// ---------------------------------------------------------------------

export const dashboardRoutes = new Router();
const dash = dashboardRoutes;
dash.use(authenticate);

dash.get('/api/v1/dashboard', async (ctx: Ctx) => {
  const scope = vehicleScopeClause(ctx.user!, 'v', 1);
  const centreFilter = ctx.query.get('serviceCentreId');
  const params: unknown[] = [...scope.params];
  let where = scope.clause;
  if (centreFilter) { params.push(Number(centreFilter)); where += ` AND v.assigned_service_centre_id = $${params.length}`; }

  const [fleet, pmCounts, jobCounts, breakdowns, alerts, appointments, slaBreaches] = await Promise.all([
    // Vehicle status — from the cached state, reconciled to the ledger.
    one<any>(pool, `
      SELECT count(*)::int AS total,
             count(*) FILTER (WHERE v.current_availability_state IN ('In Service','Idle'))::int AS in_service,
             count(*) FILTER (WHERE v.current_availability_state LIKE 'Down-%')::int AS under_maintenance,
             count(*) FILTER (WHERE v.current_availability_state = 'Off Hire/Suspended')::int AS off_hire,
             count(*) FILTER (WHERE v.usage_is_stale)::int AS stale_telematics
      FROM master.vehicle v WHERE ${where} AND v.lifecycle_status = 'Active'`, params),

    // PM obligations — FR-DASH-001
    many<any>(pool, `
      SELECT o.status, count(*)::int AS n
      FROM pm.pm_obligation o JOIN master.vehicle v ON v.vehicle_id = o.vehicle_id
      WHERE ${where} AND o.status IN ('Upcoming','Due Soon','Due','Overdue','Scheduled','Under Service')
      GROUP BY 1`, params),

    many<any>(pool, `
      SELECT jc.status, count(*)::int AS n
      FROM service.job_card jc JOIN master.vehicle v ON v.vehicle_id = jc.vehicle_id
      WHERE ${where} AND jc.status NOT IN ('Closed','Cancelled')
      GROUP BY 1`, params),

    many<any>(pool, `
      SELECT be.breakdown_id, be.priority, be.mobility, be.complaint_text, be.reported_utc,
             be.disposition, se.service_event_no, se.status, v.vin, v.registration_no,
             org.name AS customer_name,
             EXTRACT(EPOCH FROM (now() - be.reported_utc))/3600.0 AS age_hours
      FROM service.breakdown_event be
      JOIN service.service_event se ON se.service_event_id = be.service_event_id
      JOIN master.vehicle v ON v.vehicle_id = be.vehicle_id
      JOIN org.organisation org ON org.organisation_id = v.organisation_id
      WHERE ${where} AND se.status NOT IN ('Closed','Cancelled')
      ORDER BY CASE be.priority WHEN 'P1' THEN 1 WHEN 'P2' THEN 2 ELSE 3 END, be.reported_utc
      LIMIT 20`, params),

    many<any>(pool, `
      SELECT n.* FROM service.notification n
      LEFT JOIN master.vehicle v ON v.vehicle_id = n.vehicle_id
      WHERE n.status = 'New' AND (n.vehicle_id IS NULL OR (${where}))
      ORDER BY CASE n.severity WHEN 'Critical' THEN 1 WHEN 'Warning' THEN 2 ELSE 3 END,
               n.created_at DESC
      LIMIT 12`, params),

    many<any>(pool, `
      SELECT a.appointment_id, a.appointment_no, a.slot_start, a.service_type, a.status,
             v.vin, v.registration_no, org.name AS customer_name, sc.name AS service_centre_name
      FROM schedule.appointment a
      JOIN master.vehicle v ON v.vehicle_id = a.vehicle_id
      JOIN org.organisation org ON org.organisation_id = v.organisation_id
      JOIN master.service_centre sc ON sc.service_centre_id = a.service_centre_id
      WHERE ${where} AND a.slot_start::date = CURRENT_DATE
        AND a.status NOT IN ('Cancelled')
      ORDER BY a.slot_start LIMIT 12`, params),

    one<any>(pool, `
      SELECT count(*)::int AS n FROM service.sla_breach b
      JOIN service.service_event se ON se.service_event_id = b.service_event_id
      JOIN master.vehicle v ON v.vehicle_id = se.vehicle_id
      WHERE ${where} AND b.status = 'Breached'`, params),
  ]);

  const pm = Object.fromEntries(pmCounts.map(r => [r.status, Number(r.n)]));
  const jobs = Object.fromEntries(jobCounts.map(r => [r.status, Number(r.n)]));

  // Bay load for today at the user's primary centre.
  const centreId = centreFilter ? Number(centreFilter)
    : (ctx.user!.serviceCentreIds[0] ?? null);
  const bayLoad = centreId ? await many<any>(pool, `
    SELECT b.bay_code,
      COALESCE((SELECT SUM(a.estimated_minutes) FROM schedule.appointment a
                 WHERE a.bay_id = b.bay_id AND a.slot_start::date = CURRENT_DATE
                   AND a.status NOT IN ('Cancelled','No Show')),0)::int AS booked_minutes,
      480 AS capacity_minutes
    FROM schedule.service_bay b
    WHERE b.service_centre_id = $1 AND b.status = 'Active' ORDER BY b.bay_code`, [centreId]) : [];

  const totalPmObligations = Object.values(pm).reduce((a: number, b) => a + Number(b), 0);
  const overdue = Number(pm['Overdue'] ?? 0);
  const compliancePct = totalPmObligations
    ? Number((((totalPmObligations - overdue) / totalPmObligations) * 100).toFixed(1)) : null;

  return {
    fleet: {
      total: Number(fleet?.total ?? 0),
      inService: Number(fleet?.in_service ?? 0),
      underMaintenance: Number(fleet?.under_maintenance ?? 0),
      offHire: Number(fleet?.off_hire ?? 0),
      staleTelematics: Number(fleet?.stale_telematics ?? 0),
    },
    pm: {
      upcoming: Number(pm['Upcoming'] ?? 0),
      dueSoon: Number(pm['Due Soon'] ?? 0),
      due: Number(pm['Due'] ?? 0),
      overdue,
      scheduled: Number(pm['Scheduled'] ?? 0),
      underService: Number(pm['Under Service'] ?? 0),
      totalOpen: totalPmObligations,
      compliancePct,
    },
    jobs: {
      open: Object.entries(jobs).reduce((a, [, v]) => a + Number(v), 0),
      underDiagnosis: Number(jobs['Under Diagnosis'] ?? 0),
      repairing: Number(jobs['Repairing'] ?? 0),
      awaitingParts: Number(jobs['Awaiting Parts'] ?? 0),
      awaitingApproval: Number(jobs['Awaiting Customer Approval'] ?? 0),
      qcPending: Number(jobs['QC Pending'] ?? 0),
      technicianComplete: Number(jobs['Technician Complete'] ?? 0),
      byStatus: jobs,
    },
    breakdowns: {
      open: breakdowns.length,
      p1: breakdowns.filter(b => b.priority === 'P1').length,
      immobilized: breakdowns.filter(b => b.mobility === 'Immobilized').length,
      rows: breakdowns.map(b => ({ ...b, ageHours: Number(Number(b.age_hours).toFixed(1)) })),
    },
    slaBreaches: Number(slaBreaches?.n ?? 0),
    alerts,
    appointmentsToday: appointments,
    bayLoad: bayLoad.map(b => ({
      bayCode: b.bay_code, bookedMinutes: b.booked_minutes,
      utilisationPct: Math.round((b.booked_minutes / Math.max(1, b.capacity_minutes)) * 100),
    })),
  };
});

/** GET /api/v1/kpis?from=&to= — the Final KPI Dictionary figures. */
dash.get('/api/v1/kpis', async (ctx: Ctx) => {
  const scope = vehicleScopeClause(ctx.user!, 'v', 1);
  const to = ctx.query.get('to') ? new Date(ctx.query.get('to')!) : new Date();
  const from = ctx.query.get('from')
    ? new Date(ctx.query.get('from')!) : new Date(to.getTime() - 90 * 86_400_000);
  const centreId = ctx.query.get('serviceCentreId') ? Number(ctx.query.get('serviceCentreId')) : null;

  // PM compliance — BL-PM-025/026, from persisted obligation outcomes.
  const compliance = await one<any>(pool, `
    SELECT
      count(*) FILTER (WHERE o.target_date BETWEEN $${scope.params.length + 1}
                                             AND $${scope.params.length + 2}
                         AND o.exclusion_reason IS NULL)::int AS eligible,
      count(*) FILTER (WHERE o.outcome = 'Completed On Time')::int AS on_time,
      count(*) FILTER (WHERE o.outcome IN ('Completed On Time','Completed Within Tolerance'))::int AS within_tolerance,
      count(*) FILTER (WHERE o.outcome = 'Completed Late')::int AS late,
      count(*) FILTER (WHERE o.status = 'Overdue')::int AS still_overdue
    FROM pm.pm_obligation o
    JOIN master.vehicle v ON v.vehicle_id = o.vehicle_id
    WHERE ${scope.clause}
      AND o.target_date BETWEEN $${scope.params.length + 1} AND $${scope.params.length + 2}`,
    [...scope.params, from.toISOString().slice(0, 10), to.toISOString().slice(0, 10)]);

  const eligible = Number(compliance?.eligible ?? 0);

  // Workshop turnaround — gross and net of explicit pauses (BL-CLK-002).
  const turnaround = await one<any>(pool, `
    SELECT
      avg(EXTRACT(EPOCH FROM (jc.closed_utc - COALESCE(jc.accepted_utc, jc.opened_utc))))/3600.0 AS gross_hours,
      avg((EXTRACT(EPOCH FROM (jc.closed_utc - COALESCE(jc.accepted_utc, jc.opened_utc)))
           - COALESCE((SELECT SUM(EXTRACT(EPOCH FROM (COALESCE(cp.end_utc, jc.closed_utc) - cp.start_utc)))
                        FROM service.clock_pause cp
                        WHERE cp.job_card_id = jc.job_card_id AND cp.exclude_from_net),0))/3600.0) AS net_hours,
      count(*)::int AS n
    FROM service.job_card jc
    JOIN master.vehicle v ON v.vehicle_id = jc.vehicle_id
    WHERE ${scope.clause} AND jc.closed_utc BETWEEN $${scope.params.length + 1} AND $${scope.params.length + 2}
      AND ($${scope.params.length + 3}::bigint IS NULL OR jc.service_centre_id = $${scope.params.length + 3})`,
    [...scope.params, from, to, centreId]);

  // Fleet availability from the ledger (Doc 04 §29).
  const availability = await one<any>(pool, `
    SELECT
      SUM(EXTRACT(EPOCH FROM (LEAST(COALESCE(l.end_utc, $${scope.params.length + 2}::timestamptz),
                                    $${scope.params.length + 2}::timestamptz)
                            - GREATEST(l.start_utc, $${scope.params.length + 1}::timestamptz))))
        FILTER (WHERE r.is_down = false)::bigint AS up_seconds,
      SUM(EXTRACT(EPOCH FROM (LEAST(COALESCE(l.end_utc, $${scope.params.length + 2}::timestamptz),
                                    $${scope.params.length + 2}::timestamptz)
                            - GREATEST(l.start_utc, $${scope.params.length + 1}::timestamptz))))
        FILTER (WHERE r.is_down = true AND l.reason_code NOT IN ('OFF_HIRE','RETIRED'))::bigint AS down_seconds
    FROM uptime.vehicle_status_ledger l
    JOIN uptime.vehicle_status_reason r ON r.reason_code = l.reason_code
    JOIN master.vehicle v ON v.vehicle_id = l.vehicle_id
    WHERE ${scope.clause} AND l.availability_eligible
      AND l.start_utc < $${scope.params.length + 2}::timestamptz
      AND COALESCE(l.end_utc, $${scope.params.length + 2}::timestamptz) > $${scope.params.length + 1}::timestamptz`,
    [...scope.params, from, to]);

  const up = Number(availability?.up_seconds ?? 0);
  const down = Number(availability?.down_seconds ?? 0);

  // Downtime attribution (FR-AVL-004).
  const attribution = await many<any>(pool, `
    SELECT COALESCE(l.attribution_party,'Unattributed') AS party, r.category,
           SUM(EXTRACT(EPOCH FROM (LEAST(COALESCE(l.end_utc, $${scope.params.length + 2}::timestamptz),
                                         $${scope.params.length + 2}::timestamptz)
                                 - GREATEST(l.start_utc, $${scope.params.length + 1}::timestamptz))))/3600.0 AS hours
    FROM uptime.vehicle_status_ledger l
    JOIN uptime.vehicle_status_reason r ON r.reason_code = l.reason_code
    JOIN master.vehicle v ON v.vehicle_id = l.vehicle_id
    WHERE ${scope.clause} AND r.is_down AND l.availability_eligible
      AND l.reason_code NOT IN ('OFF_HIRE','RETIRED')
      AND l.start_utc < $${scope.params.length + 2}::timestamptz
      AND COALESCE(l.end_utc, $${scope.params.length + 2}::timestamptz) > $${scope.params.length + 1}::timestamptz
    GROUP BY 1,2 ORDER BY 3 DESC`, [...scope.params, from, to]);

  const [reliability, restore] = await Promise.all([
    reliabilityKpis(pool, from, to, centreId),
    mttr(pool, from, to),
  ]);

  // Top failure subsystems (Doc 01 §14 Top Failure Components).
  const topFailures = await many<any>(pool, `
    SELECT d.subsystem, count(*)::int AS n
    FROM service.defect d JOIN master.vehicle v ON v.vehicle_id = d.vehicle_id
    WHERE ${scope.clause} AND d.opened_date BETWEEN $${scope.params.length + 1}::date
                                              AND $${scope.params.length + 2}::date
      AND d.subsystem IS NOT NULL
    GROUP BY 1 ORDER BY 2 DESC LIMIT 8`,
    [...scope.params, from.toISOString().slice(0, 10), to.toISOString().slice(0, 10)]);

  return {
    period: { from, to },
    pmCompliance: {
      eligibleObligations: eligible,
      onTimePct: eligible ? Number(((Number(compliance.on_time) / eligible) * 100).toFixed(1)) : null,
      withinTolerancePct: eligible
        ? Number(((Number(compliance.within_tolerance) / eligible) * 100).toFixed(1)) : null,
      completedLate: Number(compliance?.late ?? 0),
      carriedOverOverdue: Number(compliance?.still_overdue ?? 0),
      definition: 'BL-PM-025/026 — obligations due in period, counted once; ' +
                  'authorised off-hire excluded; carried-over overdue reported separately.',
    },
    availability: {
      upHours: Number((up / 3600).toFixed(1)),
      downHours: Number((down / 3600).toFixed(1)),
      availabilityPct: (up + down) ? Number(((up / (up + down)) * 100).toFixed(2)) : null,
      attribution: attribution.map(a => ({
        party: a.party, category: a.category, hours: Number(Number(a.hours).toFixed(1)),
      })),
      source: 'uptime.vehicle_status_ledger (Doc 04 §29)',
    },
    turnaround: {
      sampleSize: Number(turnaround?.n ?? 0),
      grossHours: turnaround?.gross_hours != null ? Number(Number(turnaround.gross_hours).toFixed(1)) : null,
      netHours: turnaround?.net_hours != null ? Number(Number(turnaround.net_hours).toFixed(1)) : null,
    },
    restore,
    reliability,
    topFailures,
  };
});

/** GET /api/v1/notifications */
dash.get('/api/v1/notifications', async (ctx: Ctx) => {
  const scope = vehicleScopeClause(ctx.user!, 'v', 1);
  return many(pool, `
    SELECT n.*, v.vin FROM service.notification n
    LEFT JOIN master.vehicle v ON v.vehicle_id = n.vehicle_id
    WHERE n.status = 'New' AND (n.vehicle_id IS NULL OR (${scope.clause}))
    ORDER BY n.created_at DESC LIMIT 100`, scope.params);
});

dash.post('/api/v1/notifications/:id/acknowledge', async (ctx: Ctx) => {
  return one(pool, `
    UPDATE service.notification SET status = 'Acknowledged', acknowledged_at = now()
    WHERE notification_id = $1 RETURNING *`, [Number(ctx.params.id)]);
});

/** GET /api/v1/reference — masters the UI needs for dropdowns. */
dash.get('/api/v1/reference', async (ctx: Ctx) => {
  const [centres, categories, variants, failureCodes, reasons, slas] = await Promise.all([
    many(pool, `SELECT service_centre_id, code, name, centre_type, city, capabilities
                FROM master.service_centre WHERE status = 'Active' ORDER BY name`),
    many(pool, `SELECT category_id, code, name FROM master.vehicle_category ORDER BY name`),
    many(pool, `
      SELECT vv.variant_id, vv.code, vv.name, vv.confirmation_status,
             vm.name AS model_name, pf.name AS family_name, cat.code AS category_code
      FROM master.vehicle_variant vv
      JOIN master.vehicle_model vm ON vm.model_id = vv.model_id
      JOIN master.product_family pf ON pf.family_id = vm.family_id
      JOIN master.vehicle_category cat ON cat.category_id = pf.category_id
      WHERE vv.status = 'Active' ORDER BY cat.code, vm.name, vv.name`),
    many(pool, `SELECT code, code_type, description, subsystem FROM master.failure_code
                WHERE status = 'Active' ORDER BY code_type, code`),
    many(pool, `SELECT reason_code, availability_state, category, is_down, planned_class
                FROM uptime.vehicle_status_reason WHERE status = 'Active' ORDER BY source_precedence DESC`),
    many(pool, `SELECT sla_id, code, service_type, priority, response_minutes, restore_minutes
                FROM service.sla_master WHERE status = 'Active'`),
  ]);
  return { serviceCentres: centres, categories, variants, failureCodes,
           availabilityReasons: reasons, slas };
});

/** GET /api/v1/configuration/readiness — CFG-003 publication gate report. */
dash.get('/api/v1/configuration/readiness', async (ctx: Ctx) => {
  const placeholders = await many(pool, `
    SELECT vm.code AS model_code, vm.name AS model_name, vm.confirmation_status,
           vv.code AS variant_code, vv.name AS variant_name, vv.confirmation_status AS variant_status,
           (SELECT count(*) FROM master.vehicle v WHERE v.variant_id = vv.variant_id)::int AS vehicles
    FROM master.vehicle_model vm
    LEFT JOIN master.vehicle_variant vv ON vv.model_id = vm.model_id
    WHERE vm.confirmation_status = 'Placeholder' OR vv.confirmation_status = 'Placeholder'
    ORDER BY vm.code`);

  const blocked = await many(pool, `
    SELECT 'PM Plan' AS config_type, p.code AS config_code, pv.approval_status,
           vm.code AS model_code, vm.confirmation_status
    FROM pm.pm_plan_version pv
    JOIN pm.pm_plan p ON p.plan_id = pv.plan_id
    LEFT JOIN master.vehicle_variant vv ON vv.variant_id = pv.variant_id
    LEFT JOIN master.vehicle_model vm ON vm.model_id = COALESCE(pv.model_id, vv.model_id)
    WHERE vm.confirmation_status = 'Placeholder' AND pv.approval_status <> 'Published'`);

  return {
    rule: 'BL-CFG-002 / CFG-002 — configuration may be authored against a Placeholder model ' +
          'but cannot be published until the model and variant are Confirmed.',
    placeholderModels: placeholders,
    blockedConfiguration: blocked,
  };
});

/** GET /api/v1/audit?entityType=&entityId= */
dash.get('/api/v1/audit', async (ctx: Ctx) => {
  const entityType = ctx.query.get('entityType');
  const entityId = ctx.query.get('entityId');
  const params: unknown[] = [];
  const where: string[] = ['TRUE'];
  if (entityType) { params.push(entityType); where.push(`entity_type = $${params.length}`); }
  if (entityId) { params.push(Number(entityId)); where.push(`entity_id = $${params.length}`); }
  const limit = Math.min(Number(ctx.query.get('limit') ?? 100), 500);
  params.push(limit);
  return many(pool, `
    SELECT * FROM audit.audit_event WHERE ${where.join(' AND ')}
    ORDER BY occurred_at DESC LIMIT $${params.length}`, params);
});

/** GET /api/v1/integration/health — Doc 03 §16 operations console. */
dash.get('/api/v1/integration/health', async (ctx: Ctx) => {
  const [connectors, errors, recent, stale] = await Promise.all([
    many(pool, `SELECT * FROM integration.connector_health`),
    many(pool, `
      SELECT * FROM integration.integration_error WHERE status IN ('Open','Retrying')
      ORDER BY created_at DESC LIMIT 50`),
    many(pool, `
      SELECT t.vin, t.odometer_km, t.source_timestamp_utc, t.accepted, t.rejection_reason, t.received_at
      FROM integration.telematics_transaction t ORDER BY t.received_at DESC LIMIT 25`),
    one<any>(pool, `
      SELECT count(*)::int AS n FROM master.vehicle WHERE usage_is_stale = true`),
  ]);
  return { connectors, openErrors: errors, recentTelematics: recent,
           staleVehicles: Number(stale?.n ?? 0) };
});

// ---------------------------------------------------------------------
// Telematics ingestion — machine-to-machine, separate auth
// ---------------------------------------------------------------------

export const integrationRoutes = new Router();

/**
 * POST /api/v1/integrations/telematics/events
 * Accepts one event or a batch. Authenticated with a shared API key so the
 * telematics platform does not need a user session.
 */
integrationRoutes.post('/api/v1/integrations/telematics/events', async (ctx: Ctx) => {
  const key = ctx.req.headers['x-api-key'];
  const expected = process.env.TELEMATICS_API_KEY ?? 'montra-telematics-dev-key';
  if (key !== expected) {
    ctx.res.writeHead(401, { 'Content-Type': 'application/json' });
    ctx.res.end(JSON.stringify({ error: { code: 'UNAUTHENTICATED', message: 'Invalid API key.' } }));
    return;
  }

  const events = Array.isArray(ctx.body) ? ctx.body : [ctx.body];
  if (!events.length) throw badRequest('No events supplied.');

  const results = [];
  for (const ev of events) {
    if (!ev?.externalMessageId || !ev?.vin || !ev?.sourceTimestampUtc) {
      results.push({ externalMessageId: ev?.externalMessageId ?? null,
                     result: 'quarantined',
                     reason: 'externalMessageId, vin and sourceTimestampUtc are required' });
      continue;
    }
    const r = await ingestTelematics(pool, ev);
    results.push({ externalMessageId: ev.externalMessageId, ...r });
  }

  return {
    accepted: results.filter(r => r.result === 'accepted').length,
    duplicates: results.filter(r => r.result === 'duplicate').length,
    quarantined: results.filter(r => r.result === 'quarantined').length,
    results,
  };
});

/** POST /api/v1/integrations/telematics/mark-stale — worker hook. */
integrationRoutes.post('/api/v1/integrations/telematics/mark-stale', async (ctx: Ctx) => {
  const n = await markStaleFeeds(pool);
  return { markedStale: n };
});
