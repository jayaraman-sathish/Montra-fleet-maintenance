import { api } from '../api.js';
import { h, pill, table, fmtNum, fmtDateTime, fmtTime, ago, durationHrs, cardOf } from '../ui.js';
import { setPageTitle, state } from '../app.js';

export async function dashboardView() {
  setPageTitle('Dashboard', `${state.user.displayName} — ${new Date().toLocaleDateString('en-GB',
    { weekday: 'long', day: '2-digit', month: 'short', year: 'numeric' })}`);

  const d = await api.get('/api/v1/dashboard');

  const tile = (label, value, note, icon, cls, href) => h('div', {
    class: 'tile', onclick: () => { if (href) location.hash = href; },
  },
    h('div', { class: `tico ${cls}` }, icon),
    h('div', { class: 'tbody' },
      h('div', { class: 'tlabel' }, label),
      h('div', { class: 'tvalue' }, fmtNum(value)),
      note ? h('div', { class: 'tnote' }, note) : null));

  const row1 = h('div', { class: 'grid g4' },
    tile('Total Vehicles', d.fleet.total,
      `${fmtNum(d.fleet.inService)} in service`, '🚚', 'i-blue', '#/vehicles'),
    tile('Under Maintenance', d.fleet.underMaintenance,
      d.fleet.total ? `${((d.fleet.underMaintenance / d.fleet.total) * 100).toFixed(0)}% of fleet` : '',
      '🛠', 'i-amber', '#/job-cards'),
    tile('PM Overdue', d.pm.overdue,
      `${fmtNum(d.pm.due)} due · ${fmtNum(d.pm.dueSoon)} due soon`, '⏰', 'i-red', '#/pm'),
    tile('Off Hire / Suspended', d.fleet.offHire, 'Excluded from availability', '⏸', 'i-purple', '#/vehicles'));

  const row2 = h('div', { class: 'grid g4', style: 'margin-top:14px' },
    tile("Today's Appointments", d.appointmentsToday.length,
      `${fmtNum(d.jobs.open)} jobs in progress`, '📆', 'i-blue', '#/appointments'),
    tile('Breakdown Requests', d.breakdowns.open,
      `${fmtNum(d.breakdowns.p1)} P1 · ${fmtNum(d.breakdowns.immobilized)} immobilised`, '⚠', 'i-red', '#/breakdowns'),
    tile('Waiting for Parts', d.jobs.awaitingParts, 'Blocked jobs', '📦', 'i-amber', '#/job-cards'),
    tile('QC Pending', d.jobs.qcPending, 'Awaiting release', '✓', 'i-purple', '#/qc'));

  // --- Bay load ---
  const bayCard = cardOf('Service Centre Load (Today)',
    h('div', { class: 'card-body' },
      d.bayLoad.length
        ? d.bayLoad.map(b => h('div', { style: 'display:grid;grid-template-columns:60px 1fr 46px;gap:10px;align-items:center;margin-bottom:11px' },
            h('div', { class: 'small' }, b.bayCode),
            h('div', { class: 'bar' }, h('span', {
              style: `width:${Math.min(100, b.utilisationPct)}%;background:${
                b.utilisationPct > 85 ? 'var(--red)' : b.utilisationPct > 60 ? 'var(--amber)' : 'var(--blue)'}`,
            })),
            h('div', { class: 'small', style: 'text-align:right' }, `${b.utilisationPct}%`)))
        : h('div', { class: 'muted small' }, 'No bays configured for your service centre.')));

  // --- Alerts ---
  const alertIcon = (sev) => sev === 'Critical' ? '🔴' : sev === 'Warning' ? '🟠' : '🔵';
  const alertsCard = cardOf('Recent Alerts',
    d.alerts.length
      ? h('div', {}, d.alerts.slice(0, 6).map(a => h('div', { class: 'alert' },
          h('span', { class: 'aico' }, alertIcon(a.severity)),
          h('div', { style: 'flex:1;min-width:0' },
            h('div', {}, a.title),
            a.body ? h('div', { class: 'small muted' }, a.body) : null),
          h('div', { class: 'small muted', style: 'white-space:nowrap' }, ago(a.created_at)))))
      : h('div', { class: 'empty' }, 'No open alerts.'));

  // --- Vehicle status summary ---
  const statusCard = cardOf('Vehicle Status',
    h('div', { class: 'card-body' },
      [['In Service', d.fleet.inService, 'var(--green)'],
       ['Under Maintenance', d.fleet.underMaintenance, 'var(--amber)'],
       ['Off Hire / Suspended', d.fleet.offHire, 'var(--purple)']]
        .map(([label, n, colour]) => h('div', { style: 'display:flex;align-items:center;gap:10px;margin-bottom:10px' },
          h('span', { style: `width:9px;height:9px;border-radius:50%;background:${colour};flex:none` }),
          h('div', { style: 'flex:1' }, label),
          h('b', {}, fmtNum(n)),
          h('span', { class: 'small muted', style: 'width:44px;text-align:right' },
            d.fleet.total ? `${((n / d.fleet.total) * 100).toFixed(0)}%` : '—'))),
      h('div', { style: 'border-top:1px solid var(--line-2);margin-top:10px;padding-top:10px;display:flex' },
        h('div', { style: 'flex:1' }, 'Total'), h('b', {}, fmtNum(d.fleet.total))),
      d.fleet.staleTelematics
        ? h('div', { class: 'small', style: 'margin-top:10px;color:var(--amber)' },
            `⚠ ${d.fleet.staleTelematics} vehicle(s) have stale telematics — PM status shown as estimated.`)
        : null));

  // --- Appointments today ---
  const apptCard = cardOf('Upcoming Appointments',
    table([
      { label: 'Time', render: r => fmtTime(r.slot_start) },
      { label: 'Vehicle', render: r => h('a', { href: `#/vehicles/${r.vin}` }, r.registration_no || r.vin) },
      { label: 'Customer', key: 'customer_name' },
      { label: 'Service Type', key: 'service_type' },
      { label: 'Status', render: r => pill(r.status) },
    ], d.appointmentsToday, { empty: 'No appointments scheduled for today.' }),
    h('a', { href: '#/appointments', class: 'small' }, 'View all'));

  // --- Breakdown queue ---
  const bdCard = cardOf('Breakdown Requests',
    table([
      { label: 'Reported', render: r => fmtTime(r.reported_utc) },
      { label: 'Vehicle', render: r => h('a', { href: `#/vehicles/${r.vin}` }, r.registration_no || r.vin) },
      { label: 'Priority', render: r => pill(r.priority) },
      { label: 'Ageing', render: r => durationHrs(r.ageHours) },
      { label: 'Status', render: r => pill(r.status) },
    ], d.breakdowns.rows.slice(0, 6), { empty: 'No open breakdowns.' }),
    h('a', { href: '#/breakdowns', class: 'small' }, 'View all'));

  // --- PM compliance ---
  const pmCard = cardOf('PM Compliance',
    h('div', { class: 'card-body' },
      h('div', { style: 'text-align:center;margin-bottom:14px' },
        h('div', { style: 'font-size:34px;font-weight:700;letter-spacing:-1px' },
          d.pm.compliancePct !== null ? `${d.pm.compliancePct}%` : '—'),
        h('div', { class: 'small muted' }, 'of open obligations within threshold')),
      [['Upcoming', d.pm.upcoming, 'p-grey'],
       ['Due Soon', d.pm.dueSoon, 'p-amber'],
       ['Due', d.pm.due, 'p-amber'],
       ['Overdue', d.pm.overdue, 'p-red'],
       ['Scheduled', d.pm.scheduled, 'p-blue'],
       ['Under Service', d.pm.underService, 'p-blue']]
        .map(([label, n, cls]) => h('div', { style: 'display:flex;align-items:center;gap:9px;margin-bottom:7px' },
          pill(label, cls), h('div', { style: 'flex:1' }), h('b', {}, fmtNum(n)))),
      h('div', { style: 'border-top:1px solid var(--line-2);margin-top:8px;padding-top:9px;display:flex' },
        h('div', { style: 'flex:1' }, 'Total open obligations'), h('b', {}, fmtNum(d.pm.totalOpen))),
      d.slaBreaches
        ? h('div', { class: 'small', style: 'margin-top:10px;color:var(--red)' },
            `⚠ ${d.slaBreaches} open SLA breach(es).`)
        : null));

  return h('div', {},
    row1, row2,
    h('div', { class: 'grid g3', style: 'margin-top:14px' }, bayCard, alertsCard, statusCard),
    h('div', { class: 'grid g3', style: 'margin-top:14px' }, apptCard, bdCard, pmCard));
}
