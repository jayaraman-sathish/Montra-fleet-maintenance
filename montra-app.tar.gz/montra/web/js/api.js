/** Thin API client. Carries the session token and surfaces server error text. */

const BASE = '';
let token = null;
try { token = localStorage.getItem('montra_token'); } catch { /* private mode */ }

export function setToken(t) {
  token = t;
  try { t ? localStorage.setItem('montra_token', t) : localStorage.removeItem('montra_token'); } catch {}
}
export function getToken() { return token; }

export class ApiError extends Error {
  constructor(status, payload) {
    const e = payload?.error ?? {};
    super(e.message || `Request failed (${status})`);
    this.name = 'ApiError';
    this.status = status;
    this.code = e.code;
    this.details = e.details;
    this.correlationId = e.correlationId;
  }
}

async function request(method, path, body) {
  const headers = { 'Accept': 'application/json' };
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res = await fetch(BASE + path, {
    method, headers,
    body: body === undefined ? undefined : JSON.stringify(body),
  });

  let payload = null;
  const text = await res.text();
  if (text) { try { payload = JSON.parse(text); } catch { payload = { raw: text }; } }

  if (!res.ok) {
    if (res.status === 401) {
      setToken(null);
      if (!location.hash.startsWith('#/login')) location.hash = '#/login';
    }
    throw new ApiError(res.status, payload);
  }
  return payload;
}

export const api = {
  get:   (p)    => request('GET', p),
  post:  (p, b) => request('POST', p, b ?? {}),
  patch: (p, b) => request('PATCH', p, b ?? {}),
  del:   (p)    => request('DELETE', p),
};

export function qs(params) {
  const u = new URLSearchParams();
  for (const [k, v] of Object.entries(params ?? {})) {
    if (v !== undefined && v !== null && v !== '') u.set(k, v);
  }
  const s = u.toString();
  return s ? `?${s}` : '';
}
