import { api, qs } from '../api.js';
import {
  h, pill, table, fmtNum, fmtDate, fmtTime, fmtDateTime, cardOf, field, select,
  modal, toast, showApiError,
} from '../ui.js';
import { setPageTitle, reference, can } from '../app.js';

export async function appointmentsView({ params }) {
  setPageTitle('Appointments & Capacity', 'Bay, shift and technician capacity (FR-APT-001, CAP-001)');

  const ref = await reference();
  const centres = ref.serviceCentres.filter(c => c.centre_type !== 'Mobile');
  const wrap = h('div', {});

  const centreSel = select(centres.map(c => ({ value: c.service_centre_id, label: c.name })),
    params.get('serviceCentreId') ?? centres[0]?.service_centre_id);
  const dateInput = h('input', { type: 'date', value: params.get('date') ?? new Date().toISOString().slice(0, 10) });

  const capacityPanel = h('div', {});
  const listPanel = h('div', { style: 'margin-top:14px' });

  async function load() {
    capacityPanel.replaceChildren(h('div', { class: 'spin' }, 'Loading capacity…'));
    const [cap, appts] = await Promise.all([
      api.get(`/api/v1/service-centres/${centreSel.value}/capacity?date=${dateInput.value}`),
      api.get('/api/v1/appointments' + qs({ serviceCentreId: centreSel.value, date: dateInput.value })),
    ]);

    const bayCard = cardOf('Bay utilisation', h('div', { class: 'card-body' },
      cap.isWorkingDay ? null : h('div', { class: 'banner banner-amber' },
        h('span', {}, '⚠'),
        h('div', {}, 'This service centre is closed on the selected date under its business calendar. ',
          h('span', { class: 'small' }, 'Booking requires an authorised override (CAP-001).'))),
      cap.bays.map(b => h('div', {
        style: 'display:grid;grid-template-columns:80px 1fr 110px;gap:11px;align-items:center;margin-bottom:11px',
      },
        h('div', { class: 'small' }, b.bayCode),
        h('div', { class: 'bar' }, h('span', {
          style: `width:${Math.min(100, b.utilisationPct)}%;background:${
            b.utilisationPct > 85 ? 'var(--red)' : b.utilisationPct > 60 ? 'var(--amber)' : 'var(--blue)'}`,
        })),
        h('div', { class: 'small', style: 'text-align:right' },
          `${Math.round(b.bookedMinutes / 60 * 10) / 10}h / ${Math.round(b.capacityMinutes / 60)}h`)))));

    const techCard = cardOf('Technician load',
      table([
        { label: 'Technician', key: 'name' },
        { label: 'Code', render: r => h('span', { class: 'mono small' }, r.employee_code) },
        { label: 'Skills', render: r => h('div', { style: 'display:flex;gap:4px;flex-wrap:wrap' },
            (r.skills ?? []).map(s => h('span', { class: 'pill p-grey', style: 'font-size:10px' }, s))) },
        { label: 'Booked', num: true, render: r => `${Math.round(r.booked_minutes / 60 * 10) / 10} h` },
        { label: 'Available', render: r => r.is_available ? pill('Yes', 'p-green') : pill('No', 'p-red') },
      ], cap.technicians, { empty: 'No technicians rostered.' }));

    capacityPanel.replaceChildren(h('div', { class: 'grid g2' }, bayCard, techCard));

    listPanel.replaceChildren(cardOf(
      `Appointments — ${fmtDate(dateInput.value)}`,
      table([
        { label: 'Time', render: r => h('div', {},
            h('div', {}, fmtTime(r.slot_start)),
            h('div', { class: 'small muted' }, `${r.estimated_minutes} min`)) },
        { label: 'Appointment', render: r => h('span', { class: 'mono small' }, r.appointment_no) },
        { label: 'Vehicle', render: r => h('a', { href: `#/vehicles/${r.vin}` }, r.registration_no || r.vin) },
        { label: 'Customer', key: 'customer_name' },
        { label: 'Service type', key: 'service_type' },
        { label: 'Bay', key: 'bay_code' },
        { label: 'Technician', key: 'technician_name' },
        { label: 'Status', render: r => pill(r.status) },
        { label: '', render: r => ['Scheduled', 'Confirmed'].includes(r.status)
            ? h('div', { style: 'display:flex;gap:5px' },
                h('button', {
                  class: 'btn btn-sm',
                  onclick: () => reasonModal('Record no-show', 'No-show reason',
                    `/api/v1/appointments/${r.appointment_id}/no-show`, load,
                    'The PM obligation returns to the due queue and is not closed (FR-APT-003).'),
                }, 'No show'),
                h('button', {
                  class: 'btn btn-sm',
                  onclick: () => reasonModal('Cancel appointment', 'Cancellation reason',
                    `/api/v1/appointments/${r.appointment_id}/cancel`, load),
                }, 'Cancel'))
            : '—' },
      ], appts, { empty: 'No appointments booked for this date.' })));
  }

  centreSel.addEventListener('change', load);
  dateInput.addEventListener('change', load);

  wrap.appendChild(h('div', { class: 'filters' },
    field('Service centre', centreSel), field('Date', dateInput),
    h('button', { class: 'btn', onclick: () => {
      dateInput.value = new Date().toISOString().slice(0, 10); load();
    } }, 'Today'),
    h('div', { class: 'spacer' }),
    can('appointment.book')
      ? h('button', { class: 'btn btn-primary', onclick: () => newAppointmentModal(ref, load) },
          '+ New appointment')
      : null));
  wrap.appendChild(capacityPanel);
  wrap.appendChild(listPanel);

  await load();
  return wrap;
}

function reasonModal(title, label, url, onDone, note) {
  const input = h('textarea', { placeholder: 'Reason…' });
  modal({
    title,
    body: h('div', {},
      note ? h('div', { class: 'banner banner-blue' }, h('div', { class: 'small' }, note)) : null,
      field(label, input, { required: true })),
    actions: [
      { label: 'Cancel', onClick: () => true },
      { label: 'Confirm', class: 'btn-primary', onClick: async () => {
          if (!input.value.trim()) { toast('A reason is required.', 'err'); return false; }
          try {
            await api.post(url, { reason: input.value.trim() });
            toast('Recorded.', 'ok'); onDone?.(); return true;
          } catch (e) { showApiError(e); return false; }
        } },
    ],
  });
}

async function newAppointmentModal(ref, onDone) {
  const vinInput = h('input', { type: 'text', placeholder: 'VIN or registration' });
  const found = h('div', { class: 'small muted' });
  let vehicle = null;
  let obligations = [];

  const obSel = select([{ value: '', label: 'No specific PM obligation' }], '');
  const centreSel = select(ref.serviceCentres.filter(c => c.centre_type !== 'Mobile')
    .map(c => ({ value: c.service_centre_id, label: c.name })), '');
  const typeSel = select(['Preventive Maintenance', 'General Service', 'Breakdown', 'Inspection', 'Campaign'], 'Preventive Maintenance');
  const dateInput = h('input', { type: 'date', value: new Date(Date.now() + 86400000).toISOString().slice(0, 10) });
  const timeSel = select(['08:00', '09:00', '10:00', '11:00', '12:00', '14:00', '15:00', '16:00'], '09:00');
  const minutes = h('input', { type: 'number', value: 240, min: 30, step: 15 });
  const notes = h('textarea', {});

  async function lookup() {
    const q = vinInput.value.trim();
    if (!q) return;
    try {
      const r = await api.get('/api/v1/vehicles' + qs({ search: q, limit: 5 }));
      if (!r.rows.length) { found.textContent = 'No vehicle matched.'; vehicle = null; return; }
      vehicle = r.rows[0];
      found.textContent = `${vehicle.registration_no ?? ''} — ${vehicle.model_name} ${vehicle.variant_name} (${vehicle.customer_name})`;
      centreSel.value = vehicle.service_centre_id ?? '';
      const v360 = await api.get(`/api/v1/vehicles/${encodeURIComponent(vehicle.vin)}/360`);
      obligations = v360.openObligations ?? [];
      obSel.replaceChildren(
        h('option', { value: '' }, 'No specific PM obligation'),
        ...obligations.map(o => h('option', { value: o.pm_obligation_id },
          `${o.pm_level} cycle ${o.cycle_no} — ${o.status}`)));
    } catch (e) { showApiError(e); }
  }
  vinInput.addEventListener('change', lookup);
  vinInput.addEventListener('blur', lookup);

  modal({
    title: 'New appointment',
    body: h('div', {},
      field('Vehicle', vinInput, { required: true }), found,
      field('PM obligation', obSel),
      field('Service centre', centreSel, { required: true }),
      field('Service type', typeSel, { required: true }),
      h('div', { class: 'grid g2' }, field('Date', dateInput), field('Start time', timeSel)),
      field('Estimated duration (minutes)', minutes),
      field('Notes', notes)),
    actions: [
      { label: 'Cancel', onClick: () => true },
      { label: 'Book', class: 'btn-primary', onClick: async () => {
          if (!vehicle) { toast('Select a vehicle first.', 'err'); return false; }
          try {
            await api.post('/api/v1/appointments', {
              vin: vehicle.vin,
              pmObligationId: obSel.value ? Number(obSel.value) : null,
              serviceCentreId: Number(centreSel.value),
              serviceType: typeSel.value,
              slotStart: new Date(`${dateInput.value}T${timeSel.value}:00`).toISOString(),
              estimatedMinutes: Number(minutes.value),
              requestNotes: notes.value.trim() || null,
            });
            toast('Appointment booked.', 'ok'); onDone?.(); return true;
          } catch (e) { showApiError(e); return false; }
        } },
    ],
  });
}
