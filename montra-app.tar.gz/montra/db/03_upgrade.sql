-- =====================================================================
-- 03_upgrade.sql — idempotent forward migration.
--
-- Applied on EVERY start, after 01/02 have established the baseline.
-- Every statement must be safe to run repeatedly against a database that
-- already contains production data: additive only, IF NOT EXISTS guards,
-- no destructive DDL.
--
-- Purpose of this revision: the vehicle master file (Document 01 §Vehicle
-- 360) presents component specification, condition and inspection data,
-- and a live telematics panel. The baseline schema recorded fitment but
-- not the specification or condition attributes behind it.
-- =====================================================================

-- --- Serialised component specification & condition (Doc 1.1 §21) -----

ALTER TABLE master.vehicle_component
    ADD COLUMN IF NOT EXISTS specification        JSONB,
    ADD COLUMN IF NOT EXISTS health_status        TEXT,
    ADD COLUMN IF NOT EXISTS last_inspection_date DATE,
    ADD COLUMN IF NOT EXISTS next_inspection_date DATE,
    ADD COLUMN IF NOT EXISTS fault_count          INT NOT NULL DEFAULT 0,
    ADD COLUMN IF NOT EXISTS operating_hours      NUMERIC(12,2),
    ADD COLUMN IF NOT EXISTS position_label       TEXT,
    ADD COLUMN IF NOT EXISTS image_url            TEXT;

-- Specification is held as an ordered [{label, value}] list so the detail
-- panel shows engineering order rather than JSON key order. Rows written by
-- the first revision hold a plain object; clear them so the backfill rewrites
-- them in the ordered form. Idempotent: once converted the type is 'array'.
UPDATE master.vehicle_component
   SET specification = NULL
 WHERE specification IS NOT NULL
   AND jsonb_typeof(specification) = 'object';

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM pg_constraint WHERE conname = 'ck_component_health_status'
    ) THEN
        ALTER TABLE master.vehicle_component
            ADD CONSTRAINT ck_component_health_status
            CHECK (health_status IS NULL
                   OR health_status IN ('Good','Monitor','Degraded','Faulty'));
    END IF;
END $$;

-- --- Component type catalogue: the specification template per type ----
-- Specification is a property of the component TYPE; the fitment row
-- carries the as-built values. Keeping the catalogue separate means a new
-- component type is reference data, not a code change.

CREATE TABLE IF NOT EXISTS master.component_type (
    component_type    TEXT PRIMARY KEY,
    display_name      TEXT NOT NULL,
    category          TEXT NOT NULL,
    is_serialised     BOOLEAN NOT NULL DEFAULT true,
    is_hv             BOOLEAN NOT NULL DEFAULT false,
    inspection_months INT,
    spec_template     JSONB NOT NULL DEFAULT '{}'::jsonb,
    display_order     INT NOT NULL DEFAULT 100
);

-- --- Document classification (FR-DOC-001) ----------------------------

ALTER TABLE campaign.vehicle_document
    ADD COLUMN IF NOT EXISTS document_category TEXT,
    ADD COLUMN IF NOT EXISTS uploaded_on       DATE,
    ADD COLUMN IF NOT EXISTS uploaded_by       TEXT;

UPDATE campaign.vehicle_document
   SET document_category = CASE
         WHEN document_type IN ('RC','Insurance','PUC','Fitness','Permit','Tax',
                                'Emission Compliance') THEN 'Statutory'
         WHEN document_type IN ('AMC Contract','Warranty Certificate')   THEN 'Commercial'
         WHEN document_type IN ('Service Manual','Wiring Diagram')       THEN 'Technical'
         ELSE 'Other' END
 WHERE document_category IS NULL;

UPDATE campaign.vehicle_document
   SET uploaded_on = COALESCE(issue_date, CURRENT_DATE)
 WHERE uploaded_on IS NULL;

-- --- Reference data for the component catalogue ----------------------

INSERT INTO master.component_type
    (component_type, display_name, category, is_hv, inspection_months, spec_template, display_order)
VALUES
 ('BatteryPack','Battery Pack','Powertrain',true,6,
  '{"Nominal Capacity":"","Nominal Voltage":"","Chemistry":"","Cooling Type":"","Module Count":""}',10),
 ('TractionMotor','Traction Motor','Powertrain',true,12,
  '{"Rated Power":"","Peak Power":"","Rated Speed":"","Cooling Type":"","Insulation Class":""}',20),
 ('MotorController','Motor Controller','Powertrain',true,12,
  '{"Rated Power":"","Input Voltage":"","Cooling Type":"","Firmware Version":"","Hardware Revision":""}',30),
 ('DCDCConverter','DC-DC Converter','Electrical',true,12,
  '{"Input Voltage":"","Output Voltage":"","Rated Output":"","Cooling Type":""}',40),
 ('OnBoardCharger','On-board Charger','Electrical',true,12,
  '{"Rated Power":"","Input":"","Output Voltage":"","Protection Class":""}',50),
 ('HVJunctionBox','HV Battery Junction Box','Electrical',true,6,
  '{"Rated Current":"","Voltage Class":"","Protection Class":""}',60),
 ('AirCompressor','Air Compressor','Chassis',false,12,
  '{"Free Air Delivery":"","Working Pressure":"","Drive Type":""}',70),
 ('BrakeSystem','Brake System (EBS)','Chassis',false,6,
  '{"System Type":"","Channels":"","Regenerative Blending":""}',80),
 ('Tyre','Tyre','Chassis',false,3,
  '{"Size":"","Load Index":"","Speed Rating":"","Pattern":""}',90)
ON CONFLICT (component_type) DO NOTHING;
