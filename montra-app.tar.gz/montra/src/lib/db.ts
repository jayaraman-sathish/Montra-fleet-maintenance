/**
 * Database access singleton and query helpers.
 */

import { Pool, configFromEnv } from './pgclient.ts';
import type { Connection, QueryResult } from './pgclient.ts';

export const pool = new Pool(configFromEnv(), Number(process.env.DB_POOL_MAX ?? 8));

export type Db = Pool | Connection;

/** Run a query against the pool or an open transaction. */
export async function q<T = Record<string, any>>(
  db: Db, sql: string, params: unknown[] = [],
): Promise<QueryResult<T>> {
  return db.query<T>(sql, params);
}

/** First row or null. */
export async function one<T = Record<string, any>>(
  db: Db, sql: string, params: unknown[] = [],
): Promise<T | null> {
  const r = await db.query<T>(sql, params);
  return r.rows[0] ?? null;
}

/** All rows. */
export async function many<T = Record<string, any>>(
  db: Db, sql: string, params: unknown[] = [],
): Promise<T[]> {
  const r = await db.query<T>(sql, params);
  return r.rows;
}

/** First column of the first row. */
export async function scalar<T = unknown>(
  db: Db, sql: string, params: unknown[] = [],
): Promise<T | null> {
  const r = await db.query(sql, params);
  if (!r.rows.length) return null;
  return Object.values(r.rows[0])[0] as T;
}

/**
 * Generate a human-readable document number, e.g. SE-2026-001234.
 * Uses a per-prefix sequence table so numbers are gapless and unique.
 */
export async function nextDocumentNo(db: Db, prefix: string, width = 6): Promise<string> {
  const year = new Date().getFullYear();
  const key = `${prefix}-${year}`;
  await q(db, `
    INSERT INTO public.document_sequence (sequence_key, last_value)
    VALUES ($1, 0) ON CONFLICT (sequence_key) DO NOTHING`, [key]);
  const n = await scalar<number>(db, `
    UPDATE public.document_sequence SET last_value = last_value + 1
    WHERE sequence_key = $1 RETURNING last_value`, [key]);
  return `${prefix}-${year}-${String(n).padStart(width, '0')}`;
}

/** Append an immutable audit record (FR-AUD-001, BL-SEC-004). */
export async function audit(db: Db, e: {
  entityType: string; entityId?: number | null; action: string;
  actor: string; actorRole?: string | null; actorScope?: string | null;
  before?: unknown; after?: unknown; reason?: string | null; correlationId?: string | null;
}): Promise<void> {
  await q(db, `
    INSERT INTO audit.audit_event
      (entity_type, entity_id, action, actor, actor_role, actor_scope,
       before_value, after_value, reason, correlation_id)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
    [e.entityType, e.entityId ?? null, e.action, e.actor, e.actorRole ?? null, e.actorScope ?? null,
     e.before ? JSON.stringify(e.before) : null,
     e.after ? JSON.stringify(e.after) : null,
     e.reason ?? null, e.correlationId ?? null]);
}

/** Append a status transition record (BL-JC-003, audit.status_history). */
export async function recordStatus(db: Db, e: {
  entityType: string; entityId: number; from?: string | null; to: string;
  actor: string; reason?: string | null; ruleId?: string | null;
}): Promise<void> {
  await q(db, `
    INSERT INTO audit.status_history (entity_type, entity_id, from_status, to_status, actor, reason, rule_id)
    VALUES ($1,$2,$3,$4,$5,$6,$7)`,
    [e.entityType, e.entityId, e.from ?? null, e.to, e.actor, e.reason ?? null, e.ruleId ?? null]);
}

/** Raise an operational notification (BL-ALR-001..009). */
export async function notify(db: Db, n: {
  alertType: string; severity?: 'Critical' | 'Warning' | 'Info'; title: string; body?: string;
  entityType?: string; entityId?: number; vehicleId?: number | null; serviceCentreId?: number | null;
}): Promise<void> {
  await q(db, `
    INSERT INTO service.notification
      (alert_type, severity, title, body, entity_type, entity_id, vehicle_id, service_centre_id)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
    [n.alertType, n.severity ?? 'Info', n.title, n.body ?? null,
     n.entityType ?? null, n.entityId ?? null, n.vehicleId ?? null, n.serviceCentreId ?? null]);
}
