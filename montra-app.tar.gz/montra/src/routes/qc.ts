/**
 * QC, release and concession endpoints.
 * QC-001..003, BL-QC-001..008, BL-CON-001.
 */

import { Router, notFound, badRequest, conflict, forbidden } from '../lib/http.ts';
import type { Ctx } from '../lib/http.ts';
import { pool, one, many, q, audit } from '../lib/db.ts';
import { authenticate, assertAuthorised, assertPermission } from '../lib/auth.ts';
import { evaluateReleaseGate, releaseVehicle, createConcession } from '../domain/qc.ts';

export const qcRoutes = new Router();
qcRoutes.use(authenticate);

/** GET /api/v1/job-cards/:id/release-gate — why the vehicle is or isn't releasable. */
qcRoutes.get('/api/v1/job-cards/:id/release-gate', async (ctx: Ctx) => {
  return evaluateReleaseGate(pool, Number(ctx.params.id));
});

/** GET /api/v1/job-cards/:id/qc-checklist */
qcRoutes.get('/api/v1/job-cards/:id/qc-checklist', async (ctx: Ctx) => {
  const jc = await one<any>(pool, `
    SELECT jc.job_card_id, se.event_type FROM service.job_card jc
    JOIN service.service_event se ON se.service_event_id = jc.service_event_id
    WHERE jc.job_card_id = $1`, [Number(ctx.params.id)]);
  if (!jc) throw notFound('Job card not found.');

  const code = jc.event_type === 'PM' ? 'QC-PM-STD' : 'QC-BD-STD';
  const items = await many<any>(pool, `
    SELECT qi.qc_item_id, qi.code, qi.description, qi.is_mandatory, qi.display_order,
           qr.qc_result_id, qr.result, qr.remarks, qr.checked_at, u.display_name AS checked_by
    FROM quality.qc_checklist qc
    JOIN quality.qc_checklist_item qi ON qi.qc_checklist_id = qc.qc_checklist_id
    LEFT JOIN quality.qc_result qr ON qr.qc_item_id = qi.qc_item_id AND qr.job_card_id = $1
    LEFT JOIN security.application_user u ON u.user_id = qr.checked_by_user_id
    WHERE qc.code = $2 ORDER BY qi.display_order`, [Number(ctx.params.id), code]);

  return { checklistCode: code, items };
});

/** POST /api/v1/job-cards/:id/qc — record QC results. */
qcRoutes.post('/api/v1/job-cards/:id/qc', async (ctx: Ctx) => {
  assertPermission(ctx.user!, 'qc.perform');
  const results = Array.isArray(ctx.body) ? ctx.body : ctx.body?.results;
  if (!Array.isArray(results) || !results.length) throw badRequest('Provide an array of QC results.');

  const jobCardId = Number(ctx.params.id);
  for (const r of results) {
    if (!r.qcItemId || !r.result) continue;
    await q(pool, `
      INSERT INTO quality.qc_result (job_card_id, qc_item_id, result, remarks, checked_by_user_id)
      VALUES ($1,$2,$3,$4,$5)
      ON CONFLICT (job_card_id, qc_item_id) DO UPDATE
        SET result = EXCLUDED.result, remarks = EXCLUDED.remarks,
            checked_by_user_id = EXCLUDED.checked_by_user_id, checked_at = now()`,
      [jobCardId, Number(r.qcItemId), r.result, r.remarks ?? null, ctx.user!.userId]);
  }

  await audit(pool, {
    entityType: 'JobCard', entityId: jobCardId, action: 'QC_RECORD',
    actor: ctx.user!.username, after: { results: results.length },
  });

  return evaluateReleaseGate(pool, jobCardId);
});

/** POST /api/v1/job-cards/:id/release — the release gate (BL-QC-002..008). */
qcRoutes.post('/api/v1/job-cards/:id/release', async (ctx: Ctx) => {
  await assertAuthorised(pool, ctx.user!, 'qc.release');
  const { releaseType, concessionId, roadTestDone, odometerAtRelease, remarks } = ctx.body ?? {};

  if (releaseType === 'Remote QC') await assertAuthorised(pool, ctx.user!, 'qc.remote');

  try {
    return await releaseVehicle(pool, {
      jobCardId: Number(ctx.params.id),
      releasedByUserId: ctx.user!.userId,
      actor: ctx.user!.username,
      releaseType, concessionId: concessionId ?? null,
      roadTestDone, odometerAtRelease, remarks,
    });
  } catch (e: any) {
    if (e.code === 'RELEASE_BLOCKED') {
      throw conflict(e.message, { ruleId: 'BL-QC-002/003', blockers: e.blockers });
    }
    if (e.code === 'SEGREGATION_OF_DUTIES') {
      throw forbidden(e.message, { ruleId: 'BL-QC-006' });
    }
    throw e;
  }
});

/** POST /api/v1/concessions — authorised release deviation (BL-QC-007). */
qcRoutes.post('/api/v1/concessions', async (ctx: Ctx) => {
  await assertAuthorised(pool, ctx.user!, 'concession.approve');
  const { vin, defectId, jobCardId, reason, expiryDate, expiryKm, followUpAction, ownerRole, evidenceRef } =
    ctx.body ?? {};
  if (!vin || !reason || !followUpAction) {
    throw badRequest('Vehicle, reason and follow-up action are required for a concession.');
  }
  const v = await one<any>(pool, `SELECT vehicle_id FROM master.vehicle WHERE vin = $1`, [vin]);
  if (!v) throw notFound('Vehicle not found.');

  try {
    return await createConcession(pool, {
      vehicleId: v.vehicle_id, defectId, jobCardId, reason,
      approver: ctx.user!.username, expiryDate, expiryKm,
      followUpAction, ownerRole: ownerRole ?? 'Service Centre Manager', evidenceRef,
    });
  } catch (e: any) {
    if (e.code === 'CONCESSION_EXPIRY_REQUIRED') throw badRequest(e.message, { ruleId: 'BL-CON-001' });
    throw e;
  }
});

/** GET /api/v1/concessions */
qcRoutes.get('/api/v1/concessions', async (ctx: Ctx) => {
  return many(pool, `
    SELECT c.*, v.vin, v.registration_no, v.current_odometer_km, d.defect_no,
           CASE WHEN (c.expiry_date IS NOT NULL AND c.expiry_date < CURRENT_DATE)
                  OR (c.expiry_km IS NOT NULL AND v.current_odometer_km > c.expiry_km)
                THEN true ELSE false END AS is_expired
    FROM quality.concession c
    JOIN master.vehicle v ON v.vehicle_id = c.vehicle_id
    LEFT JOIN service.defect d ON d.defect_id = c.defect_id
    WHERE c.status = 'Active'
    ORDER BY c.approved_on DESC LIMIT 200`);
});

/** GET /api/v1/releases — release register. */
qcRoutes.get('/api/v1/releases', async (ctx: Ctx) => {
  return many(pool, `
    SELECT r.*, v.vin, v.registration_no, jc.job_card_no, se.service_event_no, se.event_type,
           u.display_name AS released_by
    FROM quality.vehicle_release r
    JOIN master.vehicle v ON v.vehicle_id = r.vehicle_id
    JOIN service.job_card jc ON jc.job_card_id = r.job_card_id
    JOIN service.service_event se ON se.service_event_id = r.service_event_id
    JOIN security.application_user u ON u.user_id = r.released_by_user_id
    ORDER BY r.released_at DESC LIMIT 100`);
});
