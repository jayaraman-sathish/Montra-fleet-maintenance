import { api, qs } from '../api.js';
import {
  h, pill, table, fmtNum, fmtDateTime, ago, durationHrs, cardOf, field, select,
  modal, toast, showApiError,
} from '../ui.js';
import { setPageTitle, reference, can } from '../app.js';

export async function breakdownsView() {
  setPageTitle('Breakdowns (RSA)', 'Intake, triage and dispatch — P1 immobilised vehicles first');

  const ref = await reference();
  const wrap = h('div', {});
  const results = h('div', {});

  async function load() {
    results.replaceChildren(h('div', { class: 'spin' }));
    const d = await api.get('/api/v1/dashboard');
    const rows = d.breakdowns.rows;

    const tiles = h('div', { class: 'grid g4', style: 'margin-bottom:14px' },
      tile('Open breakdowns', d.breakdowns.open, 'i-red', '⚠'),
      tile('P1 — highest priority', d.breakdowns.p1, 'i-red', '🚨'),
      tile('Immobilised', d.breakdowns.immobilized, 'i-amber', '⛔'),
      tile('SLA breaches', d.slaBreaches, 'i-purple', '⏱'));

    results.replaceChildren(tiles, cardOf('Breakdown queue',
      table([
        { label: 'Reported', render: r => h('div', {},
            h('div', {}, fmtDateTime(r.reported_utc)),
            h('div', { class: 'small muted' }, ago(r.reported_utc))) },
        { label: 'Event', render: r => h('span', { class: 'mono small' }, r.service_event_no) },
        { label: 'Vehicle', render: r => h('div', {},
            h('a', { href: `#/vehicles/${r.vin}` }, r.registration_no || r.vin),
            h('div', { class: 'small muted' }, r.customer_name)) },
        { label: 'Complaint', render: r => h('div', { style: 'max-width:300px' }, r.complaint_text) },
        { label: 'Mobility', render: r => pill(r.mobility,
            r.mobility === 'Immobilized' ? 'p-red' : r.mobility === 'Limited movement' ? 'p-amber' : 'p-grey') },
        { label: 'Priority', render: r => pill(r.priority) },
        { label: 'Ageing', render: r => h('span', {
            style: r.ageHours > 24 ? 'color:var(--red);font-weight:600' : '' }, durationHrs(r.ageHours)) },
        { label: 'Disposition', key: 'disposition' },
        { label: 'Status', render: r => pill(r.status) },
        { label: '', render: r => can('breakdown.triage')
            ? h('button', { class: 'btn btn-sm btn-primary',
                onclick: () => triageModal(r, ref, load) }, 'Triage')
            : '—' },
      ], rows, { empty: 'No open breakdowns.' })));
  }

  function tile(label, n, cls, icon) {
    return h('div', { class: 'tile' },
      h('div', { class: `tico ${cls}` }, icon),
      h('div', { class: 'tbody' },
        h('div', { class: 'tlabel' }, label),
        h('div', { class: 'tvalue' }, fmtNum(n))));
  }

  wrap.appendChild(h('div', { class: 'filters' },
    h('div', { class: 'spacer' }),
    can('breakdown.create')
      ? h('button', { class: 'btn btn-primary', onclick: () => intakeModal(ref, load) },
          '+ Log breakdown (RSA)')
      : null));
  wrap.appendChild(results);
  await load();
  return wrap;
}

/** Breakdown intake — FR-BD-001/002. Priority derives from mobility (BL-BD-002..004). */
function intakeModal(ref, onDone) {
  const vinInput = h('input', { type: 'text', placeholder: 'VIN or registration number' });
  const found = h('div', { class: 'small muted' });
  let vehicle = null;

  const reportedBy = select(['Driver (Customer)', 'Fleet Manager', 'Service Coordinator',
    'Telematics Alert', 'Service Centre'], 'Driver (Customer)');
  const phone = h('input', { type: 'text', placeholder: '+91…' });
  const location = h('input', { type: 'text', placeholder: 'Where is the vehicle?' });
  const mobility = select(['Can move', 'Limited movement', 'Immobilized'], 'Can move');
  const complaintSel = h('select', {});
  const complaintText = h('textarea', { placeholder: 'What is the driver reporting?' });
  const warning = h('input', { type: 'text', placeholder: 'Warning lamp or alert shown' });
  const dtc = h('input', { type: 'text', placeholder: 'DTC summary, if available' });
  const priorityNote = h('div', { class: 'banner banner-blue' });

  complaintSel.replaceChildren(h('option', { value: '' }, 'Select complaint code…'),
    ...ref.failureCodes.filter(f => f.code_type === 'Complaint')
      .map(f => h('option', { value: f.code }, `${f.code} — ${f.description}`)));

  function updatePriority() {
    const p = mobility.value === 'Immobilized' ? 'P1'
            : mobility.value === 'Limited movement' ? 'P2' : 'P3';
    priorityNote.replaceChildren(
      h('div', {},
        h('b', {}, `Priority will be set to ${p}. `),
        h('span', { class: 'small' },
          p === 'P1'
            ? 'Immobilised or safety-critical: immediate triage and escalation, and vehicle downtime ' +
              'starts from the actual stoppage time (BL-BD-002 / BL-AVL-003).'
            : p === 'P2'
            ? 'Critical but still operational: urgent technical assessment (BL-BD-003).'
            : 'Non-critical: may convert to scheduled service (BL-BD-004).')));
  }
  mobility.addEventListener('change', updatePriority);
  updatePriority();

  async function lookup() {
    const q = vinInput.value.trim();
    if (!q) return;
    try {
      const r = await api.get('/api/v1/vehicles' + qs({ search: q, limit: 5 }));
      if (!r.rows.length) { found.textContent = 'No vehicle matched.'; vehicle = null; return; }
      vehicle = r.rows[0];
      found.replaceChildren(
        h('span', {}, `${vehicle.registration_no ?? ''} — ${vehicle.model_name} ${vehicle.variant_name}`),
        h('span', { class: 'muted' }, ` · ${vehicle.customer_name} · ${vehicle.service_centre_name ?? ''}`));
    } catch (e) { showApiError(e); }
  }
  vinInput.addEventListener('change', lookup);
  vinInput.addEventListener('blur', lookup);

  modal({
    title: 'Log breakdown request',
    width: 680,
    body: h('div', {},
      field('Vehicle', vinInput, { required: true }), found,
      h('div', { class: 'grid g2' },
        field('Reported by', reportedBy, { required: true }),
        field('Contact number', phone)),
      field('Location', location, { required: true }),
      field('Vehicle mobility', mobility, { required: true }),
      priorityNote,
      field('Complaint code', complaintSel),
      field('Complaint description', complaintText, { required: true }),
      h('div', { class: 'grid g2' },
        field('Warning indicator', warning),
        field('DTC summary', dtc))),
    actions: [
      { label: 'Cancel', onClick: () => true },
      { label: 'Submit', class: 'btn-primary', onClick: async () => {
          if (!vehicle) { toast('Select a vehicle first.', 'err'); return false; }
          if (!complaintText.value.trim()) { toast('A complaint description is required.', 'err'); return false; }
          try {
            const r = await api.post('/api/v1/breakdowns', {
              vin: vehicle.vin,
              reportedBy: reportedBy.value,
              contactPhone: phone.value.trim() || null,
              locationText: location.value.trim() || null,
              mobility: mobility.value,
              complaintCode: complaintSel.value || null,
              complaintText: complaintText.value.trim(),
              warningIndicator: warning.value.trim() || null,
              dtcSummary: dtc.value.trim() || null,
              stoppedActualUtc: mobility.value === 'Immobilized' ? new Date().toISOString() : null,
            });
            toast(`Breakdown ${r.serviceEvent.service_event_no} logged.`, 'ok');
            onDone?.(); return true;
          } catch (e) { showApiError(e); return false; }
        } },
    ],
  });
}

/** Triage — FR-BD-006. Downgrading a P1 requires authorisation and a reason. */
async function triageModal(row, ref, onDone) {
  const bd = await api.get(`/api/v1/service-events/${await serviceEventIdFor(row)}`);
  const breakdown = bd.breakdown;

  const prioritySel = select(['P1', 'P2', 'P3'], breakdown.priority);
  const dispSel = select([{ value: '', label: 'Select disposition…' },
    { value: 'RemoteResolution', label: 'Remote resolution — no job card' },
    { value: 'MobileTechnician', label: 'Mobile technician (roadside job card)' },
    { value: 'ServiceCentre', label: 'Recover to service centre (workshop job card)' },
    { value: 'Towing', label: 'Towing / recovery' }], breakdown.disposition ?? '');
  const centreSel = select([{ value: '', label: 'Use assigned service centre' },
    ...ref.serviceCentres.map(c => ({ value: c.service_centre_id, label: c.name }))], '');
  const reason = h('textarea', { placeholder: 'Triage notes / reason for priority change' });
  const warn = h('div', {});

  function updateWarn() {
    warn.replaceChildren(
      breakdown.priority === 'P1' && prioritySel.value !== 'P1'
        ? h('div', { class: 'banner banner-amber' },
            h('span', {}, '⚠'),
            h('div', {},
              h('b', {}, 'Downgrading a P1 is a privileged action. '),
              h('span', { class: 'small' },
                'A reason is mandatory and the change is audited (BL-BD-002 / BL-BD-005).')))
        : null);
  }
  prioritySel.addEventListener('change', updateWarn);
  updateWarn();

  modal({
    title: `Triage ${bd.serviceEvent.service_event_no}`,
    width: 640,
    body: h('div', {},
      h('div', { class: 'card', style: 'margin-bottom:14px' },
        h('div', { class: 'card-body' },
          h('div', { class: 'kv' },
            h('div', {}, 'Vehicle'), h('div', {}, bd.serviceEvent.registration_no ?? bd.serviceEvent.vin),
            h('div', {}, 'Complaint'), h('div', {}, breakdown.complaint_text),
            h('div', {}, 'Mobility'), h('div', {}, pill(breakdown.mobility)),
            h('div', {}, 'Location'), h('div', {}, breakdown.location_text ?? '—'),
            h('div', {}, 'Reported'), h('div', {}, fmtDateTime(breakdown.reported_utc))))),
      field('Priority', prioritySel, { required: true }),
      warn,
      field('Disposition', dispSel, { required: true },
        ),
      field('Service centre', centreSel,
        { hint: 'Where physical intervention will happen. Remote resolution creates no job card.' }),
      field('Triage notes', reason)),
    actions: [
      { label: 'Cancel', onClick: () => true },
      { label: 'Apply triage', class: 'btn-primary', onClick: async () => {
          if (breakdown.priority === 'P1' && prioritySel.value !== 'P1' && !reason.value.trim()) {
            toast('A reason is required to downgrade a P1 breakdown.', 'err'); return false;
          }
          try {
            const r = await api.post(`/api/v1/breakdowns/${breakdown.breakdown_id}/triage`, {
              priority: prioritySel.value,
              disposition: dispSel.value || null,
              reason: reason.value.trim() || null,
              assignServiceCentreId: centreSel.value ? Number(centreSel.value) : null,
            });
            toast(r.jobCard ? `Job card ${r.jobCard.job_card_no} created.` : 'Triage recorded.', 'ok');
            onDone?.();
            if (r.jobCard) location.hash = `#/job-cards/${r.jobCard.job_card_id}`;
            return true;
          } catch (e) { showApiError(e); return false; }
        } },
    ],
  });
}

async function serviceEventIdFor(row) {
  const list = await api.get('/api/v1/service-events' + qs({ status: 'Open', eventType: 'Breakdown', limit: 200 }));
  const m = list.find(x => x.service_event_no === row.service_event_no);
  return m?.service_event_id;
}
