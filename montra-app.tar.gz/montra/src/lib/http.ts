/**
 * Minimal HTTP router built on node:http.
 *
 * Provides pattern routing, JSON body parsing, static file serving and a
 * consistent error envelope (Doc 04 §24: code, message, correlationId,
 * fieldErrors). No third-party web framework is available in this build
 * environment, so this file stands in for Express.
 */

import * as http from 'node:http';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { randomUUID } from 'node:crypto';

export interface Ctx {
  req: http.IncomingMessage;
  res: http.ServerResponse;
  params: Record<string, string>;
  query: URLSearchParams;
  body: any;
  correlationId: string;
  user?: AuthUser;
}

export interface AuthUser {
  userId: number;
  username: string;
  displayName: string;
  roles: string[];
  permissions: Set<string>;
  scopes: { scopeType: string; scopeNodeId: number | null }[];
  organisationIds: number[];
  serviceCentreIds: number[];
  isGlobal: boolean;
}

export type Handler = (ctx: Ctx) => Promise<unknown> | unknown;

export class HttpError extends Error {
  status: number;
  code: string;
  details?: unknown;
  constructor(status: number, code: string, message: string, details?: unknown) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

export const badRequest = (m: string, d?: unknown) => new HttpError(400, 'BAD_REQUEST', m, d);
export const unauthorized = (m = 'Authentication required.') => new HttpError(401, 'UNAUTHENTICATED', m);
export const forbidden = (m: string, d?: unknown) => new HttpError(403, 'FORBIDDEN', m, d);
export const notFound = (m = 'Not found.') => new HttpError(404, 'NOT_FOUND', m);
export const conflict = (m: string, d?: unknown) => new HttpError(409, 'CONFLICT', m, d);

interface Route {
  method: string;
  segments: string[];
  handler: Handler;
  middleware: Handler[];
}

export class Router {
  private routes: Route[] = [];
  private globalMiddleware: Handler[] = [];

  use(mw: Handler) { this.globalMiddleware.push(mw); return this; }

  add(method: string, pattern: string, handler: Handler, ...middleware: Handler[]) {
    this.routes.push({
      method,
      segments: pattern.split('/').filter(Boolean),
      handler,
      middleware,
    });
    return this;
  }

  get(p: string, h: Handler, ...m: Handler[]) { return this.add('GET', p, h, ...m); }
  post(p: string, h: Handler, ...m: Handler[]) { return this.add('POST', p, h, ...m); }
  patch(p: string, h: Handler, ...m: Handler[]) { return this.add('PATCH', p, h, ...m); }
  put(p: string, h: Handler, ...m: Handler[]) { return this.add('PUT', p, h, ...m); }
  delete(p: string, h: Handler, ...m: Handler[]) { return this.add('DELETE', p, h, ...m); }

  match(method: string, pathname: string): { route: Route; params: Record<string, string> } | null {
    const parts = pathname.split('/').filter(Boolean);
    for (const route of this.routes) {
      if (route.method !== method) continue;
      if (route.segments.length !== parts.length) continue;
      const params: Record<string, string> = {};
      let ok = true;
      for (let i = 0; i < route.segments.length; i++) {
        const seg = route.segments[i];
        if (seg.startsWith(':')) params[seg.slice(1)] = decodeURIComponent(parts[i]);
        else if (seg !== parts[i]) { ok = false; break; }
      }
      if (ok) return { route, params };
    }
    return null;
  }

  get allRoutes() {
    return this.routes.map(r => ({ method: r.method, path: '/' + r.segments.join('/') }));
  }

  async handle(ctx: Ctx, pathname: string): Promise<boolean> {
    const m = this.match(ctx.req.method ?? 'GET', pathname);
    if (!m) return false;
    ctx.params = m.params;
    for (const mw of [...this.globalMiddleware, ...m.route.middleware]) await mw(ctx);
    const result = await m.route.handler(ctx);
    if (result !== undefined && !ctx.res.writableEnded) sendJson(ctx.res, 200, result);
    else if (!ctx.res.writableEnded) ctx.res.end();
    return true;
  }
}

export function sendJson(res: http.ServerResponse, status: number, payload: unknown) {
  const body = JSON.stringify(payload, (_k, v) => (v instanceof Set ? [...v] : v));
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
  });
  res.end(body);
}

export async function readBody(req: http.IncomingMessage, limitBytes = 8 * 1024 * 1024): Promise<any> {
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const c of req) {
    size += (c as Buffer).length;
    if (size > limitBytes) throw badRequest('Request body too large.');
    chunks.push(c as Buffer);
  }
  if (!chunks.length) return undefined;
  const raw = Buffer.concat(chunks).toString('utf8');
  const type = req.headers['content-type'] ?? '';
  if (type.includes('application/json')) {
    try { return JSON.parse(raw); }
    catch { throw badRequest('Request body is not valid JSON.'); }
  }
  return raw;
}

const MIME: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.map': 'application/json',
};

/** Serve a static directory, falling back to index.html for client routes. */
export function serveStatic(root: string, urlPath: string, res: http.ServerResponse): boolean {
  const clean = urlPath.split('?')[0].replace(/\.\./g, '');
  let file = path.join(root, clean === '/' ? 'index.html' : clean);

  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) {
    const indexFile = path.join(root, 'index.html');
    if (!fs.existsSync(indexFile)) return false;
    file = indexFile;
  }
  if (!file.startsWith(root)) return false;

  const ext = path.extname(file).toLowerCase();
  const body = fs.readFileSync(file);
  res.writeHead(200, {
    'Content-Type': MIME[ext] ?? 'application/octet-stream',
    'Content-Length': body.length,
    'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=3600',
  });
  res.end(body);
  return true;
}

export function newCorrelationId(): string { return randomUUID(); }
