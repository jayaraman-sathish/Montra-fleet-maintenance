import { api, setToken } from '../api.js';
import { h, toast } from '../ui.js';

const DEMO_USERS = [
  ['ravi.kumar', 'Service Centre Manager'],
  ['kumar.s',    'Technician'],
  ['priya.n',    'QC Supervisor'],
  ['vijay.r',    'Service Coordinator'],
  ['meena.s',    'Parts / Stores'],
  ['fleet.abc',  'Fleet Customer (ABC Logistics)'],
  ['admin',      'System Administrator'],
];

export async function loginView() {
  const username = h('input', { type: 'text', id: 'u', value: 'ravi.kumar', autocomplete: 'username' });
  const password = h('input', { type: 'password', id: 'p', value: 'montra123', autocomplete: 'current-password' });
  const btn = h('button', { class: 'btn btn-primary', style: 'width:100%', type: 'submit' }, 'Sign in');
  const err = h('div', { class: 'small', style: 'color:var(--red);min-height:18px;margin-bottom:8px' });

  const submit = async (e) => {
    e?.preventDefault();
    err.textContent = '';
    btn.disabled = true; btn.textContent = 'Signing in…';
    try {
      const r = await api.post('/api/v1/auth/login', {
        username: username.value.trim(), password: password.value,
      });
      setToken(r.token);
      location.hash = '#/dashboard';
      location.reload();
    } catch (ex) {
      err.textContent = ex.message ?? 'Sign in failed.';
      btn.disabled = false; btn.textContent = 'Sign in';
    }
  };

  const form = h('form', { onsubmit: submit },
    h('div', { class: 'field' }, h('label', {}, 'Username'), username),
    h('div', { class: 'field' }, h('label', {}, 'Password'), password),
    err, btn);

  const demoRows = DEMO_USERS.map(([u, label]) => h('tr', {},
    h('td', {}, h('a', {
      onclick: () => { username.value = u; password.value = 'montra123'; submit(); },
    }, u)),
    h('td', { class: 'muted', style: 'text-align:right' }, label)));

  return h('div', { class: 'login-wrap' },
    h('div', { class: 'login-card' },
      h('div', { class: 'brand' },
        h('div', { class: 'brand-mark' }, 'A'),
        h('div', { class: 'brand-text' },
          h('b', { style: 'color:var(--ink)' }, 'AUDREE'),
          h('span', {}, 'Montra Fleet Maintenance'))),
      h('div', { style: 'text-align:center;margin-bottom:18px' },
        h('div', { style: 'font-weight:650;font-size:15px' }, 'Fleet Maintenance, Breakdown & Uptime'),
        h('div', { class: 'small muted' }, 'Sign in to continue')),
      form,
      h('div', { class: 'login-demo' },
        h('div', { style: 'margin-bottom:6px' }, 'Demo accounts — click to sign in (password ',
          h('span', { class: 'mono' }, 'montra123'), ')'),
        h('table', {}, h('tbody', {}, demoRows)))));
}
