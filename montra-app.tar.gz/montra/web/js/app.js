/** Application shell, navigation and hash router. */

import { api, setToken, getToken } from './api.js';
import { h, clear, spinner, toast, showApiError } from './ui.js';

import { loginView } from './views/login.js';
import { dashboardView } from './views/dashboard.js';
import { vehiclesView } from './views/vehicles.js';
import { vehicle360View } from './views/vehicle360.js';
import { pmView } from './views/pm.js';
import { appointmentsView } from './views/appointments.js';
import { serviceEventsView, jobCardsView, jobCardView } from './views/service.js';
import { breakdownsView } from './views/breakdowns.js';
import { qcView } from './views/qc.js';
import { reportsView } from './views/reports.js';
import { adminView } from './views/admin.js';

export const state = { user: null, reference: null };

const NAV = [
  { group: 'Operations' },
  { path: '/dashboard',    label: 'Dashboard',              icon: '▤' },
  { path: '/vehicles',     label: 'Vehicles',               icon: '🚚' },
  { path: '/pm',           label: 'Preventive Maintenance', icon: '🗓' },
  { path: '/appointments', label: 'Appointments',           icon: '📆' },
  { path: '/breakdowns',   label: 'Breakdowns (RSA)',       icon: '⚠' },
  { group: 'Workshop' },
  { path: '/service-events', label: 'Service Events',       icon: '🧾' },
  { path: '/job-cards',    label: 'Job Cards',              icon: '🛠' },
  { path: '/qc',           label: 'QC & Release',           icon: '✓' },
  { group: 'Insight' },
  { path: '/reports',      label: 'Reports & KPIs',         icon: '📊' },
  { path: '/admin',        label: 'Administration',         icon: '⚙' },
];

const ROUTES = [
  { re: /^\/dashboard$/,        view: dashboardView,     title: 'Dashboard' },
  { re: /^\/vehicles$/,         view: vehiclesView,      title: 'Vehicles' },
  { re: /^\/vehicles\/(.+)$/,   view: vehicle360View,    title: 'Vehicle Details' },
  { re: /^\/pm$/,               view: pmView,            title: 'Preventive Maintenance' },
  { re: /^\/appointments$/,     view: appointmentsView,  title: 'Appointments & Capacity' },
  { re: /^\/breakdowns$/,       view: breakdownsView,    title: 'Breakdowns (RSA)' },
  { re: /^\/service-events$/,   view: serviceEventsView, title: 'Service Events' },
  { re: /^\/job-cards$/,        view: jobCardsView,      title: 'Job Cards' },
  { re: /^\/job-cards\/(\d+)$/, view: jobCardView,       title: 'Job Card' },
  { re: /^\/qc$/,               view: qcView,            title: 'QC & Release' },
  { re: /^\/reports$/,          view: reportsView,       title: 'Reports & KPIs' },
  { re: /^\/admin$/,            view: adminView,         title: 'Administration' },
];

function currentPath() {
  const hash = location.hash.replace(/^#/, '');
  return hash || '/dashboard';
}

function buildShell() {
  const sidebar = h('aside', { class: 'sidebar', id: 'sidebar' },
    h('div', { class: 'brand' },
      h('div', { class: 'brand-mark' }, 'A'),
      h('div', { class: 'brand-text' },
        h('b', {}, 'AUDREE'),
        h('span', {}, 'Montra Fleet Maintenance'))),
    h('nav', { class: 'nav', id: 'nav' }),
    h('div', { class: 'sidebar-foot' },
      h('div', {}, 'Montra Fleet Maintenance'),
      h('div', { style: 'opacity:.7' }, 'Baseline v3.0')));

  const topbar = h('header', { class: 'topbar' },
    h('button', {
      class: 'btn btn-ghost btn-sm', style: 'display:none',
      id: 'menuBtn',
      onclick: () => document.getElementById('sidebar').classList.toggle('open'),
    }, '☰'),
    h('div', {}, h('h1', { id: 'pageTitle' }, ''), h('div', { class: 'sub', id: 'pageSub' }, '')),
    h('div', { class: 'spacer' }),
    h('div', { class: 'searchbox' },
      h('span', { class: 'muted' }, '🔍'),
      h('input', {
        type: 'text', placeholder: 'Search VIN, registration, job card…', id: 'globalSearch',
        onkeydown: (e) => {
          if (e.key === 'Enter' && e.target.value.trim()) {
            location.hash = `#/vehicles?search=${encodeURIComponent(e.target.value.trim())}`;
          }
        },
      })),
    h('div', { class: 'bell', id: 'bell', onclick: () => { location.hash = '#/dashboard'; } }, '🔔'),
    h('div', { class: 'userchip', id: 'userchip' }));

  const content = h('main', { class: 'content', id: 'content' });
  return h('div', { class: 'shell' }, sidebar, h('div', { class: 'main' }, topbar, content));
}

function renderNav(path) {
  const nav = clear(document.getElementById('nav'));
  for (const item of NAV) {
    if (item.group) { nav.appendChild(h('div', { class: 'nav-group' }, item.group)); continue; }
    const active = path === item.path || path.startsWith(item.path + '/');
    nav.appendChild(h('a', { href: `#${item.path}`, class: active ? 'active' : '' },
      h('span', { class: 'ico' }, item.icon), item.label));
  }
}

function renderUser() {
  const chip = clear(document.getElementById('userchip'));
  const u = state.user;
  if (!u) return;
  const initials = u.displayName.split(/\s+/).map(s => s[0]).slice(0, 2).join('').toUpperCase();
  chip.appendChild(h('div', { class: 'avatar' }, initials));
  chip.appendChild(h('div', { class: 'who' },
    h('b', {}, u.displayName),
    h('span', {}, roleLabel(u.roles[0]))));
  chip.appendChild(h('button', {
    class: 'btn btn-ghost btn-sm', title: 'Sign out',
    onclick: async () => { try { await api.post('/api/v1/auth/logout'); } catch {} setToken(null); state.user = null; location.hash = '#/login'; render(); },
  }, '⏻'));
}

export function roleLabel(code) {
  return ({
    FLEET_CUSTOMER: 'Fleet / Customer', SERVICE_COORD: 'Service Coordinator',
    SC_MANAGER: 'Service Centre Manager', TECHNICIAN: 'Technician', STORES: 'Parts / Stores',
    WARRANTY_USER: 'Warranty', QC_SUPERVISOR: 'QC Supervisor', ENGINEERING: 'Engineering / Quality',
    MASTER_DATA_ADMIN: 'System Administrator', MANAGEMENT: 'Management',
  })[code] ?? code ?? '';
}

export function setPageTitle(title, sub) {
  document.getElementById('pageTitle').textContent = title ?? '';
  document.getElementById('pageSub').textContent = sub ?? '';
}

export function can(action) {
  return !!state.user && (state.user.permissions || []).includes(action);
}
export function hasRole(...roles) {
  return !!state.user && roles.some(r => (state.user.roles || []).includes(r));
}

/** Load reference master data once per session (dropdown sources). */
export async function reference() {
  if (!state.reference) state.reference = await api.get('/api/v1/reference');
  return state.reference;
}

let shellBuilt = false;

export async function render() {
  const app = document.getElementById('app');
  const path = currentPath();

  // Unauthenticated
  if (!getToken()) {
    shellBuilt = false;
    clear(app).appendChild(await loginView());
    return;
  }

  if (!state.user) {
    try { state.user = await api.get('/api/v1/auth/me'); }
    catch { setToken(null); clear(app).appendChild(await loginView()); return; }
  }

  if (path === '/login') { location.hash = '#/dashboard'; return; }

  if (!shellBuilt) { clear(app).appendChild(buildShell()); shellBuilt = true; }
  renderNav(path.split('?')[0]);
  renderUser();

  const [pathname, query] = path.split('?');
  const params = new URLSearchParams(query ?? '');
  const content = clear(document.getElementById('content'));
  content.appendChild(spinner());

  const route = ROUTES.find(r => r.re.test(pathname));
  if (!route) {
    setPageTitle('Not found');
    clear(content).appendChild(h('div', { class: 'empty' }, `No screen matches ${pathname}.`));
    return;
  }

  const match = pathname.match(route.re);
  try {
    const node = await route.view({ params, match, path: pathname });
    clear(content).appendChild(node);
  } catch (err) {
    showApiError(err);
    clear(content).appendChild(h('div', { class: 'banner banner-red' },
      h('span', {}, '⚠'),
      h('div', {},
        h('b', {}, 'This screen could not be loaded. '),
        h('div', { class: 'small' }, err.message ?? String(err)),
        err.correlationId ? h('div', { class: 'small mono muted' }, `Reference: ${err.correlationId}`) : null)));
  }
}

/** Refresh the notification badge. */
async function refreshBell() {
  if (!getToken() || !state.user) return;
  try {
    const list = await api.get('/api/v1/notifications');
    const bell = document.getElementById('bell');
    if (!bell) return;
    clear(bell).appendChild(document.createTextNode('🔔'));
    const critical = list.filter(n => n.severity === 'Critical').length;
    if (list.length) {
      bell.appendChild(h('span', { class: 'count', style: critical ? '' : 'background:#d98324' },
        String(list.length)));
    }
  } catch { /* not fatal */ }
}

window.addEventListener('hashchange', render);
window.addEventListener('DOMContentLoaded', async () => {
  await render();
  refreshBell();
  setInterval(refreshBell, 60000);
});

// Already-parsed DOM (module executes after DOMContentLoaded in some cases)
if (document.readyState !== 'loading') {
  render().then(refreshBell);
}
