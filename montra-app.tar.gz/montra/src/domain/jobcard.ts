/**
 * Job card lifecycle and state machine.
 *
 * Implements Document 02 BL-JC-001..013 (canonical status set, controlled
 * transitions, immutability after closure, assignment history) and the
 * availability side-effects in BL-AVL-002..008.
 */

import { q, one, many, recordStatus, audit, notify, nextDocumentNo } from '../lib/db.ts';
import type { Db } from '../lib/db.ts';
import { transition, reasonForJobStatus } from './availability.ts';

/** BL-JC-011 canonical job card statuses. */
export const JOB_STATUSES = [
  'Open', 'Scheduled', 'Assigned', 'Under Diagnosis', 'Repairing', 'Awaiting Parts',
  'Awaiting Customer Approval', 'Awaiting Warranty Decision', 'Awaiting Internal Authorization',
  'Awaiting Insurance', 'Technician Complete', 'QC Pending', 'Completed', 'Closed',
  'On Hold', 'Transferred', 'Split', 'Reopened', 'Cancelled',
] as const;

export type JobStatus = typeof JOB_STATUSES[number];

const AWAITING: JobStatus[] = [
  'Awaiting Parts', 'Awaiting Customer Approval', 'Awaiting Warranty Decision',
  'Awaiting Internal Authorization', 'Awaiting Insurance',
];

/**
 * BL-JC-003: valid transitions only. Notably there is no path from Open
 * straight to Completed — execution and QC stages cannot be skipped.
 */
export const ALLOWED_TRANSITIONS: Record<JobStatus, JobStatus[]> = {
  'Open':            ['Scheduled', 'Assigned', 'Cancelled', 'On Hold'],
  'Scheduled':       ['Assigned', 'Cancelled', 'On Hold'],
  'Assigned':        ['Under Diagnosis', 'Repairing', 'On Hold', 'Transferred', 'Cancelled'],
  'Under Diagnosis': ['Repairing', ...AWAITING, 'Technician Complete', 'On Hold', 'Transferred', 'Cancelled'],
  'Repairing':       [...AWAITING, 'Technician Complete', 'Under Diagnosis', 'On Hold', 'Transferred', 'Split'],
  'Awaiting Parts':                     ['Repairing', 'Under Diagnosis', 'On Hold', 'Cancelled', 'Transferred'],
  'Awaiting Customer Approval':         ['Repairing', 'Under Diagnosis', 'On Hold', 'Cancelled'],
  'Awaiting Warranty Decision':         ['Repairing', 'Under Diagnosis', 'On Hold', 'Cancelled'],
  'Awaiting Internal Authorization':    ['Repairing', 'Under Diagnosis', 'On Hold', 'Cancelled'],
  'Awaiting Insurance':                 ['Repairing', 'Under Diagnosis', 'On Hold', 'Cancelled'],
  'Technician Complete': ['QC Pending', 'Repairing'],
  'QC Pending':      ['Completed', 'Repairing'],       // QC failure returns the job
  'Completed':       ['Closed'],
  'Closed':          ['Reopened'],                     // privileged, BL-JC-012
  'On Hold':         ['Assigned', 'Under Diagnosis', 'Repairing', 'Cancelled'],
  'Transferred':     [],
  'Split':           ['Repairing'],
  'Reopened':        ['Under Diagnosis', 'Repairing', 'Assigned'],
  'Cancelled':       [],
};

export class TransitionError extends Error {
  code = 'INVALID_TRANSITION';
  constructor(from: string, to: string) {
    super(`Job card cannot move from "${from}" to "${to}". ` +
          `Allowed from "${from}": ${(ALLOWED_TRANSITIONS[from as JobStatus] ?? []).join(', ') || 'none'} (BL-JC-003).`);
    this.name = 'TransitionError';
  }
}

export function canTransition(from: string, to: string): boolean {
  return (ALLOWED_TRANSITIONS[from as JobStatus] ?? []).includes(to as JobStatus);
}

/** Open a job card under an existing service event (FR-JC-001, FR-JC-009). */
export async function createJobCard(db: Db, input: {
  serviceEventId: number;
  vehicleId: number;
  serviceCentreId?: number | null;
  locationType?: 'Workshop' | 'Roadside' | 'Customer Site';
  jobType: string;
  bayId?: number | null;
  technicianId?: number | null;
  complaintText?: string | null;
  transferredFromJobCardId?: number | null;
  transferReason?: string | null;
  actor: string;
}): Promise<any> {
  const vehicle = await one<any>(db, `
    SELECT current_odometer_km, current_operating_hours FROM master.vehicle WHERE vehicle_id = $1`,
    [input.vehicleId]);

  const jobCardNo = await nextDocumentNo(db, 'JC', 5);

  const row = await one<any>(db, `
    INSERT INTO service.job_card
      (job_card_no, service_event_id, vehicle_id, service_centre_id, location_type, job_type,
       bay_id, technician_id, status, odometer_at_open, hours_at_open, complaint_text,
       transferred_from_job_card_id, transfer_reason, created_by)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
    RETURNING *`,
    [jobCardNo, input.serviceEventId, input.vehicleId, input.serviceCentreId ?? null,
     input.locationType ?? 'Workshop', input.jobType, input.bayId ?? null,
     input.technicianId ?? null, input.technicianId ? 'Assigned' : 'Open',
     vehicle?.current_odometer_km ?? null, vehicle?.current_operating_hours ?? null,
     input.complaintText ?? null, input.transferredFromJobCardId ?? null,
     input.transferReason ?? null, input.actor]);

  await recordStatus(db, {
    entityType: 'JobCard', entityId: row.job_card_id,
    from: null, to: row.status, actor: input.actor, ruleId: 'FR-JC-001',
  });
  await audit(db, {
    entityType: 'JobCard', entityId: row.job_card_id, action: 'CREATE',
    actor: input.actor, after: { jobCardNo, status: row.status },
  });

  return row;
}

/**
 * Move a job card to a new status, applying the controlled transition rules
 * and the availability-ledger side effects.
 */
export async function changeStatus(db: Db, input: {
  jobCardId: number;
  toStatus: JobStatus;
  actor: string;
  reason?: string | null;
  force?: boolean;          // privileged override, always audited
}): Promise<any> {
  const job = await one<any>(db, `
    SELECT * FROM service.job_card WHERE job_card_id = $1`, [input.jobCardId]);
  if (!job) throw new Error('Job card not found');

  if (job.status === input.toStatus) return job;

  // BL-JC-012: closed job cards are read-only to normal flows.
  if (job.status === 'Closed' && input.toStatus !== 'Reopened') {
    throw new TransitionError(job.status, input.toStatus);
  }

  if (!canTransition(job.status, input.toStatus)) {
    if (!input.force) throw new TransitionError(job.status, input.toStatus);
    await audit(db, {
      entityType: 'JobCard', entityId: input.jobCardId, action: 'FORCED_TRANSITION',
      actor: input.actor, reason: input.reason ?? 'forced',
      before: { status: job.status }, after: { status: input.toStatus },
    });
  }

  // Reasons are mandatory on exception paths.
  if (['Cancelled', 'Reopened', 'On Hold', 'Transferred'].includes(input.toStatus) && !input.reason) {
    const err: any = new Error(`A reason is required to move a job card to ${input.toStatus}.`);
    err.code = 'REASON_REQUIRED';
    throw err;
  }

  const now = new Date();
  const stamps: Record<string, string> = {
    'Assigned': 'accepted_utc',
    'Under Diagnosis': 'started_utc',
    'Repairing': 'started_utc',
    'Technician Complete': 'technician_complete_utc',
    'QC Pending': 'qc_utc',
    'Completed': 'released_utc',
    'Closed': 'closed_utc',
  };
  const stampCol = stamps[input.toStatus];

  const extra: string[] = [];
  const params: unknown[] = [input.toStatus, input.jobCardId];
  if (stampCol) extra.push(`${stampCol} = COALESCE(${stampCol}, now())`);
  if (input.toStatus === 'Cancelled') { extra.push(`cancel_reason = $3`); params.push(input.reason); }
  else if (input.toStatus === 'Reopened') { extra.push(`reopen_reason = $3`); params.push(input.reason); }

  const updated = await one<any>(db, `
    UPDATE service.job_card
    SET status = $1${extra.length ? ', ' + extra.join(', ') : ''}, row_version = row_version + 1
    WHERE job_card_id = $2
    RETURNING *`, params);

  await recordStatus(db, {
    entityType: 'JobCard', entityId: input.jobCardId,
    from: job.status, to: input.toStatus, actor: input.actor,
    reason: input.reason ?? null, ruleId: 'BL-JC-003',
  });

  // --- Availability side effects (BL-AVL-002..008) ---
  const avl = reasonForJobStatus(input.toStatus, job.job_type);
  if (avl) {
    await transition(db, {
      vehicleId: job.vehicle_id, reasonCode: avl.reasonCode, sourceType: 'JobCard',
      sourceEntityId: input.jobCardId, ruleId: avl.ruleId, actor: input.actor,
      reason: `Job ${job.job_card_no} → ${input.toStatus}`,
    });
  }

  // --- Structured clock pauses (BL-CLK-001: status alone never pauses a clock) ---
  if (AWAITING.includes(input.toStatus)) {
    const accountable = input.toStatus === 'Awaiting Parts' ? 'Supplier'
                      : input.toStatus === 'Awaiting Customer Approval' ? 'Customer' : 'Montra';
    await q(db, `
      INSERT INTO service.clock_pause
        (job_card_id, service_event_id, clock_type, pause_reason, start_utc, accountable_party, authorized_by)
      VALUES ($1,$2,'Turnaround',$3,$4,$5,$6)`,
      [input.jobCardId, job.service_event_id, input.toStatus, now, accountable, input.actor]);
  } else {
    await q(db, `
      UPDATE service.clock_pause SET end_utc = $1
      WHERE job_card_id = $2 AND end_utc IS NULL`, [now, input.jobCardId]);
  }

  // --- Notifications (BL-ALR-006/007/009) ---
  if (input.toStatus === 'Awaiting Parts') {
    await notify(db, { alertType: 'WAITING_PARTS', severity: 'Warning',
      title: `Job ${job.job_card_no} is waiting for parts`,
      entityType: 'JobCard', entityId: input.jobCardId,
      vehicleId: job.vehicle_id, serviceCentreId: job.service_centre_id });
  } else if (input.toStatus === 'QC Pending') {
    await notify(db, { alertType: 'QC_PENDING', severity: 'Info',
      title: `Job ${job.job_card_no} is awaiting QC`,
      entityType: 'JobCard', entityId: input.jobCardId,
      vehicleId: job.vehicle_id, serviceCentreId: job.service_centre_id });
  } else if (input.toStatus === 'Completed') {
    await notify(db, { alertType: 'READY_FOR_RELEASE', severity: 'Info',
      title: `Vehicle ready for release — job ${job.job_card_no}`,
      entityType: 'JobCard', entityId: input.jobCardId,
      vehicleId: job.vehicle_id, serviceCentreId: job.service_centre_id });
  }

  return updated;
}

/** BL-SVC-005 / BL-JC-013: reassignment preserves prior assignment history. */
export async function reassign(db: Db, input: {
  jobCardId: number; toTechnicianId?: number | null; toServiceCentreId?: number | null;
  reason: string; actor: string;
}): Promise<any> {
  const job = await one<any>(db, `SELECT * FROM service.job_card WHERE job_card_id = $1`, [input.jobCardId]);
  if (!job) throw new Error('Job card not found');

  // BL-SVC-007: HV work requires valid certification.
  if (input.toTechnicianId) {
    const ok = await checkTechnicianAuthorised(db, input.toTechnicianId, job.job_type);
    if (!ok.authorised) {
      const err: any = new Error(ok.message);
      err.code = 'TECHNICIAN_NOT_AUTHORISED';
      throw err;
    }
  }

  await q(db, `
    INSERT INTO service.assignment_history
      (job_card_id, from_technician_id, to_technician_id, from_service_centre_id,
       to_service_centre_id, reason, actor)
    VALUES ($1,$2,$3,$4,$5,$6,$7)`,
    [input.jobCardId, job.technician_id, input.toTechnicianId ?? job.technician_id,
     job.service_centre_id, input.toServiceCentreId ?? job.service_centre_id,
     input.reason, input.actor]);

  return one<any>(db, `
    UPDATE service.job_card
    SET technician_id = COALESCE($1, technician_id),
        service_centre_id = COALESCE($2, service_centre_id),
        row_version = row_version + 1
    WHERE job_card_id = $3 RETURNING *`,
    [input.toTechnicianId ?? null, input.toServiceCentreId ?? null, input.jobCardId]);
}

/** BL-SVC-002/003/007 technician skill and HV authorisation validation. */
export async function checkTechnicianAuthorised(
  db: Db, technicianId: number, jobType: string,
): Promise<{ authorised: boolean; message: string }> {
  const tech = await one<any>(db, `
    SELECT t.*, sc.name AS centre_name FROM master.technician t
    JOIN master.service_centre sc ON sc.service_centre_id = t.service_centre_id
    WHERE t.technician_id = $1`, [technicianId]);
  if (!tech) return { authorised: false, message: 'Technician not found.' };
  if (tech.status !== 'Active') {
    return { authorised: false, message: `${tech.name} is not active and cannot be assigned (BL-SVC-004).` };
  }

  // High-voltage work needs a valid, unexpired HV authorisation.
  const needsHv = ['PM', 'Breakdown', 'Warranty'].includes(jobType);
  if (needsHv) {
    const hv = await one<any>(db, `
      SELECT * FROM master.technician_skill
      WHERE technician_id = $1 AND skill_code = 'HV_BATTERY'
        AND valid_from <= CURRENT_DATE AND (valid_to IS NULL OR valid_to >= CURRENT_DATE)`,
      [technicianId]);
    if (!hv) {
      return {
        authorised: false,
        message: `${tech.name} has no valid high-voltage authorisation, which is required for ` +
                 `${jobType} work on an electric vehicle (BL-SVC-007).`,
      };
    }
  }
  return { authorised: true, message: 'Authorised.' };
}

/**
 * BL-JC-010: roadside-to-workshop handover creates a new linked job card under
 * the same service event. The original job keeps its own parts, labour and history.
 */
export async function transferToWorkshop(db: Db, input: {
  jobCardId: number; toServiceCentreId: number; reason: string; actor: string;
}): Promise<any> {
  const job = await one<any>(db, `SELECT * FROM service.job_card WHERE job_card_id = $1`, [input.jobCardId]);
  if (!job) throw new Error('Job card not found');

  await changeStatus(db, {
    jobCardId: input.jobCardId, toStatus: 'Transferred',
    actor: input.actor, reason: input.reason,
  });

  const next = await createJobCard(db, {
    serviceEventId: job.service_event_id,
    vehicleId: job.vehicle_id,
    serviceCentreId: input.toServiceCentreId,
    locationType: 'Workshop',
    jobType: job.job_type,
    complaintText: job.complaint_text,
    transferredFromJobCardId: input.jobCardId,
    transferReason: input.reason,
    actor: input.actor,
  });

  await audit(db, {
    entityType: 'JobCard', entityId: input.jobCardId, action: 'TRANSFER',
    actor: input.actor, reason: input.reason,
    after: { newJobCardId: next.job_card_id, newJobCardNo: next.job_card_no },
  });

  return next;
}
