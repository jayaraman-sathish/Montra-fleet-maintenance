/**
 * Forward migration and backfill, run on every start.
 *
 * Unlike migrate.ts — which only ever acts on an empty database — this runs
 * against live data. Everything here must therefore be additive and safe to
 * repeat: it applies db/03_upgrade.sql, then fills in values the newer
 * columns need for rows that predate them.
 *
 * The backfills that manufacture demonstration content (extra fitments,
 * telematics history, warranty claims) are gated on SEED_DEMO_DATA so a
 * production database is only ever given the schema change.
 */

import * as fs from 'node:fs';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';
import { pool, q, many, scalar } from '../lib/db.ts';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_DIR = path.resolve(__dirname, '../../db');

/** As-built specification values by component type. */
const SPECS: Record<string, Record<string, string>> = {
  BatteryPack: {
    'Nominal Capacity': '100 kWh', 'Nominal Voltage': '600 V', 'Chemistry': 'LFP',
    'Cooling Type': 'Liquid Cooled', 'Module Count': '12',
  },
  TractionMotor: {
    'Rated Power': '100 kW', 'Peak Power': '150 kW', 'Rated Speed': '3,000 rpm',
    'Cooling Type': 'Liquid Cooled', 'Insulation Class': 'Class H',
  },
  MotorController: {
    'Rated Power': '100 kW', 'Input Voltage': '600 V', 'Cooling Type': 'Liquid Cooled',
    'Firmware Version': 'FW-MC-2.3.1', 'Hardware Revision': 'Rev B',
  },
  DCDCConverter: {
    'Input Voltage': '600 V', 'Output Voltage': '24 V', 'Rated Output': '2.5 kW',
    'Cooling Type': 'Air Cooled',
  },
  OnBoardCharger: {
    'Rated Power': '11 kW', 'Input': '415 V AC 3-phase', 'Output Voltage': '600 V DC',
    'Protection Class': 'IP67',
  },
  HVJunctionBox: {
    'Rated Current': '250 A', 'Voltage Class': '600 V', 'Protection Class': 'IP67',
  },
  AirCompressor: {
    'Free Air Delivery': '250 l/min', 'Working Pressure': '10 bar', 'Drive Type': 'Electric',
  },
  BrakeSystem: {
    'System Type': 'EBS with ABS', 'Channels': '4', 'Regenerative Blending': 'Yes',
  },
  Tyre: {
    'Size': '10.00 R20', 'Load Index': '149/146', 'Speed Rating': 'K', 'Pattern': 'Rib-Lug',
  },
};

export async function upgradeIfNeeded(): Promise<void> {
  const sql = fs.readFileSync(path.join(DB_DIR, '03_upgrade.sql'), 'utf8');
  await pool.runScript(sql);
  console.log('[upgrade] applied 03_upgrade.sql');

  await backfillComponentSpecs();

  if (process.env.SEED_DEMO_DATA === 'true') {
    await backfillDemoFitments();
    await backfillTelematicsHistory();
    await backfillWarrantyClaims();
  }
}

/**
 * Give every fitment its specification, health and inspection dates. Health
 * is derived, not invented: a component with recorded faults is degraded, one
 * past two thirds of its warranty life is on watch, everything else is good.
 */
async function backfillComponentSpecs(): Promise<void> {
  const rows = await many<any>(pool, `
    SELECT c.fitment_id, c.component_type, c.installed_on, c.warranty_end,
           ct.inspection_months
    FROM master.vehicle_component c
    LEFT JOIN master.component_type ct ON ct.component_type = c.component_type
    WHERE c.specification IS NULL`);
  if (!rows.length) return;

  for (const r of rows) {
    const spec = SPECS[r.component_type] ?? {};
    const months = r.inspection_months ?? 12;
    const installed = new Date(r.installed_on);

    // Last inspection: the most recent multiple of the interval that has passed.
    const now = new Date();
    let last = new Date(installed);
    while (true) {
      const next = new Date(last);
      next.setMonth(next.getMonth() + months);
      if (next > now) break;
      last = next;
    }
    const next = new Date(last);
    next.setMonth(next.getMonth() + months);

    const warrantyEnd = r.warranty_end ? new Date(r.warranty_end) : null;
    const lifeUsed = warrantyEnd
      ? (now.getTime() - installed.getTime()) / (warrantyEnd.getTime() - installed.getTime())
      : 0;
    const health = lifeUsed > 0.85 ? 'Monitor' : 'Good';

    await q(pool, `
      UPDATE master.vehicle_component
         SET specification = $2::jsonb, health_status = $3,
             last_inspection_date = $4, next_inspection_date = $5
       WHERE fitment_id = $1`,
      [r.fitment_id, JSON.stringify(Object.entries(spec).map(([label, value]) => ({ label, value }))),
       health,
       last.toISOString().slice(0, 10), next.toISOString().slice(0, 10)]);
  }
  console.log(`[upgrade] specification backfilled for ${rows.length} component fitments`);
}

/**
 * The baseline seed fitted three to six powertrain components. The vehicle
 * master file shows the full serialised build, so fit the chassis items and
 * tyres that were always part of the specification but not seeded.
 */
async function backfillDemoFitments(): Promise<void> {
  const vehicles = await many<any>(pool, `
    SELECT v.vehicle_id, v.commissioning_date, cat.code AS category_code
    FROM master.vehicle v
    JOIN master.vehicle_variant vv ON vv.variant_id = v.variant_id
    JOIN master.vehicle_model vm   ON vm.model_id = vv.model_id
    JOIN master.product_family pf  ON pf.family_id = vm.family_id
    JOIN master.vehicle_category cat ON cat.category_id = pf.category_id
    WHERE NOT EXISTS (
      SELECT 1 FROM master.vehicle_component c
      WHERE c.vehicle_id = v.vehicle_id AND c.component_type = 'Tyre')`);
  if (!vehicles.length) return;

  let fitted = 0;
  for (const v of vehicles) {
    const heavy = v.category_code !== 'THREE_WHEELER' && v.category_code !== '3W';
    const axleTyres = heavy
      ? ['Front Left', 'Front Right', 'Rear Left 1', 'Rear Left 2', 'Rear Right 1', 'Rear Right 2']
      : ['Front', 'Rear Left', 'Rear Right'];

    const extras: [string, string, string | null][] = [
      ['AirCompressor', 'AC-001', null],
      ['BrakeSystem', heavy ? 'EBS-7T' : 'EBS-3W', null],
      ...axleTyres.map(p => ['Tyre', '10.00R20', p] as [string, string, string]),
    ];

    for (const [type, partNo, position] of extras) {
      const serial = `${type.slice(0, 2).toUpperCase()}${String(v.vehicle_id).padStart(5, '0')}` +
                     `${String(fitted % 1000).padStart(3, '0')}`;
      await q(pool, `
        INSERT INTO master.vehicle_component
          (vehicle_id, component_type, part_no, serial_no, supplier, installed_on,
           installed_odometer_km, warranty_start, warranty_end, warranty_km_limit,
           position_label, is_active)
        VALUES ($1,$2,$3,$4,'Montra Electric',$5,0,$5,
                ($5::date + INTERVAL '3 years')::date, 150000, $6, true)
        ON CONFLICT DO NOTHING`,
        [v.vehicle_id, type, partNo, serial,
         (v.commissioning_date instanceof Date
           ? v.commissioning_date.toISOString().slice(0, 10)
           : String(v.commissioning_date).slice(0, 10)),
         position]);
      fitted++;
    }
  }
  console.log(`[upgrade] fitted ${fitted} chassis components across ${vehicles.length} vehicles`);
  await backfillComponentSpecs();
}

/**
 * Seven days of telematics history per vehicle, so the live panel and trend
 * chart have something real to draw. Written straight to the transaction log
 * as accepted historical readings: the ingestion path is not replayed, since
 * these precede the current odometer and would fail the monotonicity check
 * (BL-USG-003) by design.
 */
async function backfillTelematicsHistory(): Promise<void> {
  const vehicles = await many<any>(pool, `
    SELECT v.vehicle_id, v.vin, v.current_odometer_km, v.current_operating_hours
    FROM master.vehicle v
    WHERE v.lifecycle_status = 'Active'
      AND (SELECT count(*) FROM integration.telematics_transaction t
            WHERE t.vehicle_id = v.vehicle_id AND t.accepted) < 8`);
  if (!vehicles.length) return;

  const POINTS = 7 * 4;               // four readings a day for seven days
  const STEP_MS = 6 * 60 * 60 * 1000;
  const STATES = ['Driving', 'Idle', 'Charging', 'Parked'];
  let written = 0;

  for (const v of vehicles) {
    const odo = Number(v.current_odometer_km ?? 0);
    const hrs = Number(v.current_operating_hours ?? 0);
    // Work backwards from the present reading at a plausible daily rate.
    const kmPerPoint = Math.max(8, Math.round((odo * 0.0012) / 4));
    const hrPerPoint = Math.max(1, Math.round((hrs * 0.0012) / 4));

    const values: string[] = [];
    const params: unknown[] = [];
    let p = 1;

    for (let i = POINTS - 1; i >= 0; i--) {
      const ts = new Date(Date.now() - i * STEP_MS);
      const km = Math.max(0, odo - i * kmPerPoint);
      const oh = Math.max(0, hrs - i * hrPerPoint);
      const state = STATES[(v.vehicle_id + i) % STATES.length];
      // State of charge cycles through a working day: discharge, then charge.
      const phase = ((POINTS - i) % 8) / 8;
      const soc = Math.round(38 + 45 * Math.abs(Math.sin(Math.PI * phase)) +
                             ((v.vehicle_id * 7 + i) % 7));
      const soh = 100 - Math.min(12, Math.round(odo / 12000));

      values.push(`($${p++},$${p++},$${p++},$${p++},$${p++},$${p++},$${p++},$${p++},$${p++},$${p++},true)`);
      params.push(v.vehicle_id, v.vin, km, oh, ts.toISOString(), state,
                  12.9716 + ((v.vehicle_id % 40) - 20) / 100,
                  80.2674 + ((v.vehicle_id % 30) - 15) / 100,
                  Math.min(98, Math.max(12, soc)), soh);
      written++;
    }

    await q(pool, `
      INSERT INTO integration.telematics_transaction
        (vehicle_id, vin, odometer_km, operating_hours, source_timestamp_utc,
         vehicle_status, latitude, longitude, soc_pct, soh_pct, accepted)
      VALUES ${values.join(',')}`, params);
  }
  console.log(`[upgrade] telematics history: ${written} readings across ${vehicles.length} vehicles`);
}

/**
 * A handful of warranty claim decisions so the entitlements tab shows a real
 * claim history rather than an empty table. Each is tied to an existing job
 * card, and the decision reflects the rule that would have been applied.
 */
async function backfillWarrantyClaims(): Promise<void> {
  const existing = await scalar<number>(pool, `
    SELECT count(*)::int FROM commercial.warranty_evaluation WHERE claim_no IS NOT NULL`);
  if ((existing ?? 0) > 0) return;

  const jobCards = await many<any>(pool, `
    SELECT jc.job_card_id, se.vehicle_id, se.event_type, jc.opened_utc
    FROM service.job_card jc
    JOIN service.service_event se ON se.service_event_id = jc.service_event_id
    ORDER BY jc.job_card_id LIMIT 12`);
  if (!jobCards.length) return;

  const OUTCOMES: [string, string, string][] = [
    ['Eligible',          'Component Replacement', 'Within vehicle warranty period and kilometre limit.'],
    ['Approval Required', 'Labour',                'Awaiting OEM technical review of the failure evidence.'],
    ['Not Eligible',      'Component Replacement', 'Vehicle beyond the kilometre limit for this component.'],
    ['Goodwill',          'Labour',                'Outside warranty; approved as goodwill by the service head.'],
  ];

  let n = 0;
  for (const jc of jobCards) {
    const [result, , reason] = OUTCOMES[n % OUTCOMES.length];
    const decided = result === 'Approval Required' ? null : jc.opened_utc;
    await q(pool, `
      INSERT INTO commercial.warranty_evaluation
        (job_card_id, result, reason, approver, decided_at, claim_no)
      VALUES ($1,$2,$3,$4,$5,$6)`,
      [jc.job_card_id, result, reason,
       decided ? 'service.head' : null, decided,
       `WCL-${new Date().getFullYear()}-${String(1000 + n).padStart(4, '0')}`]);
    n++;
  }
  console.log(`[upgrade] recorded ${n} warranty claim decisions`);
}
