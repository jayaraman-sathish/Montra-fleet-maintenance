/**
 * Render check for the vehicle master file.
 *
 * Signs in, opens the vehicle 360 screen, clicks through every tab and reports
 * console errors, failed requests and what each tab actually rendered. The
 * point is that a screen can be syntactically valid and still throw at runtime
 * — only rendering it proves otherwise.
 *
 *   node src/scripts/check-vehicle360.ts <baseUrl> <vin> [outDir]
 */

import * as fs from 'node:fs';
import { visit } from './browser.ts';

const BASE = process.argv[2] ?? 'http://127.0.0.1:3400';
const VIN = process.argv[3];
const OUT = process.argv[4];
const SHOT_TAB = process.argv[5];   // optional: leave this tab open for the screenshot

const TABS = [
  'Overview', 'Components', 'PM Obligations', 'Service History', 'Defects',
  'Documents', 'Telematics', 'Warranty & Entitlements', 'Campaigns', 'Uptime History',
];

async function login(): Promise<string> {
  const r = await fetch(`${BASE}/api/v1/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'ravi.kumar', password: 'montra123' }),
  });
  const j: any = await r.json();
  if (!j.token) throw new Error(`Login failed: ${JSON.stringify(j).slice(0, 200)}`);
  return j.token;
}

async function pickVin(token: string): Promise<string> {
  if (VIN) return VIN;
  const r = await fetch(`${BASE}/api/v1/vehicles?limit=1`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  const j: any = await r.json();
  const rows = j.rows ?? j.items ?? j;
  return rows[0].vin;
}

/** Runs inside the page: click each tab, wait a frame, report what rendered. */
function pageProbe(tabs: string[]): string {
  return `(async () => {
    const sleep = (ms) => new Promise(r => setTimeout(r, ms));
    const out = [];
    const bar = document.querySelector('.tabs');
    if (!bar) return { fatal: 'No tab bar rendered — the screen failed to load.' };
    const buttons = [...bar.querySelectorAll('button')];
    out.push({ tab: '(tab bar)', detail: buttons.map(b => b.textContent).join(' | ') });

    for (const name of ${JSON.stringify(tabs)}) {
      const btn = buttons.find(b => b.textContent === name);
      if (!btn) { out.push({ tab: name, error: 'tab button missing' }); continue; }
      btn.click();
      await sleep(140);
      const panel = btn.closest('.card').nextElementSibling;
      const text = (panel.textContent || '').replace(/\\s+/g, ' ').trim();
      out.push({
        tab: name,
        cards: panel.querySelectorAll('.card').length,
        rows: panel.querySelectorAll('table.data tbody tr').length,
        svg: panel.querySelectorAll('svg').length,
        empties: panel.querySelectorAll('.empty').length,
        chars: text.length,
        sample: text.slice(0, 90),
      });
    }

    // Leave a nominated tab open so the screenshot shows it.
    const shotTab = ${JSON.stringify(SHOT_TAB ?? 'Overview')};
    const shotBtn = buttons.find(b => b.textContent === shotTab);
    if (shotBtn) { shotBtn.click(); await sleep(250); }

    // Header assertions
    const head = document.querySelector('.veh-head');
    const tiles = head ? head.querySelectorAll('.veh-tile').length : 0;
    return { tiles, out };
  })()`;
}

const token = await login();
const vin = await pickVin(token);
console.log(`Vehicle master file render check — ${vin}\n`);

const r = await visit(`${BASE}/#/vehicles/${encodeURIComponent(vin)}`, {
  waitMs: 2200,
  screenshot: !!OUT,
  width: 1600,
  height: 1200,
  localStorage: { montra_token: token },
  evaluate: pageProbe(TABS),
});

const res: any = r.evalResult;
if (res?.fatal) {
  console.error('FATAL:', res.fatal);
} else {
  console.log(`Header usage tiles: ${res.tiles}`);
  for (const row of res.out) {
    if (row.detail) { console.log(`Tabs: ${row.detail}\n`); continue; }
    if (row.error) { console.log(`  ✗ ${row.tab}: ${row.error}`); continue; }
    console.log(`  ✓ ${row.tab.padEnd(24)} cards=${String(row.cards).padStart(2)} ` +
                `rows=${String(row.rows).padStart(3)} svg=${row.svg} empty=${row.empties} ` +
                `text=${String(row.chars).padStart(5)}  ${row.sample}`);
  }
}

const errors = r.console.filter(c => c.level === 'error');
console.log(`\nConsole errors: ${errors.length}`);
for (const e of errors) console.log('  ✗', e.text);
console.log(`Failed requests: ${r.failedRequests.length}`);
for (const f of r.failedRequests) console.log('  ✗', f.url, f.error);
for (const e of r.errors) console.log('  ✗ page error:', e);

if (OUT && r.screenshot) { fs.writeFileSync(OUT, r.screenshot); console.log('\nScreenshot →', OUT); }

const failed = errors.length + r.errors.length
  + (res?.out ?? []).filter((x: any) => x.error).length;
console.log(failed === 0 ? '\nRESULT: clean' : `\nRESULT: ${failed} problem(s)`);
