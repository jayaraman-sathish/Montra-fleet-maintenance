/** Wrapper so the startup migration can invoke the demo seed as a module. */
import { seedDemo } from './seed-demo.ts';
await seedDemo();
