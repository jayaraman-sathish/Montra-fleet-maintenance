/**
 * Minimal Chrome DevTools Protocol driver for smoke-testing the web client.
 * Uses Node's built-in WebSocket — no Playwright/Puppeteer available here.
 *
 * Usage:  node src/scripts/browser.ts <url> [outfile.png] [--wait=ms] [--script='...']
 */

import { spawn } from 'node:child_process';
import * as fs from 'node:fs';
import * as os from 'node:os';
import * as path from 'node:path';

const CHROME = process.env.CHROME_PATH ?? '/opt/pw-browsers/chromium-1194/chrome-linux/chrome';

export interface PageResult {
  console: { level: string; text: string }[];
  errors: string[];
  failedRequests: { url: string; error: string }[];
  screenshot?: Buffer;
  title?: string;
  evalResult?: unknown;
}

export async function visit(url: string, opts: {
  waitMs?: number; screenshot?: boolean; evaluate?: string;
  width?: number; height?: number; localStorage?: Record<string, string>;
} = {}): Promise<PageResult> {
  const userDataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'cdp-'));
  const port = 9200 + Math.floor(Math.random() * 500);

  const chrome = spawn(CHROME, [
    '--headless=new', '--disable-gpu', '--no-sandbox', '--disable-dev-shm-usage',
    '--hide-scrollbars', '--mute-audio', '--no-first-run',
    `--remote-debugging-port=${port}`, `--user-data-dir=${userDataDir}`,
    `--window-size=${opts.width ?? 1600},${opts.height ?? 1100}`,
    'about:blank',
  ], { stdio: ['ignore', 'ignore', 'pipe'] });

  const result: PageResult = { console: [], errors: [], failedRequests: [] };

  try {
    // Wait for the debugging endpoint.
    let wsUrl = '';
    for (let i = 0; i < 60; i++) {
      try {
        const r = await fetch(`http://127.0.0.1:${port}/json/version`);
        const j: any = await r.json();
        wsUrl = j.webSocketDebuggerUrl;
        break;
      } catch { await new Promise(r => setTimeout(r, 200)); }
    }
    if (!wsUrl) throw new Error('Chrome did not expose a debugging endpoint');

    const ws = new WebSocket(wsUrl);
    await new Promise((res, rej) => { ws.onopen = () => res(null); ws.onerror = rej; });

    let msgId = 0;
    const pending = new Map<number, { resolve: (v: any) => void; reject: (e: any) => void }>();

    ws.onmessage = (ev) => {
      const msg = JSON.parse(String(ev.data));
      if (msg.id && pending.has(msg.id)) {
        const p = pending.get(msg.id)!;
        pending.delete(msg.id);
        msg.error ? p.reject(new Error(msg.error.message)) : p.resolve(msg.result);
        return;
      }
      switch (msg.method) {
        case 'Runtime.consoleAPICalled':
          result.console.push({
            level: msg.params.type,
            text: (msg.params.args ?? []).map((a: any) =>
              a.value ?? a.description ?? JSON.stringify(a.preview ?? '')).join(' '),
          });
          break;
        case 'Runtime.exceptionThrown': {
          const d = msg.params.exceptionDetails;
          result.errors.push(
            `${d.text} ${d.exception?.description ?? ''} @ ${d.url ?? ''}:${d.lineNumber ?? ''}`);
          break;
        }
        case 'Log.entryAdded':
          if (msg.params.entry.level === 'error') {
            result.errors.push(`${msg.params.entry.text} (${msg.params.entry.url ?? ''})`);
          }
          break;
        case 'Network.loadingFailed':
          result.failedRequests.push({ url: msg.params.requestId, error: msg.params.errorText });
          break;
      }
    };

    const send = (method: string, params: any = {}) => new Promise<any>((resolve, reject) => {
      const id = ++msgId;
      pending.set(id, { resolve, reject });
      ws.send(JSON.stringify({ id, method, params }));
      setTimeout(() => { if (pending.has(id)) { pending.delete(id); reject(new Error(`${method} timed out`)); } }, 30000);
    });

    const { targetId } = await send('Target.createTarget', { url: 'about:blank' });
    const { sessionId } = await send('Target.attachToTarget', { targetId, flatten: true });

    const sessionSend = (method: string, params: any = {}) => new Promise<any>((resolve, reject) => {
      const id = ++msgId;
      pending.set(id, { resolve, reject });
      ws.send(JSON.stringify({ id, method, params, sessionId }));
      setTimeout(() => { if (pending.has(id)) { pending.delete(id); reject(new Error(`${method} timed out`)); } }, 30000);
    });

    await sessionSend('Runtime.enable');
    await sessionSend('Log.enable');
    await sessionSend('Network.enable');
    await sessionSend('Page.enable');

    if (opts.localStorage) {
      // Seed storage on the origin first, then load the target URL with a full
      // document load. Navigating between two URLs that differ only by hash is
      // a same-document navigation and would not re-run the application.
      const origin = new URL(url).origin;
      await sessionSend('Page.navigate', { url: origin });
      await new Promise(r => setTimeout(r, 500));
      for (const [k, v] of Object.entries(opts.localStorage)) {
        await sessionSend('Runtime.evaluate', {
          expression: `localStorage.setItem(${JSON.stringify(k)}, ${JSON.stringify(v)})`,
        });
      }
      await sessionSend('Page.navigate', { url: 'about:blank' });
      await new Promise(r => setTimeout(r, 150));
    }

    await sessionSend('Page.navigate', { url });
    await new Promise(r => setTimeout(r, opts.waitMs ?? 2500));

    const t = await sessionSend('Runtime.evaluate', { expression: 'document.title', returnByValue: true });
    result.title = t?.result?.value;

    if (opts.evaluate) {
      const ev = await sessionSend('Runtime.evaluate', {
        expression: opts.evaluate, returnByValue: true, awaitPromise: true,
      });
      result.evalResult = ev?.result?.value;
    }

    if (opts.screenshot) {
      const shot = await sessionSend('Page.captureScreenshot', { format: 'png', captureBeyondViewport: true });
      result.screenshot = Buffer.from(shot.data, 'base64');
    }

    ws.close();
  } finally {
    chrome.kill('SIGKILL');
    try { fs.rmSync(userDataDir, { recursive: true, force: true }); } catch {}
  }

  return result;
}

// CLI
const isMain = process.argv[1] && process.argv[1].endsWith('browser.ts');
if (isMain) {
  const url = process.argv[2] ?? 'http://localhost:3000/';
  const out = process.argv.find(a => a.endsWith('.png'));
  const waitArg = process.argv.find(a => a.startsWith('--wait='));
  const scriptArg = process.argv.find(a => a.startsWith('--script='));
  const tokenArg = process.argv.find(a => a.startsWith('--token='));

  visit(url, {
    screenshot: !!out,
    waitMs: waitArg ? Number(waitArg.split('=')[1]) : 2500,
    evaluate: scriptArg ? scriptArg.slice('--script='.length) : undefined,
    localStorage: tokenArg ? { montra_token: tokenArg.slice('--token='.length) } : undefined,
  }).then(r => {
    console.log('TITLE:', r.title);
    if (r.errors.length) { console.log('\nPAGE ERRORS:'); r.errors.forEach(e => console.log('  ✗', e)); }
    const interesting = r.console.filter(c => ['error', 'warning'].includes(c.level));
    if (interesting.length) { console.log('\nCONSOLE:'); interesting.forEach(c => console.log(`  [${c.level}] ${c.text}`)); }
    if (r.evalResult !== undefined) console.log('\nEVAL:', JSON.stringify(r.evalResult, null, 1));
    if (out && r.screenshot) { fs.writeFileSync(out, r.screenshot); console.log('\nScreenshot →', out); }
    if (!r.errors.length && !interesting.length) console.log('\nNo page errors.');
  }).catch(e => { console.error('Browser run failed:', e); process.exit(1); });
}
