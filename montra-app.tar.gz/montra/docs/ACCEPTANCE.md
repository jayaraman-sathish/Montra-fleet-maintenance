# Acceptance run — Document 05 scenario catalogue

This is a real execution log, not a plan. The checks below were run against a
freshly seeded build using `src/scripts/acceptance.ts`, which drives the live
API exactly as a client would. Reproduce it with:

```bash
node src/scripts/reset-db.ts
node src/scripts/seed-demo.ts
node src/index.ts &
node src/scripts/acceptance.ts
```

**Result: 36 of 36 checks passed.**

The emphasis is deliberately on the *negative* paths. Document 05 §2 is explicit
that "a requirement is not considered accepted merely because a related screen
exists" — so most of these checks try to do something the rules forbid and
verify that the system refuses, with a readable reason and the governing rule.

| Test ID | Area | Source refs | Scenario | Result | Evidence |
|---|---|---|---|---|---|
| AT-VEH-002 | Vehicle | FR-VEH-002; BL-VEH-002 | VIN maps to exactly one Category > Family > Model > Variant | **Pass** | 82 vehicles in scope |
| AT-VEH-003 | Vehicle | FR-VEH-004; CMP-001..003 | Serialised components carry install history against the VIN | **Pass** | 6 components on MT7T2036001000 |
| AT-CFG-001 | Configuration | CFG-001..003; BL-CFG-001..003 | Placeholder models are identified and their configuration is blocked from publication | **Pass** | 2 placeholder model/variant rows |
| AT-PM-001..004 | PM | FR-PM-001..005; BL-PM-005..008 | Obligations classify across Upcoming / Due Soon / Due / Overdue | **Pass** | {"Due Soon":1,"Overdue":9,"Due":2,"Upcoming":50,"Scheduled":14,"Under Service":6} |
| AT-PM-002 | PM | BL-PM-005..008 | The most urgent trigger drives status and is identifiable | **Pass** | driven by KM, 2 trigger(s) evaluated |
| AT-PMO-001 | PM Obligation | FR-PMO-001/002; BL-PM-024..026 | Prior cycles persist with their outcome; the next cycle is a new row | **Pass** | 5 cycles, 4 completed with outcome |
| AT-AVL-001/002 | Availability | FR-AVL-001..003; BL-AVL-* | Ledger intervals are created from job/breakdown transitions with the causing rule | **Pass** | 2 intervals, rules: BL-AVL-002, BL-AVL-001 |
| UPM-001 | Availability | UPM-001 | Exactly one open interval per VIN — no overlaps | **Pass** | 1 open interval(s) |
| AT-AVL-005 | Availability | KPI dictionary | Availability reconciles to ledger timestamps | **Pass** | 100% over the window |
| AT-CAP-001 | Appointment | FR-APT-001; CAP-001 | Capacity view returns bays, roster and booked minutes | **Pass** | 4 bays, 3 technicians |
| AT-CAP-002 | Appointment | FR-APT-001; CAP-001 | Double booking the same bay and slot is refused | **Pass** | That bay is already booked from 09:00 to 13:00 (APT-2026-00016). Choose another slot or ba |
| AT-JC-001 | Job Card | FR-JC-010; BL-JC-003 | An invalid status jump is blocked with the allowed set explained | **Pass** | Job card cannot move from "Repairing" to "Completed". Allowed from "Repairing": Awaiting Parts, Awaiting Custo |
| BL-JC-003b | Job Card | BL-JC-003 | Exception transitions require a reason | **Pass** | A reason is required to move a job card to On Hold. |
| AT-SP-001a | Parts | SPM-003/004 | Only parts approved for the variant are offered | **Pass** | 25 applicable parts |
| AT-SP-003 | Parts | BL-SP-008 | Zero or negative issue quantity is rejected | **Pass** | Part quantity must be greater than zero (BL-SP-008). |
| AT-SP-002 | Parts | SPM-006/007; BL-SP-003 | A serialised part cannot be fitted without its serial number | **Pass** | BP-7T-001 is serial-controlled: the new component serial number must be recorded (BL-SP-00 |
| AT-QC-001 | QC | QC-001..003; BL-QC-* | Release is blocked while mandatory checks are incomplete, with reasons given | **Pass** | NOT_TECHNICIAN_COMPLETE, MANDATORY_CHECKLIST_INCOMPLETE, QC_CHECKS_INCOMPLETE |
| AT-QC-001b | QC | BL-QC-002/003 | Attempting release anyway is refused and returns the blocking conditions | **Pass** | 3 blocker(s) returned |
| AT-QC-002 | QC | BL-CHK-005; BL-QC-003 | An open critical defect is surfaced as a release blocker | **Pass** | no critical defect on this job |
| AT-SEC-001 | Security | FR-ORG-001..003; BL-SEC-* | A fleet customer sees only their own organisation’s vehicles | **Pass** | customer sees 20 of 82 (ABC Logistics Ltd.) |
| AT-SEC-002 | Security | FR-ORG-001..003 | A service centre manager sees only their own centre’s vehicles | **Pass** | centre manager sees 28 of 82 |
| AT-SEC-003 | Security | BL-SEC-007..010 | A technician cannot authorise a release | **Pass** | "qc.release" is restricted to: QC_SUPERVISOR. Your roles: TECHNICIAN. |
| BL-SEC-008 | Security | BL-SEC-008 | Even an administrator cannot perform an action outside the authorisation matrix | **Pass** | "qc.release" is restricted to: QC_SUPERVISOR. Your roles: MASTER_DATA_ADMIN. |
| AT-SEC-000 | Security | Doc 03 §11 | Unauthenticated API access is refused | **Pass** | HTTP 401 |
| AT-INT-001 | Telematics | FR-INT-001; BL-USG-001..007 | A valid usage event is accepted and updates the snapshot | **Pass** | {"externalMessageId":"AT-INT-1789149309466","result":"accepted","vehicleId":1,"pmChanged":0} |
| AT-INT-004 | Telematics | BL-INT-002 | Replaying the same event is idempotent — no duplicate processing | **Pass** | {"externalMessageId":"AT-INT-1789149309466","result":"duplicate"} |
| AT-INT-002a | Telematics | BL-USG-001 | An odometer regression is quarantined, not applied | **Pass** | Odometer regression: received 5 km, last accepted 57833 km. An authorised correction is re |
| AT-INT-002 | Telematics | BL-USG-002 | An implausible distance jump is quarantined | **Pass** | Implausible distance: 89975 km in 0.0 day(s) exceeds the MHCV limit of 38 km (BL-USG-002). |
| AT-INT-002b | Telematics | Doc 04 §27 | An unknown VIN is quarantined and never auto-creates a vehicle | **Pass** | Unknown VIN NOSUCHVIN000000000 — production vehicles are never auto-created |
| AT-INT-000 | Telematics | Doc 04 §24 | Telematics ingestion requires the shared API key | **Pass** | HTTP 401 |
| AT-INT-006 | Integration | Doc 03 §16 | Quarantined events are visible in the operations console | **Pass** | 11 open error(s) listed |
| AT-KPI-001/002 | KPI | BL-KPI-PM-001 | PM compliance reports on-time and within-tolerance separately, with carry-over excluded | **Pass** | on-time 57.9%, carry-over 5 |
| AT-KPI-004 | KPI | Availability ledger | Availability derives from the ledger, with attribution | **Pass** | 99.99% · 4 attribution group(s) |
| AT-KPI-005 | KPI | BL-BD-014..016 | First-time fix and repeat breakdown rate share one eligible denominator | **Pass** | FTF 50%, repeat 50%, denominator 2 |
| AT-KPI-003 | KPI | KPI timestamp dictionary | Turnaround reports gross and pause-excluded net separately | **Pass** | gross 6h / net 6h |
| AT-SEC-004 | Audit | FR-AUD-001; BL-SEC-004 | Privileged and transactional actions are recorded in the audit trail | **Pass** | 29 events; actions: LOGIN, CREATE, CHECKLIST_RECORD |
---

## Two defects found and fixed during this run

Running the specification rather than reading it surfaced two real faults:

**1. Released vehicles stayed flagged as under maintenance.**
The availability-ledger precedence rule (BL-AVL-014) was implemented against the
*reason code* rather than the *source*. Because `Down-PM` carried a higher
precedence value than `In Service`, the return-to-service transition on release
was silently suppressed, and the vehicle remained in `Down-PM` forever. Downtime
would have accumulated indefinitely and fleet availability would have been
permanently wrong.

Fixed by reading BL-AVL-014 as it is actually written — precedence is a property
of the *source* of the claim ("telematics evidence > approved transactional
state > authorised manual correction > derived display state"), not of the state
being claimed. A transactional source can always progress or close the state it
owns; only telematics-derived states are suppressed while an approved
transactional interval is open. That also satisfies BL-AVL-013.

**2. Routine work was blocked by the privileged-action matrix.**
Booking an appointment, issuing a part and recording QC results were being
checked against the FR-AUTH-001 authorisation matrix, which only contains
privileged actions. Since an action absent from that matrix is correctly treated
as performable by nobody (BL-SEC-008), ordinary operations failed for every
role.

Fixed by separating the two controls, which the baseline does distinguish:
`assertPermission` for everyday role permissions, and `assertAuthorised` for the
privileged and exceptional actions that carry maker-checker, segregation and
reason requirements. Both are still enforced server-side.

---

## Scenarios not covered by this automated run

| Document 05 scenario | Status | Note |
|---|---|---|
| AT-OFF-001..003 offline technician execution | **Not implemented** | The server side is ready (`integration.offline_operation`, `client_operation_id`, idempotent result sync) but the client has no service worker or local queue. This is the main Phase-1 functional gap — see `docs/DEVIATIONS.md` §3. |
| AT-NFR-001..003 performance, DR, concurrency | Not run | Requires the agreed 50,000-VIN dataset and a production-like environment (Document 05 §12). Optimistic concurrency columns (`row_version`) are in place. |
| AT-MIG-001..003 migration and cutover | Not run | Requires Montra source extracts. The migration rules of Document 04 §30 are reflected in the schema, including the "Unknown / inspect at first service" PM baseline state. |
| AT-INT-005 ERP reservation and issue | Partially | `PartUsage` carries ERP reservation and issue references and the reconciliation states exist, but no ERP endpoint was available to integrate against. |
| AT-DPDP-001 data protection | Partially | Field-visibility masking by audience is implemented and tested; retention, correction and erasure workflows are not built. |
| AT-UX-003 printable artefacts | Not implemented | Job card, estimate, PM certificate, gate pass and handover documents (FR-UX-004). |
