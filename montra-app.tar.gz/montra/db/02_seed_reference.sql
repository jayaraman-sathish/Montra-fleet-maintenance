-- =====================================================================
-- Reference / configuration seed data
-- Sources: Document 1.1 FINAL v3.0 §2 (vehicle hierarchy), §4 (model
-- reference data), §6-11 (checklists), §18 (spare parts), §24 (service
-- centres), §25 (technicians); Document 02 §24.1 (availability states).
--
-- NOTE: Montra must validate all values before production use
-- (Doc 1.1 §16). Models not yet confirmed are loaded as 'Placeholder'
-- and are blocked from configuration publication by BL-CFG-002.
-- =====================================================================

-- ---------------------------------------------------------------------
-- Organisations and hierarchy (FR-ORG-001)
-- ---------------------------------------------------------------------
INSERT INTO org.organisation (org_type, code, name) VALUES
 ('Montra',   'MONTRA',   'Montra Electric'),
 ('Customer', 'ABCLOG',   'ABC Logistics Ltd.'),
 ('Customer', 'GRNFLX',   'Green Falx Pvt. Ltd.'),
 ('Customer', 'CITYFL',   'City Fleet Services'),
 ('Customer', 'EVNEXT',   'EV Next Pvt. Ltd.'),
 ('Dealer',   'DLR-TN01', 'Montra Authorised Service — Tamil Nadu');

INSERT INTO org.organisation_node (organisation_id, parent_node_id, node_type, code, name)
SELECT o.organisation_id, NULL, 'Customer', o.code, o.name
FROM org.organisation o WHERE o.org_type = 'Customer';

INSERT INTO org.organisation_node (organisation_id, parent_node_id, node_type, code, name)
SELECT n.organisation_id, n.node_id, 'Region', n.code || '-SOUTH', 'South Region'
FROM org.organisation_node n WHERE n.node_type = 'Customer';

INSERT INTO org.organisation_node (organisation_id, parent_node_id, node_type, code, name)
SELECT n.organisation_id, n.node_id, 'Depot', n.code || '-CHN', 'Chennai Depot'
FROM org.organisation_node n WHERE n.node_type = 'Region';

INSERT INTO org.service_network_node (parent_node_id, node_type, code, name) VALUES
 (NULL, 'Montra', 'MONTRA-SVC', 'Montra Service Network');
INSERT INTO org.service_network_node (parent_node_id, node_type, code, name)
SELECT node_id, 'Zone', 'ZONE-SOUTH', 'South Zone' FROM org.service_network_node WHERE code='MONTRA-SVC';
INSERT INTO org.service_network_node (parent_node_id, node_type, code, name)
SELECT node_id, 'Zone', 'ZONE-WEST', 'West Zone' FROM org.service_network_node WHERE code='MONTRA-SVC';

-- ---------------------------------------------------------------------
-- Business calendar and service centres (Doc 1.1 §24)
-- ---------------------------------------------------------------------
INSERT INTO master.business_calendar (code, name, timezone, is_24x7, working_days, day_start, day_end) VALUES
 ('CAL-STD',  'Standard Workshop Calendar', 'Asia/Kolkata', false, '{1,2,3,4,5,6}', '09:00', '18:00'),
 ('CAL-24X7', '24x7 Roadside Calendar',     'Asia/Kolkata', true,  '{1,2,3,4,5,6,7}', '00:00', '23:59');

INSERT INTO master.service_centre
 (network_node_id, code, name, centre_type, city, state, region, contact_phone, latitude, longitude, capabilities, business_calendar_id)
SELECT z.node_id, v.code, v.name, v.ctype, v.city, v.state, 'South', v.phone, v.lat, v.lon, v.caps,
       (SELECT calendar_id FROM master.business_calendar WHERE code='CAL-STD')
FROM (VALUES
 ('SC-CHN','Chennai Service Centre','Company','Chennai','Tamil Nadu','+914428000001',13.0827,80.2707,
    ARRAY['PM','Breakdown','HV','Diagnostics','BatterySwap','Towing']),
 ('SC-CBE','Coimbatore Service Centre','Company','Coimbatore','Tamil Nadu','+914224000002',11.0168,76.9558,
    ARRAY['PM','Breakdown','HV','Diagnostics']),
 ('SC-BLR','Bengaluru Service Centre','Authorized','Bengaluru','Karnataka','+918040000003',12.9716,77.5946,
    ARRAY['PM','Breakdown','Diagnostics']),
 ('SC-MDU','Madurai Mobile Unit','Mobile','Madurai','Tamil Nadu','+914524000004',9.9252,78.1198,
    ARRAY['Breakdown','Towing'])
) AS v(code,name,ctype,city,state,phone,lat,lon,caps)
CROSS JOIN (SELECT node_id FROM org.service_network_node WHERE code='ZONE-SOUTH') z;

INSERT INTO schedule.service_bay (service_centre_id, bay_code, bay_type, supported_categories)
SELECT sc.service_centre_id, b.code, b.btype, ARRAY['LMP','LMC','SCV','MHCV','TRACTOR']
FROM master.service_centre sc
CROSS JOIN (VALUES ('Bay 1','General'),('Bay 2','General'),('Bay 3','HV'),('Bay 4','Heavy')) AS b(code,btype)
WHERE sc.centre_type <> 'Mobile';

INSERT INTO schedule.shift (service_centre_id, code, start_time, end_time)
SELECT service_centre_id, 'GENERAL', '09:00', '18:00' FROM master.service_centre;

-- ---------------------------------------------------------------------
-- Roles, permissions and users (Doc 1.1 §28)
-- ---------------------------------------------------------------------
INSERT INTO security.role (code, name, description) VALUES
 ('FLEET_CUSTOMER',    'Fleet / Customer User',     'View scoped fleet, raise service requests, approve estimates'),
 ('SERVICE_COORD',     'Montra Service Coordinator','Monitor queues, triage, schedule, manage SLA/escalation'),
 ('SC_MANAGER',        'Service Centre Manager',    'Accept jobs, schedule bays, assign technicians'),
 ('TECHNICIAN',        'Technician',                'Execute checklist, diagnosis, repair, parts and labour'),
 ('STORES',            'Parts / Stores',            'Reserve, issue and return parts'),
 ('WARRANTY_USER',     'Warranty User',             'Review eligibility and approve/reject claims'),
 ('QC_SUPERVISOR',     'Supervisor / QC',           'Verify work, execute release checklist, authorise release'),
 ('ENGINEERING',       'Engineering / Quality',     'Repeat failures, root cause, campaigns, technical masters'),
 ('MASTER_DATA_ADMIN', 'Master Data Admin',         'Maintain approved models, PM plans, checklists, parts, rules'),
 ('MANAGEMENT',        'Management',                'KPI, reliability and cost dashboards');

INSERT INTO security.permission (action_code, description) VALUES
 ('vehicle.read','View vehicle records'),
 ('vehicle.write','Create/amend vehicle records'),
 ('pm.schedule','Schedule a PM obligation'),
 ('pm.override_next','Override next PM target'),
 ('appointment.book','Book an appointment'),
 ('appointment.override_capacity','Book beyond capacity'),
 ('breakdown.create','Report a breakdown'),
 ('breakdown.triage','Triage and set priority'),
 ('breakdown.downgrade_p1','Downgrade a P1 priority'),
 ('jobcard.create','Open a job card'),
 ('jobcard.execute','Record checklist, parts, labour'),
 ('jobcard.transition','Change job card status'),
 ('jobcard.reopen','Reopen a closed job card'),
 ('qc.perform','Perform QC checks'),
 ('qc.release','Authorise vehicle release'),
 ('qc.remote','Perform remote QC'),
 ('concession.approve','Approve a release concession'),
 ('warranty.decide','Approve/reject warranty'),
 ('warranty.override','Override warranty eligibility'),
 ('estimate.approve','Approve a customer estimate'),
 ('parts.issue','Issue parts'),
 ('offhire.set','Set or clear off-hire'),
 ('config.author','Author technical configuration'),
 ('config.publish','Publish technical configuration'),
 ('usage.correct','Correct odometer or hours'),
 ('availability.correct','Correct availability ledger'),
 ('integration.reprocess','Replay integration messages');

-- Password for every demo account is 'montra123' (scrypt, N=16384).
INSERT INTO security.application_user (username, display_name, email, password_hash) VALUES
 ('ravi.kumar',   'Ravi Kumar',   'ravi.kumar@montra.example',   'scrypt$16384$8$1$hZ6X4Mp7BMaAaViuy4v3Gg==$ccdi4Sbz/ODAbdR4Uxu92nfPRatq3ONkuPMg1ecqywc='),
 ('kumar.s',      'Kumar S',      'kumar.s@montra.example',      'scrypt$16384$8$1$hZ6X4Mp7BMaAaViuy4v3Gg==$ccdi4Sbz/ODAbdR4Uxu92nfPRatq3ONkuPMg1ecqywc='),
 ('arul.m',       'Arul M',       'arul.m@montra.example',       'scrypt$16384$8$1$hZ6X4Mp7BMaAaViuy4v3Gg==$ccdi4Sbz/ODAbdR4Uxu92nfPRatq3ONkuPMg1ecqywc='),
 ('suresh.k',     'Suresh K',     'suresh.k@montra.example',     'scrypt$16384$8$1$hZ6X4Mp7BMaAaViuy4v3Gg==$ccdi4Sbz/ODAbdR4Uxu92nfPRatq3ONkuPMg1ecqywc='),
 ('priya.n',      'Priya N',      'priya.n@montra.example',      'scrypt$16384$8$1$hZ6X4Mp7BMaAaViuy4v3Gg==$ccdi4Sbz/ODAbdR4Uxu92nfPRatq3ONkuPMg1ecqywc='),
 ('vijay.r',      'Vijay R',      'vijay.r@montra.example',      'scrypt$16384$8$1$hZ6X4Mp7BMaAaViuy4v3Gg==$ccdi4Sbz/ODAbdR4Uxu92nfPRatq3ONkuPMg1ecqywc='),
 ('meena.s',      'Meena S',      'meena.s@montra.example',      'scrypt$16384$8$1$hZ6X4Mp7BMaAaViuy4v3Gg==$ccdi4Sbz/ODAbdR4Uxu92nfPRatq3ONkuPMg1ecqywc='),
 ('admin',        'System Administrator','admin@montra.example',  'scrypt$16384$8$1$hZ6X4Mp7BMaAaViuy4v3Gg==$ccdi4Sbz/ODAbdR4Uxu92nfPRatq3ONkuPMg1ecqywc='),
 ('fleet.abc',    'ABC Logistics Fleet Manager','fleet@abclogistics.example','scrypt$16384$8$1$hZ6X4Mp7BMaAaViuy4v3Gg==$ccdi4Sbz/ODAbdR4Uxu92nfPRatq3ONkuPMg1ecqywc=');

-- Role + scope assignment (FR-ORG-002)
INSERT INTO security.user_role_scope (user_id, role_id, scope_type, scope_node_id)
SELECT u.user_id, r.role_id, v.scope_type,
       CASE WHEN v.scope_type='ServiceCentre'
            THEN (SELECT service_centre_id FROM master.service_centre WHERE code='SC-CHN')
            WHEN v.scope_type='Organisation'
            THEN (SELECT organisation_id FROM org.organisation WHERE code='ABCLOG')
            ELSE NULL END
FROM (VALUES
 ('ravi.kumar','SC_MANAGER','ServiceCentre'),
 ('kumar.s','TECHNICIAN','ServiceCentre'),
 ('arul.m','TECHNICIAN','ServiceCentre'),
 ('suresh.k','TECHNICIAN','ServiceCentre'),
 ('priya.n','QC_SUPERVISOR','ServiceCentre'),
 ('vijay.r','SERVICE_COORD','Global'),
 ('meena.s','STORES','ServiceCentre'),
 ('admin','MASTER_DATA_ADMIN','Global'),
 ('fleet.abc','FLEET_CUSTOMER','Organisation')
) AS v(username, role_code, scope_type)
JOIN security.application_user u ON u.username = v.username
JOIN security.role r ON r.code = v.role_code;

-- FR-AUTH-001 / Doc 1.1 §36.10 authorisation matrix
INSERT INTO security.authorization_policy (action_code, role_code, requires_approval, sod_rule) VALUES
 ('config.publish','MASTER_DATA_ADMIN', true,  'CreatorMayNotApprove'),
 ('config.publish','ENGINEERING',       true,  'CreatorMayNotApprove'),
 ('breakdown.downgrade_p1','SERVICE_COORD', false, 'ReasonMandatory'),
 ('breakdown.downgrade_p1','SC_MANAGER',    false, 'ReasonMandatory'),
 ('usage.correct','SC_MANAGER',        false, 'ReasonAndEvidenceMandatory'),
 ('offhire.set','SERVICE_COORD',       false, 'EvidenceAndExpectedReturnMandatory'),
 ('pm.override_next','ENGINEERING',    false, 'ReasonMandatory'),
 ('concession.approve','QC_SUPERVISOR',false, 'ExpiryAndFollowUpMandatory'),
 ('concession.approve','ENGINEERING',  false, 'ExpiryAndFollowUpMandatory'),
 ('warranty.override','WARRANTY_USER', false, 'ReasonMandatory'),
 ('qc.remote','QC_SUPERVISOR',         false, 'EvidenceMandatory'),
 ('qc.release','QC_SUPERVISOR',        false, 'RepairerMayNotRelease'),
 ('integration.reprocess','MASTER_DATA_ADMIN', false, 'AuditedReplay'),
 ('jobcard.reopen','SC_MANAGER',       false, 'ReasonMandatory'),
 ('appointment.override_capacity','SC_MANAGER', false, 'ReasonMandatory'),
 ('estimate.approve','FLEET_CUSTOMER', false, NULL),
 ('availability.correct','SERVICE_COORD', false, 'ReasonAndEvidenceMandatory');

INSERT INTO security.field_visibility_policy (audience, field_group, treatment) VALUES
 ('Customer','Cost','Mask'), ('Customer','WarrantyDecision','Allow'),
 ('Customer','RootCause','Mask'), ('Customer','TechnicianIdentity','Hide'),
 ('Customer','Reliability','Hide'),
 ('Dealer','Cost','Allow'), ('Dealer','WarrantyDecision','Allow'),
 ('Dealer','RootCause','Allow'), ('Dealer','TechnicianIdentity','Allow'),
 ('Dealer','Reliability','Mask'),
 ('OEM','Cost','Allow'), ('OEM','WarrantyDecision','Allow'),
 ('OEM','RootCause','Allow'), ('OEM','TechnicianIdentity','Allow'),
 ('OEM','Reliability','Allow');

-- ---------------------------------------------------------------------
-- Vehicle hierarchy (Doc 1.1 §2) — Category > Family > Model > Variant
-- ---------------------------------------------------------------------
INSERT INTO master.vehicle_category (code, name) VALUES
 ('LMP','Last Mile Passenger'),
 ('LMC','Last Mile Cargo'),
 ('SCV','Small Commercial Vehicle'),
 ('MHCV','Medium & Heavy Commercial Vehicle'),
 ('TRACTOR','Tractor');

INSERT INTO master.product_family (category_id, code, name)
SELECT c.category_id, v.code, v.name FROM (VALUES
 ('LMP','SUPERAUTO','Super Auto'),
 ('LMC','SUPERCARGO','Super Cargo'),
 ('SCV','EVIATOR','EVIATOR'),
 ('MHCV','RHINO','Rhino'),
 ('TRACTOR','ETRACTOR','E-Tractor')
) AS v(cat,code,name) JOIN master.vehicle_category c ON c.code = v.cat;

-- Confirmation status per Doc 1.1 §4: values marked "to confirm" load as Placeholder
INSERT INTO master.vehicle_model (family_id, code, name, confirmation_status)
SELECT f.family_id, v.code, v.name, v.conf FROM (VALUES
 ('SUPERAUTO','EPL20','ePL 2.0','Confirmed'),
 ('SUPERAUTO','EPL20R','ePL 2.0 R','Confirmed'),
 ('SUPERCARGO','SCARGO','Super Cargo','Confirmed'),
 ('EVIATOR','EVI350','EVIATOR 350','Confirmed'),
 ('EVIATOR','EVICORE','EVIATOR (core)','Confirmed'),
 ('EVIATOR','EVI350LP','EVIATOR 350L+','Confirmed'),
 ('RHINO','RH5538','Rhino 5538 EV','Confirmed'),
 ('RHINO','RH2838','Rhino 2838 EV','Placeholder'),
 ('ETRACTOR','E27','E-27','Confirmed'),
 ('ETRACTOR','E45','E-45','Placeholder')
) AS v(fam,code,name,conf) JOIN master.product_family f ON f.code = v.fam;

-- Variant technical data from Doc 1.1 §4 "Model Reference Data"
INSERT INTO master.vehicle_variant
 (model_id, code, name, confirmation_status, axle_configuration, body_type, drive_type,
  motor_type, peak_power_kw, peak_torque_nm, battery_chemistry, battery_capacity_kwh,
  battery_configuration, transmission, front_brake, rear_brake, gvw_kg)
SELECT m.model_id, v.code, v.name, v.conf, v.axle, v.body, v.drive, v.motor, v.pkw, v.ptq,
       v.chem, v.kwh, v.batcfg, v.trans, v.fbrake, v.rbrake, v.gvw
FROM (VALUES
 ('EPL20','EPL20-STD','ePL 2.0 Standard','Confirmed','3W','Passenger',NULL,
    'PMSM',10.0,60.0,'Li-ion',10.6,'Fixed',NULL,'Hydraulic Drum','Hydraulic Drum',NULL::numeric),
 ('EPL20R','EPL20R-STD','ePL 2.0 R','Confirmed','3W','Passenger',NULL,
    'PMSM',10.0,60.0,'Li-ion',10.6,'Fixed',NULL,'Hydraulic Drum','Hydraulic Drum',NULL),
 ('SCARGO','SCARGO-CGO','Super Cargo','Confirmed','3W','Cargo',NULL,
    'Advanced PMSM',12.0,70.0,'Li-ion',NULL,'Fixed',NULL,'Disc','Drum',NULL),
 ('EVI350','EVI350-32','EVIATOR 350 — 32 kWh','Confirmed','4x2','Cargo','2WD',
    'PMSM',NULL,NULL,'LFP',32.0,'Fixed',NULL,'Disc','Drum',3490),
 ('EVICORE','EVICORE-40','EVIATOR core — 40 kWh','Confirmed','4x2','Cargo','2WD',
    'PMSM',NULL,NULL,'LFP',40.0,'Fixed',NULL,'Disc','Drum',3490),
 ('EVI350LP','EVI350LP-50','EVIATOR 350L+ — 50 kWh','Confirmed','4x2','Cargo','2WD',
    'PMSM',NULL,NULL,'LFP',50.0,'Fixed',NULL,'Disc','Drum',3490),
 ('RH5538','RH5538-4X2','Rhino 5538 EV 4x2 Tractor Trailer','Confirmed','4x2','Tractor Trailer','2WD',
    'PMSM',280.0,2000.0,'LFP',282.0,'Fixed/Swappable','6-speed AMT','Air Disc','Air Drum',55000),
 ('RH5538','RH5538-6X4','Rhino 5538 EV 6x4 Tractor Trailer','Confirmed','6x4','Tractor Trailer','6x4',
    'PMSM',280.0,2000.0,'LFP',282.0,'Fixed/Swappable','6-speed AMT','Air Disc','Air Drum',55000),
 ('RH2838','RH2838-TIP','Rhino 2838 EV Tipper','Placeholder','6x4','Tipper',NULL,
    NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
 ('E27','E27-2WD','E-27 2WD','Confirmed',NULL,'Tractor','2WD',
    'PMSM',NULL,NULL,'LFP',22.37,'Fixed','8F + 2R',NULL,NULL,NULL),
 ('E27','E27-4WD','E-27 4WD','Confirmed',NULL,'Tractor','4WD',
    'PMSM',NULL,NULL,'LFP',22.37,'Fixed','8F + 2R',NULL,NULL,NULL),
 ('E45','E45-STD','E-45 (specification to confirm)','Placeholder',NULL,'Tractor',NULL,
    NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL)
) AS v(model,code,name,conf,axle,body,drive,motor,pkw,ptq,chem,kwh,batcfg,trans,fbrake,rbrake,gvw)
JOIN master.vehicle_model m ON m.code = v.model;

-- ---------------------------------------------------------------------
-- Availability state / reason master (Doc 02 §24.1, FR-AVL-002)
-- ---------------------------------------------------------------------
INSERT INTO uptime.vehicle_status_reason
 (reason_code, availability_state, category, is_down, planned_class, default_attribution,
  pause_eligible, include_in_sla, include_in_availability, source_precedence) VALUES
 ('IN_SERVICE',       'In Service',                        'Available','false','NotApplicable','None',      false,true, true, 10),
 ('IDLE',             'Idle',                              'Available','false','NotApplicable','Customer',  false,true, true, 10),
 ('OFF_HIRE',         'Off Hire/Suspended',                'OffHire',  'true', 'Planned',    'Customer',    false,false,false,80),
 ('DOWN_PM',          'Down-PM',                           'PM',       'true', 'Planned',    'Montra',      false,true, true, 50),
 ('DOWN_BREAKDOWN',   'Down-Breakdown',                    'Breakdown','true', 'Unplanned',  'Montra',      false,true, true, 90),
 ('DOWN_PARTS',       'Down-Awaiting Parts',               'Parts',    'true', 'Unplanned',  'Supplier',    true, true, true, 60),
 ('DOWN_CUST_APPR',   'Down-Awaiting Customer Approval',   'Customer', 'true', 'Unplanned',  'Customer',    true, false,true, 60),
 ('DOWN_WAR_DEC',     'Down-Awaiting Warranty Decision',   'Warranty', 'true', 'Unplanned',  'Montra',      true, false,true, 60),
 ('DOWN_INT_AUTH',    'Down-Awaiting Internal Authorization','Internal','true','Unplanned',  'Montra',      true, false,true, 60),
 ('DOWN_ACCIDENT',    'Down-Accident',                     'Accident', 'true', 'Unplanned',  'External',    false,false,true, 70),
 ('DOWN_COMPLIANCE',  'Down-Compliance',                   'Compliance','true','Unplanned',  'Customer',    false,false,true, 70),
 ('DOWN_CHARGING',    'Down-Charging Infrastructure',      'Charging', 'true', 'Unplanned',  'External',    false,false,true, 40),
 ('RETIRED',          'Retired',                           'Lifecycle','true', 'Planned',    'None',        false,false,false,99);

-- ---------------------------------------------------------------------
-- SLA master (FR-SLA-001)
-- ---------------------------------------------------------------------
INSERT INTO service.sla_master (code, service_type, priority, calendar_id, response_minutes, on_site_minutes, restore_minutes, release_minutes)
SELECT v.code, v.stype, v.pri,
       (SELECT calendar_id FROM master.business_calendar WHERE code = v.cal),
       v.resp, v.onsite, v.restore, v.release
FROM (VALUES
 ('SLA-BD-P1','Breakdown','P1','CAL-24X7',  30,  120,  480,  600),
 ('SLA-BD-P2','Breakdown','P2','CAL-24X7',  60,  360, 1440, 1560),
 ('SLA-BD-P3','Breakdown','P3','CAL-STD',  240, 1440, 2880, 3000),
 ('SLA-PM-STD','PM',NULL,'CAL-STD',        480, NULL,  960, 1080)
) AS v(code,stype,pri,cal,resp,onsite,restore,release);

-- BL-BD-014 repeat failure rule
INSERT INTO service.repeat_failure_rule (code, match_keys, day_window, km_window, exclusions) VALUES
 ('RPT-DEFAULT', ARRAY['complaint_code','subsystem'], 30, 2000,
  'Excludes accident, no-fault-found and customer-damage events');

-- ---------------------------------------------------------------------
-- Failure / complaint codes (Doc 1.1 §22)
-- ---------------------------------------------------------------------
INSERT INTO master.failure_code (code, code_type, description, subsystem) VALUES
 ('CMP-NOSTART','Complaint','Vehicle not starting','Battery/HV'),
 ('CMP-NOPOWER','Complaint','Loss of power while driving','Motor'),
 ('CMP-CHARGE','Complaint','Charging issue','Charging'),
 ('CMP-WARNLAMP','Complaint','Warning lamp illuminated','Electrical'),
 ('CMP-BRAKE','Complaint','Brake performance concern','Brakes'),
 ('CMP-NOISE','Complaint','Abnormal noise or vibration','Motor'),
 ('CMP-OVERHEAT','Complaint','Overheating indication','Battery/HV'),
 ('CMP-TYRE','Complaint','Tyre damage or puncture','Tyres'),
 ('SUB-BATTERY','Subsystem','Battery / High Voltage','Battery/HV'),
 ('SUB-MOTOR','Subsystem','Motor / Inverter / Controller','Motor'),
 ('SUB-CHARGING','Subsystem','Charging System','Charging'),
 ('SUB-BRAKES','Subsystem','Brake System','Brakes'),
 ('SUB-SUSP','Subsystem','Steering & Suspension','Suspension'),
 ('SUB-TYRE','Subsystem','Tyres & Wheels','Tyres'),
 ('SUB-ELEC','Subsystem','Low Voltage Electrical','Electrical'),
 ('SUB-TRANS','Subsystem','Transmission / Driveline','Transmission'),
 ('SUB-BODY','Subsystem','Body / Cabin / Chassis','Body'),
 ('FM-CELL-IMBAL','FailureMode','Cell imbalance beyond limit','Battery/HV'),
 ('FM-HV-CONN','FailureMode','HV connector degradation','Battery/HV'),
 ('FM-COOLANT-LEAK','FailureMode','Coolant leakage','Battery/HV'),
 ('FM-CTRL-FAULT','FailureMode','Controller fault','Motor'),
 ('FM-PAD-WEAR','FailureMode','Brake pad worn beyond limit','Brakes'),
 ('FM-FUSE-BLOWN','FailureMode','Fuse failure','Electrical'),
 ('RC-COMPONENT','RootCause','Component failure',NULL),
 ('RC-WEAR','RootCause','Normal wear and tear',NULL),
 ('RC-MISUSE','RootCause','Operating outside specification',NULL),
 ('RC-INSTALL','RootCause','Incorrect previous repair or fitment',NULL),
 ('RC-SOFTWARE','RootCause','Software or calibration issue',NULL),
 ('RC-EXTERNAL','RootCause','External or environmental cause',NULL),
 ('RC-NFF','RootCause','No fault found',NULL),
 ('CA-REPAIR','CorrectiveAction','Repaired',NULL),
 ('CA-REPLACE','CorrectiveAction','Component replaced',NULL),
 ('CA-ADJUST','CorrectiveAction','Adjusted / calibrated',NULL),
 ('CA-SOFTWARE','CorrectiveAction','Software update applied',NULL),
 ('CA-TOW','CorrectiveAction','Recovered / towed',NULL),
 ('CA-NFF','CorrectiveAction','No fault found — advised',NULL);

-- ---------------------------------------------------------------------
-- Spare parts master (Doc 1.1 §18.1 categories)
-- ---------------------------------------------------------------------
INSERT INTO master.part_master
 (part_no, erp_material_code, description, part_category, subcategory, criticality, part_class,
  base_uom, is_serial_controlled, warranty_return_required, standard_cost) VALUES
 ('BP-7T-001','MAT-100001','Battery Pack Assembly 282 kWh LFP','Battery & HV','Battery Pack','Critical','RepairSpare','Nos',true,true,1850000),
 ('TM-100K','MAT-100002','Traction Motor 280 kW PMSM','Motor / Inverter / Controller','Motor','Critical','RepairSpare','Nos',true,true,420000),
 ('MC-7T-001','MAT-100003','Motor Controller / Inverter 100 kW','Motor / Inverter / Controller','Controller','Critical','RepairSpare','Nos',true,true,185000),
 ('DCDC-002','MAT-100004','DC-DC Converter','Motor / Inverter / Controller','Converter','Major','RepairSpare','Nos',true,true,42000),
 ('OBC-7T','MAT-100005','On-board Charger','Charging System','Charger','Major','RepairSpare','Nos',true,true,68000),
 ('HVJB-01','MAT-100006','HV Battery Junction Box','Battery & HV','Junction Box','Critical','RepairSpare','Nos',true,true,35000),
 ('HVF-100','MAT-100007','HV Fuse 100A','Battery & HV','Fuse','Critical','Both','Nos',false,false,4200),
 ('HVC-CONN','MAT-100008','HV Connector Set','Battery & HV','Connector','Major','RepairSpare','Set',false,false,8500),
 ('CLNT-5L','MAT-100009','Battery Coolant (approved grade) 5L','Battery Cooling / Thermal','Coolant','Major','PMConsumable','Litre',false,false,1850),
 ('CLP-PUMP','MAT-100010','Coolant Pump','Battery Cooling / Thermal','Pump','Major','RepairSpare','Nos',false,false,18500),
 ('BRP-HD-01','MAT-100011','Brake Pad Set — Heavy Duty Front','Brake System','Pads','Critical','Both','Set',false,false,9800),
 ('BRL-HD-01','MAT-100012','Brake Lining Set — Rear Drum','Brake System','Lining','Critical','Both','Set',false,false,7600),
 ('BRCH-01','MAT-100013','Brake Chamber','Brake System','Chamber','Critical','RepairSpare','Nos',false,false,5400),
 ('AUX-BAT-12V','MAT-100014','12V Auxiliary Battery','Low-Voltage Electrical','Battery','Major','Both','Nos',false,false,7200),
 ('FUSE-KIT','MAT-100015','LV Fuse & Relay Kit','Low-Voltage Electrical','Fuse','Minor','PMConsumable','Set',false,false,950),
 ('LAMP-HL','MAT-100016','Headlamp Assembly','Low-Voltage Electrical','Lamp','Minor','RepairSpare','Nos',false,false,4800),
 ('TY-10R20','MAT-100017','Tyre 10R20 Radial','Tyres & Wheels','Tyre','Major','Both','Nos',false,false,22500),
 ('WN-M22','MAT-100018','Wheel Nut M22','Tyres & Wheels','Fastener','Minor','PMConsumable','Nos',false,false,180),
 ('UB-HD-01','MAT-100019','U-Bolt Set — Heavy Duty','Steering & Suspension','Fastener','Major','Both','Set',false,false,3200),
 ('SHK-ABS-01','MAT-100020','Shock Absorber','Steering & Suspension','Damper','Major','RepairSpare','Nos',false,false,6800),
 ('AMT-OIL-20L','MAT-100021','AMT Transmission Oil 20L','Axle / Driveline / Transmission','Lubricant','Major','PMConsumable','Litre',false,false,420),
 ('WPR-BLD','MAT-100022','Wiper Blade Pair','Body / Cabin / Chassis','Wiper','Minor','PMConsumable','Set',false,false,890),
 ('MIRR-01','MAT-100023','Rear View Mirror','Body / Cabin / Chassis','Mirror','Minor','RepairSpare','Nos',false,false,2400),
 ('PTO-SEAL','MAT-100024','PTO Shaft Seal','Tractor PTO & Hydraulics','Seal','Major','Both','Nos',false,false,1250),
 ('HYD-OIL-10L','MAT-100025','Hydraulic Oil (approved grade) 10L','Tractor PTO & Hydraulics','Oil','Major','PMConsumable','Litre',false,false,680),
 ('GRS-500G','MAT-100026','Multipurpose Grease 500g','Consumables','Grease','Minor','PMConsumable','Nos',false,false,320),
 ('CBL-CLAMP','MAT-100027','Cable Clamp','Consumables','Fastener','Minor','PMConsumable','Nos',false,false,45);

-- Universal PM consumables apply to every variant; the rest are mapped by family
INSERT INTO master.part_applicability (part_id, is_universal)
SELECT part_id, true FROM master.part_master
WHERE part_no IN ('GRS-500G','CBL-CLAMP','FUSE-KIT','WPR-BLD','WN-M22');

INSERT INTO master.part_applicability (part_id, variant_id)
SELECT p.part_id, vv.variant_id
FROM master.part_master p
JOIN master.vehicle_variant vv ON true
JOIN master.vehicle_model vm ON vm.model_id = vv.model_id
WHERE (p.part_no IN ('BP-7T-001','TM-100K','MC-7T-001','DCDC-002','OBC-7T','HVJB-01','HVF-100',
                     'HVC-CONN','CLNT-5L','CLP-PUMP','BRP-HD-01','BRL-HD-01','BRCH-01',
                     'TY-10R20','UB-HD-01','SHK-ABS-01','AMT-OIL-20L','AUX-BAT-12V','LAMP-HL','MIRR-01')
       AND vm.code IN ('RH5538','RH2838'))
   OR (p.part_no IN ('AUX-BAT-12V','LAMP-HL','MIRR-01','BRP-HD-01','SHK-ABS-01','CLNT-5L','HVF-100')
       AND vm.code IN ('EVI350','EVICORE','EVI350LP'))
   OR (p.part_no IN ('AUX-BAT-12V','LAMP-HL','HVF-100','CLNT-5L')
       AND vm.code IN ('EPL20','EPL20R','SCARGO'))
   OR (p.part_no IN ('PTO-SEAL','HYD-OIL-10L','AUX-BAT-12V','HVF-100','CLNT-5L')
       AND vm.code IN ('E27','E45'));

-- ---------------------------------------------------------------------
-- Warranty rules (Doc 1.1 §23)  — illustrative, pending Montra approval
-- ---------------------------------------------------------------------
INSERT INTO commercial.warranty_rule (code, name, scope_type, component_type, max_age_months, max_km, exclusions, evidence_required)
VALUES
 ('WR-VEH-STD','Standard vehicle warranty','Vehicle',NULL,36,150000,
   'Excludes consumables, accident damage, unauthorised modification and operation outside specification',
   'Job card, diagnosis, photographs'),
 ('WR-BATT','Traction battery warranty','Component','BatteryPack',96,500000,
   'Excludes capacity loss within specification, external damage and non-approved charging',
   'SoH reading, diagnostic log, photographs'),
 ('WR-MOTOR','Traction motor warranty','Component','TractionMotor',60,300000,
   'Excludes water ingress and impact damage','Diagnosis, failed part return'),
 ('WR-CTRL','Motor controller warranty','Component','MotorController',36,150000,
   'Excludes voltage abuse and external short circuit','Diagnosis, failed part return');

-- ---------------------------------------------------------------------
-- QC / release checklists (Doc 1.1 §27, QC-001)
-- ---------------------------------------------------------------------
INSERT INTO quality.qc_checklist (code, name, service_type) VALUES
 ('QC-PM-STD','Standard PM Release Check','PM'),
 ('QC-BD-STD','Breakdown Repair Release Check','Breakdown');

INSERT INTO quality.qc_checklist_item (qc_checklist_id, code, description, is_mandatory, display_order)
SELECT c.qc_checklist_id, v.code, v.descr, v.mand, v.ord
FROM (VALUES
 ('QC-PM-STD','QC-CHKLIST','All mandatory checklist items completed',true,1),
 ('QC-PM-STD','QC-DEFECT','No unresolved release-blocking defect',true,2),
 ('QC-PM-STD','QC-REPAIR','Corrective work verified; replaced parts and serials confirmed',true,3),
 ('QC-PM-STD','QC-DTC','Relevant DTC cleared or disposition recorded',true,4),
 ('QC-PM-STD','QC-FUNC','Functional test — brakes, steering, charging, propulsion',true,5),
 ('QC-PM-STD','QC-LEAK','Fluid / coolant / air leakage and HV safety check',true,6),
 ('QC-PM-STD','QC-DOC','Photographs, readings and technician notes complete',true,7),
 ('QC-PM-STD','QC-ROADTEST','Road test completed where required',false,8),
 ('QC-BD-STD','QC-CHKLIST','All mandatory checklist items completed',true,1),
 ('QC-BD-STD','QC-DEFECT','No unresolved release-blocking defect',true,2),
 ('QC-BD-STD','QC-RETEST','Reported complaint verified as resolved',true,3),
 ('QC-BD-STD','QC-RCA','Root cause and corrective action recorded',true,4),
 ('QC-BD-STD','QC-FUNC','Functional test of affected system',true,5),
 ('QC-BD-STD','QC-LEAK','Leakage and HV safety check',true,6),
 ('QC-BD-STD','QC-ROADTEST','Road test completed where required',false,7)
) AS v(chk,code,descr,mand,ord)
JOIN quality.qc_checklist c ON c.code = v.chk;

-- ---------------------------------------------------------------------
-- Role → permission grants (FR-AUTH-001)
-- ---------------------------------------------------------------------
INSERT INTO security.role_permission (role_id, permission_id)
SELECT r.role_id, p.permission_id FROM security.role r CROSS JOIN security.permission p
WHERE (r.code='MASTER_DATA_ADMIN')
   OR (r.code='SC_MANAGER' AND p.action_code IN ('vehicle.read','pm.schedule','appointment.book','appointment.override_capacity','jobcard.create','jobcard.execute','jobcard.transition','jobcard.reopen','breakdown.triage','breakdown.downgrade_p1','usage.correct','parts.issue'))
   OR (r.code='TECHNICIAN' AND p.action_code IN ('vehicle.read','jobcard.execute','jobcard.transition'))
   OR (r.code='QC_SUPERVISOR' AND p.action_code IN ('vehicle.read','qc.perform','qc.release','qc.remote','concession.approve','jobcard.transition'))
   OR (r.code='SERVICE_COORD' AND p.action_code IN ('vehicle.read','pm.schedule','appointment.book','breakdown.create','breakdown.triage','breakdown.downgrade_p1','offhire.set','availability.correct','jobcard.create'))
   OR (r.code='STORES' AND p.action_code IN ('vehicle.read','parts.issue'))
   OR (r.code='WARRANTY_USER' AND p.action_code IN ('vehicle.read','warranty.decide','warranty.override'))
   OR (r.code='FLEET_CUSTOMER' AND p.action_code IN ('vehicle.read','breakdown.create','estimate.approve'))
   OR (r.code='ENGINEERING' AND p.action_code IN ('vehicle.read','config.author','config.publish','pm.override_next','concession.approve'))
   OR (r.code='MANAGEMENT' AND p.action_code IN ('vehicle.read'))
ON CONFLICT DO NOTHING;
