/**
 * Minimal PostgreSQL client — PostgreSQL frontend/backend protocol v3.
 *
 * Written against Node's standard library only (node:net, node:tls,
 * node:crypto) because this build environment has no access to the npm
 * registry. Supports the subset the application needs:
 *
 *   - TCP and TLS (SSLRequest negotiation, required by Render Postgres)
 *   - trust, cleartext, MD5 and SCRAM-SHA-256 authentication
 *   - extended query protocol with bound parameters (no SQL injection)
 *   - simple query protocol for multi-statement scripts
 *   - a small connection pool with transaction support
 *
 * If the production .NET build proceeds, this file is replaced by
 * Npgsql / EF Core and nothing above the Db interface changes.
 */

import * as net from 'node:net';
import * as tls from 'node:tls';
import * as crypto from 'node:crypto';
import { EventEmitter } from 'node:events';

// ---------------------------------------------------------------------
// Wire-format helpers
// ---------------------------------------------------------------------

class Writer {
  private chunks: Buffer[] = [];
  int32(n: number) { const b = Buffer.allocUnsafe(4); b.writeInt32BE(n, 0); this.chunks.push(b); return this; }
  int16(n: number) { const b = Buffer.allocUnsafe(2); b.writeInt16BE(n, 0); this.chunks.push(b); return this; }
  byte(n: number) { this.chunks.push(Buffer.from([n])); return this; }
  cstr(s: string) { this.chunks.push(Buffer.from(s, 'utf8'), Buffer.from([0])); return this; }
  raw(b: Buffer) { this.chunks.push(b); return this; }
  build(): Buffer { return Buffer.concat(this.chunks); }
}

/** Frame a message with its type byte and length prefix. */
function frame(type: string | null, body: Buffer): Buffer {
  const len = Buffer.allocUnsafe(4);
  len.writeInt32BE(body.length + 4, 0);
  return type ? Buffer.concat([Buffer.from(type, 'ascii'), len, body]) : Buffer.concat([len, body]);
}

class Reader {
  private buf: Buffer;
  private pos: number;
  constructor(buf: Buffer, pos = 0) { this.buf = buf; this.pos = pos; }
  int32() { const v = this.buf.readInt32BE(this.pos); this.pos += 4; return v; }
  int16() { const v = this.buf.readInt16BE(this.pos); this.pos += 2; return v; }
  byte() { return this.buf[this.pos++]; }
  cstr() {
    const end = this.buf.indexOf(0, this.pos);
    const s = this.buf.toString('utf8', this.pos, end);
    this.pos = end + 1;
    return s;
  }
  bytes(n: number) { const b = this.buf.subarray(this.pos, this.pos + n); this.pos += n; return b; }
  rest() { return this.buf.subarray(this.pos); }
  get remaining() { return this.buf.length - this.pos; }
}

// ---------------------------------------------------------------------
// Value decoding by type OID (text format)
// ---------------------------------------------------------------------

const OID = {
  BOOL: 16, BYTEA: 17, INT8: 20, INT2: 21, INT4: 23, TEXT: 25, JSON: 114,
  FLOAT4: 700, FLOAT8: 701, VARCHAR: 1043, DATE: 1082, TIME: 1083,
  TIMESTAMP: 1114, TIMESTAMPTZ: 1184, NUMERIC: 1700, JSONB: 3802,
  INT2_ARR: 1005, INT4_ARR: 1007, TEXT_ARR: 1009, VARCHAR_ARR: 1015, INT8_ARR: 1016,
};

/** Parse Postgres array literal: {a,b,"c,d",NULL} */
function parseArray(src: string): (string | null)[] {
  if (!src.startsWith('{') || !src.endsWith('}')) return [];
  const inner = src.slice(1, -1);
  if (inner === '') return [];
  const out: (string | null)[] = [];
  let cur = '', quoted = false, escaped = false;
  for (let i = 0; i < inner.length; i++) {
    const ch = inner[i];
    if (escaped) { cur += ch; escaped = false; continue; }
    if (ch === '\\') { escaped = true; continue; }
    if (ch === '"') { quoted = !quoted; continue; }
    if (ch === ',' && !quoted) {
      out.push(cur === 'NULL' ? null : cur);
      cur = '';
      continue;
    }
    cur += ch;
  }
  out.push(cur === 'NULL' ? null : cur);
  return out;
}

function decode(raw: Buffer | null, oid: number): unknown {
  if (raw === null) return null;
  const s = raw.toString('utf8');
  switch (oid) {
    case OID.BOOL: return s === 't';
    case OID.INT2: case OID.INT4: return parseInt(s, 10);
    case OID.INT8: {
      const n = Number(s);
      return Number.isSafeInteger(n) ? n : s;
    }
    case OID.FLOAT4: case OID.FLOAT8: return parseFloat(s);
    case OID.NUMERIC: {
      const n = parseFloat(s);
      return Number.isFinite(n) ? n : s;
    }
    case OID.JSON: case OID.JSONB:
      try { return JSON.parse(s); } catch { return s; }
    case OID.TIMESTAMP: case OID.TIMESTAMPTZ: {
      const d = new Date(oid === OID.TIMESTAMP ? s + 'Z' : s);
      return isNaN(d.getTime()) ? s : d;
    }
    case OID.DATE: return s;
    case OID.BYTEA:
      return s.startsWith('\\x') ? Buffer.from(s.slice(2), 'hex') : Buffer.from(s, 'utf8');
    case OID.INT2_ARR: case OID.INT4_ARR: case OID.INT8_ARR:
      return parseArray(s).map(v => (v === null ? null : parseInt(v, 10)));
    case OID.TEXT_ARR: case OID.VARCHAR_ARR:
      return parseArray(s);
    default: return s;
  }
}

/** Encode a JS value as a text-format parameter. */
function encodeParam(v: unknown): Buffer | null {
  if (v === null || v === undefined) return null;
  if (Buffer.isBuffer(v)) return Buffer.from('\\x' + v.toString('hex'), 'utf8');
  if (v instanceof Date) return Buffer.from(v.toISOString(), 'utf8');
  if (Array.isArray(v)) {
    const items = v.map(item => {
      if (item === null || item === undefined) return 'NULL';
      const s = String(item);
      return '"' + s.replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"';
    });
    return Buffer.from('{' + items.join(',') + '}', 'utf8');
  }
  if (typeof v === 'object') return Buffer.from(JSON.stringify(v), 'utf8');
  if (typeof v === 'boolean') return Buffer.from(v ? 't' : 'f', 'utf8');
  return Buffer.from(String(v), 'utf8');
}

// ---------------------------------------------------------------------
// Errors and results
// ---------------------------------------------------------------------

export class PgError extends Error {
  severity?: string; code?: string; detail?: string;
  constraint?: string; table?: string; column?: string;
  constructor(fields: Record<string, string>) {
    super(fields.M || 'PostgreSQL error');
    this.name = 'PgError';
    this.severity = fields.S;
    this.code = fields.C;
    this.detail = fields.D;
    this.constraint = fields.n;
    this.table = fields.t;
    this.column = fields.c;
  }
}

export interface QueryResult<T = Record<string, any>> {
  rows: T[];
  rowCount: number;
  command: string;
}

export interface PgConfig {
  host: string; port: number; user: string; password: string;
  database: string; ssl: boolean | { rejectUnauthorized: boolean };
  connectionTimeoutMs?: number;
  applicationName?: string;
}

// ---------------------------------------------------------------------
// Connection
// ---------------------------------------------------------------------

type PendingOp = {
  resolve: (r: QueryResult) => void;
  reject: (e: Error) => void;
  rows: any[];
  fields: { name: string; oid: number }[];
  command: string;
  rowCount: number;
};

export class Connection extends EventEmitter {
  private socket!: net.Socket | tls.TLSSocket;
  private buffer = Buffer.alloc(0);
  private pending: PendingOp | null = null;
  private queue: (() => void)[] = [];
  private connectResolve?: () => void;
  private connectReject?: (e: Error) => void;
  private scram?: { clientNonce: string; clientFirstBare: string; saltedPassword?: Buffer; authMessage?: string };
  public ready = false;
  public broken = false;
  private cfg: PgConfig;

  constructor(cfg: PgConfig) { super(); this.cfg = cfg; }

  async connect(): Promise<void> {
    return new Promise((resolve, reject) => {
      this.connectResolve = resolve;
      this.connectReject = reject;
      const timeout = setTimeout(
        () => reject(new Error('PostgreSQL connection timed out')),
        this.cfg.connectionTimeoutMs ?? 15000,
      );
      const done = () => clearTimeout(timeout);
      this.once('ready', done);
      this.once('fatal', done);

      const raw = net.connect({ host: this.cfg.host, port: this.cfg.port });
      raw.on('error', e => this.fail(e));

      if (this.cfg.ssl) {
        raw.once('connect', () => {
          // SSLRequest: length 8, magic 80877103
          const req = Buffer.allocUnsafe(8);
          req.writeInt32BE(8, 0);
          req.writeInt32BE(80877103, 4);
          raw.write(req);
        });
        raw.once('data', (d: Buffer) => {
          if (d[0] === 0x53 /* 'S' */) {
            const opts = typeof this.cfg.ssl === 'object' ? this.cfg.ssl : { rejectUnauthorized: false };
            const secure = tls.connect({ socket: raw, ...opts, servername: this.cfg.host });
            secure.on('error', e => this.fail(e));
            secure.on('data', c => this.onData(c));
            secure.on('close', () => { this.broken = true; this.emit('close'); });
            secure.once('secureConnect', () => { this.socket = secure; this.sendStartup(); });
          } else {
            this.fail(new Error('Server refused TLS but ssl was required'));
          }
        });
      } else {
        raw.on('data', c => this.onData(c));
        raw.on('close', () => { this.broken = true; this.emit('close'); });
        raw.once('connect', () => { this.socket = raw; this.sendStartup(); });
      }
    });
  }

  private fail(e: Error) {
    this.broken = true;
    if (this.pending) { this.pending.reject(e); this.pending = null; }
    if (this.connectReject && !this.ready) this.connectReject(e);
    this.emit('fatal', e);
  }

  private send(buf: Buffer) { this.socket.write(buf); }

  private sendStartup() {
    const w = new Writer()
      .int32(196608) // protocol 3.0
      .cstr('user').cstr(this.cfg.user)
      .cstr('database').cstr(this.cfg.database)
      .cstr('application_name').cstr(this.cfg.applicationName ?? 'montra-fleet')
      .cstr('client_encoding').cstr('UTF8')
      .byte(0);
    this.send(frame(null, w.build()));
  }

  private onData(chunk: Buffer) {
    this.buffer = this.buffer.length ? Buffer.concat([this.buffer, chunk]) : chunk;
    while (this.buffer.length >= 5) {
      const len = this.buffer.readInt32BE(1);
      if (this.buffer.length < len + 1) break;
      const type = String.fromCharCode(this.buffer[0]);
      const body = this.buffer.subarray(5, len + 1);
      this.buffer = this.buffer.subarray(len + 1);
      try { this.handle(type, body); } catch (e) { this.fail(e as Error); return; }
    }
  }

  private handle(type: string, body: Buffer) {
    const r = new Reader(body);
    switch (type) {
      case 'R': return this.handleAuth(r);
      case 'S': return; // ParameterStatus
      case 'K': return; // BackendKeyData
      case 'Z': {      // ReadyForQuery
        if (!this.ready) {
          this.ready = true;
          this.connectResolve?.();
          this.emit('ready');
        }
        if (this.pending) {
          const p = this.pending;
          this.pending = null;
          p.resolve({ rows: p.rows, rowCount: p.rowCount, command: p.command });
        }
        const next = this.queue.shift();
        if (next) next();
        return;
      }
      case 'T': { // RowDescription
        const n = r.int16();
        const fields: { name: string; oid: number }[] = [];
        for (let i = 0; i < n; i++) {
          const name = r.cstr();
          r.int32(); r.int16();        // table oid, column attr
          const oid = r.int32();
          r.int16(); r.int32(); r.int16(); // typlen, typmod, format
          fields.push({ name, oid });
        }
        if (this.pending) this.pending.fields = fields;
        return;
      }
      case 'D': { // DataRow
        if (!this.pending) return;
        const n = r.int16();
        const row: Record<string, unknown> = {};
        for (let i = 0; i < n; i++) {
          const size = r.int32();
          const raw = size === -1 ? null : r.bytes(size);
          const f = this.pending.fields[i];
          if (f) row[f.name] = decode(raw, f.oid);
        }
        this.pending.rows.push(row);
        return;
      }
      case 'C': { // CommandComplete
        if (!this.pending) return;
        const tag = r.cstr();
        this.pending.command = tag.split(' ')[0];
        const parts = tag.split(' ');
        const last = parseInt(parts[parts.length - 1], 10);
        this.pending.rowCount = Number.isFinite(last) ? last : this.pending.rows.length;
        if (this.pending.rows.length) this.pending.rowCount = this.pending.rows.length;
        return;
      }
      case 'E': { // ErrorResponse
        const fields: Record<string, string> = {};
        while (r.remaining > 1) {
          const code = String.fromCharCode(r.byte());
          if (code === '\0') break;
          fields[code] = r.cstr();
        }
        const err = new PgError(fields);
        if (this.pending) { this.pending.reject(err); this.pending = null; }
        else if (!this.ready) this.fail(err);
        else this.emit('error', err);
        return;
      }
      case 'N': return;   // NoticeResponse
      case '1': case '2': case '3': case 'n': case 's': return; // Parse/Bind/Close complete, NoData, PortalSuspended
      case 'I': if (this.pending) this.pending.command = 'EMPTY'; return;
      case 'A': return;   // NotificationResponse
      default: return;
    }
  }

  private handleAuth(r: Reader) {
    const kind = r.int32();
    switch (kind) {
      case 0: return;                                  // AuthenticationOk
      case 3:                                          // Cleartext
        return this.send(frame('p', new Writer().cstr(this.cfg.password).build()));
      case 5: {                                        // MD5
        const salt = r.bytes(4);
        const md5 = (b: crypto.BinaryLike) => crypto.createHash('md5').update(b).digest('hex');
        const inner = md5(this.cfg.password + this.cfg.user);
        const outer = md5(Buffer.concat([Buffer.from(inner, 'utf8'), salt]));
        return this.send(frame('p', new Writer().cstr('md5' + outer).build()));
      }
      case 10: {                                       // SASL
        const mechanisms: string[] = [];
        while (r.remaining > 1) {
          const m = r.cstr();
          if (!m) break;
          mechanisms.push(m);
        }
        if (!mechanisms.includes('SCRAM-SHA-256')) {
          return this.fail(new Error('Server requires unsupported SASL mechanism: ' + mechanisms.join(',')));
        }
        const clientNonce = crypto.randomBytes(18).toString('base64');
        const clientFirstBare = `n=*,r=${clientNonce}`;
        this.scram = { clientNonce, clientFirstBare };
        const initial = Buffer.from('n,,' + clientFirstBare, 'utf8');
        const w = new Writer().cstr('SCRAM-SHA-256').int32(initial.length).raw(initial);
        return this.send(frame('p', w.build()));
      }
      case 11: {                                       // SASLContinue
        const serverFirst = r.rest().toString('utf8');
        const attrs = Object.fromEntries(
          serverFirst.split(',').map(kv => [kv.slice(0, kv.indexOf('=')), kv.slice(kv.indexOf('=') + 1)]),
        );
        const nonce = attrs.r, salt = Buffer.from(attrs.s, 'base64'), iterations = parseInt(attrs.i, 10);
        if (!nonce.startsWith(this.scram!.clientNonce)) return this.fail(new Error('SCRAM nonce mismatch'));

        const saltedPassword = crypto.pbkdf2Sync(this.cfg.password, salt, iterations, 32, 'sha256');
        const hmac = (key: Buffer, msg: string) => crypto.createHmac('sha256', key).update(msg, 'utf8').digest();
        const clientKey = hmac(saltedPassword, 'Client Key');
        const storedKey = crypto.createHash('sha256').update(clientKey).digest();
        const clientFinalNoProof = `c=biws,r=${nonce}`;
        const authMessage = `${this.scram!.clientFirstBare},${serverFirst},${clientFinalNoProof}`;
        const clientSignature = hmac(storedKey, authMessage);
        const proof = Buffer.alloc(clientKey.length);
        for (let i = 0; i < clientKey.length; i++) proof[i] = clientKey[i] ^ clientSignature[i];

        this.scram!.saltedPassword = saltedPassword;
        this.scram!.authMessage = authMessage;
        const final = `${clientFinalNoProof},p=${proof.toString('base64')}`;
        return this.send(frame('p', Buffer.from(final, 'utf8')));
      }
      case 12: {                                       // SASLFinal — verify server signature
        const serverFinal = r.rest().toString('utf8');
        const v = serverFinal.split(',').find(p => p.startsWith('v='))?.slice(2);
        const hmac = (key: Buffer, msg: string) => crypto.createHmac('sha256', key).update(msg, 'utf8').digest();
        const serverKey = hmac(this.scram!.saltedPassword!, 'Server Key');
        const expected = hmac(serverKey, this.scram!.authMessage!).toString('base64');
        if (v !== expected) return this.fail(new Error('SCRAM server signature verification failed'));
        return;
      }
      default:
        return this.fail(new Error('Unsupported authentication method: ' + kind));
    }
  }

  /** Extended query protocol — parameters are bound, never interpolated. */
  query<T = Record<string, any>>(sql: string, params: unknown[] = []): Promise<QueryResult<T>> {
    return new Promise((resolve, reject) => {
      const run = () => {
        if (this.broken) return reject(new Error('Connection is closed'));
        this.pending = { resolve: resolve as any, reject, rows: [], fields: [], command: '', rowCount: 0 };

        const parse = new Writer().cstr('').cstr(sql).int16(0).build();

        const bindW = new Writer().cstr('').cstr('').int16(0).int16(params.length);
        for (const p of params) {
          const enc = encodeParam(p);
          if (enc === null) bindW.int32(-1);
          else bindW.int32(enc.length).raw(enc);
        }
        bindW.int16(0); // all result columns in text format

        const describe = new Writer().byte(0x50 /* 'P' portal */).cstr('').build();
        const execute = new Writer().cstr('').int32(0).build();

        this.send(Buffer.concat([
          frame('P', parse),
          frame('B', bindW.build()),
          frame('D', describe),
          frame('E', execute),
          frame('S', Buffer.alloc(0)),
        ]));
      };
      if (this.pending) this.queue.push(run); else run();
    });
  }

  /** Simple query protocol — for multi-statement DDL scripts. No parameters. */
  simpleQuery(sql: string): Promise<QueryResult> {
    return new Promise((resolve, reject) => {
      const run = () => {
        if (this.broken) return reject(new Error('Connection is closed'));
        this.pending = { resolve, reject, rows: [], fields: [], command: '', rowCount: 0 };
        this.send(frame('Q', new Writer().cstr(sql).build()));
      };
      if (this.pending) this.queue.push(run); else run();
    });
  }

  end() {
    try { this.send(frame('X', Buffer.alloc(0))); this.socket.end(); } catch { /* already gone */ }
    this.broken = true;
  }
}

// ---------------------------------------------------------------------
// Pool
// ---------------------------------------------------------------------

export class Pool {
  private idle: Connection[] = [];
  private all: Connection[] = [];
  private waiters: ((c: Connection) => void)[] = [];
  private cfg: PgConfig;
  private max: number;

  constructor(cfg: PgConfig, max = 8) { this.cfg = cfg; this.max = max; }

  private async create(): Promise<Connection> {
    const c = new Connection(this.cfg);
    await c.connect();
    c.on('close', () => {
      this.all = this.all.filter(x => x !== c);
      this.idle = this.idle.filter(x => x !== c);
    });
    c.on('error', () => { /* surfaced per-query */ });
    this.all.push(c);
    return c;
  }

  async acquire(): Promise<Connection> {
    while (this.idle.length) {
      const c = this.idle.pop()!;
      if (!c.broken) return c;
    }
    if (this.all.length < this.max) return this.create();
    return new Promise(resolve => this.waiters.push(resolve));
  }

  release(c: Connection) {
    if (c.broken) {
      this.all = this.all.filter(x => x !== c);
      return;
    }
    const w = this.waiters.shift();
    if (w) w(c); else this.idle.push(c);
  }

  async query<T = Record<string, any>>(sql: string, params: unknown[] = []): Promise<QueryResult<T>> {
    const c = await this.acquire();
    try { return await c.query<T>(sql, params); }
    finally { this.release(c); }
  }

  /** Run a set of statements inside a transaction; rolls back on throw. */
  async transaction<T>(fn: (tx: Connection) => Promise<T>): Promise<T> {
    const c = await this.acquire();
    try {
      await c.query('BEGIN');
      const result = await fn(c);
      await c.query('COMMIT');
      return result;
    } catch (e) {
      try { await c.query('ROLLBACK'); } catch { /* connection may be gone */ }
      throw e;
    } finally {
      this.release(c);
    }
  }

  async runScript(sql: string): Promise<void> {
    const c = await this.acquire();
    try { await c.simpleQuery(sql); }
    finally { this.release(c); }
  }

  async end() {
    for (const c of this.all) c.end();
    this.all = []; this.idle = [];
  }
}

/** Build pool config from DATABASE_URL or discrete PG* variables. */
export function configFromEnv(): PgConfig {
  const url = process.env.DATABASE_URL;
  if (url) {
    const u = new URL(url);
    const sslDisabled = u.searchParams.get('sslmode') === 'disable';
    return {
      host: u.hostname,
      port: parseInt(u.port || '5432', 10),
      user: decodeURIComponent(u.username),
      password: decodeURIComponent(u.password),
      database: u.pathname.slice(1),
      // Render's managed Postgres presents a certificate signed by an
      // internal CA, so verification is relaxed while the channel stays encrypted.
      ssl: sslDisabled ? false : { rejectUnauthorized: false },
    };
  }
  return {
    host: process.env.PGHOST ?? '127.0.0.1',
    port: parseInt(process.env.PGPORT ?? '5432', 10),
    user: process.env.PGUSER ?? 'postgres',
    password: process.env.PGPASSWORD ?? '',
    database: process.env.PGDATABASE ?? 'montra',
    ssl: process.env.PGSSL === 'true',
  };
}
