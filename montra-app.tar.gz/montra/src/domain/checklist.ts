/**
 * Checklist execution and defect generation.
 *
 * Implements Document 02 BL-CHK-001..011 and Document 1.1 CHK-005..015:
 *   - the checklist version applied to a job is frozen at execution time
 *   - "Not OK" creates or requires a linked defect where configured
 *   - "Advisory-Observation" creates a VIN-owned deferred defect that does
 *     not block release but carries forward to later service
 *   - "Not Applicable" requires a reason where applicability is conditional
 *   - numeric readings are validated against configured min/max
 */

import { q, one, many, audit, nextDocumentNo } from '../lib/db.ts';
import type { Db } from '../lib/db.ts';

export type ResponseType =
  | 'OK' | 'Not OK' | 'Advisory-Observation' | 'Not Applicable' | 'Numeric' | 'Text' | 'Photo';

export interface ChecklistAnswer {
  itemId: number;
  responseType: ResponseType;
  numericValue?: number | null;
  textValue?: string | null;
  naReason?: string | null;
  photoRef?: string | null;
  clientOperationId?: string | null;
}

export interface AnswerOutcome {
  itemId: number;
  accepted: boolean;
  message?: string;
  defectId?: number;
  defectNo?: string;
  numericOutOfRange?: boolean;
}

/** The frozen checklist for a job card, with any answers already recorded. */
export async function getChecklistForJob(db: Db, jobCardId: number) {
  const exec = await one<any>(db, `
    SELECT pe.*, cv.version_no, ct.code AS template_code, ct.name AS template_name
    FROM pm.pm_execution pe
    JOIN pm.checklist_version cv ON cv.checklist_version_id = pe.frozen_checklist_version_id
    JOIN pm.checklist_template ct ON ct.template_id = cv.template_id
    WHERE pe.job_card_id = $1 LIMIT 1`, [jobCardId]);
  if (!exec) return null;

  const rows = await many<any>(db, `
    SELECT cs.section_id, cs.name AS section_name, cs.display_order AS section_order,
           ci.item_id, ci.code, ci.description, ci.inspection_method, ci.response_mode,
           ci.is_mandatory, ci.is_conditional, ci.unit, ci.min_value, ci.max_value, ci.target_value,
           ci.defect_severity_on_fail, ci.creates_defect_on_fail, ci.blocks_release_on_fail,
           ci.photo_required, ci.display_order,
           p.part_no AS recommended_part_no, p.description AS recommended_part_desc, ci.recommended_qty,
           cr.result_id, cr.response_type, cr.numeric_value, cr.text_value, cr.na_reason,
           cr.photo_ref, cr.recorded_at
    FROM pm.checklist_section cs
    JOIN pm.checklist_item ci ON ci.section_id = cs.section_id
    LEFT JOIN master.part_master p ON p.part_id = ci.recommended_part_id
    LEFT JOIN pm.checklist_result cr ON cr.item_id = ci.item_id AND cr.job_card_id = $2
    WHERE cs.checklist_version_id = $1
    ORDER BY cs.display_order, ci.display_order`,
    [exec.frozen_checklist_version_id, jobCardId]);

  const sections: any[] = [];
  for (const r of rows) {
    let section = sections.find(s => s.sectionId === r.section_id);
    if (!section) {
      section = { sectionId: r.section_id, name: r.section_name, order: r.section_order, items: [] };
      sections.push(section);
    }
    section.items.push({
      itemId: r.item_id, code: r.code, description: r.description,
      inspectionMethod: r.inspection_method, responseMode: r.response_mode,
      isMandatory: r.is_mandatory, isConditional: r.is_conditional,
      unit: r.unit, minValue: r.min_value, maxValue: r.max_value, targetValue: r.target_value,
      defectSeverityOnFail: r.defect_severity_on_fail,
      blocksReleaseOnFail: r.blocks_release_on_fail,
      photoRequired: r.photo_required,
      recommendedPart: r.recommended_part_no
        ? { partNo: r.recommended_part_no, description: r.recommended_part_desc, qty: r.recommended_qty }
        : null,
      answer: r.result_id ? {
        responseType: r.response_type, numericValue: r.numeric_value,
        textValue: r.text_value, naReason: r.na_reason, photoRef: r.photo_ref,
        recordedAt: r.recorded_at,
      } : null,
    });
  }

  const total = rows.length;
  const answered = rows.filter(r => r.result_id).length;
  const mandatoryTotal = rows.filter(r => r.is_mandatory && !r.is_conditional).length;
  const mandatoryAnswered = rows.filter(r => r.is_mandatory && !r.is_conditional && r.result_id).length;

  return {
    templateCode: exec.template_code,
    templateName: exec.template_name,
    checklistVersionId: exec.frozen_checklist_version_id,
    versionNo: exec.version_no,
    pmObligationId: exec.pm_obligation_id,
    progress: { total, answered, mandatoryTotal, mandatoryAnswered },
    sections,
  };
}

/**
 * Record one or more checklist answers. Idempotent per (job, item) so an
 * offline client can safely replay its queue (Doc 04 §18).
 */
export async function recordAnswers(db: Db, input: {
  jobCardId: number;
  answers: ChecklistAnswer[];
  technicianId?: number | null;
  actor: string;
}): Promise<AnswerOutcome[]> {
  const job = await one<any>(db, `
    SELECT jc.*, se.event_type FROM service.job_card jc
    JOIN service.service_event se ON se.service_event_id = jc.service_event_id
    WHERE jc.job_card_id = $1`, [input.jobCardId]);
  if (!job) throw new Error('Job card not found');

  // BL-JC-012: closed jobs are read-only.
  if (['Closed', 'Cancelled'].includes(job.status)) {
    const err: any = new Error(
      `Job ${job.job_card_no} is ${job.status.toLowerCase()} and can no longer be edited (BL-JC-012).`);
    err.code = 'JOB_READ_ONLY';
    throw err;
  }

  const exec = await one<any>(db, `
    SELECT * FROM pm.pm_execution WHERE job_card_id = $1 LIMIT 1`, [input.jobCardId]);

  const workItem = await one<any>(db, `
    SELECT work_item_id FROM service.work_item WHERE job_card_id = $1 ORDER BY line_no LIMIT 1`,
    [input.jobCardId]);

  const outcomes: AnswerOutcome[] = [];

  for (const a of input.answers) {
    const item = await one<any>(db, `
      SELECT ci.*, cs.checklist_version_id, cs.name AS section_name
      FROM pm.checklist_item ci JOIN pm.checklist_section cs ON cs.section_id = ci.section_id
      WHERE ci.item_id = $1`, [a.itemId]);
    if (!item) { outcomes.push({ itemId: a.itemId, accepted: false, message: 'Item not found' }); continue; }

    // --- BL-CHK-011: NA requires a reason where applicability is conditional ---
    if (a.responseType === 'Not Applicable' && (item.is_conditional || item.is_mandatory) && !a.naReason) {
      outcomes.push({ itemId: a.itemId, accepted: false,
        message: 'A reason is required when marking this item Not Applicable (BL-CHK-011).' });
      continue;
    }

    // --- BL-PM-016: numeric readings validated against configured limits ---
    let outOfRange = false;
    if (a.responseType === 'Numeric' || (item.response_mode === 'Numeric' && a.numericValue != null)) {
      if (a.numericValue == null) {
        outcomes.push({ itemId: a.itemId, accepted: false, message: 'A measured value is required.' });
        continue;
      }
      if (item.min_value != null && a.numericValue < Number(item.min_value)) outOfRange = true;
      if (item.max_value != null && a.numericValue > Number(item.max_value)) outOfRange = true;
    }

    // --- Photo evidence where configured ---
    if (item.photo_required === 'Yes' && !a.photoRef) {
      outcomes.push({ itemId: a.itemId, accepted: false, message: 'Photographic evidence is required for this item.' });
      continue;
    }
    if (item.photo_required === 'OnFailure' && (a.responseType === 'Not OK' || outOfRange) && !a.photoRef) {
      outcomes.push({ itemId: a.itemId, accepted: false,
        message: 'Photographic evidence is required when this item fails.' });
      continue;
    }

    await q(db, `
      INSERT INTO pm.checklist_result
        (job_card_id, work_item_id, checklist_version_id, item_id, response_type,
         numeric_value, text_value, na_reason, photo_ref, technician_id, client_operation_id)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
      ON CONFLICT (job_card_id, item_id) DO UPDATE
        SET response_type = EXCLUDED.response_type,
            numeric_value = EXCLUDED.numeric_value,
            text_value = EXCLUDED.text_value,
            na_reason = EXCLUDED.na_reason,
            photo_ref = EXCLUDED.photo_ref,
            technician_id = EXCLUDED.technician_id,
            recorded_at = now(),
            row_version = pm.checklist_result.row_version + 1`,
      [input.jobCardId, workItem?.work_item_id ?? null,
       exec?.frozen_checklist_version_id ?? item.checklist_version_id,
       a.itemId, a.responseType, a.numericValue ?? null, a.textValue ?? null,
       a.naReason ?? null, a.photoRef ?? null, input.technicianId ?? null,
       a.clientOperationId ?? null]);

    const outcome: AnswerOutcome = { itemId: a.itemId, accepted: true, numericOutOfRange: outOfRange };

    // --- BL-CHK-004: a failing item creates the linked defect ---
    const isFailure = a.responseType === 'Not OK' || outOfRange;
    const isAdvisory = a.responseType === 'Advisory-Observation';

    if ((isFailure && item.creates_defect_on_fail) || isAdvisory) {
      const existing = await one<any>(db, `
        SELECT defect_id, defect_no FROM service.defect
        WHERE origin_job_card_id = $1 AND origin_result_id IS NOT NULL
          AND description LIKE $2 AND status <> 'Closed'`,
        [input.jobCardId, `${item.code}%`]);

      if (existing) {
        outcome.defectId = existing.defect_id;
        outcome.defectNo = existing.defect_no;
      } else {
        const resultRow = await one<any>(db, `
          SELECT result_id FROM pm.checklist_result WHERE job_card_id = $1 AND item_id = $2`,
          [input.jobCardId, a.itemId]);

        // BL-CHK-010: advisory findings become deferred, non-blocking, VIN-owned defects.
        const severity = isAdvisory ? 'Minor' : (item.defect_severity_on_fail ?? 'Major');
        const blocks = isAdvisory ? false : !!item.blocks_release_on_fail;

        const defectNo = await nextDocumentNo(db, 'DEF', 4);
        const vehicle = await one<any>(db, `
          SELECT current_odometer_km FROM master.vehicle WHERE vehicle_id = $1`, [job.vehicle_id]);

        const dueByKm = isAdvisory && vehicle?.current_odometer_km != null
          ? Number(vehicle.current_odometer_km) + 10000 : null;
        const dueByDate = isAdvisory
          ? new Date(Date.now() + 90 * 86_400_000).toISOString().slice(0, 10) : null;

        const created = await one<any>(db, `
          INSERT INTO service.defect
            (defect_no, vehicle_id, origin_job_card_id, origin_result_id, severity, subsystem,
             description, status, is_deferred, blocks_release, opened_odometer_km,
             due_by_date, due_by_km, responsible_role, carried_forward)
          VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,'Service Centre',$14)
          RETURNING defect_id, defect_no`,
          [defectNo, job.vehicle_id, input.jobCardId, resultRow?.result_id ?? null,
           severity, item.section_name,
           `${item.code} — ${item.description}` +
             (outOfRange ? ` (reading ${a.numericValue}${item.unit ?? ''} outside ` +
                           `${item.min_value ?? '−'}–${item.max_value ?? '−'}${item.unit ?? ''})` : '') +
             (a.textValue ? `: ${a.textValue}` : ''),
           isAdvisory ? 'Deferred' : 'Open', isAdvisory, blocks,
           vehicle?.current_odometer_km ?? null, dueByDate, dueByKm, isAdvisory]);

        outcome.defectId = created.defect_id;
        outcome.defectNo = created.defect_no;

        // A blocking defect also becomes a corrective work item on this job.
        if (!isAdvisory) {
          const maxLine = await one<any>(db, `
            SELECT COALESCE(max(line_no),0) AS n FROM service.work_item WHERE job_card_id = $1`,
            [input.jobCardId]);
          await q(db, `
            INSERT INTO service.work_item (job_card_id, line_no, work_item_type, description,
                                           source_entity_type, source_entity_id, status)
            VALUES ($1,$2,'Defect',$3,'Defect',$4,'Not Started')`,
            [input.jobCardId, Number(maxLine.n) + 1,
             `Rectify: ${item.description}`, created.defect_id]);
        }
      }
    }

    outcomes.push(outcome);
  }

  await audit(db, {
    entityType: 'JobCard', entityId: input.jobCardId, action: 'CHECKLIST_RECORD',
    actor: input.actor,
    after: { answers: input.answers.length,
             defectsRaised: outcomes.filter(o => o.defectNo).map(o => o.defectNo) },
  });

  return outcomes;
}

/**
 * BL-DEF-001. Deferred defects are VIN-owned: when a new job opens on the
 * vehicle they attach to it so the workshop sees outstanding items.
 */
export async function attachDeferredDefects(db: Db, jobCardId: number, vehicleId: number): Promise<number> {
  const deferred = await many<any>(db, `
    SELECT defect_id, defect_no, description, severity
    FROM service.defect
    WHERE vehicle_id = $1 AND status IN ('Open','Deferred') AND closed_job_card_id IS NULL
      AND origin_job_card_id <> $2`, [vehicleId, jobCardId]);

  let added = 0;
  for (const d of deferred) {
    const exists = await one<any>(db, `
      SELECT work_item_id FROM service.work_item
      WHERE job_card_id = $1 AND source_entity_type = 'Defect' AND source_entity_id = $2`,
      [jobCardId, d.defect_id]);
    if (exists) continue;

    const maxLine = await one<any>(db, `
      SELECT COALESCE(max(line_no),0) AS n FROM service.work_item WHERE job_card_id = $1`, [jobCardId]);
    await q(db, `
      INSERT INTO service.work_item (job_card_id, line_no, work_item_type, description,
                                     source_entity_type, source_entity_id, status)
      VALUES ($1,$2,'Defect',$3,'Defect',$4,'Not Started')`,
      [jobCardId, Number(maxLine.n) + 1,
       `Carried forward (${d.defect_no}): ${d.description}`, d.defect_id]);

    await q(db, `UPDATE service.defect SET carried_forward = true WHERE defect_id = $1`, [d.defect_id]);
    added++;
  }
  return added;
}
