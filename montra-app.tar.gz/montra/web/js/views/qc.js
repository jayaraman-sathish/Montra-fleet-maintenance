import { api, qs } from '../api.js';
import {
  h, pill, table, fmtNum, fmtKm, fmtDate, fmtDateTime, cardOf, field, select,
  modal, toast, showApiError, clear,
} from '../ui.js';
import { setPageTitle, can, hasRole, state } from '../app.js';

export async function qcView({ params }) {
  setPageTitle('QC & Release', 'Release is blocked until every condition is satisfied (BL-QC-002/003)');

  const root = h('div', {});
  const jobParam = params.get('job');

  async function load(selectedId) {
    clear(root).appendChild(h('div', { class: 'spin' }));
    const [queue, concessions, releases] = await Promise.all([
      api.get('/api/v1/job-cards' + qs({ status: 'Open', limit: 200 })),
      api.get('/api/v1/concessions'),
      api.get('/api/v1/releases'),
    ]);

    const awaiting = queue.filter(j => ['Technician Complete', 'QC Pending'].includes(j.status));
    const detail = h('div', { style: 'margin-top:14px' });

    const queueCard = cardOf(`Awaiting QC (${awaiting.length})`,
      table([
        { label: 'Job card', render: r => h('span', { class: 'mono' }, r.job_card_no) },
        { label: 'Type', render: r => pill(r.event_type, r.event_type === 'Breakdown' ? 'p-red' : 'p-blue') },
        { label: 'Vehicle', render: r => r.registration_no || r.vin },
        { label: 'Customer', key: 'customer_name' },
        { label: 'Technician', key: 'technician_name' },
        { label: 'Status', render: r => pill(r.status) },
        { label: '', render: r => h('button', {
            class: 'btn btn-sm btn-primary',
            onclick: (e) => { e.stopPropagation(); openGate(r.job_card_id); },
          }, 'Open release gate') },
      ], awaiting, {
        empty: 'No jobs are waiting for QC.',
        onRow: r => openGate(r.job_card_id),
      }));

    const expiredConcessions = concessions.filter(c => c.is_expired);
    const concessionCard = cardOf(`Concessions (${concessions.length})`,
      table([
        { label: 'Concession', render: r => h('span', { class: 'mono' }, r.concession_no) },
        { label: 'Vehicle', render: r => h('a', { href: `#/vehicles/${r.vin}` }, r.registration_no || r.vin) },
        { label: 'Defect', render: r => r.defect_no ?? '—' },
        { label: 'Reason', render: r => h('div', { style: 'max-width:260px' }, r.reason) },
        { label: 'Expires', render: r => [r.expiry_date ? fmtDate(r.expiry_date) : null,
            r.expiry_km ? fmtKm(r.expiry_km) : null].filter(Boolean).join(' / ') || '—' },
        { label: 'Follow-up', render: r => h('div', { style: 'max-width:220px' }, r.follow_up_action) },
        { label: 'Owner', key: 'owner_role' },
        { label: 'State', render: r => r.is_expired ? pill('Expired', 'p-red') : pill('Active', 'p-green') },
      ], concessions, { empty: 'No active concessions.' }),
      expiredConcessions.length
        ? h('span', { class: 'small', style: 'color:var(--red)' },
            `${expiredConcessions.length} expired — further release is blocked (BL-CON-001)`)
        : null);

    const releaseCard = cardOf('Recent releases',
      table([
        { label: 'Released', render: r => fmtDateTime(r.released_at) },
        { label: 'Job card', render: r => h('a', { href: `#/job-cards/${r.job_card_id}` },
            h('span', { class: 'mono' }, r.job_card_no)) },
        { label: 'Vehicle', render: r => h('a', { href: `#/vehicles/${r.vin}` }, r.registration_no || r.vin) },
        { label: 'Type', render: r => pill(r.release_type,
            r.release_type === 'With Concession' ? 'p-amber' : 'p-green') },
        { label: 'Road test', render: r => r.road_test_done ? '✓' : '—' },
        { label: 'Released by', key: 'released_by' },
      ], releases.slice(0, 15), { empty: 'No releases recorded yet.' }));

    async function openGate(jobCardId) {
      detail.replaceChildren(h('div', { class: 'spin' }, 'Evaluating release conditions…'));
      const [gate, job, qcList] = await Promise.all([
        api.get(`/api/v1/job-cards/${jobCardId}/release-gate`),
        api.get(`/api/v1/job-cards/${jobCardId}`),
        api.get(`/api/v1/job-cards/${jobCardId}/qc-checklist`),
      ]);
      detail.replaceChildren(gateCard(gate, job, qcList, () => load(jobCardId)));
      detail.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    clear(root).appendChild(h('div', {},
      queueCard, detail,
      h('div', { class: 'grid g2', style: 'margin-top:14px' }, concessionCard, releaseCard)));

    if (selectedId ?? jobParam) openGate(Number(selectedId ?? jobParam));
  }

  await load();
  return root;
}

function gateCard(gate, job, qcList, reload) {
  const jc = job.jobCard;
  const checks = h('div', {});

  const banner = gate.canRelease
    ? h('div', { class: 'banner banner-green' },
        h('span', {}, '✓'),
        h('div', {},
          h('b', {}, 'All release conditions are satisfied. '),
          h('span', { class: 'small' },
            'The vehicle can be released and the job closed. The next PM obligation will be ' +
            'calculated automatically on closure (BL-QC-008).')))
    : h('div', { class: 'banner banner-red' },
        h('span', {}, '⛔'),
        h('div', {},
          h('b', {}, `Release is blocked by ${gate.blockers.length} condition` +
            `${gate.blockers.length === 1 ? '' : 's'}.`),
          h('div', { class: 'small' }, 'Each one below must be cleared, or an authorised concession raised.')));

  const blockerList = h('div', {}, gate.blockers.map(b => h('div', {
    style: 'padding:11px 13px;border:1px solid #f3c5c5;background:var(--red-soft);border-radius:8px;margin-bottom:9px',
  },
    h('div', { style: 'display:flex;gap:9px;align-items:center' },
      h('span', {}, '⛔'),
      h('b', { style: 'flex:1' }, b.message),
      h('span', { class: 'pill p-grey', style: 'font-size:10px' }, b.ruleId)),
    Array.isArray(b.detail) && b.detail.length
      ? h('ul', { class: 'small', style: 'margin:7px 0 0 24px' },
          b.detail.slice(0, 8).map(x => h('li', {},
            typeof x === 'string' ? x
              : x.item ? `${x.section}: ${x.item}`
              : x.description ? `${x.defectNo ?? x.code ?? ''} ${x.description}`
              : JSON.stringify(x))))
      : null)));

  const warningList = gate.warnings.length ? h('div', {}, gate.warnings.map(w => h('div', {
    style: 'padding:10px 13px;border:1px solid #f0d5ae;background:var(--amber-soft);border-radius:8px;margin-bottom:9px',
  },
    h('div', { style: 'display:flex;gap:9px;align-items:center' },
      h('span', {}, '⚠'),
      h('span', { style: 'flex:1' }, w.message),
      h('span', { class: 'pill p-grey', style: 'font-size:10px' }, w.ruleId))))) : null;

  // QC checklist
  const qcRows = qcList.items.map(item => {
    const seg = h('div', { class: 'seg' });
    for (const [label, value, cls] of [['Pass', 'Pass', 'on-ok'], ['Fail', 'Fail', 'on-fail'],
                                       ['N/A', 'Not Applicable', 'on-na']]) {
      const b = h('button', { class: item.result === value ? cls : '' }, label);
      b.addEventListener('click', async () => {
        try {
          await api.post(`/api/v1/job-cards/${jc.job_card_id}/qc`,
            { results: [{ qcItemId: item.qc_item_id, result: value }] });
          reload();
        } catch (e) { showApiError(e); }
      });
      seg.appendChild(b);
    }
    return h('div', { class: 'chk-item' },
      h('div', { class: 'chk-desc' },
        h('div', {}, item.description, item.is_mandatory ? h('span', { style: 'color:var(--red)' }, ' *') : null),
        h('div', { class: 'code' }, item.code),
        item.checked_at
          ? h('div', { class: 'small muted' }, `${item.result} — ${item.checked_by} · ${fmtDateTime(item.checked_at)}`)
          : null),
      h('div', { class: 'chk-actions' }, seg));
  });

  const actions = h('div', { style: 'display:flex;gap:9px;flex-wrap:wrap;padding:14px 16px;border-top:1px solid var(--line-2)' },
    h('button', {
      class: 'btn btn-primary', disabled: !gate.canRelease || !can('qc.release'),
      onclick: () => releaseModal(jc, false, reload),
    }, '✓ Release vehicle'),
    !gate.canRelease && can('concession.approve')
      ? h('button', { class: 'btn', onclick: () => concessionModal(jc, gate, reload) },
          'Raise concession & release')
      : null,
    can('qc.remote')
      ? h('button', { class: 'btn', disabled: !gate.canRelease,
          onclick: () => releaseModal(jc, true, reload) }, 'Remote QC release')
      : null,
    h('div', { class: 'spacer' }),
    h('a', { class: 'btn', href: `#/job-cards/${jc.job_card_id}` }, 'Open job card'));

  return h('div', { class: 'card' },
    h('div', { class: 'card-head' },
      h('h3', {}, `Release gate — ${jc.job_card_no}`),
      h('div', { class: 'spacer' }),
      h('span', { class: 'small muted' },
        `${jc.registration_no || jc.vin} · ${jc.event_type} · technician ${jc.technician_name ?? '—'}`)),
    h('div', { class: 'card-body' }, banner, blockerList, warningList),
    h('div', { class: 'card-head' }, h('h3', {}, 'QC release checklist')),
    h('div', {}, qcRows),
    actions);
}

function releaseModal(jc, remote, reload) {
  const odo = h('input', { type: 'number', value: jc.current_odometer_km ?? jc.odometer_at_open ?? 0 });
  const roadTest = h('input', { type: 'checkbox', checked: true });
  const remarks = h('textarea', { placeholder: 'Release remarks…' });

  modal({
    title: remote ? 'Remote QC release' : 'Release vehicle',
    body: h('div', {},
      h('div', { class: 'banner banner-blue' }, h('div', { class: 'small' },
        remote
          ? 'Remote QC is a field-service exception. Photographic evidence and readings must already be ' +
            'on the job, and the approving supervisor is recorded (BL-QC-004).'
          : 'The technician who carried out the repair cannot also authorise the release. ' +
            'A separate QC supervisor must approve (BL-QC-006).')),
      field('Odometer at release', odo),
      h('label', { style: 'display:flex;gap:8px;align-items:center;font-size:13px;margin-bottom:12px' },
        roadTest, 'Road test completed'),
      field('Remarks', remarks)),
    actions: [
      { label: 'Cancel', onClick: () => true },
      { label: 'Confirm release', class: 'btn-primary', onClick: async () => {
          try {
            const r = await api.post(`/api/v1/job-cards/${jc.job_card_id}/release`, {
              releaseType: remote ? 'Remote QC' : 'Standard',
              roadTestDone: roadTest.checked,
              odometerAtRelease: Number(odo.value) || null,
              remarks: remarks.value.trim() || null,
            });
            toast(`Vehicle released. ${r.nextObligationId
              ? 'Next PM obligation created.' : ''}`, 'ok');
            reload(); return true;
          } catch (e) { showApiError(e); return false; }
        } },
    ],
  });
}

function concessionModal(jc, gate, reload) {
  const defectBlocker = gate.blockers.find(b => b.code === 'CRITICAL_DEFECT_OPEN');
  const defects = Array.isArray(defectBlocker?.detail) ? defectBlocker.detail : [];

  const reason = h('textarea', { placeholder: 'Why is release being permitted with this deviation?' });
  const expiryDate = h('input', { type: 'date',
    value: new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 10) });
  const expiryKm = h('input', { type: 'number', placeholder: 'Kilometre limit (optional)' });
  const followUp = h('textarea', { placeholder: 'What must be done, and by when?' });
  const ownerSel = select(['Service Centre Manager', 'Engineering', 'Fleet Customer', 'Warranty Manager'],
    'Service Centre Manager');

  modal({
    title: 'Raise release concession',
    width: 660,
    body: h('div', {},
      h('div', { class: 'banner banner-amber' },
        h('span', {}, '⚠'),
        h('div', {},
          h('b', {}, 'A concession permits release with a known deviation. '),
          h('span', { class: 'small' },
            'It must carry an expiry (date or kilometres), a follow-up action and a responsible owner. ' +
            'Once expired, further release of this vehicle is blocked until the follow-up is completed ' +
            'or the concession is renewed (BL-QC-007 / BL-CON-001).'))),
      defects.length
        ? h('div', { style: 'margin-bottom:13px' },
            h('div', { class: 'small muted', style: 'margin-bottom:5px' }, 'Open blocking defects'),
            defects.map(d => h('div', { class: 'small', style: 'padding:6px 9px;background:var(--bg);border-radius:6px;margin-bottom:4px' },
              h('b', {}, d.defectNo ?? ''), ' ', d.description ?? '')))
        : null,
      field('Reason', reason, { required: true }),
      h('div', { class: 'grid g2' },
        field('Expiry date', expiryDate), field('Expiry kilometres', expiryKm)),
      field('Follow-up action', followUp, { required: true }),
      field('Responsible owner', ownerSel, { required: true })),
    actions: [
      { label: 'Cancel', onClick: () => true },
      { label: 'Approve concession & release', class: 'btn-danger', onClick: async () => {
          if (!reason.value.trim() || !followUp.value.trim()) {
            toast('Reason and follow-up action are both required.', 'err'); return false;
          }
          try {
            const c = await api.post('/api/v1/concessions', {
              vin: jc.vin, jobCardId: jc.job_card_id,
              reason: reason.value.trim(),
              expiryDate: expiryDate.value || null,
              expiryKm: expiryKm.value ? Number(expiryKm.value) : null,
              followUpAction: followUp.value.trim(),
              ownerRole: ownerSel.value,
            });
            await api.post(`/api/v1/job-cards/${jc.job_card_id}/release`, {
              releaseType: 'With Concession', concessionId: c.concession_id, roadTestDone: true,
              remarks: `Released under concession ${c.concession_no}`,
            });
            toast(`Released under concession ${c.concession_no}.`, 'ok');
            reload(); return true;
          } catch (e) { showApiError(e); return false; }
        } },
    ],
  });
}
