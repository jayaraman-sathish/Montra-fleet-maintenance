/**
 * Rebuild the database from db/01_schema.sql and db/02_seed_reference.sql.
 * Destructive: drops and recreates every application schema.
 */

import * as fs from 'node:fs';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';
import { pool } from '../lib/db.ts';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_DIR = path.resolve(__dirname, '../../db');

async function main() {
  const files = ['01_schema.sql', '02_seed_reference.sql'];
  for (const f of files) {
    const sql = fs.readFileSync(path.join(DB_DIR, f), 'utf8');
    process.stdout.write(`Applying ${f}… `);
    await pool.runScript(sql);
    console.log('ok');
  }

  const counts = await pool.query(`
    SELECT table_schema, count(*)::int AS tables
    FROM information_schema.tables
    WHERE table_schema IN ('org','security','master','uptime','pm','schedule','service',
                           'commercial','quality','campaign','integration','audit')
    GROUP BY 1 ORDER BY 1`);
  console.log('\nSchemas created:');
  for (const r of counts.rows) console.log(`  ${String(r.table_schema).padEnd(14)} ${r.tables} tables`);
}

main()
  .then(async () => { await pool.end(); process.exit(0); })
  .catch(async (e) => { console.error('Reset failed:', e); await pool.end(); process.exit(1); });
