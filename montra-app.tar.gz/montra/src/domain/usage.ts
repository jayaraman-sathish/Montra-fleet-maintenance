/**
 * Telematics usage ingestion and data-quality rules.
 *
 * Implements Document 02 BL-USG-001..007 and BL-INT-001..006, and the
 * Document 04 §22 telematics contract:
 *
 *   authenticate → schema validate → idempotency → VIN map → plausibility
 *   → persist inbound transaction → update trusted usage snapshot
 *   → refresh freshness/projection → re-evaluate open PM obligations
 */

import { q, one, audit, notify } from '../lib/db.ts';
import type { Db } from '../lib/db.ts';
import { reevaluateObligations } from './pm.ts';

/** Maximum plausible daily distance by vehicle category (BL-USG-002). */
const MAX_KM_PER_DAY: Record<string, number> = {
  LMP: 250, LMC: 300, SCV: 500, MHCV: 900, TRACTOR: 200,
};
const DEFAULT_MAX_KM_PER_DAY = 600;

/** Hours after which a feed is considered stale (BL-USG-003). */
const STALENESS_HOURS = Number(process.env.TELEMATICS_STALE_HOURS ?? 48);

export interface TelematicsEvent {
  externalMessageId: string;
  vin: string;
  odometerKm?: number;
  operatingHours?: number;
  sourceTimestampUtc: string;
  vehicleStatus?: string;
  latitude?: number;
  longitude?: number;
  socPct?: number;
  sohPct?: number;
  dtcSummary?: string;
}

export type IngestOutcome =
  | { result: 'accepted'; vehicleId: number; pmChanged: number }
  | { result: 'duplicate' }
  | { result: 'quarantined'; reason: string };

/**
 * Ingest one telematics event. Idempotent on (source system, externalMessageId).
 */
export async function ingestTelematics(
  db: Db, ev: TelematicsEvent, sourceSystem = 'TELEMATICS',
): Promise<IngestOutcome> {
  // --- BL-INT-002 idempotency ---
  const existing = await one<any>(db, `
    SELECT inbound_id, processing_status FROM integration.inbound_message
    WHERE source_system = $1 AND external_message_id = $2`, [sourceSystem, ev.externalMessageId]);
  if (existing) return { result: 'duplicate' };

  const inbound = await one<any>(db, `
    INSERT INTO integration.inbound_message
      (source_system, external_message_id, message_type, payload, correlation_id)
    VALUES ($1,$2,'usage',$3,$4)
    RETURNING inbound_id`,
    [sourceSystem, ev.externalMessageId, JSON.stringify(ev), ev.externalMessageId]);

  const quarantine = async (reason: string) => {
    await q(db, `
      UPDATE integration.inbound_message
      SET processing_status = 'Quarantined', processing_result = $1 WHERE inbound_id = $2`,
      [reason, inbound.inbound_id]);
    await q(db, `
      INSERT INTO integration.telematics_transaction
        (inbound_id, vin, odometer_km, operating_hours, source_timestamp_utc,
         accepted, rejection_reason)
      VALUES ($1,$2,$3,$4,$5,false,$6)`,
      [inbound.inbound_id, ev.vin, ev.odometerKm ?? null, ev.operatingHours ?? null,
       ev.sourceTimestampUtc, reason]);
    await q(db, `
      INSERT INTO integration.integration_error
        (source_system, interface_name, inbound_id, error_type, error_message, correlation_id)
      VALUES ($1,'telematics.usage',$2,'Quarantine',$3,$4)`,
      [sourceSystem, inbound.inbound_id, reason, ev.externalMessageId]);
    return { result: 'quarantined' as const, reason };
  };

  // --- Unknown VIN is never auto-created (Doc 04 §27) ---
  const vehicle = await one<any>(db, `
    SELECT v.*, c.code AS category_code
    FROM master.vehicle v
    JOIN master.vehicle_variant vv ON vv.variant_id = v.variant_id
    JOIN master.vehicle_model vm ON vm.model_id = vv.model_id
    JOIN master.product_family pf ON pf.family_id = vm.family_id
    JOIN master.vehicle_category c ON c.category_id = pf.category_id
    WHERE v.vin = $1`, [ev.vin]);
  if (!vehicle) return quarantine(`Unknown VIN ${ev.vin} — production vehicles are never auto-created`);

  const sourceTs = new Date(ev.sourceTimestampUtc);
  if (isNaN(sourceTs.getTime())) return quarantine('Invalid sourceTimestampUtc');

  // --- BL-USG-001 monotonicity ---
  if (ev.odometerKm != null) {
    const lastKm = Number(vehicle.current_odometer_km ?? 0);
    if (ev.odometerKm < lastKm) {
      return quarantine(
        `Odometer regression: received ${ev.odometerKm} km, last accepted ${lastKm} km. ` +
        `An authorised correction is required (BL-USG-001).`);
    }

    // --- BL-USG-002 plausibility ---
    const lastAt = vehicle.usage_updated_at ? new Date(vehicle.usage_updated_at) : null;
    if (lastAt) {
      const days = Math.max(
        0.0417, (sourceTs.getTime() - lastAt.getTime()) / 86_400_000); // min 1 hour
      const delta = ev.odometerKm - lastKm;
      const cap = (MAX_KM_PER_DAY[vehicle.category_code] ?? DEFAULT_MAX_KM_PER_DAY) * days;
      if (delta > cap) {
        return quarantine(
          `Implausible distance: ${Math.round(delta)} km in ${days.toFixed(1)} day(s) ` +
          `exceeds the ${vehicle.category_code} limit of ${Math.round(cap)} km (BL-USG-002).`);
      }
    }
  }

  if (ev.operatingHours != null && ev.operatingHours < Number(vehicle.current_operating_hours ?? 0)) {
    return quarantine('Operating hours regression (BL-USG-001)');
  }

  // --- Accept ---
  await q(db, `
    INSERT INTO integration.telematics_transaction
      (inbound_id, vehicle_id, vin, odometer_km, operating_hours, source_timestamp_utc,
       vehicle_status, latitude, longitude, soc_pct, soh_pct, dtc_summary, accepted)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,true)`,
    [inbound.inbound_id, vehicle.vehicle_id, ev.vin, ev.odometerKm ?? null,
     ev.operatingHours ?? null, sourceTs, ev.vehicleStatus ?? null,
     ev.latitude ?? null, ev.longitude ?? null, ev.socPct ?? null, ev.sohPct ?? null,
     ev.dtcSummary ?? null]);

  await q(db, `
    UPDATE master.vehicle
    SET current_odometer_km = COALESCE($1, current_odometer_km),
        current_operating_hours = COALESCE($2, current_operating_hours),
        usage_source = 'Telematics', usage_updated_at = $3, usage_is_stale = false,
        updated_at = now()
    WHERE vehicle_id = $4`,
    [ev.odometerKm ?? null, ev.operatingHours ?? null, sourceTs, vehicle.vehicle_id]);

  await q(db, `
    UPDATE integration.inbound_message
    SET processing_status = 'Processed', processing_result = 'Usage snapshot updated'
    WHERE inbound_id = $1`, [inbound.inbound_id]);

  await q(db, `
    INSERT INTO integration.connector_health (connector_name, last_success_at, status)
    VALUES ('telematics', now(), 'Healthy')
    ON CONFLICT (connector_name) DO UPDATE SET last_success_at = now(), status = 'Healthy'`);

  await refreshUsageProjection(db, vehicle.vehicle_id);
  const pm = await reevaluateObligations(db, vehicle.vehicle_id, 'telematics');

  return { result: 'accepted', vehicleId: vehicle.vehicle_id, pmChanged: pm.changed };
}

/**
 * BL-USG-004. Maintain a rolling km/day and hours/day projection so PM due
 * dates can still be estimated when the feed goes quiet.
 */
export async function refreshUsageProjection(db: Db, vehicleId: number, windowDays = 30): Promise<void> {
  const r = await one<any>(db, `
    WITH w AS (
      SELECT odometer_km, operating_hours, source_timestamp_utc
      FROM integration.telematics_transaction
      WHERE vehicle_id = $1 AND accepted = true
        AND source_timestamp_utc >= now() - ($2 || ' days')::interval
      ORDER BY source_timestamp_utc
    )
    SELECT
      (max(odometer_km) - min(odometer_km))            AS km_delta,
      (max(operating_hours) - min(operating_hours))    AS hours_delta,
      EXTRACT(EPOCH FROM (max(source_timestamp_utc) - min(source_timestamp_utc)))/86400.0 AS days,
      count(*)::int AS samples
    FROM w`, [vehicleId, windowDays]);

  const days = Number(r?.days ?? 0);
  const samples = Number(r?.samples ?? 0);
  if (!days || samples < 2) return;

  const kmPerDay = Number(r.km_delta ?? 0) / days;
  const hoursPerDay = Number(r.hours_delta ?? 0) / days;
  const confidence = samples >= 20 ? 'High' : samples >= 5 ? 'Medium' : 'Low';

  await q(db, `
    INSERT INTO pm.pm_usage_projection
      (vehicle_id, avg_km_per_day, avg_hours_per_day, window_days, confidence, calculated_at)
    VALUES ($1,$2,$3,$4,$5, now())
    ON CONFLICT (vehicle_id) DO UPDATE
      SET avg_km_per_day = EXCLUDED.avg_km_per_day,
          avg_hours_per_day = EXCLUDED.avg_hours_per_day,
          window_days = EXCLUDED.window_days,
          confidence = EXCLUDED.confidence,
          calculated_at = now()`,
    [vehicleId, Number(kmPerDay.toFixed(3)), Number(hoursPerDay.toFixed(3)), windowDays, confidence]);
}

/**
 * BL-USG-003. Flag vehicles whose feed has gone stale so the UI can show
 * freshness and PM status can be marked estimated.
 */
export async function markStaleFeeds(db: Db): Promise<number> {
  const r = await q(db, `
    UPDATE master.vehicle
    SET usage_is_stale = true
    WHERE usage_source = 'Telematics'
      AND usage_updated_at IS NOT NULL
      AND usage_updated_at < now() - ($1 || ' hours')::interval
      AND usage_is_stale = false`, [STALENESS_HOURS]);
  return r.rowCount;
}

/**
 * BL-VEH-006 / BL-USG-007. Authorised manual correction of usage. Always
 * carries a reason and preserves the source.
 */
export async function correctUsage(db: Db, input: {
  vehicleId: number; odometerKm?: number; operatingHours?: number;
  reason: string; actor: string; evidenceRef?: string;
}): Promise<void> {
  const before = await one<any>(db, `
    SELECT current_odometer_km, current_operating_hours, usage_source
    FROM master.vehicle WHERE vehicle_id = $1`, [input.vehicleId]);

  await q(db, `
    UPDATE master.vehicle
    SET current_odometer_km = COALESCE($1, current_odometer_km),
        current_operating_hours = COALESCE($2, current_operating_hours),
        usage_source = 'Manual', usage_updated_at = now(), usage_is_stale = false,
        updated_at = now()
    WHERE vehicle_id = $3`,
    [input.odometerKm ?? null, input.operatingHours ?? null, input.vehicleId]);

  await audit(db, {
    entityType: 'Vehicle', entityId: input.vehicleId, action: 'USAGE_CORRECTION',
    actor: input.actor, reason: input.reason,
    before, after: { odometerKm: input.odometerKm, operatingHours: input.operatingHours,
                     evidence: input.evidenceRef ?? null },
  });

  await reevaluateObligations(db, input.vehicleId, input.actor);
}
