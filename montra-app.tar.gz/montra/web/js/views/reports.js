import { api, qs } from '../api.js';
import { h, pill, table, fmtNum, durationHrs, fmtDate, cardOf, field, select } from '../ui.js';
import { setPageTitle, reference } from '../app.js';

export async function reportsView() {
  setPageTitle('Reports & KPIs', 'Every figure derives from the persisted source named in Document 04 §29');

  const ref = await reference();
  const wrap = h('div', {});
  const panel = h('div', {});

  const today = new Date();
  const fromInput = h('input', { type: 'date',
    value: new Date(today.getTime() - 90 * 86400000).toISOString().slice(0, 10) });
  const toInput = h('input', { type: 'date', value: today.toISOString().slice(0, 10) });
  const centreSel = select([{ value: '', label: 'All service centres' },
    ...ref.serviceCentres.map(c => ({ value: c.service_centre_id, label: c.name }))], '');

  async function load() {
    panel.replaceChildren(h('div', { class: 'spin' }, 'Calculating KPIs…'));
    const k = await api.get('/api/v1/kpis' + qs({
      from: new Date(fromInput.value).toISOString(),
      to: new Date(toInput.value + 'T23:59:59').toISOString(),
      serviceCentreId: centreSel.value,
    }));

    const tiles = h('div', { class: 'grid g4' },
      kpiTile('PM compliance — on time',
        k.pmCompliance.onTimePct !== null ? `${k.pmCompliance.onTimePct}%` : '—',
        `${fmtNum(k.pmCompliance.eligibleObligations)} eligible obligations`, 'i-green'),
      kpiTile('PM compliance — within tolerance',
        k.pmCompliance.withinTolerancePct !== null ? `${k.pmCompliance.withinTolerancePct}%` : '—',
        `${fmtNum(k.pmCompliance.completedLate)} completed late`, 'i-blue'),
      kpiTile('Fleet availability',
        k.availability.availabilityPct !== null ? `${k.availability.availabilityPct}%` : '—',
        `${durationHrs(k.availability.downHours)} down`, 'i-green'),
      kpiTile('Time to restore (MTTR)',
        k.restore.mttrHours !== null ? durationHrs(k.restore.mttrHours) : '—',
        `${fmtNum(k.restore.sampleSize)} breakdown(s)`, 'i-amber'));

    const tiles2 = h('div', { class: 'grid g4', style: 'margin-top:14px' },
      kpiTile('First-time fix',
        k.reliability.firstTimeFixPct !== null ? `${k.reliability.firstTimeFixPct}%` : '—',
        `${fmtNum(k.reliability.eligibleClosed)} eligible closed events`, 'i-green'),
      kpiTile('Repeat breakdown rate',
        k.reliability.repeatBreakdownPct !== null ? `${k.reliability.repeatBreakdownPct}%` : '—',
        `${fmtNum(k.reliability.repeatCount)} repeat event(s)`, 'i-red'),
      kpiTile('Workshop turnaround (gross)',
        k.turnaround.grossHours !== null ? durationHrs(k.turnaround.grossHours) : '—',
        `${fmtNum(k.turnaround.sampleSize)} closed jobs`, 'i-blue'),
      kpiTile('Turnaround net of pauses',
        k.turnaround.netHours !== null ? durationHrs(k.turnaround.netHours) : '—',
        'Pause-excluded accountable time', 'i-purple'));

    const complianceCard = cardOf('PM compliance detail', h('div', { class: 'card-body' },
      h('div', { class: 'kv' },
        h('div', {}, 'Eligible obligations'), h('div', {}, fmtNum(k.pmCompliance.eligibleObligations)),
        h('div', {}, 'On-time %'), h('div', {}, k.pmCompliance.onTimePct !== null ? `${k.pmCompliance.onTimePct}%` : '—'),
        h('div', {}, 'Within-tolerance %'), h('div', {},
          k.pmCompliance.withinTolerancePct !== null ? `${k.pmCompliance.withinTolerancePct}%` : '—'),
        h('div', {}, 'Completed late'), h('div', {}, fmtNum(k.pmCompliance.completedLate)),
        h('div', {}, 'Carried-over overdue'), h('div', {},
          h('span', {}, fmtNum(k.pmCompliance.carriedOverOverdue)),
          h('span', { class: 'small muted' }, ' (reported separately, never re-counted)'))),
      h('div', { class: 'small muted', style: 'margin-top:11px' }, k.pmCompliance.definition)));

    const attributionCard = cardOf('Downtime attribution',
      table([
        { label: 'Accountable party', key: 'party' },
        { label: 'Category', key: 'category' },
        { label: 'Hours', num: true, render: r => durationHrs(r.hours) },
      ], k.availability.attribution, { empty: 'No downtime recorded in this period.' }),
      h('span', { class: 'small muted' }, k.availability.source));

    const failuresCard = cardOf('Top failure subsystems',
      table([
        { label: 'Subsystem', key: 'subsystem' },
        { label: 'Defects raised', num: true, key: 'n' },
        { label: '', render: r => {
            const max = Math.max(...k.topFailures.map(x => Number(x.n)), 1);
            return h('div', { class: 'bar', style: 'width:160px' },
              h('span', { style: `width:${(Number(r.n) / max) * 100}%` }));
          } },
      ], k.topFailures, { empty: 'No defects recorded in this period.' }));

    const definitions = cardOf('KPI definitions in force',
      table([
        { label: 'KPI', key: 'kpi' },
        { label: 'Start / denominator', key: 'start' },
        { label: 'End / numerator', key: 'end' },
        { label: 'Exclusions', key: 'excl' },
      ], [
        { kpi: 'PM on-time compliance', start: 'Eligible obligations due in period',
          end: 'Completed by due threshold', excl: 'Authorised off-hire; carry-over shown separately' },
        { kpi: 'PM within-tolerance', start: 'Eligible obligations due in period',
          end: 'Completed by tolerance limit', excl: 'Same exclusions' },
        { kpi: 'Time to restore / MTTR', start: 'Actual stoppage timestamp',
          end: 'Vehicle operable timestamp', excl: 'Accident excluded from product MTTR' },
        { kpi: 'Total downtime / availability', start: 'Availability ledger unavailable start',
          end: 'Return-to-service interval close', excl: 'Gross by default; attribution classified' },
        { kpi: 'Workshop turnaround', start: 'Job card acceptance', end: 'Release timestamp',
          excl: 'Gross and pause-excluded net both retained' },
        { kpi: 'First-time fix', start: 'Eligible closed breakdown events',
          end: 'No qualifying repeat in window', excl: 'No-fault-found and accident excluded' },
        { kpi: 'Repeat breakdown rate', start: 'Eligible closed breakdown events',
          end: 'Those with a qualifying repeat', excl: 'Same repeat key and window' },
      ], {}),
      h('span', { class: 'small muted' }, 'Document 02 §24.10 Final KPI Dictionary'));

    panel.replaceChildren(h('div', {},
      tiles, tiles2,
      h('div', { class: 'grid g2', style: 'margin-top:14px' }, complianceCard, attributionCard),
      h('div', { class: 'grid g2', style: 'margin-top:14px' }, failuresCard,
        cardOf('Period', h('div', { class: 'card-body' },
          h('div', { class: 'kv' },
            h('div', {}, 'From'), h('div', {}, fmtDate(k.period.from)),
            h('div', {}, 'To'), h('div', {}, fmtDate(k.period.to)),
            h('div', {}, 'Scope'), h('div', {}, centreSel.selectedOptions[0]?.textContent ?? 'All'))))),
      h('div', { style: 'margin-top:14px' }, definitions)));
  }

  for (const c of [fromInput, toInput, centreSel]) c.addEventListener('change', load);
  wrap.appendChild(h('div', { class: 'filters' },
    field('From', fromInput), field('To', toInput), field('Service centre', centreSel),
    h('button', { class: 'btn btn-primary', onclick: load }, 'Recalculate')));
  wrap.appendChild(panel);
  await load();
  return wrap;
}

function kpiTile(label, value, note, cls) {
  return h('div', { class: 'tile', style: 'cursor:default' },
    h('div', { class: `tico ${cls}` }, '📊'),
    h('div', { class: 'tbody' },
      h('div', { class: 'tlabel' }, label),
      h('div', { class: 'tvalue' }, value),
      note ? h('div', { class: 'tnote' }, note) : null));
}
