-- =====================================================================
-- Montra Electric — Fleet Maintenance, Breakdown & Uptime Management
-- Database schema — implements Document 04 (Data Model & Integration
-- Specification) FINAL v3.0, section 3 "Corrected SQL Server Schema Map".
--
-- Target here is PostgreSQL (Render). Names follow Document 04 with
-- snake_case applied; see docs/SCHEMA-MAPPING.md for the table-by-table
-- mapping back to the SQL Server names in the specification.
-- =====================================================================

DROP SCHEMA IF EXISTS audit, integration, campaign, quality, commercial,
                      service, schedule, pm, uptime, master, org, security CASCADE;

CREATE SCHEMA org;          -- Customer/dealer hierarchy and data scope
CREATE SCHEMA security;     -- Identity / permission
CREATE SCHEMA master;       -- Vehicle and technical reference
CREATE SCHEMA uptime;       -- Availability and downtime history
CREATE SCHEMA pm;           -- PM configuration and obligation lifecycle
CREATE SCHEMA schedule;     -- Capacity and appointments
CREATE SCHEMA service;      -- Operational execution
CREATE SCHEMA commercial;   -- Warranty, entitlement, estimate and cost
CREATE SCHEMA quality;      -- QC, concession and release
CREATE SCHEMA campaign;     -- Campaign / compliance / software
CREATE SCHEMA integration;  -- External message handling
CREATE SCHEMA audit;        -- Immutable traceability

-- =====================================================================
-- ORG — Document 04 §5 Organisation and Data-Scope Model
-- Implements FR-ORG-001/002/003
-- =====================================================================

CREATE TABLE org.organisation (
    organisation_id   BIGSERIAL PRIMARY KEY,
    org_type          TEXT NOT NULL CHECK (org_type IN ('Montra','Customer','Dealer','Vendor')),
    code              TEXT NOT NULL UNIQUE,
    name              TEXT NOT NULL,
    status            TEXT NOT NULL DEFAULT 'Active' CHECK (status IN ('Active','Inactive')),
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Customer > Region > Depot > Sub-fleet  (FR-ORG-001)
CREATE TABLE org.organisation_node (
    node_id           BIGSERIAL PRIMARY KEY,
    organisation_id   BIGINT NOT NULL REFERENCES org.organisation(organisation_id),
    parent_node_id    BIGINT REFERENCES org.organisation_node(node_id),
    node_type         TEXT NOT NULL CHECK (node_type IN ('Customer','Region','Depot','SubFleet')),
    code              TEXT NOT NULL,
    name              TEXT NOT NULL,
    effective_from    DATE NOT NULL DEFAULT CURRENT_DATE,
    effective_to      DATE,
    status            TEXT NOT NULL DEFAULT 'Active',
    UNIQUE (organisation_id, code)
);

-- Montra > Zone > Service Centre  (FR-ORG-001)
CREATE TABLE org.service_network_node (
    node_id           BIGSERIAL PRIMARY KEY,
    parent_node_id    BIGINT REFERENCES org.service_network_node(node_id),
    node_type         TEXT NOT NULL CHECK (node_type IN ('Montra','Zone','ServiceCentre')),
    code              TEXT NOT NULL UNIQUE,
    name              TEXT NOT NULL,
    status            TEXT NOT NULL DEFAULT 'Active'
);

-- =====================================================================
-- SECURITY — role + scope authorisation (FR-ORG-002, FR-AUTH-001)
-- =====================================================================

CREATE TABLE security.role (
    role_id           BIGSERIAL PRIMARY KEY,
    code              TEXT NOT NULL UNIQUE,
    name              TEXT NOT NULL,
    description       TEXT
);

CREATE TABLE security.permission (
    permission_id     BIGSERIAL PRIMARY KEY,
    action_code       TEXT NOT NULL UNIQUE,
    description       TEXT
);

CREATE TABLE security.role_permission (
    role_id           BIGINT NOT NULL REFERENCES security.role(role_id),
    permission_id     BIGINT NOT NULL REFERENCES security.permission(permission_id),
    PRIMARY KEY (role_id, permission_id)
);

CREATE TABLE security.application_user (
    user_id           BIGSERIAL PRIMARY KEY,
    username          TEXT NOT NULL UNIQUE,
    display_name      TEXT NOT NULL,
    email             TEXT,
    password_hash     TEXT NOT NULL,
    status            TEXT NOT NULL DEFAULT 'Active' CHECK (status IN ('Active','Disabled')),
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Row-level scope: every role assignment is bound to an org or service-network node
CREATE TABLE security.user_role_scope (
    user_role_scope_id BIGSERIAL PRIMARY KEY,
    user_id           BIGINT NOT NULL REFERENCES security.application_user(user_id),
    role_id           BIGINT NOT NULL REFERENCES security.role(role_id),
    scope_type        TEXT NOT NULL CHECK (scope_type IN ('Global','Organisation','OrganisationNode','ServiceNetworkNode','ServiceCentre')),
    scope_node_id     BIGINT,
    effective_from    DATE NOT NULL DEFAULT CURRENT_DATE,
    effective_to      DATE
);

-- FR-ORG-003 field visibility matrix
CREATE TABLE security.field_visibility_policy (
    policy_id         BIGSERIAL PRIMARY KEY,
    audience          TEXT NOT NULL,          -- OEM / Dealer / Customer
    field_group       TEXT NOT NULL,          -- Cost / WarrantyDecision / RootCause / TechnicianIdentity / Reliability
    treatment         TEXT NOT NULL CHECK (treatment IN ('Allow','Mask','Hide'))
);

-- FR-AUTH-001 authorization / approval matrix (Doc 1.1 §36.10, Doc 04 §33.3)
CREATE TABLE security.authorization_policy (
    policy_id         BIGSERIAL PRIMARY KEY,
    action_code       TEXT NOT NULL,
    role_code         TEXT NOT NULL,
    requires_approval BOOLEAN NOT NULL DEFAULT false,
    sod_rule          TEXT,                   -- e.g. 'CreatorMayNotApprove'
    severity_threshold TEXT,
    value_threshold   NUMERIC(14,2),
    effect            TEXT NOT NULL DEFAULT 'Allow' CHECK (effect IN ('Allow','Deny')),
    effective_from    DATE NOT NULL DEFAULT CURRENT_DATE,
    effective_to      DATE,
    UNIQUE (action_code, role_code)
);

-- =====================================================================
-- MASTER — Document 1.1 §2, §3, §20, §21, §24, §25
-- Vehicle Category > Product Family > Model > Variant > VIN
-- =====================================================================

CREATE TABLE master.vehicle_category (
    category_id       BIGSERIAL PRIMARY KEY,
    code              TEXT NOT NULL UNIQUE,
    name              TEXT NOT NULL,
    status            TEXT NOT NULL DEFAULT 'Active'
);

CREATE TABLE master.product_family (
    family_id         BIGSERIAL PRIMARY KEY,
    category_id       BIGINT NOT NULL REFERENCES master.vehicle_category(category_id),
    code              TEXT NOT NULL UNIQUE,
    name              TEXT NOT NULL,
    status            TEXT NOT NULL DEFAULT 'Active'
);

CREATE TABLE master.vehicle_model (
    model_id          BIGSERIAL PRIMARY KEY,
    family_id         BIGINT NOT NULL REFERENCES master.product_family(family_id),
    code              TEXT NOT NULL UNIQUE,
    name              TEXT NOT NULL,
    -- CFG-001 / BL-CFG-001: publication gate
    confirmation_status TEXT NOT NULL DEFAULT 'Placeholder'
        CHECK (confirmation_status IN ('Confirmed','Placeholder')),
    confirmed_by      TEXT,
    confirmed_on      TIMESTAMPTZ,
    effective_from    DATE NOT NULL DEFAULT CURRENT_DATE,
    effective_to      DATE,
    status            TEXT NOT NULL DEFAULT 'Active'
);

CREATE TABLE master.vehicle_variant (
    variant_id        BIGSERIAL PRIMARY KEY,
    model_id          BIGINT NOT NULL REFERENCES master.vehicle_model(model_id),
    code              TEXT NOT NULL UNIQUE,
    name              TEXT NOT NULL,
    confirmation_status TEXT NOT NULL DEFAULT 'Placeholder'
        CHECK (confirmation_status IN ('Confirmed','Placeholder')),
    -- Doc 1.1 §3 configuration attributes
    axle_configuration TEXT,
    gvw_kg            NUMERIC(10,2),
    body_type         TEXT,
    drive_type        TEXT,                   -- 2WD / 4WD
    motor_type        TEXT,
    rated_power_kw    NUMERIC(8,2),
    peak_power_kw     NUMERIC(8,2),
    peak_torque_nm    NUMERIC(8,2),
    battery_chemistry TEXT,
    battery_capacity_kwh NUMERIC(8,2),
    battery_configuration TEXT,               -- Fixed / Swappable
    charger_type      TEXT,
    transmission      TEXT,
    front_brake       TEXT,
    rear_brake        TEXT,
    tyre_spec         TEXT,
    image_url         TEXT,
    effective_from    DATE NOT NULL DEFAULT CURRENT_DATE,
    effective_to      DATE,
    status            TEXT NOT NULL DEFAULT 'Active'
);

CREATE TABLE master.service_centre (
    service_centre_id BIGSERIAL PRIMARY KEY,
    network_node_id   BIGINT REFERENCES org.service_network_node(node_id),
    code              TEXT NOT NULL UNIQUE,
    name              TEXT NOT NULL,
    centre_type       TEXT NOT NULL DEFAULT 'Company' CHECK (centre_type IN ('Company','Authorized','Mobile')),
    city              TEXT,
    state             TEXT,
    region            TEXT,
    contact_phone     TEXT,
    latitude          NUMERIC(9,6),
    longitude         NUMERIC(9,6),
    capabilities      TEXT[],                 -- PM / Breakdown / HV / BatterySwap / Towing / Diagnostics
    business_calendar_id BIGINT,
    status            TEXT NOT NULL DEFAULT 'Active'
);

CREATE TABLE master.business_calendar (
    calendar_id       BIGSERIAL PRIMARY KEY,
    code              TEXT NOT NULL UNIQUE,
    name              TEXT NOT NULL,
    timezone          TEXT NOT NULL DEFAULT 'Asia/Kolkata',
    is_24x7           BOOLEAN NOT NULL DEFAULT false,
    working_days      INT[] NOT NULL DEFAULT '{1,2,3,4,5,6}',   -- ISO day numbers
    day_start         TIME NOT NULL DEFAULT '09:00',
    day_end           TIME NOT NULL DEFAULT '18:00'
);

CREATE TABLE master.calendar_holiday (
    holiday_id        BIGSERIAL PRIMARY KEY,
    calendar_id       BIGINT NOT NULL REFERENCES master.business_calendar(calendar_id),
    holiday_date      DATE NOT NULL,
    description       TEXT
);

ALTER TABLE master.service_centre
    ADD CONSTRAINT fk_sc_calendar FOREIGN KEY (business_calendar_id)
    REFERENCES master.business_calendar(calendar_id);

-- Doc 1.1 §25 Technician Skill & Authorization Master
CREATE TABLE master.technician (
    technician_id     BIGSERIAL PRIMARY KEY,
    user_id           BIGINT REFERENCES security.application_user(user_id),
    service_centre_id BIGINT NOT NULL REFERENCES master.service_centre(service_centre_id),
    employee_code     TEXT NOT NULL UNIQUE,
    name              TEXT NOT NULL,
    status            TEXT NOT NULL DEFAULT 'Active',
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- BL-SVC-007 / TECH-001: HV and model authorisations with validity
CREATE TABLE master.technician_skill (
    skill_id          BIGSERIAL PRIMARY KEY,
    technician_id     BIGINT NOT NULL REFERENCES master.technician(technician_id),
    skill_code        TEXT NOT NULL,          -- HV_BATTERY / MOTOR_INVERTER / CHARGING / AMT / BRAKES / PTO_HYDRAULICS / DIAGNOSTICS / QC
    authorization_level TEXT,
    certification_ref TEXT,
    valid_from        DATE NOT NULL DEFAULT CURRENT_DATE,
    valid_to          DATE,
    UNIQUE (technician_id, skill_code)
);

-- Doc 1.1 §20 VIN-level Vehicle Master
CREATE TABLE master.vehicle (
    vehicle_id        BIGSERIAL PRIMARY KEY,
    vin               TEXT NOT NULL UNIQUE,            -- BR-01 / BL-VEH-001
    registration_no   TEXT,
    fleet_asset_no    TEXT,
    variant_id        BIGINT NOT NULL REFERENCES master.vehicle_variant(variant_id),
    organisation_id   BIGINT NOT NULL REFERENCES org.organisation(organisation_id),
    depot_node_id     BIGINT REFERENCES org.organisation_node(node_id),
    assigned_service_centre_id BIGINT REFERENCES master.service_centre(service_centre_id),
    manufacture_date  DATE,
    delivery_date     DATE,
    commissioning_date DATE,
    warranty_start    DATE,
    warranty_end      DATE,
    warranty_km_limit INT,
    -- Usage snapshot (BL-USG-001..007)
    current_odometer_km NUMERIC(12,2) DEFAULT 0,
    current_operating_hours NUMERIC(12,2) DEFAULT 0,
    usage_source      TEXT DEFAULT 'Manual' CHECK (usage_source IN ('Telematics','Manual','Migration')),
    usage_updated_at  TIMESTAMPTZ,
    usage_is_stale    BOOLEAN NOT NULL DEFAULT false,
    telematics_device_id TEXT,
    -- Cached current availability state (Doc 04 §6: cache, not source of truth)
    current_availability_state TEXT DEFAULT 'In Service',
    lifecycle_status  TEXT NOT NULL DEFAULT 'Active'
        CHECK (lifecycle_status IN ('Active','Inactive','Retired','Disposed')),
    remarks           TEXT,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    row_version       BIGINT NOT NULL DEFAULT 1
);
CREATE INDEX ix_vehicle_org ON master.vehicle(organisation_id);
CREATE INDEX ix_vehicle_variant ON master.vehicle(variant_id);
CREATE INDEX ix_vehicle_sc ON master.vehicle(assigned_service_centre_id);
CREATE INDEX ix_vehicle_reg ON master.vehicle(registration_no);

-- Doc 1.1 §21 Component Master & Serialized Component History
-- BL-VEH-005: one active fitment per serialised component at a time
CREATE TABLE master.vehicle_component (
    fitment_id        BIGSERIAL PRIMARY KEY,
    vehicle_id        BIGINT NOT NULL REFERENCES master.vehicle(vehicle_id),
    component_type    TEXT NOT NULL,          -- BatteryPack / TractionMotor / MotorController / DCDC / OBC / Axle / AMT ...
    part_no           TEXT,
    serial_no         TEXT NOT NULL,
    supplier          TEXT,
    installed_on      DATE NOT NULL,
    installed_odometer_km NUMERIC(12,2),
    installed_job_card_id BIGINT,
    removed_on        DATE,
    removed_odometer_km NUMERIC(12,2),
    removed_job_card_id BIGINT,
    removal_reason    TEXT,
    warranty_start    DATE,
    warranty_end      DATE,
    warranty_km_limit INT,
    condition_status  TEXT NOT NULL DEFAULT 'Active'
        CHECK (condition_status IN ('Active','Removed','Failed','Repairable','Scrapped','Returned')),
    is_active         BOOLEAN NOT NULL DEFAULT true
);
CREATE INDEX ix_component_vehicle ON master.vehicle_component(vehicle_id, is_active);
CREATE UNIQUE INDEX ux_component_active_serial
    ON master.vehicle_component(serial_no) WHERE is_active;

-- Doc 1.1 §18 Spare Parts Master
CREATE TABLE master.part_master (
    part_id           BIGSERIAL PRIMARY KEY,
    part_no           TEXT NOT NULL UNIQUE,            -- SPM-001: Montra/OEM or ERP material code
    erp_material_code TEXT,
    description       TEXT NOT NULL,
    part_category     TEXT NOT NULL,
    subcategory       TEXT,
    criticality       TEXT CHECK (criticality IN ('Critical','Major','Minor')),
    part_class        TEXT CHECK (part_class IN ('PMConsumable','RepairSpare','Both')),
    base_uom          TEXT NOT NULL DEFAULT 'Nos',
    is_serial_controlled BOOLEAN NOT NULL DEFAULT false,   -- SPM-006
    is_batch_controlled  BOOLEAN NOT NULL DEFAULT false,
    warranty_return_required BOOLEAN NOT NULL DEFAULT false,
    superseded_by_part_id BIGINT REFERENCES master.part_master(part_id),
    standard_cost     NUMERIC(12,2),
    currency          TEXT DEFAULT 'INR',
    status            TEXT NOT NULL DEFAULT 'Active'
);

-- SPM-003/004: applicability validated before issue
CREATE TABLE master.part_applicability (
    applicability_id  BIGSERIAL PRIMARY KEY,
    part_id           BIGINT NOT NULL REFERENCES master.part_master(part_id),
    variant_id        BIGINT REFERENCES master.vehicle_variant(variant_id),
    model_id          BIGINT REFERENCES master.vehicle_model(model_id),
    is_universal      BOOLEAN NOT NULL DEFAULT false,
    effective_from    DATE NOT NULL DEFAULT CURRENT_DATE,
    effective_to      DATE,
    approval_status   TEXT NOT NULL DEFAULT 'Approved'
);
CREATE INDEX ix_part_applicability ON master.part_applicability(part_id, variant_id);

-- Doc 1.1 §22 Breakdown, Complaint & Failure Master
CREATE TABLE master.failure_code (
    failure_code_id   BIGSERIAL PRIMARY KEY,
    code              TEXT NOT NULL UNIQUE,
    code_type         TEXT NOT NULL CHECK (code_type IN ('Complaint','Subsystem','FailureMode','RootCause','CorrectiveAction')),
    description       TEXT NOT NULL,
    subsystem         TEXT,
    status            TEXT NOT NULL DEFAULT 'Active'
);

-- =====================================================================
-- UPTIME — Document 04 §6, Document 02 §24.1 (BL-AVL-001..015)
-- FR-AVL-001..005
-- =====================================================================

CREATE TABLE uptime.vehicle_status_reason (
    reason_code       TEXT PRIMARY KEY,
    availability_state TEXT NOT NULL,
    category          TEXT NOT NULL,
    is_down           BOOLEAN NOT NULL,
    planned_class     TEXT CHECK (planned_class IN ('Planned','Unplanned','NotApplicable')),
    default_attribution TEXT,                 -- Montra / ServiceCentre / Customer / Supplier / External
    pause_eligible    BOOLEAN NOT NULL DEFAULT false,
    include_in_sla    BOOLEAN NOT NULL DEFAULT true,
    include_in_availability BOOLEAN NOT NULL DEFAULT true,
    source_precedence INT NOT NULL DEFAULT 50,
    status            TEXT NOT NULL DEFAULT 'Active'
);

-- FR-AVL-001: one non-overlapping interval per operational state
CREATE TABLE uptime.vehicle_status_ledger (
    ledger_id         BIGSERIAL PRIMARY KEY,
    vehicle_id        BIGINT NOT NULL REFERENCES master.vehicle(vehicle_id),
    availability_state TEXT NOT NULL,
    reason_code       TEXT REFERENCES uptime.vehicle_status_reason(reason_code),
    start_utc         TIMESTAMPTZ NOT NULL,
    end_utc           TIMESTAMPTZ,
    source_type       TEXT NOT NULL,          -- Breakdown / ServiceEvent / JobCard / Telematics / Compliance / OffHire / ManualCorrection
    source_entity_id  BIGINT,
    transition_rule_id TEXT,                  -- BL-AVL rule that caused the transition (Doc 04 §33.1)
    precedence_rank   INT,
    correction_of_ledger_id BIGINT REFERENCES uptime.vehicle_status_ledger(ledger_id),
    attribution_party TEXT,
    gross_seconds     BIGINT,
    net_seconds       BIGINT,
    availability_eligible BOOLEAN NOT NULL DEFAULT true,
    created_by        TEXT,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT ck_ledger_interval CHECK (end_utc IS NULL OR end_utc >= start_utc)
);
CREATE INDEX ix_ledger_vehicle_start ON uptime.vehicle_status_ledger(vehicle_id, start_utc DESC);
-- UPM-001: only one open interval per VIN
CREATE UNIQUE INDEX ux_ledger_open_per_vehicle
    ON uptime.vehicle_status_ledger(vehicle_id) WHERE end_utc IS NULL;

-- FR-AVL-005 / OFF-001 / Doc 04 §33.2
CREATE TABLE uptime.off_hire_record (
    off_hire_id       BIGSERIAL PRIMARY KEY,
    vehicle_id        BIGINT NOT NULL REFERENCES master.vehicle(vehicle_id),
    reason_code       TEXT NOT NULL,
    evidence_ref      TEXT,
    requested_by      TEXT NOT NULL,
    approved_by       TEXT NOT NULL,
    start_utc         TIMESTAMPTZ NOT NULL,
    expected_return_utc TIMESTAMPTZ NOT NULL,
    end_utc           TIMESTAMPTZ,
    recommissioning_required BOOLEAN NOT NULL DEFAULT true,
    recommissioning_job_card_id BIGINT,
    status            TEXT NOT NULL DEFAULT 'Open' CHECK (status IN ('Open','Returned','Cancelled'))
);

-- =====================================================================
-- PM — Document 04 §7, §8. FR-PM-*, FR-PMO-*, CHK-*
-- =====================================================================

CREATE TABLE pm.pm_plan (
    plan_id           BIGSERIAL PRIMARY KEY,
    code              TEXT NOT NULL UNIQUE,
    name              TEXT NOT NULL,
    status            TEXT NOT NULL DEFAULT 'Active'
);

CREATE TABLE pm.pm_plan_version (
    plan_version_id   BIGSERIAL PRIMARY KEY,
    plan_id           BIGINT NOT NULL REFERENCES pm.pm_plan(plan_id),
    version_no        INT NOT NULL,
    variant_id        BIGINT REFERENCES master.vehicle_variant(variant_id),
    model_id          BIGINT REFERENCES master.vehicle_model(model_id),
    pm_level          TEXT NOT NULL,          -- PM-3M / PM-10K / PM-20K ...
    sequence_no       INT NOT NULL DEFAULT 1,
    next_plan_version_id BIGINT,              -- BL-PM-020 ladder
    checklist_version_id BIGINT,
    effective_from    DATE NOT NULL,
    effective_to      DATE,
    -- BL-SEC-007 maker-checker
    approval_status   TEXT NOT NULL DEFAULT 'Draft'
        CHECK (approval_status IN ('Draft','Review','Approved','Published','Retired')),
    created_by        TEXT,
    approved_by       TEXT,
    approved_on       TIMESTAMPTZ,
    UNIQUE (plan_id, version_no)
);

-- FR-PM-002/003: km, calendar and operating-hour triggers; earliest wins
CREATE TABLE pm.pm_plan_trigger (
    trigger_id        BIGSERIAL PRIMARY KEY,
    plan_version_id   BIGINT NOT NULL REFERENCES pm.pm_plan_version(plan_version_id) ON DELETE CASCADE,
    trigger_type      TEXT NOT NULL CHECK (trigger_type IN ('KM','Calendar','Hours')),
    interval_value    NUMERIC(12,2) NOT NULL, -- km, months, or hours
    due_soon_threshold NUMERIC(12,2) NOT NULL DEFAULT 0,
    tolerance         NUMERIC(12,2) NOT NULL DEFAULT 0,
    anchor_policy     TEXT NOT NULL DEFAULT 'OriginalSchedule'
        CHECK (anchor_policy IN ('OriginalSchedule','ActualCompletion'))   -- BL-PM-021/027
);

CREATE TABLE pm.checklist_template (
    template_id       BIGSERIAL PRIMARY KEY,
    code              TEXT NOT NULL UNIQUE,   -- e.g. RHINO-5538-6X4-PM20K
    name              TEXT NOT NULL,
    variant_id        BIGINT REFERENCES master.vehicle_variant(variant_id),
    model_id          BIGINT REFERENCES master.vehicle_model(model_id),
    service_type      TEXT NOT NULL DEFAULT 'PM',
    status            TEXT NOT NULL DEFAULT 'Active'
);

-- CHK-003/004: version-controlled publication, frozen on completed jobs
CREATE TABLE pm.checklist_version (
    checklist_version_id BIGSERIAL PRIMARY KEY,
    template_id       BIGINT NOT NULL REFERENCES pm.checklist_template(template_id),
    version_no        INT NOT NULL,
    effective_from    DATE NOT NULL,
    effective_to      DATE,
    approval_status   TEXT NOT NULL DEFAULT 'Draft'
        CHECK (approval_status IN ('Draft','Review','Approved','Published','Retired')),
    created_by        TEXT,
    approved_by       TEXT,
    approved_on       TIMESTAMPTZ,
    UNIQUE (template_id, version_no)
);

ALTER TABLE pm.pm_plan_version
    ADD CONSTRAINT fk_ppv_checklist FOREIGN KEY (checklist_version_id)
    REFERENCES pm.checklist_version(checklist_version_id);

CREATE TABLE pm.checklist_section (
    section_id        BIGSERIAL PRIMARY KEY,
    checklist_version_id BIGINT NOT NULL REFERENCES pm.checklist_version(checklist_version_id) ON DELETE CASCADE,
    code              TEXT NOT NULL,
    name              TEXT NOT NULL,
    display_order     INT NOT NULL DEFAULT 1
);

-- Doc 1.1 §5, §36.6 canonical response master
CREATE TABLE pm.checklist_item (
    item_id           BIGSERIAL PRIMARY KEY,
    section_id        BIGINT NOT NULL REFERENCES pm.checklist_section(section_id) ON DELETE CASCADE,
    code              TEXT NOT NULL,
    description       TEXT NOT NULL,
    inspection_method TEXT,                   -- Visual / Measurement / Diagnostic / Functional
    response_mode     TEXT NOT NULL DEFAULT 'PassFail'
        CHECK (response_mode IN ('PassFail','Numeric','Text','Photo')),
    is_mandatory      BOOLEAN NOT NULL DEFAULT true,
    is_conditional    BOOLEAN NOT NULL DEFAULT false,
    condition_expression TEXT,
    unit              TEXT,
    min_value         NUMERIC(12,3),
    max_value         NUMERIC(12,3),
    target_value      NUMERIC(12,3),
    defect_severity_on_fail TEXT CHECK (defect_severity_on_fail IN ('Critical','Major','Minor')),
    creates_defect_on_fail BOOLEAN NOT NULL DEFAULT true,   -- BL-CHK-004
    blocks_release_on_fail BOOLEAN NOT NULL DEFAULT false,  -- BL-CHK-005
    photo_required    TEXT NOT NULL DEFAULT 'No' CHECK (photo_required IN ('No','Yes','OnFailure')),
    recommended_part_id BIGINT REFERENCES master.part_master(part_id),  -- SPM-010
    recommended_qty   NUMERIC(10,2),
    display_order     INT NOT NULL DEFAULT 1
);

-- FR-PMO-001: one persisted obligation per VIN / PM level / cycle. Never overwritten.
CREATE TABLE pm.pm_obligation (
    pm_obligation_id  BIGSERIAL PRIMARY KEY,
    vehicle_id        BIGINT NOT NULL REFERENCES master.vehicle(vehicle_id),
    plan_version_id   BIGINT NOT NULL REFERENCES pm.pm_plan_version(plan_version_id),
    pm_level          TEXT NOT NULL,
    cycle_no          INT NOT NULL,
    target_km         NUMERIC(12,2),
    target_date       DATE,
    target_hours      NUMERIC(12,2),
    due_soon_km       NUMERIC(12,2),
    due_soon_days     INT,
    due_soon_hours    NUMERIC(12,2),
    tolerance_km      NUMERIC(12,2),
    tolerance_days    INT,
    tolerance_hours   NUMERIC(12,2),
    status            TEXT NOT NULL DEFAULT 'Upcoming' CHECK (status IN (
        'Upcoming','Due Soon','Due','Overdue','Scheduled','Under Service',
        'Completed On Time','Completed Within Tolerance','Completed Late',
        'Skipped-Authorised','Superseded','Cancelled')),
    driving_trigger   TEXT,                   -- which trigger set the current status
    is_estimated      BOOLEAN NOT NULL DEFAULT false,   -- BL-USG-004
    created_source    TEXT NOT NULL DEFAULT 'System',
    actual_completion_km NUMERIC(12,2),
    actual_completion_date DATE,
    actual_completion_hours NUMERIC(12,2),
    variance_km       NUMERIC(12,2),
    variance_days     INT,
    outcome           TEXT,
    exclusion_reason  TEXT,
    completed_job_card_id BIGINT,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    row_version       BIGINT NOT NULL DEFAULT 1,
    UNIQUE (vehicle_id, plan_version_id, cycle_no)
);
CREATE INDEX ix_pmo_status ON pm.pm_obligation(status);
CREATE INDEX ix_pmo_vehicle ON pm.pm_obligation(vehicle_id);
CREATE INDEX ix_pmo_target_date ON pm.pm_obligation(target_date);

-- BL-USG-004: projected usage when telematics is stale
CREATE TABLE pm.pm_usage_projection (
    vehicle_id        BIGINT PRIMARY KEY REFERENCES master.vehicle(vehicle_id),
    avg_km_per_day    NUMERIC(10,3),
    avg_hours_per_day NUMERIC(10,3),
    window_days       INT,
    confidence        TEXT,
    calculated_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    is_stale          BOOLEAN NOT NULL DEFAULT false
);

-- =====================================================================
-- SCHEDULE — Document 04 §11. FR-APT-001..004, CAP-001
-- =====================================================================

CREATE TABLE schedule.service_bay (
    bay_id            BIGSERIAL PRIMARY KEY,
    service_centre_id BIGINT NOT NULL REFERENCES master.service_centre(service_centre_id),
    bay_code          TEXT NOT NULL,
    bay_type          TEXT,
    supported_categories TEXT[],
    status            TEXT NOT NULL DEFAULT 'Active',
    UNIQUE (service_centre_id, bay_code)
);

CREATE TABLE schedule.shift (
    shift_id          BIGSERIAL PRIMARY KEY,
    service_centre_id BIGINT NOT NULL REFERENCES master.service_centre(service_centre_id),
    code              TEXT NOT NULL,
    start_time        TIME NOT NULL,
    end_time          TIME NOT NULL,
    working_days      INT[] NOT NULL DEFAULT '{1,2,3,4,5,6}'
);

CREATE TABLE schedule.technician_roster (
    roster_id         BIGSERIAL PRIMARY KEY,
    technician_id     BIGINT NOT NULL REFERENCES master.technician(technician_id),
    service_centre_id BIGINT NOT NULL REFERENCES master.service_centre(service_centre_id),
    roster_date       DATE NOT NULL,
    shift_id          BIGINT REFERENCES schedule.shift(shift_id),
    is_available      BOOLEAN NOT NULL DEFAULT true,
    unavailable_reason TEXT,
    UNIQUE (technician_id, roster_date)
);

-- FR-APT-002: Standard Repair Time by operation x model/variant
CREATE TABLE schedule.standard_repair_time (
    srt_id            BIGSERIAL PRIMARY KEY,
    operation_code    TEXT NOT NULL,
    description       TEXT NOT NULL,
    variant_id        BIGINT REFERENCES master.vehicle_variant(variant_id),
    model_id          BIGINT REFERENCES master.vehicle_model(model_id),
    work_item_type    TEXT,
    standard_minutes  INT NOT NULL,
    skill_code        TEXT,
    version_no        INT NOT NULL DEFAULT 1,
    effective_from    DATE NOT NULL DEFAULT CURRENT_DATE,
    approval_status   TEXT NOT NULL DEFAULT 'Approved',
    UNIQUE (operation_code, variant_id, version_no)
);

CREATE TABLE schedule.appointment (
    appointment_id    BIGSERIAL PRIMARY KEY,
    appointment_no    TEXT NOT NULL UNIQUE,
    vehicle_id        BIGINT NOT NULL REFERENCES master.vehicle(vehicle_id),
    pm_obligation_id  BIGINT REFERENCES pm.pm_obligation(pm_obligation_id),
    service_event_id  BIGINT,
    service_centre_id BIGINT NOT NULL REFERENCES master.service_centre(service_centre_id),
    bay_id            BIGINT REFERENCES schedule.service_bay(bay_id),
    technician_id     BIGINT REFERENCES master.technician(technician_id),
    service_type      TEXT NOT NULL,
    slot_start        TIMESTAMPTZ NOT NULL,
    slot_end          TIMESTAMPTZ NOT NULL,
    estimated_minutes INT NOT NULL,
    status            TEXT NOT NULL DEFAULT 'Scheduled'
        CHECK (status IN ('Scheduled','Confirmed','In Progress','Completed','No Show','Rescheduled','Cancelled')),
    no_show_reason    TEXT,
    reschedule_reason TEXT,
    booked_by         TEXT,
    request_notes     TEXT,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    row_version       BIGINT NOT NULL DEFAULT 1,
    CONSTRAINT ck_appt_slot CHECK (slot_end > slot_start)
);
CREATE INDEX ix_appt_centre_slot ON schedule.appointment(service_centre_id, slot_start);
CREATE INDEX ix_appt_status ON schedule.appointment(status);

-- =====================================================================
-- SERVICE — Document 04 §9, §12. FR-SE-001, FR-JC-*, BL-JC-009..013
-- Service Event (1) -> Job Card (many) -> Work Item (many)
-- =====================================================================

CREATE TABLE service.service_event (
    service_event_id  BIGSERIAL PRIMARY KEY,
    service_event_no  TEXT NOT NULL UNIQUE,
    vehicle_id        BIGINT NOT NULL REFERENCES master.vehicle(vehicle_id),
    event_type        TEXT NOT NULL CHECK (event_type IN ('PM','Breakdown','Accident','Campaign','Inspection','General Service','Warranty')),
    source_channel    TEXT,                   -- Portal / CallCentre / Telematics / WalkIn / System
    priority          TEXT CHECK (priority IN ('P1','P2','P3')),
    customer_visible_start TIMESTAMPTZ NOT NULL DEFAULT now(),
    customer_visible_end TIMESTAMPTZ,
    status            TEXT NOT NULL DEFAULT 'Open'
        CHECK (status IN ('Open','In Progress','Completed','Closed','Cancelled')),
    -- BL-BD-013: closure content
    final_diagnosis   TEXT,
    root_cause_code   TEXT,
    corrective_action_code TEXT,
    closure_disposition TEXT,                 -- Normal / NoFaultFound / UnableToReproduce
    -- Reliability (Doc 04 §33.4)
    is_repeat         BOOLEAN NOT NULL DEFAULT false,
    prior_service_event_id BIGINT REFERENCES service.service_event(service_event_id),
    ftf_eligible      BOOLEAN NOT NULL DEFAULT true,
    ftf_result        TEXT,
    sla_id            BIGINT,
    created_by        TEXT,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    row_version       BIGINT NOT NULL DEFAULT 1
);
CREATE INDEX ix_se_vehicle ON service.service_event(vehicle_id);
CREATE INDEX ix_se_status ON service.service_event(status);
CREATE INDEX ix_se_type ON service.service_event(event_type);

-- Doc 04 §12, BL-TS-001: breakdown timestamp dictionary stored separately
CREATE TABLE service.breakdown_event (
    breakdown_id      BIGSERIAL PRIMARY KEY,
    service_event_id  BIGINT NOT NULL REFERENCES service.service_event(service_event_id),
    vehicle_id        BIGINT NOT NULL REFERENCES master.vehicle(vehicle_id),
    -- BL-TS-001 timestamps
    stopped_actual_utc TIMESTAMPTZ,
    reported_utc      TIMESTAMPTZ NOT NULL,
    logged_utc        TIMESTAMPTZ NOT NULL DEFAULT now(),
    accepted_utc      TIMESTAMPTZ,
    assigned_utc      TIMESTAMPTZ,
    en_route_utc      TIMESTAMPTZ,
    on_site_utc       TIMESTAMPTZ,
    restored_operable_utc TIMESTAMPTZ,
    released_utc      TIMESTAMPTZ,
    closed_utc        TIMESTAMPTZ,
    -- Intake (FR-BD-002)
    reported_by       TEXT,
    contact_phone     TEXT,
    location_text     TEXT,
    latitude          NUMERIC(9,6),
    longitude         NUMERIC(9,6),
    mobility          TEXT NOT NULL CHECK (mobility IN ('Can move','Limited movement','Immobilized')),
    complaint_code    TEXT,
    complaint_text    TEXT NOT NULL,
    warning_indicator TEXT,
    dtc_summary       TEXT,
    priority          TEXT NOT NULL CHECK (priority IN ('P1','P2','P3')),
    priority_reason   TEXT,
    breakdown_type    TEXT,
    disposition       TEXT,                   -- RemoteResolution / MobileTechnician / ServiceCentre / Towing
    triaged_by        TEXT,
    triaged_at        TIMESTAMPTZ
);
CREATE INDEX ix_bd_service_event ON service.breakdown_event(service_event_id);

-- FR-JC-009: job card is location/workshop owned
CREATE TABLE service.job_card (
    job_card_id       BIGSERIAL PRIMARY KEY,
    job_card_no       TEXT NOT NULL UNIQUE,
    service_event_id  BIGINT NOT NULL REFERENCES service.service_event(service_event_id),
    vehicle_id        BIGINT NOT NULL REFERENCES master.vehicle(vehicle_id),
    service_centre_id BIGINT REFERENCES master.service_centre(service_centre_id),
    location_type     TEXT NOT NULL DEFAULT 'Workshop' CHECK (location_type IN ('Workshop','Roadside','Customer Site')),
    job_type          TEXT NOT NULL,
    bay_id            BIGINT REFERENCES schedule.service_bay(bay_id),
    technician_id     BIGINT REFERENCES master.technician(technician_id),
    supervisor_user_id BIGINT REFERENCES security.application_user(user_id),
    -- BL-JC-011 canonical status set
    status            TEXT NOT NULL DEFAULT 'Open' CHECK (status IN (
        'Open','Scheduled','Assigned','Under Diagnosis','Repairing','Awaiting Parts',
        'Awaiting Customer Approval','Awaiting Warranty Decision','Awaiting Internal Authorization',
        'Awaiting Insurance','Technician Complete','QC Pending','Completed','Closed',
        'On Hold','Transferred','Split','Reopened','Cancelled')),
    odometer_at_open  NUMERIC(12,2),
    hours_at_open     NUMERIC(12,2),
    -- Timestamps
    opened_utc        TIMESTAMPTZ NOT NULL DEFAULT now(),
    accepted_utc      TIMESTAMPTZ,
    started_utc       TIMESTAMPTZ,
    technician_complete_utc TIMESTAMPTZ,
    qc_utc            TIMESTAMPTZ,
    released_utc      TIMESTAMPTZ,
    closed_utc        TIMESTAMPTZ,
    -- Handover (BL-JC-010)
    transferred_from_job_card_id BIGINT REFERENCES service.job_card(job_card_id),
    transfer_reason   TEXT,
    reopen_reason     TEXT,
    cancel_reason     TEXT,
    complaint_text    TEXT,
    created_by        TEXT,
    row_version       BIGINT NOT NULL DEFAULT 1
);
CREATE INDEX ix_jc_service_event ON service.job_card(service_event_id);
CREATE INDEX ix_jc_status ON service.job_card(status);
CREATE INDEX ix_jc_vehicle ON service.job_card(vehicle_id);
CREATE INDEX ix_jc_centre ON service.job_card(service_centre_id);

CREATE TABLE service.work_item (
    work_item_id      BIGSERIAL PRIMARY KEY,
    job_card_id       BIGINT NOT NULL REFERENCES service.job_card(job_card_id),
    line_no           INT NOT NULL,
    work_item_type    TEXT NOT NULL CHECK (work_item_type IN ('PM','Defect','Campaign','Accident','Software','Inspection','Repair','Diagnosis','Part Replacement','Other')),
    description       TEXT NOT NULL,
    source_entity_type TEXT,
    source_entity_id  BIGINT,
    srt_id            BIGINT REFERENCES schedule.standard_repair_time(srt_id),
    srt_minutes       INT,
    status            TEXT NOT NULL DEFAULT 'Not Started'
        CHECK (status IN ('Not Started','In Progress','Completed','Deferred','Cancelled')),
    started_utc       TIMESTAMPTZ,
    completed_utc     TIMESTAMPTZ,
    UNIQUE (job_card_id, line_no)
);
CREATE INDEX ix_wi_job_card ON service.work_item(job_card_id);

-- Frozen PM execution context (Doc 04 §7)
CREATE TABLE pm.pm_execution (
    pm_execution_id   BIGSERIAL PRIMARY KEY,
    work_item_id      BIGINT NOT NULL REFERENCES service.work_item(work_item_id),
    job_card_id       BIGINT NOT NULL REFERENCES service.job_card(job_card_id),
    pm_obligation_id  BIGINT NOT NULL REFERENCES pm.pm_obligation(pm_obligation_id),
    frozen_plan_version_id BIGINT NOT NULL REFERENCES pm.pm_plan_version(plan_version_id),
    frozen_checklist_version_id BIGINT NOT NULL REFERENCES pm.checklist_version(checklist_version_id),
    actual_km         NUMERIC(12,2),
    actual_hours      NUMERIC(12,2),
    executed_at       TIMESTAMPTZ
);

-- CHK-013 / Doc 04 §8
CREATE TABLE pm.checklist_result (
    result_id         BIGSERIAL PRIMARY KEY,
    job_card_id       BIGINT NOT NULL REFERENCES service.job_card(job_card_id),
    work_item_id      BIGINT REFERENCES service.work_item(work_item_id),
    checklist_version_id BIGINT NOT NULL REFERENCES pm.checklist_version(checklist_version_id),
    item_id           BIGINT NOT NULL REFERENCES pm.checklist_item(item_id),
    -- BL-CHK-009 canonical response types
    response_type     TEXT NOT NULL CHECK (response_type IN ('OK','Not OK','Advisory-Observation','Not Applicable','Numeric','Text','Photo')),
    numeric_value     NUMERIC(12,3),
    text_value        TEXT,
    na_reason         TEXT,                   -- BL-CHK-011
    photo_ref         TEXT,
    technician_id     BIGINT REFERENCES master.technician(technician_id),
    recorded_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    client_operation_id TEXT,                 -- offline idempotency (Doc 04 §18)
    row_version       BIGINT NOT NULL DEFAULT 1,
    UNIQUE (job_card_id, item_id)
);
CREATE INDEX ix_result_job ON pm.checklist_result(job_card_id);

-- BL-DEF-001: defect ownership is VIN-level, survives job closure
CREATE TABLE service.defect (
    defect_id         BIGSERIAL PRIMARY KEY,
    defect_no         TEXT NOT NULL UNIQUE,
    vehicle_id        BIGINT NOT NULL REFERENCES master.vehicle(vehicle_id),
    origin_job_card_id BIGINT REFERENCES service.job_card(job_card_id),
    origin_result_id  BIGINT REFERENCES pm.checklist_result(result_id),
    severity          TEXT NOT NULL CHECK (severity IN ('Critical','Major','Minor')),
    subsystem         TEXT,
    component_type    TEXT,
    description       TEXT NOT NULL,
    status            TEXT NOT NULL DEFAULT 'Open'
        CHECK (status IN ('Open','Under Action','Retest/Verification','Closed','Deferred','Dispositioned')),
    is_deferred       BOOLEAN NOT NULL DEFAULT false,
    blocks_release    BOOLEAN NOT NULL DEFAULT false,   -- BL-CHK-005 / BL-QC-003
    opened_date       DATE NOT NULL DEFAULT CURRENT_DATE,
    opened_odometer_km NUMERIC(12,2),
    due_by_date       DATE,
    due_by_km         NUMERIC(12,2),
    responsible_role  TEXT,
    carried_forward   BOOLEAN NOT NULL DEFAULT false,
    closed_job_card_id BIGINT REFERENCES service.job_card(job_card_id),
    closed_at         TIMESTAMPTZ,
    closure_action    TEXT,
    repeat_rule_group TEXT,
    row_version       BIGINT NOT NULL DEFAULT 1
);
CREATE INDEX ix_defect_vehicle_status ON service.defect(vehicle_id, status);

CREATE TABLE service.labour (
    labour_id         BIGSERIAL PRIMARY KEY,
    job_card_id       BIGINT NOT NULL REFERENCES service.job_card(job_card_id),
    work_item_id      BIGINT REFERENCES service.work_item(work_item_id),
    technician_id     BIGINT NOT NULL REFERENCES master.technician(technician_id),
    activity          TEXT,
    start_utc         TIMESTAMPTZ NOT NULL,
    end_utc           TIMESTAMPTZ,
    hours             NUMERIC(8,2)
);

-- Doc 04 §13 Parts, VOR and serialized replacement
CREATE TABLE service.part_usage (
    part_usage_id     BIGSERIAL PRIMARY KEY,
    job_card_id       BIGINT NOT NULL REFERENCES service.job_card(job_card_id),
    work_item_id      BIGINT REFERENCES service.work_item(work_item_id),
    part_id           BIGINT NOT NULL REFERENCES master.part_master(part_id),
    quantity          NUMERIC(10,2) NOT NULL CHECK (quantity > 0),   -- BL-SP-008
    uom               TEXT NOT NULL DEFAULT 'Nos',
    source            TEXT NOT NULL DEFAULT 'Stock' CHECK (source IN ('Stock','Vendor','Customer','Warranty')),
    status            TEXT NOT NULL DEFAULT 'Requested'
        CHECK (status IN ('Requested','Reserved','Issued','Fitted','Returned','Cancelled','Pending')),
    old_serial_no     TEXT,
    new_serial_no     TEXT,
    batch_no          TEXT,
    erp_reservation_ref TEXT,
    erp_issue_ref     TEXT,
    is_warranty       BOOLEAN NOT NULL DEFAULT false,
    failed_part_disposition TEXT,             -- Return / WarrantyReturn / Repairable / Scrap / Quarantine
    unit_cost         NUMERIC(12,2),
    recorded_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_part_usage_job ON service.part_usage(job_card_id);

-- FR-SP-022 VOR
CREATE TABLE service.vor_status (
    vor_id            BIGSERIAL PRIMARY KEY,
    job_card_id       BIGINT NOT NULL REFERENCES service.job_card(job_card_id),
    part_id           BIGINT REFERENCES master.part_master(part_id),
    vehicle_off_road  BOOLEAN NOT NULL DEFAULT true,
    promised_availability_date DATE,
    backorder_ref     TEXT,
    expedite_status   TEXT,
    escalation_owner  TEXT,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- FR-CLK-001 / BL-CLK-001: explicit pause intervals; status alone never pauses a clock
CREATE TABLE service.clock_pause (
    pause_id          BIGSERIAL PRIMARY KEY,
    job_card_id       BIGINT REFERENCES service.job_card(job_card_id),
    service_event_id  BIGINT REFERENCES service.service_event(service_event_id),
    ledger_id         BIGINT REFERENCES uptime.vehicle_status_ledger(ledger_id),
    clock_type        TEXT NOT NULL CHECK (clock_type IN ('SLA','Turnaround','Downtime')),
    pause_reason      TEXT NOT NULL,
    start_utc         TIMESTAMPTZ NOT NULL,
    end_utc           TIMESTAMPTZ,
    accountable_party TEXT,
    authorized_by     TEXT,
    exclude_from_net  BOOLEAN NOT NULL DEFAULT true,
    comment           TEXT
);

CREATE TABLE service.job_activity (
    activity_id       BIGSERIAL PRIMARY KEY,
    job_card_id       BIGINT NOT NULL REFERENCES service.job_card(job_card_id),
    work_item_id      BIGINT REFERENCES service.work_item(work_item_id),
    activity_type     TEXT NOT NULL,
    from_status       TEXT,
    to_status         TEXT,
    performed_by      TEXT,
    performed_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    reason            TEXT,
    remarks           TEXT
);
CREATE INDEX ix_activity_job ON service.job_activity(job_card_id, performed_at);

-- BL-SVC-005 / Doc 04 §33.5 assignment history
CREATE TABLE service.assignment_history (
    assignment_id     BIGSERIAL PRIMARY KEY,
    job_card_id       BIGINT NOT NULL REFERENCES service.job_card(job_card_id),
    from_technician_id BIGINT REFERENCES master.technician(technician_id),
    to_technician_id  BIGINT REFERENCES master.technician(technician_id),
    from_service_centre_id BIGINT REFERENCES master.service_centre(service_centre_id),
    to_service_centre_id BIGINT REFERENCES master.service_centre(service_centre_id),
    reason            TEXT NOT NULL,
    actor             TEXT NOT NULL,
    occurred_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Doc 04 §12 RSA / recovery (FR-RSA-001)
CREATE TABLE service.recovery_request (
    recovery_id       BIGSERIAL PRIMARY KEY,
    breakdown_id      BIGINT NOT NULL REFERENCES service.breakdown_event(breakdown_id),
    provider_name     TEXT,
    eta_utc           TIMESTAMPTZ,
    requested_utc     TIMESTAMPTZ NOT NULL DEFAULT now(),
    accepted_utc      TIMESTAMPTZ,
    en_route_utc      TIMESTAMPTZ,
    on_site_utc       TIMESTAMPTZ,
    in_transit_utc    TIMESTAMPTZ,
    delivered_utc     TIMESTAMPTZ,
    tow_status        TEXT,
    cost              NUMERIC(12,2)
);

-- FR-ACC-001
CREATE TABLE service.accident_record (
    accident_id       BIGSERIAL PRIMARY KEY,
    service_event_id  BIGINT NOT NULL REFERENCES service.service_event(service_event_id),
    accident_date     TIMESTAMPTZ NOT NULL,
    location_text     TEXT,
    fir_reference     TEXT,
    third_party_details TEXT,
    damage_assessment TEXT,
    insurer           TEXT,
    policy_no         TEXT,
    claim_no          TEXT,
    surveyor          TEXT,
    survey_date       DATE,
    approved_amount   NUMERIC(14,2),
    settlement_status TEXT
);

-- =====================================================================
-- COMMERCIAL — Document 04 §14
-- =====================================================================

CREATE TABLE commercial.warranty_rule (
    warranty_rule_id  BIGSERIAL PRIMARY KEY,
    code              TEXT NOT NULL UNIQUE,
    name              TEXT NOT NULL,
    scope_type        TEXT NOT NULL CHECK (scope_type IN ('Vehicle','Component','Part')),
    variant_id        BIGINT REFERENCES master.vehicle_variant(variant_id),
    model_id          BIGINT REFERENCES master.vehicle_model(model_id),
    component_type    TEXT,
    max_age_months    INT,
    max_km            INT,
    max_hours         INT,
    exclusions        TEXT,
    evidence_required TEXT,
    version_no        INT NOT NULL DEFAULT 1,
    effective_from    DATE NOT NULL DEFAULT CURRENT_DATE,
    effective_to      DATE,
    status            TEXT NOT NULL DEFAULT 'Active'
);

CREATE TABLE commercial.warranty_evaluation (
    evaluation_id     BIGSERIAL PRIMARY KEY,
    job_card_id       BIGINT REFERENCES service.job_card(job_card_id),
    work_item_id      BIGINT REFERENCES service.work_item(work_item_id),
    defect_id         BIGINT REFERENCES service.defect(defect_id),
    part_usage_id     BIGINT REFERENCES service.part_usage(part_usage_id),
    warranty_rule_id  BIGINT REFERENCES commercial.warranty_rule(warranty_rule_id),
    rule_version      INT,
    result            TEXT NOT NULL CHECK (result IN ('Eligible','Not Eligible','Approval Required','Rejected','Goodwill','Customer Pay','Engineering Review')),
    reason            TEXT,
    evidence_ref      TEXT,
    approver          TEXT,
    decided_at        TIMESTAMPTZ,
    claim_no          TEXT,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE commercial.contract (
    contract_id       BIGSERIAL PRIMARY KEY,
    contract_no       TEXT NOT NULL UNIQUE,
    organisation_id   BIGINT NOT NULL REFERENCES org.organisation(organisation_id),
    contract_type     TEXT NOT NULL,          -- AMC / Warranty Extension / Uptime
    start_date        DATE NOT NULL,
    end_date          DATE NOT NULL,
    km_limit          INT,
    hour_limit        INT,
    free_services_total INT DEFAULT 0,
    labour_cover_pct  NUMERIC(5,2) DEFAULT 0,
    parts_cover_pct   NUMERIC(5,2) DEFAULT 0,
    uptime_commitment_pct NUMERIC(5,2),
    inclusions        TEXT,
    exclusions        TEXT,
    status            TEXT NOT NULL DEFAULT 'Active'
);

CREATE TABLE commercial.entitlement (
    entitlement_id    BIGSERIAL PRIMARY KEY,
    contract_id       BIGINT NOT NULL REFERENCES commercial.contract(contract_id),
    vehicle_id        BIGINT NOT NULL REFERENCES master.vehicle(vehicle_id),
    entitlement_type  TEXT NOT NULL,
    total_quantity    INT,
    consumed_quantity INT NOT NULL DEFAULT 0,
    status            TEXT NOT NULL DEFAULT 'Active'
);

CREATE TABLE commercial.estimate (
    estimate_id       BIGSERIAL PRIMARY KEY,
    estimate_no       TEXT NOT NULL UNIQUE,
    service_event_id  BIGINT NOT NULL REFERENCES service.service_event(service_event_id),
    job_card_id       BIGINT REFERENCES service.job_card(job_card_id),
    revision_no       INT NOT NULL DEFAULT 1,
    total_amount      NUMERIC(14,2) NOT NULL DEFAULT 0,
    currency          TEXT NOT NULL DEFAULT 'INR',
    valid_to          DATE,
    sent_at           TIMESTAMPTZ,
    decision          TEXT CHECK (decision IN ('Pending','Approved','Rejected','Revised')),
    approver          TEXT,
    decided_at        TIMESTAMPTZ,
    notes             TEXT,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    row_version       BIGINT NOT NULL DEFAULT 1
);

CREATE TABLE commercial.estimate_line (
    estimate_line_id  BIGSERIAL PRIMARY KEY,
    estimate_id       BIGINT NOT NULL REFERENCES commercial.estimate(estimate_id) ON DELETE CASCADE,
    line_type         TEXT NOT NULL CHECK (line_type IN ('Part','Labour','External')),
    item_ref          TEXT,
    description       TEXT NOT NULL,
    quantity          NUMERIC(10,2) NOT NULL DEFAULT 1,
    rate              NUMERIC(12,2) NOT NULL DEFAULT 0,
    amount            NUMERIC(14,2) NOT NULL DEFAULT 0,
    coverage_split    TEXT NOT NULL DEFAULT 'Customer'
        CHECK (coverage_split IN ('Warranty','Customer','Goodwill','AMC','Internal'))
);

CREATE TABLE commercial.cost_line (
    cost_line_id      BIGSERIAL PRIMARY KEY,
    service_event_id  BIGINT REFERENCES service.service_event(service_event_id),
    job_card_id       BIGINT REFERENCES service.job_card(job_card_id),
    work_item_id      BIGINT REFERENCES service.work_item(work_item_id),
    category          TEXT NOT NULL CHECK (category IN ('Parts','Labour','External','Towing','Consumable')),
    amount            NUMERIC(14,2) NOT NULL,
    currency          TEXT NOT NULL DEFAULT 'INR',
    payer_class       TEXT NOT NULL CHECK (payer_class IN ('Warranty','Customer','Goodwill','AMC','Internal')),
    source            TEXT NOT NULL DEFAULT 'Manual',
    recorded_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =====================================================================
-- QUALITY — Document 04 §8 / Doc 1.1 §27. QC-001..003, BL-QC-*
-- =====================================================================

CREATE TABLE quality.qc_checklist (
    qc_checklist_id   BIGSERIAL PRIMARY KEY,
    code              TEXT NOT NULL UNIQUE,
    name              TEXT NOT NULL,
    service_type      TEXT,
    category_id       BIGINT REFERENCES master.vehicle_category(category_id),
    status            TEXT NOT NULL DEFAULT 'Active'
);

CREATE TABLE quality.qc_checklist_item (
    qc_item_id        BIGSERIAL PRIMARY KEY,
    qc_checklist_id   BIGINT NOT NULL REFERENCES quality.qc_checklist(qc_checklist_id) ON DELETE CASCADE,
    code              TEXT NOT NULL,
    description       TEXT NOT NULL,
    is_mandatory      BOOLEAN NOT NULL DEFAULT true,
    display_order     INT NOT NULL DEFAULT 1
);

CREATE TABLE quality.qc_result (
    qc_result_id      BIGSERIAL PRIMARY KEY,
    job_card_id       BIGINT NOT NULL REFERENCES service.job_card(job_card_id),
    qc_item_id        BIGINT NOT NULL REFERENCES quality.qc_checklist_item(qc_item_id),
    result            TEXT NOT NULL CHECK (result IN ('Pass','Fail','Not Applicable')),
    remarks           TEXT,
    checked_by_user_id BIGINT REFERENCES security.application_user(user_id),
    checked_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (job_card_id, qc_item_id)
);

-- FR-CON-001 / BL-CON-001
CREATE TABLE quality.concession (
    concession_id     BIGSERIAL PRIMARY KEY,
    concession_no     TEXT NOT NULL UNIQUE,
    vehicle_id        BIGINT NOT NULL REFERENCES master.vehicle(vehicle_id),
    defect_id         BIGINT REFERENCES service.defect(defect_id),
    job_card_id       BIGINT REFERENCES service.job_card(job_card_id),
    reason            TEXT NOT NULL,
    approver          TEXT NOT NULL,
    approved_on       TIMESTAMPTZ NOT NULL DEFAULT now(),
    expiry_date       DATE,
    expiry_km         NUMERIC(12,2),
    follow_up_action  TEXT NOT NULL,
    owner_role        TEXT NOT NULL,
    evidence_ref      TEXT,
    status            TEXT NOT NULL DEFAULT 'Active' CHECK (status IN ('Active','Closed','Expired','Escalated')),
    blocks_release_after_expiry BOOLEAN NOT NULL DEFAULT true
);

CREATE TABLE quality.vehicle_release (
    release_id        BIGSERIAL PRIMARY KEY,
    job_card_id       BIGINT NOT NULL REFERENCES service.job_card(job_card_id),
    service_event_id  BIGINT NOT NULL REFERENCES service.service_event(service_event_id),
    vehicle_id        BIGINT NOT NULL REFERENCES master.vehicle(vehicle_id),
    release_type      TEXT NOT NULL DEFAULT 'Standard' CHECK (release_type IN ('Standard','Remote QC','With Concession')),
    released_by_user_id BIGINT NOT NULL REFERENCES security.application_user(user_id),
    released_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    odometer_at_release NUMERIC(12,2),
    concession_id     BIGINT REFERENCES quality.concession(concession_id),
    road_test_done    BOOLEAN NOT NULL DEFAULT false,
    remarks           TEXT,
    customer_ack_by   TEXT,
    customer_ack_at   TIMESTAMPTZ
);

-- =====================================================================
-- CAMPAIGN / COMPLIANCE — Document 04 §15. FR-CAM-001, FR-DOC-001, FR-FW-001
-- =====================================================================

CREATE TABLE campaign.campaign (
    campaign_id       BIGSERIAL PRIMARY KEY,
    code              TEXT NOT NULL UNIQUE,
    name              TEXT NOT NULL,
    classification    TEXT NOT NULL CHECK (classification IN ('Safety','Service','Software','Compliance')),
    work_instruction_ref TEXT,
    effective_from    DATE NOT NULL,
    mandatory_by_date DATE,
    status            TEXT NOT NULL DEFAULT 'Open' CHECK (status IN ('Draft','Open','Closed'))
);

CREATE TABLE campaign.campaign_vehicle (
    campaign_vehicle_id BIGSERIAL PRIMARY KEY,
    campaign_id       BIGINT NOT NULL REFERENCES campaign.campaign(campaign_id),
    vehicle_id        BIGINT NOT NULL REFERENCES master.vehicle(vehicle_id),
    status            TEXT NOT NULL DEFAULT 'Open' CHECK (status IN ('Open','Completed','Not Applicable')),
    work_item_id      BIGINT REFERENCES service.work_item(work_item_id),
    completion_evidence TEXT,
    completed_at      TIMESTAMPTZ,
    UNIQUE (campaign_id, vehicle_id)
);

CREATE TABLE campaign.vehicle_document (
    document_id       BIGSERIAL PRIMARY KEY,
    vehicle_id        BIGINT NOT NULL REFERENCES master.vehicle(vehicle_id),
    document_type     TEXT NOT NULL,          -- RC / Insurance / PUC / Fitness / Permit / Tax
    document_no       TEXT,
    issuing_authority TEXT,
    issue_date        DATE,
    expiry_date       DATE,
    file_ref          TEXT,
    renewal_status    TEXT NOT NULL DEFAULT 'Valid' CHECK (renewal_status IN ('Valid','Due Soon','Expired','Not Applicable')),
    UNIQUE (vehicle_id, document_type)
);

CREATE TABLE campaign.firmware_baseline (
    baseline_id       BIGSERIAL PRIMARY KEY,
    vehicle_id        BIGINT NOT NULL REFERENCES master.vehicle(vehicle_id),
    ecu_module        TEXT NOT NULL,
    current_version   TEXT,
    target_version    TEXT,
    last_updated_on   DATE,
    update_method     TEXT,
    last_result       TEXT,
    UNIQUE (vehicle_id, ecu_module)
);

-- =====================================================================
-- SLA — Document 04 §16. FR-SLA-001, BL-SLA-001/002
-- =====================================================================

CREATE TABLE service.sla_master (
    sla_id            BIGSERIAL PRIMARY KEY,
    code              TEXT NOT NULL UNIQUE,
    service_type      TEXT NOT NULL,
    priority          TEXT,
    organisation_id   BIGINT REFERENCES org.organisation(organisation_id),
    service_centre_id BIGINT REFERENCES master.service_centre(service_centre_id),
    calendar_id       BIGINT REFERENCES master.business_calendar(calendar_id),
    response_minutes  INT,
    on_site_minutes   INT,
    restore_minutes   INT,
    release_minutes   INT,
    version_no        INT NOT NULL DEFAULT 1,
    effective_from    DATE NOT NULL DEFAULT CURRENT_DATE,
    status            TEXT NOT NULL DEFAULT 'Active'
);

ALTER TABLE service.service_event
    ADD CONSTRAINT fk_se_sla FOREIGN KEY (sla_id) REFERENCES service.sla_master(sla_id);

CREATE TABLE service.sla_breach (
    breach_id         BIGSERIAL PRIMARY KEY,
    service_event_id  BIGINT REFERENCES service.service_event(service_event_id),
    job_card_id       BIGINT REFERENCES service.job_card(job_card_id),
    sla_id            BIGINT REFERENCES service.sla_master(sla_id),
    sla_version       INT,
    clock_type        TEXT NOT NULL,          -- Response / OnSite / Restore / Release
    target_utc        TIMESTAMPTZ NOT NULL,
    actual_utc        TIMESTAMPTZ,
    variance_minutes  INT,
    pause_minutes     INT NOT NULL DEFAULT 0,
    reason            TEXT,
    owner             TEXT,
    status            TEXT NOT NULL DEFAULT 'Breached' CHECK (status IN ('At Risk','Breached','Resolved'))
);

-- Doc 04 §33.4 reliability
CREATE TABLE service.repeat_failure_rule (
    rule_id           BIGSERIAL PRIMARY KEY,
    code              TEXT NOT NULL UNIQUE,
    match_keys        TEXT[] NOT NULL,        -- {complaint_code, subsystem, component_type}
    day_window        INT NOT NULL,
    km_window         INT,
    exclusions        TEXT,
    version_no        INT NOT NULL DEFAULT 1,
    effective_from    DATE NOT NULL DEFAULT CURRENT_DATE,
    status            TEXT NOT NULL DEFAULT 'Active'
);

CREATE TABLE service.repeat_failure_match (
    match_id          BIGSERIAL PRIMARY KEY,
    current_service_event_id BIGINT NOT NULL REFERENCES service.service_event(service_event_id),
    prior_service_event_id BIGINT NOT NULL REFERENCES service.service_event(service_event_id),
    vehicle_id        BIGINT NOT NULL REFERENCES master.vehicle(vehicle_id),
    rule_id           BIGINT NOT NULL REFERENCES service.repeat_failure_rule(rule_id),
    rule_version      INT,
    matched_attributes TEXT,
    day_delta         INT,
    km_delta          NUMERIC(12,2),
    match_result      BOOLEAN NOT NULL,
    evaluated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- =====================================================================
-- NOTIFICATION — Document 04 §17
-- =====================================================================

CREATE TABLE service.notification (
    notification_id   BIGSERIAL PRIMARY KEY,
    alert_type        TEXT NOT NULL,          -- BL-ALR-001..009
    severity          TEXT NOT NULL DEFAULT 'Info' CHECK (severity IN ('Critical','Warning','Info')),
    title             TEXT NOT NULL,
    body              TEXT,
    entity_type       TEXT,
    entity_id         BIGINT,
    vehicle_id        BIGINT REFERENCES master.vehicle(vehicle_id),
    service_centre_id BIGINT REFERENCES master.service_centre(service_centre_id),
    status            TEXT NOT NULL DEFAULT 'New' CHECK (status IN ('New','Acknowledged','Snoozed','Closed')),
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    acknowledged_at   TIMESTAMPTZ
);
CREATE INDEX ix_notification_status ON service.notification(status, created_at DESC);

-- =====================================================================
-- INTEGRATION — Document 04 §26. BL-INT-001..006
-- =====================================================================

CREATE TABLE integration.inbound_message (
    inbound_id        BIGSERIAL PRIMARY KEY,
    source_system     TEXT NOT NULL,
    external_message_id TEXT NOT NULL,        -- idempotency key
    message_type      TEXT NOT NULL,
    payload           JSONB NOT NULL,
    received_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    processing_status TEXT NOT NULL DEFAULT 'Received'
        CHECK (processing_status IN ('Received','Processed','Quarantined','Failed','Duplicate')),
    processing_result TEXT,
    correlation_id    TEXT,
    UNIQUE (source_system, external_message_id)
);

CREATE TABLE integration.telematics_transaction (
    transaction_id    BIGSERIAL PRIMARY KEY,
    inbound_id        BIGINT REFERENCES integration.inbound_message(inbound_id),
    vehicle_id        BIGINT REFERENCES master.vehicle(vehicle_id),
    vin               TEXT NOT NULL,
    odometer_km       NUMERIC(12,2),
    operating_hours   NUMERIC(12,2),
    source_timestamp_utc TIMESTAMPTZ NOT NULL,
    vehicle_status    TEXT,
    latitude          NUMERIC(9,6),
    longitude         NUMERIC(9,6),
    soc_pct           NUMERIC(5,2),
    soh_pct           NUMERIC(5,2),
    dtc_summary       TEXT,
    accepted          BOOLEAN NOT NULL DEFAULT false,
    rejection_reason  TEXT,                   -- UnknownVIN / NonMonotonic / ImplausibleDelta
    received_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_telematics_vehicle ON integration.telematics_transaction(vehicle_id, source_timestamp_utc DESC);

CREATE TABLE integration.integration_error (
    error_id          BIGSERIAL PRIMARY KEY,
    source_system     TEXT NOT NULL,
    interface_name    TEXT,
    inbound_id        BIGINT REFERENCES integration.inbound_message(inbound_id),
    error_type        TEXT NOT NULL,
    error_message     TEXT NOT NULL,
    correlation_id    TEXT,
    retry_count       INT NOT NULL DEFAULT 0,
    status            TEXT NOT NULL DEFAULT 'Open' CHECK (status IN ('Open','Retrying','DeadLetter','Resolved')),
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE integration.connector_health (
    connector_name    TEXT PRIMARY KEY,
    last_success_at   TIMESTAMPTZ,
    last_failure_at   TIMESTAMPTZ,
    queue_depth       INT NOT NULL DEFAULT 0,
    status            TEXT NOT NULL DEFAULT 'Unknown'
);

-- Doc 04 §18 offline sync
CREATE TABLE integration.offline_operation (
    operation_id      BIGSERIAL PRIMARY KEY,
    client_operation_id TEXT NOT NULL UNIQUE,
    user_id           BIGINT REFERENCES security.application_user(user_id),
    job_card_id       BIGINT REFERENCES service.job_card(job_card_id),
    operation_type    TEXT NOT NULL,
    payload           JSONB,
    client_timestamp  TIMESTAMPTZ,
    sync_status       TEXT NOT NULL DEFAULT 'Pending'
        CHECK (sync_status IN ('Pending','Synced','Conflict','Rejected')),
    server_result     TEXT,
    synced_at         TIMESTAMPTZ
);

-- =====================================================================
-- AUDIT — Document 04 §19. FR-AUD-001, BL-SEC-004/009/010
-- Append-only to operational users.
-- =====================================================================

CREATE TABLE audit.audit_event (
    audit_id          BIGSERIAL PRIMARY KEY,
    entity_type       TEXT NOT NULL,
    entity_id         BIGINT,
    action            TEXT NOT NULL,
    actor             TEXT NOT NULL,
    actor_role        TEXT,
    actor_scope       TEXT,
    before_value      JSONB,
    after_value       JSONB,
    reason            TEXT,
    correlation_id    TEXT,
    occurred_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_audit_entity ON audit.audit_event(entity_type, entity_id, occurred_at DESC);
CREATE INDEX ix_audit_actor ON audit.audit_event(actor, occurred_at DESC);

CREATE TABLE audit.status_history (
    history_id        BIGSERIAL PRIMARY KEY,
    entity_type       TEXT NOT NULL,
    entity_id         BIGINT NOT NULL,
    from_status       TEXT,
    to_status         TEXT NOT NULL,
    actor             TEXT NOT NULL,
    reason            TEXT,
    rule_id           TEXT,
    occurred_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX ix_status_history ON audit.status_history(entity_type, entity_id, occurred_at);

CREATE TABLE audit.approval_history (
    approval_id       BIGSERIAL PRIMARY KEY,
    entity_type       TEXT NOT NULL,
    entity_id         BIGINT NOT NULL,
    action_code       TEXT NOT NULL,
    policy_version    INT,
    requested_by      TEXT NOT NULL,
    approver          TEXT,
    decision          TEXT NOT NULL CHECK (decision IN ('Approved','Rejected','Pending')),
    reason            TEXT,
    self_approval_blocked BOOLEAN NOT NULL DEFAULT false,
    occurred_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------
-- Document number sequences (SE-2026-000123 style identifiers)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.document_sequence (
    sequence_key      TEXT PRIMARY KEY,
    last_value        BIGINT NOT NULL DEFAULT 0
);
