/**
 * Quality control and vehicle release gate.
 *
 * Implements Document 02 BL-QC-001..008, BL-CHK-005, BL-CON-001,
 * BL-BD-013 and Document 1.1 QC-001..003. Release is the system's principal
 * safety control: the gate below is evaluated server-side on every attempt,
 * and the reasons are returned so the supervisor can see exactly what blocks
 * the vehicle.
 */

import { q, one, many, audit, recordStatus, nextDocumentNo } from '../lib/db.ts';
import type { Db } from '../lib/db.ts';
import { changeStatus } from './jobcard.ts';
import { transition } from './availability.ts';
import { completeObligation } from './pm.ts';
import { evaluateRepeatFailure } from './reliability.ts';

export interface Blocker {
  code: string;
  ruleId: string;
  message: string;
  severity: 'Blocking' | 'Warning';
  detail?: unknown;
}

export interface ReleaseGate {
  canRelease: boolean;
  blockers: Blocker[];
  warnings: Blocker[];
}

/**
 * Evaluate every release precondition without changing anything.
 * The UI calls this to show the supervisor why a vehicle is held.
 */
export async function evaluateReleaseGate(db: Db, jobCardId: number): Promise<ReleaseGate> {
  const blockers: Blocker[] = [];
  const warnings: Blocker[] = [];

  const job = await one<any>(db, `
    SELECT jc.*, se.event_type, se.final_diagnosis, se.root_cause_code,
           se.corrective_action_code, se.closure_disposition
    FROM service.job_card jc
    JOIN service.service_event se ON se.service_event_id = jc.service_event_id
    WHERE jc.job_card_id = $1`, [jobCardId]);

  if (!job) {
    return { canRelease: false, blockers: [{
      code: 'JOB_NOT_FOUND', ruleId: '-', message: 'Job card not found.', severity: 'Blocking' }], warnings: [] };
  }

  // --- BL-QC-001: QC only after technician completion ---
  if (!['Technician Complete', 'QC Pending', 'Completed'].includes(job.status)) {
    blockers.push({
      code: 'NOT_TECHNICIAN_COMPLETE', ruleId: 'BL-QC-001',
      message: `Work is still in progress (status "${job.status}"). ` +
               `The technician must complete the job before QC can start.`,
      severity: 'Blocking',
    });
  }

  // --- BL-QC-002 / CHK-015: mandatory checklist items must be answered ---
  const missing = await many<any>(db, `
    SELECT ci.item_id, ci.code, ci.description, cs.name AS section_name
    FROM service.work_item wi
    JOIN pm.pm_execution pe ON pe.work_item_id = wi.work_item_id
    JOIN pm.checklist_section cs ON cs.checklist_version_id = pe.frozen_checklist_version_id
    JOIN pm.checklist_item ci ON ci.section_id = cs.section_id
    LEFT JOIN pm.checklist_result cr
           ON cr.item_id = ci.item_id AND cr.job_card_id = $1
    WHERE wi.job_card_id = $1
      AND ci.is_mandatory = true
      AND ci.is_conditional = false
      AND cr.result_id IS NULL
    ORDER BY cs.display_order, ci.display_order`, [jobCardId]);

  if (missing.length) {
    blockers.push({
      code: 'MANDATORY_CHECKLIST_INCOMPLETE', ruleId: 'BL-QC-002 / CHK-015',
      message: `${missing.length} mandatory checklist item${missing.length === 1 ? '' : 's'} ` +
               `still ${missing.length === 1 ? 'has' : 'have'} no response.`,
      severity: 'Blocking',
      detail: missing.map(m => ({ section: m.section_name, item: m.description })),
    });
  }

  // --- BL-QC-003 / BL-CHK-005: release-blocking defects ---
  const openBlocking = await many<any>(db, `
    SELECT d.defect_id, d.defect_no, d.severity, d.description,
           c.concession_id, c.expiry_date, c.expiry_km, c.status AS concession_status
    FROM service.defect d
    LEFT JOIN quality.concession c
           ON c.defect_id = d.defect_id AND c.status = 'Active'
    WHERE d.vehicle_id = $1
      AND d.status IN ('Open','Under Action','Retest/Verification')
      AND (d.blocks_release = true OR d.severity = 'Critical')`, [job.vehicle_id]);

  const uncovered = openBlocking.filter(d => !d.concession_id);
  if (uncovered.length) {
    blockers.push({
      code: 'CRITICAL_DEFECT_OPEN', ruleId: 'BL-QC-003 / BL-CHK-005',
      message: `${uncovered.length} release-blocking defect${uncovered.length === 1 ? '' : 's'} ` +
               `remain${uncovered.length === 1 ? 's' : ''} open on this vehicle. ` +
               `Close the defect, or release under an authorised concession.`,
      severity: 'Blocking',
      detail: uncovered.map(d => ({ defectNo: d.defect_no, severity: d.severity, description: d.description })),
    });
  }

  // --- BL-CON-001: an expired concession blocks further release ---
  const expired = await many<any>(db, `
    SELECT c.*, v.current_odometer_km
    FROM quality.concession c
    JOIN master.vehicle v ON v.vehicle_id = c.vehicle_id
    WHERE c.vehicle_id = $1 AND c.status = 'Active'
      AND c.blocks_release_after_expiry = true
      AND ((c.expiry_date IS NOT NULL AND c.expiry_date < CURRENT_DATE)
        OR (c.expiry_km IS NOT NULL AND v.current_odometer_km > c.expiry_km))`, [job.vehicle_id]);

  if (expired.length) {
    blockers.push({
      code: 'CONCESSION_EXPIRED', ruleId: 'BL-CON-001',
      message: `${expired.length} release concession${expired.length === 1 ? ' has' : 's have'} expired. ` +
               `The follow-up action must be completed or the concession renewed by an authorised approver.`,
      severity: 'Blocking',
      detail: expired.map(c => ({ concessionNo: c.concession_no, expiryDate: c.expiry_date,
                                  expiryKm: c.expiry_km, followUp: c.follow_up_action })),
    });
  }

  // --- QC-002: mandatory QC checklist items must pass ---
  const qcMissing = await many<any>(db, `
    SELECT qi.qc_item_id, qi.code, qi.description
    FROM quality.qc_checklist qc
    JOIN quality.qc_checklist_item qi ON qi.qc_checklist_id = qc.qc_checklist_id
    LEFT JOIN quality.qc_result qr ON qr.qc_item_id = qi.qc_item_id AND qr.job_card_id = $1
    WHERE qc.code = $2 AND qi.is_mandatory = true
      AND (qr.qc_result_id IS NULL OR qr.result = 'Fail')
    ORDER BY qi.display_order`,
    [jobCardId, job.event_type === 'PM' ? 'QC-PM-STD' : 'QC-BD-STD']);

  if (qcMissing.length) {
    blockers.push({
      code: 'QC_CHECKS_INCOMPLETE', ruleId: 'QC-002 / BL-QC-002',
      message: `${qcMissing.length} mandatory QC check${qcMissing.length === 1 ? '' : 's'} ` +
               `not yet passed.`,
      severity: 'Blocking',
      detail: qcMissing.map(i => ({ code: i.code, description: i.description })),
    });
  }

  // --- BL-BD-013: breakdown closure needs diagnosis, root cause, corrective action ---
  if (job.event_type === 'Breakdown' && job.closure_disposition !== 'NoFaultFound'
      && job.closure_disposition !== 'UnableToReproduce') {
    const gaps: string[] = [];
    if (!job.final_diagnosis) gaps.push('final diagnosis');
    if (!job.root_cause_code) gaps.push('root cause');
    if (!job.corrective_action_code) gaps.push('corrective action');
    if (gaps.length) {
      blockers.push({
        code: 'BREAKDOWN_CLOSURE_INCOMPLETE', ruleId: 'BL-BD-013',
        message: `Breakdown closure requires ${gaps.join(', ')}. ` +
                 `Record these, or use an authorised No-Fault-Found disposition with evidence.`,
        severity: 'Blocking', detail: { missing: gaps },
      });
    }
  }

  // --- Warnings: deferred/advisory defects travel with the VIN (BL-DEF-001) ---
  const deferred = await many<any>(db, `
    SELECT defect_no, severity, description, due_by_date, due_by_km
    FROM service.defect
    WHERE vehicle_id = $1 AND status IN ('Open','Deferred') AND blocks_release = false
      AND severity <> 'Critical'`, [job.vehicle_id]);
  if (deferred.length) {
    warnings.push({
      code: 'DEFERRED_DEFECTS', ruleId: 'BL-DEF-001',
      message: `${deferred.length} deferred defect${deferred.length === 1 ? '' : 's'} ` +
               `will carry forward with this vehicle.`,
      severity: 'Warning', detail: deferred,
    });
  }

  const openParts = await many<any>(db, `
    SELECT pu.part_usage_id, pm.part_no, pm.description, pu.status
    FROM service.part_usage pu JOIN master.part_master pm ON pm.part_id = pu.part_id
    WHERE pu.job_card_id = $1 AND pu.status IN ('Requested','Reserved','Pending')`, [jobCardId]);
  if (openParts.length) {
    warnings.push({
      code: 'PARTS_NOT_ISSUED', ruleId: 'BL-SP-007',
      message: `${openParts.length} part line${openParts.length === 1 ? ' is' : 's are'} not yet issued or fitted.`,
      severity: 'Warning', detail: openParts,
    });
  }

  return { canRelease: blockers.length === 0, blockers, warnings };
}

/**
 * Release the vehicle and close the job.
 *
 * BL-QC-005  records approving user and timestamp
 * BL-QC-006  segregation of duties — the technician who did the work may not release it
 * BL-QC-008  closing updates VIN history and next PM due data
 */
export async function releaseVehicle(db: Db, input: {
  jobCardId: number;
  releasedByUserId: number;
  actor: string;
  releaseType?: 'Standard' | 'Remote QC' | 'With Concession';
  concessionId?: number | null;
  roadTestDone?: boolean;
  odometerAtRelease?: number | null;
  remarks?: string | null;
  overrideSoD?: boolean;
}): Promise<{ releaseId: number; jobCardNo: string; nextObligationId: number | null }> {
  const gate = await evaluateReleaseGate(db, input.jobCardId);
  if (!gate.canRelease && !input.concessionId) {
    const err: any = new Error('Vehicle cannot be released — release conditions are not met.');
    err.code = 'RELEASE_BLOCKED';
    err.blockers = gate.blockers;
    throw err;
  }

  const job = await one<any>(db, `
    SELECT jc.*, se.event_type, t.user_id AS technician_user_id
    FROM service.job_card jc
    JOIN service.service_event se ON se.service_event_id = jc.service_event_id
    LEFT JOIN master.technician t ON t.technician_id = jc.technician_id
    WHERE jc.job_card_id = $1`, [input.jobCardId]);
  if (!job) throw new Error('Job card not found');

  // BL-QC-006 segregation of duties.
  if (!input.overrideSoD && job.technician_user_id
      && Number(job.technician_user_id) === Number(input.releasedByUserId)) {
    const err: any = new Error(
      'The technician who carried out the repair cannot also authorise the release. ' +
      'A separate QC supervisor must approve this vehicle (BL-QC-006).');
    err.code = 'SEGREGATION_OF_DUTIES';
    throw err;
  }

  if (job.status === 'Technician Complete') {
    await changeStatus(db, { jobCardId: input.jobCardId, toStatus: 'QC Pending', actor: input.actor });
  }
  await changeStatus(db, { jobCardId: input.jobCardId, toStatus: 'Completed', actor: input.actor });

  const release = await one<any>(db, `
    INSERT INTO quality.vehicle_release
      (job_card_id, service_event_id, vehicle_id, release_type, released_by_user_id,
       odometer_at_release, concession_id, road_test_done, remarks)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
    RETURNING release_id`,
    [input.jobCardId, job.service_event_id, job.vehicle_id,
     input.releaseType ?? (input.concessionId ? 'With Concession' : 'Standard'),
     input.releasedByUserId, input.odometerAtRelease ?? job.odometer_at_open,
     input.concessionId ?? null, input.roadTestDone ?? false, input.remarks ?? null]);

  // BL-QC-008: PM closure calculates and stores the next obligation.
  let nextObligationId: number | null = null;
  const pmExec = await one<any>(db, `
    SELECT pe.*, wi.work_item_id FROM pm.pm_execution pe
    JOIN service.work_item wi ON wi.work_item_id = pe.work_item_id
    WHERE pe.job_card_id = $1 LIMIT 1`, [input.jobCardId]);

  if (pmExec) {
    const vehicle = await one<any>(db, `
      SELECT current_odometer_km, current_operating_hours FROM master.vehicle WHERE vehicle_id = $1`,
      [job.vehicle_id]);
    const result = await completeObligation(db, {
      pmObligationId: pmExec.pm_obligation_id,
      jobCardId: input.jobCardId,
      actualKm: Number(input.odometerAtRelease ?? vehicle?.current_odometer_km ?? 0),
      actualHours: Number(vehicle?.current_operating_hours ?? 0),
      actor: input.actor,
    });
    nextObligationId = result.nextObligationId;
    await q(db, `UPDATE pm.pm_execution SET actual_km = $1, executed_at = now() WHERE pm_execution_id = $2`,
      [input.odometerAtRelease ?? vehicle?.current_odometer_km ?? null, pmExec.pm_execution_id]);
  }

  // Close the job and the customer-visible service event.
  await changeStatus(db, { jobCardId: input.jobCardId, toStatus: 'Closed', actor: input.actor });

  const siblingOpen = await one<any>(db, `
    SELECT count(*)::int AS n FROM service.job_card
    WHERE service_event_id = $1 AND status NOT IN ('Closed','Cancelled','Transferred')`,
    [job.service_event_id]);

  if (Number(siblingOpen?.n ?? 0) === 0) {
    await q(db, `
      UPDATE service.service_event
      SET status = 'Closed', customer_visible_end = now(), row_version = row_version + 1
      WHERE service_event_id = $1`, [job.service_event_id]);
    await recordStatus(db, {
      entityType: 'ServiceEvent', entityId: job.service_event_id,
      to: 'Closed', actor: input.actor, ruleId: 'BL-QC-008',
    });

    // Breakdown restore/release timestamps (BL-TS-001).
    await q(db, `
      UPDATE service.breakdown_event
      SET restored_operable_utc = COALESCE(restored_operable_utc, now()),
          released_utc = now(), closed_utc = now()
      WHERE service_event_id = $1`, [job.service_event_id]);

    // BL-BD-014/015 repeat-failure and first-time-fix evaluation.
    if (job.event_type === 'Breakdown') {
      await evaluateRepeatFailure(db, job.service_event_id, input.actor);
    }
  }

  // Vehicle returns to service (BL-AVL-001).
  await transition(db, {
    vehicleId: job.vehicle_id, reasonCode: 'IN_SERVICE', sourceType: 'JobCard',
    sourceEntityId: input.jobCardId, ruleId: 'BL-AVL-001', actor: input.actor,
    reason: `Released after job ${job.job_card_no}`,
  });

  await audit(db, {
    entityType: 'VehicleRelease', entityId: release.release_id, action: 'RELEASE',
    actor: input.actor,
    after: { jobCardId: input.jobCardId, releaseType: input.releaseType ?? 'Standard',
             concessionId: input.concessionId ?? null, warnings: gate.warnings.map(w => w.code) },
  });

  return { releaseId: release.release_id, jobCardNo: job.job_card_no, nextObligationId };
}

/** Raise a release concession (BL-QC-007 / BL-CON-001). */
export async function createConcession(db: Db, input: {
  vehicleId: number; defectId?: number | null; jobCardId?: number | null;
  reason: string; approver: string; expiryDate?: string | null; expiryKm?: number | null;
  followUpAction: string; ownerRole: string; evidenceRef?: string | null;
}): Promise<any> {
  if (!input.expiryDate && !input.expiryKm) {
    const err: any = new Error(
      'A concession must carry an expiry date or expiry kilometre reading (BL-CON-001).');
    err.code = 'CONCESSION_EXPIRY_REQUIRED';
    throw err;
  }
  const no = await nextDocumentNo(db, 'CON', 4);
  const row = await one<any>(db, `
    INSERT INTO quality.concession
      (concession_no, vehicle_id, defect_id, job_card_id, reason, approver,
       expiry_date, expiry_km, follow_up_action, owner_role, evidence_ref)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
    RETURNING *`,
    [no, input.vehicleId, input.defectId ?? null, input.jobCardId ?? null, input.reason,
     input.approver, input.expiryDate ?? null, input.expiryKm ?? null,
     input.followUpAction, input.ownerRole, input.evidenceRef ?? null]);

  await audit(db, {
    entityType: 'Concession', entityId: row.concession_id, action: 'CREATE',
    actor: input.approver, reason: input.reason, after: row,
  });
  return row;
}
