/**
 * Preventive maintenance and appointment endpoints.
 * FR-PM-*, FR-PMO-*, FR-APT-001..004, CAP-001.
 */

import { Router, notFound, badRequest, conflict } from '../lib/http.ts';
import type { Ctx } from '../lib/http.ts';
import { pool, one, many, q, audit, recordStatus, nextDocumentNo } from '../lib/db.ts';
import { authenticate, vehicleScopeClause, assertAuthorised, assertPermission } from '../lib/auth.ts';
import { reevaluateObligations, evaluateDueState } from '../domain/pm.ts';

export const pmRoutes = new Router();
pmRoutes.use(authenticate);

/** GET /api/v1/pm/obligations — the due queue. */
pmRoutes.get('/api/v1/pm/obligations', async (ctx: Ctx) => {
  const scope = vehicleScopeClause(ctx.user!, 'v', 1);
  const params: unknown[] = [...scope.params];
  const where: string[] = [scope.clause];

  const status = ctx.query.get('status');
  if (status && status !== 'All') {
    if (status === 'Open') {
      where.push(`o.status IN ('Upcoming','Due Soon','Due','Overdue','Scheduled','Under Service')`);
    } else if (status === 'Completed') {
      where.push(`o.status LIKE 'Completed%'`);
    } else {
      params.push(status);
      where.push(`o.status = $${params.length}`);
    }
  } else {
    where.push(`o.status IN ('Upcoming','Due Soon','Due','Overdue','Scheduled','Under Service')`);
  }

  const centre = ctx.query.get('serviceCentreId');
  if (centre) { params.push(Number(centre)); where.push(`v.assigned_service_centre_id = $${params.length}`); }

  const vin = ctx.query.get('vin');
  if (vin) { params.push(`%${vin}%`); where.push(`v.vin ILIKE $${params.length}`); }

  const limit = Math.min(Number(ctx.query.get('limit') ?? 100), 500);
  const offset = Number(ctx.query.get('offset') ?? 0);
  params.push(limit, offset);

  const rows = await many<any>(pool, `
    SELECT o.pm_obligation_id, o.vehicle_id, o.pm_level, o.cycle_no, o.status, o.driving_trigger,
           o.target_km, o.target_date, o.target_hours, o.is_estimated,
           o.due_soon_km, o.due_soon_days, o.tolerance_km, o.tolerance_days,
           o.actual_completion_date, o.outcome, o.variance_km, o.variance_days,
           v.vin, v.registration_no, v.current_odometer_km, v.current_operating_hours, v.usage_is_stale,
           vv.name AS variant_name, org.name AS customer_name,
           sc.name AS service_centre_name, sc.service_centre_id,
           p.code AS plan_code,
           a.appointment_id, a.appointment_no, a.slot_start
    FROM pm.pm_obligation o
    JOIN master.vehicle v ON v.vehicle_id = o.vehicle_id
    JOIN master.vehicle_variant vv ON vv.variant_id = v.variant_id
    JOIN org.organisation org ON org.organisation_id = v.organisation_id
    LEFT JOIN master.service_centre sc ON sc.service_centre_id = v.assigned_service_centre_id
    JOIN pm.pm_plan_version pv ON pv.plan_version_id = o.plan_version_id
    JOIN pm.pm_plan p ON p.plan_id = pv.plan_id
    LEFT JOIN schedule.appointment a
           ON a.pm_obligation_id = o.pm_obligation_id AND a.status IN ('Scheduled','Confirmed')
    WHERE ${where.join(' AND ')}
    ORDER BY CASE o.status WHEN 'Overdue' THEN 4 WHEN 'Due' THEN 3 WHEN 'Due Soon' THEN 2 ELSE 1 END DESC,
             o.target_date NULLS LAST
    LIMIT $${params.length - 1} OFFSET $${params.length}`, params);

  const countParams = params.slice(0, params.length - 2);
  const total = await one<any>(pool, `
    SELECT count(*)::int AS n
    FROM pm.pm_obligation o JOIN master.vehicle v ON v.vehicle_id = o.vehicle_id
    WHERE ${where.join(' AND ')}`, countParams);

  const counts = await many<any>(pool, `
    SELECT o.status, count(*)::int AS n
    FROM pm.pm_obligation o JOIN master.vehicle v ON v.vehicle_id = o.vehicle_id
    WHERE ${scope.clause}
      AND o.status IN ('Upcoming','Due Soon','Due','Overdue','Scheduled','Under Service')
    GROUP BY 1`, scope.params);

  return {
    total: Number(total?.n ?? 0), limit, offset, rows,
    statusCounts: Object.fromEntries(counts.map(c => [c.status, Number(c.n)])),
  };
});

/** GET /api/v1/pm/obligations/:id */
pmRoutes.get('/api/v1/pm/obligations/:id', async (ctx: Ctx) => {
  const o = await one<any>(pool, `
    SELECT o.*, v.vin, v.current_odometer_km, v.current_operating_hours, v.usage_is_stale,
           p.code AS plan_code, pv.pm_level AS plan_level, pv.version_no AS plan_version
    FROM pm.pm_obligation o
    JOIN master.vehicle v ON v.vehicle_id = o.vehicle_id
    JOIN pm.pm_plan_version pv ON pv.plan_version_id = o.plan_version_id
    JOIN pm.pm_plan p ON p.plan_id = pv.plan_id
    WHERE o.pm_obligation_id = $1`, [Number(ctx.params.id)]);
  if (!o) throw notFound('PM obligation not found.');

  const triggers = await many<any>(pool, `
    SELECT * FROM pm.pm_plan_trigger WHERE plan_version_id = $1`, [o.plan_version_id]);

  return {
    ...o,
    triggers,
    liveEvaluation: evaluateDueState({
      targetKm: o.target_km, targetDate: o.target_date, targetHours: o.target_hours,
      dueSoonKm: o.due_soon_km, dueSoonDays: o.due_soon_days, dueSoonHours: o.due_soon_hours,
      toleranceKm: o.tolerance_km, toleranceDays: o.tolerance_days, toleranceHours: o.tolerance_hours,
      currentKm: Number(o.current_odometer_km ?? 0),
      currentHours: Number(o.current_operating_hours ?? 0),
      isEstimated: o.usage_is_stale,
    }),
  };
});

/** POST /api/v1/pm/obligations/:id/reevaluate */
pmRoutes.post('/api/v1/pm/obligations/:id/reevaluate', async (ctx: Ctx) => {
  const o = await one<any>(pool, `
    SELECT vehicle_id FROM pm.pm_obligation WHERE pm_obligation_id = $1`, [Number(ctx.params.id)]);
  if (!o) throw notFound('PM obligation not found.');
  return reevaluateObligations(pool, o.vehicle_id, ctx.user!.username);
});

// ---------------------------------------------------------------------
// Appointments and capacity — FR-APT-001..004, CAP-001
// ---------------------------------------------------------------------

/** GET /api/v1/service-centres/:id/capacity?date= */
pmRoutes.get('/api/v1/service-centres/:id/capacity', async (ctx: Ctx) => {
  const centreId = Number(ctx.params.id);
  const date = ctx.query.get('date') ?? new Date().toISOString().slice(0, 10);

  const centre = await one<any>(pool, `
    SELECT sc.*, bc.working_days, bc.day_start, bc.day_end, bc.is_24x7, bc.timezone
    FROM master.service_centre sc
    LEFT JOIN master.business_calendar bc ON bc.calendar_id = sc.business_calendar_id
    WHERE sc.service_centre_id = $1`, [centreId]);
  if (!centre) throw notFound('Service centre not found.');

  const bays = await many<any>(pool, `
    SELECT b.*,
      COALESCE((SELECT SUM(a.estimated_minutes) FROM schedule.appointment a
                 WHERE a.bay_id = b.bay_id AND a.slot_start::date = $2::date
                   AND a.status NOT IN ('Cancelled','No Show')),0)::int AS booked_minutes
    FROM schedule.service_bay b
    WHERE b.service_centre_id = $1 AND b.status = 'Active'
    ORDER BY b.bay_code`, [centreId, date]);

  const shift = await one<any>(pool, `
    SELECT * FROM schedule.shift WHERE service_centre_id = $1 LIMIT 1`, [centreId]);

  const shiftMinutes = shift
    ? (() => {
        const [sh, sm] = String(shift.start_time).split(':').map(Number);
        const [eh, em] = String(shift.end_time).split(':').map(Number);
        return (eh * 60 + em) - (sh * 60 + sm);
      })()
    : 480;

  // BL-SVC-004: unavailable technicians are not offered.
  const technicians = await many<any>(pool, `
    SELECT t.technician_id, t.name, t.employee_code,
           COALESCE(r.is_available, true) AS is_available,
           ARRAY(SELECT ts.skill_code FROM master.technician_skill ts
                  WHERE ts.technician_id = t.technician_id
                    AND (ts.valid_to IS NULL OR ts.valid_to >= CURRENT_DATE)) AS skills,
           COALESCE((SELECT SUM(a.estimated_minutes) FROM schedule.appointment a
                      WHERE a.technician_id = t.technician_id AND a.slot_start::date = $2::date
                        AND a.status NOT IN ('Cancelled','No Show')),0)::int AS booked_minutes
    FROM master.technician t
    LEFT JOIN schedule.technician_roster r
           ON r.technician_id = t.technician_id AND r.roster_date = $2::date
    WHERE t.service_centre_id = $1 AND t.status = 'Active'
    ORDER BY t.name`, [centreId, date]);

  const appointments = await many<any>(pool, `
    SELECT a.*, v.vin, v.registration_no, b.bay_code, t.name AS technician_name
    FROM schedule.appointment a
    JOIN master.vehicle v ON v.vehicle_id = a.vehicle_id
    LEFT JOIN schedule.service_bay b ON b.bay_id = a.bay_id
    LEFT JOIN master.technician t ON t.technician_id = a.technician_id
    WHERE a.service_centre_id = $1 AND a.slot_start::date = $2::date
    ORDER BY a.slot_start`, [centreId, date]);

  const dow = new Date(date + 'T00:00:00Z').getUTCDay() || 7;
  const isWorkingDay = centre.is_24x7 || (centre.working_days ?? [1,2,3,4,5,6]).includes(dow);

  return {
    serviceCentre: { id: centre.service_centre_id, code: centre.code, name: centre.name },
    date, isWorkingDay, shiftMinutes,
    bays: bays.map(b => ({
      bayId: b.bay_id, bayCode: b.bay_code, bayType: b.bay_type,
      bookedMinutes: b.booked_minutes, capacityMinutes: shiftMinutes,
      utilisationPct: Math.round((b.booked_minutes / Math.max(1, shiftMinutes)) * 100),
    })),
    technicians, appointments,
  };
});

/** POST /api/v1/appointments — capacity-validated booking (CAP-001). */
pmRoutes.post('/api/v1/appointments', async (ctx: Ctx) => {
  assertPermission(ctx.user!, 'appointment.book');
  const {
    vin, pmObligationId, serviceCentreId, bayId, technicianId,
    serviceType, slotStart, estimatedMinutes, requestNotes, overrideCapacity,
  } = ctx.body ?? {};

  if (!vin || !serviceCentreId || !slotStart) {
    throw badRequest('Vehicle, service centre and start time are required.');
  }

  const vehicle = await one<any>(pool, `
    SELECT v.*, vv.variant_id FROM master.vehicle v
    JOIN master.vehicle_variant vv ON vv.variant_id = v.variant_id WHERE v.vin = $1`, [vin]);
  if (!vehicle) throw notFound(`Vehicle ${vin} not found.`);

  // FR-APT-002: estimate the duration from the SRT master where configured.
  let minutes = Number(estimatedMinutes ?? 0);
  if (!minutes) {
    const srt = await one<any>(pool, `
      SELECT standard_minutes FROM schedule.standard_repair_time
      WHERE (variant_id = $1 OR variant_id IS NULL)
        AND (work_item_type = $2 OR work_item_type IS NULL)
        AND approval_status = 'Approved'
      ORDER BY variant_id NULLS LAST LIMIT 1`, [vehicle.variant_id, serviceType ?? 'PM']);
    minutes = Number(srt?.standard_minutes ?? 120);
  }

  const start = new Date(slotStart);
  const end = new Date(start.getTime() + minutes * 60_000);

  // Business calendar check (AT-CAP-004).
  const centre = await one<any>(pool, `
    SELECT sc.*, bc.working_days, bc.is_24x7 FROM master.service_centre sc
    LEFT JOIN master.business_calendar bc ON bc.calendar_id = sc.business_calendar_id
    WHERE sc.service_centre_id = $1`, [Number(serviceCentreId)]);
  if (!centre) throw notFound('Service centre not found.');

  const dow = start.getUTCDay() || 7;
  if (!centre.is_24x7 && !(centre.working_days ?? [1,2,3,4,5,6]).includes(dow) && !overrideCapacity) {
    throw conflict(
      `${centre.name} is closed on that day under its business calendar. ` +
      `Choose a working day, or book with an authorised override.`,
      { ruleId: 'CAP-001', workingDays: centre.working_days });
  }

  // CAP-001: bay and technician double-booking prevention.
  if (bayId) {
    const clash = await one<any>(pool, `
      SELECT a.appointment_no, a.slot_start, a.slot_end FROM schedule.appointment a
      WHERE a.bay_id = $1 AND a.status NOT IN ('Cancelled','No Show','Completed')
        AND a.slot_start < $3 AND a.slot_end > $2`, [Number(bayId), start, end]);
    if (clash && !overrideCapacity) {
      throw conflict(
        `That bay is already booked from ${new Date(clash.slot_start).toISOString().slice(11,16)} ` +
        `to ${new Date(clash.slot_end).toISOString().slice(11,16)} (${clash.appointment_no}). ` +
        `Choose another slot or bay, or book with an authorised override.`,
        { ruleId: 'CAP-001', conflictingAppointment: clash.appointment_no });
    }
  }

  if (technicianId) {
    const clash = await one<any>(pool, `
      SELECT a.appointment_no FROM schedule.appointment a
      WHERE a.technician_id = $1 AND a.status NOT IN ('Cancelled','No Show','Completed')
        AND a.slot_start < $3 AND a.slot_end > $2`, [Number(technicianId), start, end]);
    if (clash && !overrideCapacity) {
      throw conflict(
        `That technician is already assigned to ${clash.appointment_no} in this slot.`,
        { ruleId: 'CAP-001' });
    }
    const roster = await one<any>(pool, `
      SELECT is_available, unavailable_reason FROM schedule.technician_roster
      WHERE technician_id = $1 AND roster_date = $2::date`,
      [Number(technicianId), start.toISOString().slice(0, 10)]);
    if (roster && roster.is_available === false && !overrideCapacity) {
      throw conflict(
        `That technician is not available on this date (${roster.unavailable_reason ?? 'rostered off'}).`,
        { ruleId: 'BL-SVC-004' });
    }
  }

  if (overrideCapacity) await assertAuthorised(pool, ctx.user!, 'appointment.override_capacity');

  const appointmentNo = await nextDocumentNo(pool, 'APT', 5);
  const appt = await one<any>(pool, `
    INSERT INTO schedule.appointment
      (appointment_no, vehicle_id, pm_obligation_id, service_centre_id, bay_id, technician_id,
       service_type, slot_start, slot_end, estimated_minutes, request_notes, booked_by)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,
    [appointmentNo, vehicle.vehicle_id, pmObligationId ?? null, Number(serviceCentreId),
     bayId ?? null, technicianId ?? null, serviceType ?? 'Preventive Maintenance',
     start, end, minutes, requestNotes ?? null, ctx.user!.username]);

  // BL-PM-011: scheduling does not close or reset the obligation.
  if (pmObligationId) {
    await q(pool, `
      UPDATE pm.pm_obligation SET status = 'Scheduled', updated_at = now(),
             row_version = row_version + 1
      WHERE pm_obligation_id = $1 AND status IN ('Upcoming','Due Soon','Due','Overdue')`,
      [Number(pmObligationId)]);
    await recordStatus(pool, {
      entityType: 'PMObligation', entityId: Number(pmObligationId),
      to: 'Scheduled', actor: ctx.user!.username, ruleId: 'BL-PM-011',
    });
  }

  await audit(pool, {
    entityType: 'Appointment', entityId: appt.appointment_id, action: 'CREATE',
    actor: ctx.user!.username, after: { appointmentNo, vin, slotStart: start, minutes },
    reason: overrideCapacity ? 'Booked with authorised capacity override' : null,
  });

  return appt;
});

/** GET /api/v1/appointments */
pmRoutes.get('/api/v1/appointments', async (ctx: Ctx) => {
  const scope = vehicleScopeClause(ctx.user!, 'v', 1);
  const params: unknown[] = [...scope.params];
  const where = [scope.clause];

  const date = ctx.query.get('date');
  if (date) { params.push(date); where.push(`a.slot_start::date = $${params.length}::date`); }
  const centre = ctx.query.get('serviceCentreId');
  if (centre) { params.push(Number(centre)); where.push(`a.service_centre_id = $${params.length}`); }
  const status = ctx.query.get('status');
  if (status) { params.push(status); where.push(`a.status = $${params.length}`); }

  return many(pool, `
    SELECT a.*, v.vin, v.registration_no, org.name AS customer_name,
           b.bay_code, t.name AS technician_name, sc.name AS service_centre_name
    FROM schedule.appointment a
    JOIN master.vehicle v ON v.vehicle_id = a.vehicle_id
    JOIN org.organisation org ON org.organisation_id = v.organisation_id
    LEFT JOIN schedule.service_bay b ON b.bay_id = a.bay_id
    LEFT JOIN master.technician t ON t.technician_id = a.technician_id
    JOIN master.service_centre sc ON sc.service_centre_id = a.service_centre_id
    WHERE ${where.join(' AND ')}
    ORDER BY a.slot_start LIMIT 200`, params);
});

/** POST /api/v1/appointments/:id/no-show — FR-APT-003. */
pmRoutes.post('/api/v1/appointments/:id/no-show', async (ctx: Ctx) => {
  const { reason } = ctx.body ?? {};
  if (!reason) throw badRequest('A reason is required to record a no-show.');

  const appt = await one<any>(pool, `
    UPDATE schedule.appointment SET status = 'No Show', no_show_reason = $2,
           row_version = row_version + 1
    WHERE appointment_id = $1 RETURNING *`, [Number(ctx.params.id), reason]);
  if (!appt) throw notFound('Appointment not found.');

  // FR-APT-003: the obligation returns to the due queue, it is not closed.
  if (appt.pm_obligation_id) {
    await q(pool, `
      UPDATE pm.pm_obligation SET status = 'Due', updated_at = now()
      WHERE pm_obligation_id = $1 AND status = 'Scheduled'`, [appt.pm_obligation_id]);
    await reevaluateObligations(pool, appt.vehicle_id, ctx.user!.username);
  }

  await audit(pool, {
    entityType: 'Appointment', entityId: appt.appointment_id, action: 'NO_SHOW',
    actor: ctx.user!.username, reason,
  });
  return appt;
});

/** POST /api/v1/appointments/:id/cancel */
pmRoutes.post('/api/v1/appointments/:id/cancel', async (ctx: Ctx) => {
  const { reason } = ctx.body ?? {};
  if (!reason) throw badRequest('A reason is required to cancel an appointment.');
  const appt = await one<any>(pool, `
    UPDATE schedule.appointment SET status = 'Cancelled', reschedule_reason = $2
    WHERE appointment_id = $1 RETURNING *`, [Number(ctx.params.id), reason]);
  if (!appt) throw notFound('Appointment not found.');
  if (appt.pm_obligation_id) {
    await q(pool, `
      UPDATE pm.pm_obligation SET status = 'Due' WHERE pm_obligation_id = $1 AND status = 'Scheduled'`,
      [appt.pm_obligation_id]);
    await reevaluateObligations(pool, appt.vehicle_id, ctx.user!.username);
  }
  return appt;
});

/** GET /api/v1/pm/forecast — FR-APT-004 forward demand by week and centre. */
pmRoutes.get('/api/v1/pm/forecast', async (ctx: Ctx) => {
  const scope = vehicleScopeClause(ctx.user!, 'v', 1);
  const weeks = Math.min(Number(ctx.query.get('weeks') ?? 8), 26);
  return many(pool, `
    SELECT date_trunc('week', o.target_date)::date AS week_start,
           sc.service_centre_id, sc.name AS service_centre_name,
           count(*)::int AS projected_obligations,
           count(*) FILTER (WHERE o.status = 'Overdue')::int AS already_overdue
    FROM pm.pm_obligation o
    JOIN master.vehicle v ON v.vehicle_id = o.vehicle_id
    LEFT JOIN master.service_centre sc ON sc.service_centre_id = v.assigned_service_centre_id
    WHERE ${scope.clause}
      AND o.status IN ('Upcoming','Due Soon','Due','Overdue')
      AND o.target_date IS NOT NULL
      AND o.target_date < CURRENT_DATE + ($${scope.params.length + 1} || ' weeks')::interval
    GROUP BY 1,2,3
    ORDER BY 1,3`, [...scope.params, weeks]);
});
