/**
 * Demo data seed.
 *
 * Builds PM plans, version-controlled checklists, SRTs, a representative
 * fleet and a set of in-flight service events. Transactional data is created
 * *through the domain rules* — PM obligations come from createObligation,
 * availability intervals from the ledger transitions, defects from checklist
 * answers — so the seeded state is one the running system could actually
 * have produced.
 *
 * Checklist content follows Document 1.1 §6-11. Numeric limits are
 * illustrative and must be replaced with Montra-approved service data
 * before production use (Doc 1.1 §5).
 */

import { pool, one, many, q, nextDocumentNo } from '../lib/db.ts';
import { createObligation, reevaluateObligations } from '../domain/pm.ts';
import { transition } from '../domain/availability.ts';
import { createJobCard, changeStatus } from '../domain/jobcard.ts';
import { recordAnswers } from '../domain/checklist.ts';
import { ingestTelematics } from '../domain/usage.ts';

// ---------------------------------------------------------------------
// Checklist content — Document 1.1 §6 (common EV) and §7-11 (by family)
// ---------------------------------------------------------------------

type ItemDef = [
  code: string, description: string, mode: 'PassFail' | 'Numeric' | 'Text' | 'Photo',
  mandatory: boolean, severity: 'Critical' | 'Major' | 'Minor' | null,
  blocksRelease: boolean, unit?: string, min?: number, max?: number,
];

const COMMON_EV: Record<string, ItemDef[]> = {
  'Battery & High-Voltage System': [
    ['BAT-01', 'Battery pack physical condition', 'PassFail', true, 'Critical', true],
    ['BAT-02', 'Battery mounting and protection', 'PassFail', true, 'Critical', true],
    ['BAT-03', 'HV cables and harness condition', 'PassFail', true, 'Critical', true],
    ['BAT-04', 'HV connectors and locking', 'PassFail', true, 'Critical', true],
    ['BAT-05', 'Signs of overheating, arcing or damage', 'PassFail', true, 'Critical', true],
    ['BAT-06', 'Battery temperature reading', 'Numeric', false, 'Major', false, '°C', 5, 45],
    ['BAT-07', 'State of charge', 'Numeric', false, null, false, '%', 0, 100],
    ['BAT-08', 'State of health', 'Numeric', false, 'Major', false, '%', 80, 100],
    ['BAT-09', 'Cell imbalance indication', 'PassFail', false, 'Major', false],
    ['BAT-10', 'Isolation / insulation status', 'PassFail', true, 'Critical', true],
    ['BAT-11', 'Battery cooling system condition', 'PassFail', true, 'Major', false],
    ['BAT-12', 'Coolant leakage', 'PassFail', true, 'Major', true],
    ['BAT-13', 'Battery warning or fault indication', 'PassFail', true, 'Critical', true],
    ['BAT-14', 'Battery communication status', 'PassFail', true, 'Major', false],
  ],
  'Motor / Inverter / Controller': [
    ['MOT-01', 'Motor mounting', 'PassFail', true, 'Major', false],
    ['MOT-02', 'Abnormal motor noise', 'PassFail', true, 'Major', false],
    ['MOT-03', 'Motor vibration', 'PassFail', true, 'Major', false],
    ['MOT-04', 'Motor temperature', 'Numeric', false, 'Major', false, '°C', 0, 90],
    ['MOT-05', 'Motor electrical connections', 'PassFail', true, 'Critical', true],
    ['MOT-06', 'Inverter / controller condition', 'PassFail', true, 'Critical', true],
    ['MOT-07', 'Cooling connections and leakage', 'PassFail', true, 'Major', false],
    ['MOT-08', 'Fault indication / DTC review', 'PassFail', true, 'Major', false],
    ['MOT-09', 'Regenerative braking functional check', 'PassFail', true, 'Critical', true],
  ],
  'Charging System': [
    ['CHG-01', 'Charge inlet condition', 'PassFail', true, 'Major', false],
    ['CHG-02', 'Charge connector condition', 'PassFail', true, 'Major', false],
    ['CHG-03', 'Connector pins', 'PassFail', true, 'Major', false],
    ['CHG-04', 'Locking mechanism', 'PassFail', true, 'Major', false],
    ['CHG-05', 'Charging communication', 'PassFail', true, 'Major', false],
    ['CHG-06', 'Charging functional check', 'PassFail', true, 'Major', false],
    ['CHG-07', 'Signs of overheating or burning', 'PassFail', true, 'Critical', true],
    ['CHG-08', 'Protective caps and covers', 'PassFail', false, 'Minor', false],
  ],
  'Low-Voltage Electrical': [
    ['LV-01', '12 V auxiliary battery condition', 'PassFail', true, 'Major', false],
    ['LV-02', 'Battery terminals', 'PassFail', true, 'Minor', false],
    ['LV-03', 'Headlamps', 'PassFail', true, 'Major', true],
    ['LV-04', 'Tail lamps', 'PassFail', true, 'Major', true],
    ['LV-05', 'Indicators and hazard lights', 'PassFail', true, 'Major', true],
    ['LV-06', 'Horn', 'PassFail', true, 'Major', true],
    ['LV-07', 'Instrument cluster', 'PassFail', true, 'Major', false],
    ['LV-08', 'Warning lamps', 'PassFail', true, 'Major', false],
    ['LV-09', 'Visible wiring harness condition', 'PassFail', true, 'Major', false],
    ['LV-10', 'Fuse and relay condition', 'PassFail', false, 'Minor', false],
  ],
};

const HEAVY_SECTIONS: Record<string, ItemDef[]> = {
  'Motor & AMT': [
    ['AMT-01', 'Gearbox oil level and condition', 'PassFail', true, 'Major', false],
    ['AMT-02', 'Gearbox leakage', 'PassFail', true, 'Major', false],
    ['AMT-03', 'AMT operation', 'PassFail', true, 'Critical', true],
    ['AMT-04', 'Gear-shift function', 'PassFail', true, 'Critical', true],
    ['AMT-05', 'Transmission mounting', 'PassFail', true, 'Major', false],
  ],
  'Axles / Driveline': [
    ['AXL-01', 'Front axle', 'PassFail', true, 'Major', false],
    ['AXL-02', 'Rear axle(s)', 'PassFail', true, 'Major', false],
    ['AXL-03', 'Differential', 'PassFail', true, 'Major', false],
    ['AXL-04', 'Hub and bearing', 'PassFail', true, 'Critical', true],
    ['AXL-05', 'Leakage', 'PassFail', true, 'Major', false],
    ['AXL-06', 'Driveline play', 'PassFail', true, 'Major', false],
  ],
  'Air / Brake System': [
    ['BRK-01', 'Brake lining / pad thickness', 'Numeric', true, 'Critical', true, 'mm', 5, 30],
    ['BRK-02', 'Brake chamber', 'PassFail', true, 'Critical', true],
    ['BRK-03', 'Air pressure build-up', 'Numeric', true, 'Critical', true, 'bar', 7, 12],
    ['BRK-04', 'Air leakage', 'PassFail', true, 'Critical', true],
    ['BRK-05', 'Hoses and valves', 'PassFail', true, 'Critical', true],
    ['BRK-06', 'Parking brake', 'PassFail', true, 'Critical', true],
    ['BRK-07', 'ABS/EBS warning indication', 'PassFail', true, 'Critical', true],
    ['BRK-08', 'Brake balance functional check', 'PassFail', true, 'Critical', true],
  ],
  'Tyres / Chassis / Coupling': [
    ['TYR-01', 'Tyre pressure — front left', 'Numeric', true, 'Major', false, 'psi', 90, 130],
    ['TYR-02', 'Tyre pressure — front right', 'Numeric', true, 'Major', false, 'psi', 90, 130],
    ['TYR-03', 'Tread depth — minimum across axles', 'Numeric', true, 'Critical', true, 'mm', 3, 20],
    ['TYR-04', 'Abnormal or uneven wear', 'PassFail', true, 'Major', false],
    ['TYR-05', 'Wheel alignment and fasteners', 'PassFail', true, 'Critical', true],
    ['TYR-06', 'Frame cracks or deformation', 'PassFail', true, 'Critical', true],
    ['TYR-07', 'Fifth wheel / kingpin coupling', 'PassFail', true, 'Critical', true],
    ['TYR-08', 'Trailer electrical and air connections', 'PassFail', true, 'Critical', true],
  ],
  'Cabin & Safety': [
    ['CAB-01', 'Steering', 'PassFail', true, 'Critical', true],
    ['CAB-02', 'Seat and seat belt', 'PassFail', true, 'Critical', true],
    ['CAB-03', 'Mirrors', 'PassFail', true, 'Major', true],
    ['CAB-04', 'Windscreen and wipers', 'PassFail', true, 'Major', false],
    ['CAB-05', 'HVAC', 'PassFail', false, 'Minor', false],
    ['CAB-06', 'Mandatory emergency equipment', 'PassFail', true, 'Major', true],
  ],
};

const LIGHT_SECTIONS: Record<string, ItemDef[]> = {
  'Brakes': [
    ['BRK-01', 'Front brake condition', 'PassFail', true, 'Critical', true],
    ['BRK-02', 'Rear brake condition', 'PassFail', true, 'Critical', true],
    ['BRK-03', 'Brake fluid level and leakage', 'PassFail', true, 'Critical', true],
    ['BRK-04', 'Service brake operation', 'PassFail', true, 'Critical', true],
    ['BRK-05', 'Parking brake', 'PassFail', true, 'Critical', true],
  ],
  'Steering & Suspension': [
    ['STR-01', 'Steering free play and operation', 'PassFail', true, 'Critical', true],
    ['STR-02', 'Front suspension condition', 'PassFail', true, 'Major', false],
    ['STR-03', 'Rear suspension condition', 'PassFail', true, 'Major', false],
    ['STR-04', 'Shock absorber condition', 'PassFail', true, 'Major', false],
    ['STR-05', 'Mounting points', 'PassFail', true, 'Major', false],
  ],
  'Tyres & Wheels': [
    ['TYR-01', 'Tyre pressure', 'Numeric', true, 'Major', false, 'psi', 28, 50],
    ['TYR-02', 'Tread depth', 'Numeric', true, 'Critical', true, 'mm', 2, 12],
    ['TYR-03', 'Uneven wear', 'PassFail', true, 'Major', false],
    ['TYR-04', 'Sidewall damage', 'PassFail', true, 'Critical', true],
    ['TYR-05', 'Wheel fastener condition', 'PassFail', true, 'Critical', true],
  ],
  'Body & Safety': [
    ['BOD-01', 'Driver seat and mounting', 'PassFail', true, 'Major', false],
    ['BOD-02', 'Body panels and doors', 'PassFail', true, 'Minor', false],
    ['BOD-03', 'Mirrors', 'PassFail', true, 'Major', true],
    ['BOD-04', 'Windscreen', 'PassFail', true, 'Major', false],
    ['BOD-05', 'Wiper', 'PassFail', true, 'Minor', false],
  ],
};

const TRACTOR_SECTIONS: Record<string, ItemDef[]> = {
  'Transmission': [
    ['TRN-01', 'Gear selection', 'PassFail', true, 'Major', false],
    ['TRN-02', '8F + 2R operation', 'PassFail', true, 'Major', false],
    ['TRN-03', 'Transmission oil condition', 'PassFail', true, 'Major', false],
    ['TRN-04', 'Leakage', 'PassFail', true, 'Major', false],
  ],
  'PTO': [
    ['PTO-01', 'PTO engagement', 'PassFail', true, 'Critical', true],
    ['PTO-02', '540 RPM mode operation', 'PassFail', true, 'Major', false],
    ['PTO-03', '1000 RPM mode operation', 'PassFail', true, 'Major', false],
    ['PTO-04', 'PTO shaft condition', 'PassFail', true, 'Critical', true],
    ['PTO-05', 'PTO guard', 'PassFail', true, 'Critical', true],
  ],
  'Hydraulics': [
    ['HYD-01', 'Hydraulic oil level and condition', 'PassFail', true, 'Major', false],
    ['HYD-02', 'Leakage', 'PassFail', true, 'Major', false],
    ['HYD-03', 'Hoses', 'PassFail', true, 'Major', false],
    ['HYD-04', 'Lift arms', 'PassFail', true, 'Major', false],
    ['HYD-05', 'Lifting function', 'PassFail', true, 'Critical', true],
  ],
  'Implement Attachment': [
    ['IMP-01', 'Three-point linkage', 'PassFail', true, 'Critical', true],
    ['IMP-02', 'Top link and pins', 'PassFail', true, 'Major', false],
    ['IMP-03', 'Safety locking', 'PassFail', true, 'Critical', true],
  ],
};

// ---------------------------------------------------------------------

async function buildChecklist(
  templateCode: string, name: string, variantCode: string,
  sections: Record<string, ItemDef[]>,
): Promise<number> {
  const variant = await one<any>(pool, `
    SELECT variant_id FROM master.vehicle_variant WHERE code = $1`, [variantCode]);

  const tpl = await one<any>(pool, `
    INSERT INTO pm.checklist_template (code, name, variant_id, service_type)
    VALUES ($1,$2,$3,'PM') RETURNING template_id`, [templateCode, name, variant?.variant_id ?? null]);

  const ver = await one<any>(pool, `
    INSERT INTO pm.checklist_version
      (template_id, version_no, effective_from, approval_status, created_by, approved_by, approved_on)
    VALUES ($1,1,CURRENT_DATE - 180,'Published','admin','engineering', now())
    RETURNING checklist_version_id`, [tpl.template_id]);

  let sectionOrder = 1;
  for (const [sectionName, items] of Object.entries(sections)) {
    const sec = await one<any>(pool, `
      INSERT INTO pm.checklist_section (checklist_version_id, code, name, display_order)
      VALUES ($1,$2,$3,$4) RETURNING section_id`,
      [ver.checklist_version_id, sectionName.replace(/[^A-Z]/gi, '').slice(0, 8).toUpperCase(),
       sectionName, sectionOrder++]);

    let itemOrder = 1;
    for (const [code, description, mode, mandatory, severity, blocks, unit, min, max] of items) {
      await q(pool, `
        INSERT INTO pm.checklist_item
          (section_id, code, description, inspection_method, response_mode, is_mandatory,
           unit, min_value, max_value, defect_severity_on_fail, creates_defect_on_fail,
           blocks_release_on_fail, photo_required, display_order)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,true,$11,$12,$13)`,
        [sec.section_id, code, description,
         mode === 'Numeric' ? 'Measurement' : 'Visual', mode, mandatory,
         unit ?? null, min ?? null, max ?? null, severity,
         blocks, blocks ? 'OnFailure' : 'No', itemOrder++]);
    }
  }
  return ver.checklist_version_id;
}

async function buildPmPlan(
  code: string, name: string, variantCode: string, level: string, sequence: number,
  checklistVersionId: number,
  triggers: { type: 'KM' | 'Calendar' | 'Hours'; interval: number; dueSoon: number; tolerance: number }[],
): Promise<number> {
  const variant = await one<any>(pool, `
    SELECT variant_id FROM master.vehicle_variant WHERE code = $1`, [variantCode]);

  let plan = await one<any>(pool, `SELECT plan_id FROM pm.pm_plan WHERE code = $1`, [code]);
  if (!plan) {
    plan = await one<any>(pool, `
      INSERT INTO pm.pm_plan (code, name) VALUES ($1,$2) RETURNING plan_id`, [code, name]);
  }

  const version = await one<any>(pool, `
    INSERT INTO pm.pm_plan_version
      (plan_id, version_no, variant_id, pm_level, sequence_no, checklist_version_id,
       effective_from, approval_status, created_by, approved_by, approved_on)
    VALUES ($1,$2,$3,$4,$5,$6, CURRENT_DATE - 180, 'Published','admin','engineering', now())
    RETURNING plan_version_id`,
    [plan.plan_id, sequence, variant?.variant_id ?? null, level, sequence, checklistVersionId]);

  for (const t of triggers) {
    await q(pool, `
      INSERT INTO pm.pm_plan_trigger
        (plan_version_id, trigger_type, interval_value, due_soon_threshold, tolerance, anchor_policy)
      VALUES ($1,$2,$3,$4,$5,'OriginalSchedule')`,
      [version.plan_version_id, t.type, t.interval, t.dueSoon, t.tolerance]);
  }
  return version.plan_version_id;
}

// ---------------------------------------------------------------------

const VIN_PREFIX = 'MT7T2036';
const REG_STATES = ['TN', 'KA', 'TN', 'TN', 'AP'];

function pad(n: number, w: number) { return String(n).padStart(w, '0'); }

export async function seedDemo() {
  console.log('Seeding demo data…');

  // --- Checklists (version-controlled, published) ---
  console.log('  building checklists…');
  const clRhino4x2 = await buildChecklist(
    'RHINO-5538-4X2-PM', 'Rhino 5538 EV 4x2 — PM checklist', 'RH5538-4X2',
    { ...COMMON_EV, ...HEAVY_SECTIONS });
  const clRhino6x4 = await buildChecklist(
    'RHINO-5538-6X4-PM', 'Rhino 5538 EV 6x4 — PM checklist', 'RH5538-6X4',
    { ...COMMON_EV, ...HEAVY_SECTIONS });
  const clEviator = await buildChecklist(
    'EVIATOR-PM', 'EVIATOR — PM checklist', 'EVICORE-40',
    { ...COMMON_EV, ...LIGHT_SECTIONS });
  const clEviator350 = await buildChecklist(
    'EVIATOR-350-PM', 'EVIATOR 350 — PM checklist', 'EVI350-32',
    { ...COMMON_EV, ...LIGHT_SECTIONS });
  const clSuperAuto = await buildChecklist(
    'SUPERAUTO-PM', 'Super Auto ePL 2.0 — PM checklist', 'EPL20-STD',
    { 'Battery & High-Voltage System': COMMON_EV['Battery & High-Voltage System'],
      'Motor / Inverter / Controller': COMMON_EV['Motor / Inverter / Controller'],
      'Charging System': COMMON_EV['Charging System'],
      'Low-Voltage Electrical': COMMON_EV['Low-Voltage Electrical'],
      ...LIGHT_SECTIONS });
  const clTractor = await buildChecklist(
    'ETRACTOR-E27-PM', 'E-27 Tractor — PM checklist', 'E27-2WD',
    { 'Battery & High-Voltage System': COMMON_EV['Battery & High-Voltage System'],
      'Motor / Inverter / Controller': COMMON_EV['Motor / Inverter / Controller'],
      'Charging System': COMMON_EV['Charging System'],
      ...TRACTOR_SECTIONS });

  // --- PM plans (Doc 1.1 §12; intervals await Montra approval) ---
  console.log('  building PM plans…');
  const planRhino4x2 = await buildPmPlan('PM-RHINO-4X2', 'Rhino 5538 4x2 Standard PM',
    'RH5538-4X2', 'PM-20K', 1, clRhino4x2,
    [{ type: 'KM', interval: 20000, dueSoon: 2000, tolerance: 1000 },
     { type: 'Calendar', interval: 6, dueSoon: 21, tolerance: 15 }]);
  const planRhino6x4 = await buildPmPlan('PM-RHINO-6X4', 'Rhino 5538 6x4 Standard PM',
    'RH5538-6X4', 'PM-20K', 1, clRhino6x4,
    [{ type: 'KM', interval: 20000, dueSoon: 2000, tolerance: 1000 },
     { type: 'Calendar', interval: 6, dueSoon: 21, tolerance: 15 }]);
  const planEviator = await buildPmPlan('PM-EVIATOR', 'EVIATOR Standard PM',
    'EVICORE-40', 'PM-10K', 1, clEviator,
    [{ type: 'KM', interval: 10000, dueSoon: 1000, tolerance: 500 },
     { type: 'Calendar', interval: 6, dueSoon: 15, tolerance: 15 }]);
  const planEviator350 = await buildPmPlan('PM-EVIATOR-350', 'EVIATOR 350 Standard PM',
    'EVI350-32', 'PM-10K', 1, clEviator350,
    [{ type: 'KM', interval: 10000, dueSoon: 1000, tolerance: 500 },
     { type: 'Calendar', interval: 6, dueSoon: 15, tolerance: 15 }]);
  const planSuperAuto = await buildPmPlan('PM-SUPERAUTO', 'Super Auto Standard PM',
    'EPL20-STD', 'PM-5K', 1, clSuperAuto,
    [{ type: 'KM', interval: 5000, dueSoon: 500, tolerance: 250 },
     { type: 'Calendar', interval: 3, dueSoon: 10, tolerance: 10 }]);
  const planTractor = await buildPmPlan('PM-E27', 'E-27 Tractor Standard PM',
    'E27-2WD', 'PM-250H', 1, clTractor,
    [{ type: 'Hours', interval: 250, dueSoon: 25, tolerance: 15 },
     { type: 'Calendar', interval: 6, dueSoon: 15, tolerance: 15 }]);

  // The ladder repeats the same plan version for the next cycle.
  for (const pv of [planRhino4x2, planRhino6x4, planEviator, planEviator350, planSuperAuto, planTractor]) {
    await q(pool, `UPDATE pm.pm_plan_version SET next_plan_version_id = $1 WHERE plan_version_id = $1`, [pv]);
  }

  // --- Standard repair times (FR-APT-002) ---
  console.log('  building SRT master…');
  const srtRows = [
    ['PM-FULL', 'Full preventive maintenance service', 'PM', 240],
    ['PM-LIGHT', 'Light vehicle preventive maintenance', 'PM', 120],
    ['DIAG-HV', 'High-voltage diagnostic investigation', 'Diagnosis', 90],
    ['DIAG-GEN', 'General diagnostic investigation', 'Diagnosis', 60],
    ['REP-BRAKE', 'Brake system repair', 'Repair', 180],
    ['REP-BATT', 'Battery pack replacement', 'Part Replacement', 300],
    ['REP-CTRL', 'Motor controller replacement', 'Part Replacement', 150],
    ['REP-TYRE', 'Tyre replacement', 'Part Replacement', 45],
    ['SW-UPDATE', 'ECU software update', 'Software', 60],
    ['INSP-RECOM', 'Recommissioning inspection', 'Inspection', 90],
  ];
  for (const [code, desc, type, minutes] of srtRows) {
    await q(pool, `
      INSERT INTO schedule.standard_repair_time
        (operation_code, description, work_item_type, standard_minutes, version_no, approval_status)
      VALUES ($1,$2,$3,$4,1,'Approved') ON CONFLICT DO NOTHING`, [code, desc, type, minutes]);
  }

  // --- Technicians and skills (Doc 1.1 §25) ---
  console.log('  building technician master…');
  const centres = await many<any>(pool, `
    SELECT service_centre_id, code FROM master.service_centre ORDER BY code`);
  const centreByCode = Object.fromEntries(centres.map(c => [c.code, c.service_centre_id]));

  const techDefs = [
    ['TECH-001', 'Kumar S', 'SC-CHN', 'kumar.s', ['HV_BATTERY', 'MOTOR_INVERTER', 'DIAGNOSTICS']],
    ['TECH-002', 'Arul M', 'SC-CHN', 'arul.m', ['HV_BATTERY', 'BRAKES', 'AMT']],
    ['TECH-003', 'Suresh K', 'SC-CHN', 'suresh.k', ['HV_BATTERY', 'CHARGING', 'DIAGNOSTICS']],
    ['TECH-004', 'Ramesh P', 'SC-CBE', null, ['HV_BATTERY', 'BRAKES']],
    ['TECH-005', 'Anand V', 'SC-CBE', null, ['MOTOR_INVERTER', 'AMT']],
    ['TECH-006', 'Karthik R', 'SC-BLR', null, ['HV_BATTERY', 'DIAGNOSTICS']],
    ['TECH-007', 'Mani T', 'SC-BLR', null, ['BRAKES', 'PTO_HYDRAULICS']],
    ['TECH-008', 'Selvam D', 'SC-MDU', null, ['HV_BATTERY', 'DIAGNOSTICS']],
  ] as const;

  for (const [code, name, centre, username, skills] of techDefs) {
    const user = username
      ? await one<any>(pool, `SELECT user_id FROM security.application_user WHERE username = $1`, [username])
      : null;
    const t = await one<any>(pool, `
      INSERT INTO master.technician (user_id, service_centre_id, employee_code, name)
      VALUES ($1,$2,$3,$4) ON CONFLICT (employee_code) DO UPDATE SET name = EXCLUDED.name
      RETURNING technician_id`,
      [user?.user_id ?? null, centreByCode[centre], code, name]);
    for (const s of skills) {
      await q(pool, `
        INSERT INTO master.technician_skill
          (technician_id, skill_code, authorization_level, certification_ref, valid_from, valid_to)
        VALUES ($1,$2,'Level 2',$3, CURRENT_DATE - 365, CURRENT_DATE + 365)
        ON CONFLICT (technician_id, skill_code) DO NOTHING`,
        [t.technician_id, s, `CERT-${code}-${s}`]);
    }
  }

  // --- Fleet ---
  console.log('  building fleet…');
  const variants = await many<any>(pool, `
    SELECT vv.variant_id, vv.code, vm.code AS model_code
    FROM master.vehicle_variant vv JOIN master.vehicle_model vm ON vm.model_id = vv.model_id
    WHERE vv.confirmation_status = 'Confirmed'`);
  const variantByCode = Object.fromEntries(variants.map(v => [v.code, v.variant_id]));

  const orgs = await many<any>(pool, `
    SELECT organisation_id, code FROM org.organisation WHERE org_type = 'Customer'`);
  const depots = await many<any>(pool, `
    SELECT node_id, organisation_id FROM org.organisation_node WHERE node_type = 'Depot'`);

  const planByVariant: Record<string, number> = {
    'RH5538-4X2': planRhino4x2, 'RH5538-6X4': planRhino6x4,
    'EVICORE-40': planEviator, 'EVI350-32': planEviator350, 'EVI350LP-50': planEviator,
    'EPL20-STD': planSuperAuto, 'EPL20R-STD': planSuperAuto, 'SCARGO-CGO': planSuperAuto,
    'E27-2WD': planTractor, 'E27-4WD': planTractor,
  };

  // Fleet mix roughly proportional to a commercial EV operator.
  const mix: [string, number][] = [
    ['RH5538-4X2', 14], ['RH5538-6X4', 10],
    ['EVICORE-40', 12], ['EVI350-32', 8], ['EVI350LP-50', 6],
    ['EPL20-STD', 10], ['EPL20R-STD', 6], ['SCARGO-CGO', 8],
    ['E27-2WD', 5], ['E27-4WD', 3],
  ];

  let vinSeq = 1000;
  let regSeq = 1000;
  const created: { vehicleId: number; vin: string; variantCode: string; odo: number }[] = [];

  for (const [variantCode, count] of mix) {
    for (let i = 0; i < count; i++) {
      const vin = `${VIN_PREFIX}${pad(vinSeq++, 6)}`;
      const state = REG_STATES[vinSeq % REG_STATES.length];
      const reg = `${state}${pad(10 + (vinSeq % 80), 2)}${String.fromCharCode(65 + (vinSeq % 26))}` +
                  `${String.fromCharCode(65 + ((vinSeq * 7) % 26))}${pad(regSeq++, 4)}`;
      const org = orgs[vinSeq % orgs.length];
      const depot = depots.find(d => d.organisation_id === org.organisation_id);
      const centre = centres[vinSeq % 3];   // exclude the mobile unit from assignment

      // Age and usage spread so the due queue is realistic.
      const monthsOld = 3 + (vinSeq % 30);
      const commissioning = new Date();
      commissioning.setMonth(commissioning.getMonth() - monthsOld);

      // Usage profile by vehicle type. Tractors are metered primarily in
      // operating hours and cover little distance; heavy tractor-trailers
      // cover the most ground.
      const isHeavy = variantCode.startsWith('RH');
      const isTractor = variantCode.startsWith('E27') || variantCode.startsWith('E45');
      const isThreeWheeler = variantCode.startsWith('EP') || variantCode.startsWith('SCARGO');

      const kmPerMonth = isHeavy ? 5500
                       : isTractor ? 450
                       : isThreeWheeler ? 1400
                       : 3000;
      const hoursPerMonth = isTractor ? 95 : isHeavy ? 190 : 110;

      const usageFactor = 0.75 + ((vinSeq % 7) / 14);
      const odo = Math.round(kmPerMonth * monthsOld * usageFactor);
      const hours = Math.round(hoursPerMonth * monthsOld * usageFactor);

      const v = await one<any>(pool, `
        INSERT INTO master.vehicle
          (vin, registration_no, fleet_asset_no, variant_id, organisation_id, depot_node_id,
           assigned_service_centre_id, manufacture_date, delivery_date, commissioning_date,
           warranty_start, warranty_end, warranty_km_limit,
           current_odometer_km, current_operating_hours, usage_source, usage_updated_at,
           telematics_device_id, lifecycle_status)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$8,$8,$8,$9,150000,$10,$11,'Telematics', now(),$12,'Active')
        RETURNING vehicle_id`,
        [vin, reg, `FA-${pad(vinSeq, 5)}`, variantByCode[variantCode], org.organisation_id,
         depot?.node_id ?? null, centre.service_centre_id,
         commissioning.toISOString().slice(0, 10),
         new Date(commissioning.getFullYear() + 3, commissioning.getMonth(), commissioning.getDate())
           .toISOString().slice(0, 10),
         odo, hours, `TEL-${pad(vinSeq, 6)}`]);

      created.push({ vehicleId: v.vehicle_id, vin, variantCode, odo });

      // Opening availability interval (Doc 04 §30: one per active VIN at cutover).
      await transition(pool, {
        vehicleId: v.vehicle_id, reasonCode: 'IN_SERVICE', sourceType: 'Commissioning',
        ruleId: 'BL-AVL-001', actor: 'migration',
        startUtc: commissioning, reason: 'Opening state at go-live',
      });

      // Serialised components (Doc 1.1 §21).
      const components = isHeavy
        ? [['BatteryPack', 'BP-7T-001'], ['TractionMotor', 'TM-100K'], ['MotorController', 'MC-7T-001'],
           ['DCDCConverter', 'DCDC-002'], ['OnBoardCharger', 'OBC-7T'], ['HVJunctionBox', 'HVJB-01']]
        : [['BatteryPack', 'BP-7T-001'], ['TractionMotor', 'TM-100K'], ['MotorController', 'MC-7T-001']];
      for (const [type, partNo] of components) {
        await q(pool, `
          INSERT INTO master.vehicle_component
            (vehicle_id, component_type, part_no, serial_no, supplier, installed_on,
             installed_odometer_km, warranty_start, warranty_end, warranty_km_limit, is_active)
          VALUES ($1,$2,$3,$4,'Montra Electric',$5,0,$5,$6,$7,true)`,
          [v.vehicle_id, type, partNo,
           `${type.slice(0, 2).toUpperCase()}${pad(vinSeq, 6)}${String(Math.floor(Math.random() * 900) + 100)}`,
           commissioning.toISOString().slice(0, 10),
           new Date(commissioning.getFullYear() + (type === 'BatteryPack' ? 8 : 5),
                    commissioning.getMonth(), commissioning.getDate()).toISOString().slice(0, 10),
           type === 'BatteryPack' ? 500000 : 300000]);
      }

      // Statutory documents (FR-DOC-001) — a few deliberately near expiry.
      const docTypes: [string, number][] = [
        ['RC', 1800], ['Insurance', vinSeq % 11 === 0 ? 12 : 400],
        ['PUC', vinSeq % 7 === 0 ? 8 : 180], ['Fitness', 900],
      ];
      for (const [type, daysAhead] of docTypes) {
        const expiry = new Date(Date.now() + daysAhead * 86_400_000);
        await q(pool, `
          INSERT INTO campaign.vehicle_document
            (vehicle_id, document_type, document_no, issuing_authority, issue_date, expiry_date, renewal_status)
          VALUES ($1,$2,$3,'RTO Tamil Nadu', CURRENT_DATE - 365, $4,
                  CASE WHEN $4::date < CURRENT_DATE THEN 'Expired'
                       WHEN $4::date < CURRENT_DATE + 30 THEN 'Due Soon' ELSE 'Valid' END)
          ON CONFLICT (vehicle_id, document_type) DO NOTHING`,
          [v.vehicle_id, type, `${type}-${pad(vinSeq, 6)}`, expiry.toISOString().slice(0, 10)]);
      }

      await q(pool, `
        INSERT INTO campaign.firmware_baseline
          (vehicle_id, ecu_module, current_version, target_version, last_updated_on, update_method)
        VALUES ($1,'VCU',$2,$3, CURRENT_DATE - 60,'Workshop'),
               ($1,'BMS',$4,$4, CURRENT_DATE - 60,'OTA')
        ON CONFLICT (vehicle_id, ecu_module) DO NOTHING`,
        [v.vehicle_id, `FW-VCU-2.${vinSeq % 4}.1`, 'FW-VCU-2.4.1', `FW-BMS-1.${vinSeq % 3}.0`]);

      // --- PM obligations through the domain engine ---
      //
      // History is reconstructed from actual usage so the open obligation
      // sits realistically against the vehicle's odometer, and the calendar
      // ladder is re-anchored on each completion (the km trigger fires first
      // on a hard-working fleet, which is what re-sets the date target).
      const planVersionId = planByVariant[variantCode];
      if (planVersionId) {
        const kmTrigger = await one<any>(pool, `
          SELECT interval_value FROM pm.pm_plan_trigger
          WHERE plan_version_id = $1 AND trigger_type = 'KM'`, [planVersionId]);
        const hoursTrigger = await one<any>(pool, `
          SELECT interval_value FROM pm.pm_plan_trigger
          WHERE plan_version_id = $1 AND trigger_type = 'Hours'`, [planVersionId]);

        const interval = Number(kmTrigger?.interval_value ?? 0);
        const hourInterval = Number(hoursTrigger?.interval_value ?? 0);

        // How many cycles this vehicle has already worked through.
        let completedCycles = interval
          ? Math.floor(odo / interval)
          : hourInterval ? Math.floor(hours / hourInterval) : 0;

        // Roughly one vehicle in eight is left genuinely overdue so the
        // exception paths and escalation queues are populated.
        const leaveOverdue = vinSeq % 8 === 0;
        if (leaveOverdue && completedCycles > 0) completedCycles -= 1;

        let baselineKm = 0;
        let baselineHours2 = 0;
        let baselineDate = new Date(commissioning);

        for (let c = 1; c <= completedCycles + 1; c++) {
          const obId = await createObligation(pool, {
            vehicleId: v.vehicle_id, planVersionId, cycleNo: c,
            baselineKm, baselineDate, baselineHours: baselineHours2,
            createdSource: c === 1 ? 'Commissioning' : 'PM Completion',
          });

          if (c <= completedCycles) {
            const ob = await one<any>(pool, `
              SELECT * FROM pm.pm_obligation WHERE pm_obligation_id = $1`, [obId]);

            const targetKm = Number(ob.target_km ?? 0);
            const driftKm = ((vinSeq + c) % 5) * 120 - 200;
            const actualKm = targetKm + driftKm;

            // Date the work actually happened, interpolated from the meter that
            // drives this plan (hours for tractors, distance otherwise).
            const monthsToReach = interval
              ? (kmPerMonth ? actualKm / kmPerMonth : c * 6)
              : (hoursPerMonth ? (Number(ob.target_hours ?? 0)) / hoursPerMonth : c * 6);
            const actualDate = new Date(commissioning);
            actualDate.setMonth(actualDate.getMonth() + Math.round(monthsToReach));

            const targetDate = ob.target_date ? new Date(ob.target_date + 'T00:00:00Z') : actualDate;
            const varianceDays = Math.round(
              (actualDate.getTime() - targetDate.getTime()) / 86_400_000);
            const toleranceDays = Number(ob.tolerance_days ?? 0);

            const outcome = varianceDays > toleranceDays ? 'Completed Late'
                          : varianceDays > 0 ? 'Completed Within Tolerance'
                          : 'Completed On Time';

            await q(pool, `
              UPDATE pm.pm_obligation
              SET status = $1, outcome = $1, actual_completion_km = $2, actual_completion_date = $3,
                  actual_completion_hours = $4, variance_km = $5, variance_days = $6
              WHERE pm_obligation_id = $7`,
              [outcome, actualKm, actualDate.toISOString().slice(0, 10),
               Math.round(actualKm / (isHeavy ? 28 : 12)), driftKm, varianceDays, obId]);

            baselineKm = targetKm;
            baselineHours2 = Number(ob.target_hours ?? 0);
            baselineDate = actualDate;   // re-anchor the calendar ladder
          }
        }
        await reevaluateObligations(pool, v.vehicle_id, 'migration');
      }
    }
  }
  console.log(`  created ${created.length} vehicles`);

  // --- Contracts and entitlements ---
  const abc = orgs.find(o => o.code === 'ABCLOG');
  if (abc) {
    const contract = await one<any>(pool, `
      INSERT INTO commercial.contract
        (contract_no, organisation_id, contract_type, start_date, end_date, km_limit,
         free_services_total, labour_cover_pct, parts_cover_pct, uptime_commitment_pct, inclusions)
      VALUES ('AMC-2026-001',$1,'AMC', CURRENT_DATE - 200, CURRENT_DATE + 900, 200000, 6, 100, 80, 95,
              'Scheduled PM, wear parts, roadside assistance')
      RETURNING contract_id`, [abc.organisation_id]);

    for (const v of created.filter((_, i) => i % 3 === 0).slice(0, 20)) {
      await q(pool, `
        INSERT INTO commercial.entitlement
          (contract_id, vehicle_id, entitlement_type, total_quantity, consumed_quantity)
        VALUES ($1,$2,'Free PM Service',6,$3)`,
        [contract.contract_id, v.vehicleId, Math.floor(Math.random() * 3)]);
    }
  }

  // --- Campaign (FR-CAM-001) ---
  const camp = await one<any>(pool, `
    INSERT INTO campaign.campaign (code, name, classification, work_instruction_ref,
                                   effective_from, mandatory_by_date, status)
    VALUES ('CMP-2026-01','MCU software update to FW-VCU-2.4.1','Software','WI-MCU-2026-01',
            CURRENT_DATE - 30, CURRENT_DATE + 90, 'Open')
    RETURNING campaign_id`);
  for (const v of created.filter(c => c.variantCode.startsWith('RH')).slice(0, 15)) {
    await q(pool, `
      INSERT INTO campaign.campaign_vehicle (campaign_id, vehicle_id, status)
      VALUES ($1,$2,$3) ON CONFLICT DO NOTHING`,
      [camp.campaign_id, v.vehicleId, Math.random() > 0.6 ? 'Completed' : 'Open']);
  }

  console.log('  creating in-flight service work…');
  await createInFlightWork(created, centreByCode);

  // --- A telematics batch so the integration console has traffic ---
  console.log('  sending telematics batch…');
  let accepted = 0, quarantined = 0;
  for (const v of created.slice(0, 30)) {
    const r = await ingestTelematics(pool, {
      externalMessageId: `SEED-${v.vin}-${Date.now()}`,
      vin: v.vin,
      odometerKm: v.odo + Math.round(Math.random() * 40),
      operatingHours: undefined,
      sourceTimestampUtc: new Date().toISOString(),
      socPct: 40 + Math.round(Math.random() * 55),
      sohPct: 92 + Math.round(Math.random() * 8),
    });
    if (r.result === 'accepted') accepted++;
  }
  // Two deliberately bad events so the quarantine path is visible.
  const bad = created[0];
  const r1 = await ingestTelematics(pool, {
    externalMessageId: `SEED-BAD-ROLLBACK-${Date.now()}`, vin: bad.vin,
    odometerKm: 10, sourceTimestampUtc: new Date().toISOString(),
  });
  const r2 = await ingestTelematics(pool, {
    externalMessageId: `SEED-BAD-UNKNOWNVIN-${Date.now()}`, vin: 'UNKNOWNVIN00000000',
    odometerKm: 1000, sourceTimestampUtc: new Date().toISOString(),
  });
  if (r1.result === 'quarantined') quarantined++;
  if (r2.result === 'quarantined') quarantined++;
  console.log(`    telematics: ${accepted} accepted, ${quarantined} quarantined`);

  const summary = await one<any>(pool, `
    SELECT
      (SELECT count(*) FROM master.vehicle)::int AS vehicles,
      (SELECT count(*) FROM pm.pm_obligation)::int AS obligations,
      (SELECT count(*) FROM pm.pm_obligation WHERE status='Overdue')::int AS overdue,
      (SELECT count(*) FROM pm.pm_obligation WHERE status='Due')::int AS due,
      (SELECT count(*) FROM pm.pm_obligation WHERE status='Due Soon')::int AS due_soon,
      (SELECT count(*) FROM service.service_event)::int AS service_events,
      (SELECT count(*) FROM service.job_card)::int AS job_cards,
      (SELECT count(*) FROM service.defect)::int AS defects,
      (SELECT count(*) FROM uptime.vehicle_status_ledger)::int AS ledger_rows,
      (SELECT count(*) FROM pm.checklist_item)::int AS checklist_items`);

  console.log('\nSeed complete:');
  for (const [k, v] of Object.entries(summary ?? {})) console.log(`  ${k.padEnd(16)} ${v}`);
}

/** Build a spread of service work so every workshop state is represented. */
async function createInFlightWork(
  created: { vehicleId: number; vin: string; variantCode: string; odo: number }[],
  centreByCode: Record<string, number>,
) {
  const techs = await many<any>(pool, `
    SELECT technician_id, service_centre_id, name FROM master.technician ORDER BY technician_id`);
  const chennaiTechs = techs.filter(t => t.service_centre_id === centreByCode['SC-CHN']);

  // --- Breakdowns in assorted states ---
  const breakdownSpecs = [
    { i: 2,  mobility: 'Immobilized',      complaint: 'CMP-NOSTART',  text: 'Vehicle not starting, no power on dashboard.',    priority: 'P1', ageHours: 3,  disposition: 'ServiceCentre' },
    { i: 7,  mobility: 'Immobilized',      complaint: 'CMP-NOPOWER',  text: 'Complete loss of power on the outer ring road.',  priority: 'P1', ageHours: 9,  disposition: 'MobileTechnician' },
    { i: 13, mobility: 'Limited movement', complaint: 'CMP-OVERHEAT', text: 'Battery overheat warning, speed limited.',        priority: 'P2', ageHours: 26, disposition: 'ServiceCentre' },
    { i: 21, mobility: 'Can move',         complaint: 'CMP-CHARGE',   text: 'Vehicle will not accept charge at depot point.',  priority: 'P3', ageHours: 50, disposition: 'ServiceCentre' },
    { i: 28, mobility: 'Limited movement', complaint: 'CMP-BRAKE',    text: 'Brake warning lamp and reduced braking feel.',    priority: 'P2', ageHours: 5,  disposition: 'ServiceCentre' },
    { i: 34, mobility: 'Can move',         complaint: 'CMP-NOISE',    text: 'Abnormal whine from drive motor under load.',     priority: 'P3', ageHours: 70, disposition: 'ServiceCentre' },
  ];

  for (const spec of breakdownSpecs) {
    const v = created[spec.i % created.length];
    const reported = new Date(Date.now() - spec.ageHours * 3_600_000);

    const seNo = await nextDocumentNo(pool, 'SE', 6);
    const se = await one<any>(pool, `
      INSERT INTO service.service_event
        (service_event_no, vehicle_id, event_type, source_channel, priority, status,
         customer_visible_start, created_by, sla_id)
      VALUES ($1,$2,'Breakdown','CallCentre',$3,'In Progress',$4,'vijay.r',
        (SELECT sla_id FROM service.sla_master WHERE service_type='Breakdown' AND priority=$3 LIMIT 1))
      RETURNING *`, [seNo, v.vehicleId, spec.priority, reported]);

    await q(pool, `
      INSERT INTO service.breakdown_event
        (service_event_id, vehicle_id, stopped_actual_utc, reported_utc, accepted_utc, assigned_utc,
         reported_by, contact_phone, location_text, mobility, complaint_code, complaint_text,
         priority, disposition, triaged_by, triaged_at)
      VALUES ($1,$2,$3,$4,$5,$6,'Driver (Customer)','+919840000000',
              'Chennai Outer Ring Road, Chennai',$7,$8,$9,$10,$11,'vijay.r',$5)`,
      [se.service_event_id, v.vehicleId, reported, reported,
       new Date(reported.getTime() + 18 * 60_000),
       new Date(reported.getTime() + 35 * 60_000),
       spec.mobility, spec.complaint, spec.text, spec.priority, spec.disposition]);

    if (spec.mobility === 'Immobilized') {
      await transition(pool, {
        vehicleId: v.vehicleId, reasonCode: 'DOWN_BREAKDOWN', sourceType: 'Breakdown',
        sourceEntityId: se.service_event_id, ruleId: 'BL-AVL-003', actor: 'vijay.r',
        startUtc: reported, reason: `Breakdown ${seNo}`,
      });
    }

    const jc = await createJobCard(pool, {
      serviceEventId: se.service_event_id, vehicleId: v.vehicleId,
      serviceCentreId: centreByCode['SC-CHN'],
      locationType: spec.disposition === 'MobileTechnician' ? 'Roadside' : 'Workshop',
      jobType: 'Breakdown',
      technicianId: chennaiTechs[spec.i % chennaiTechs.length]?.technician_id,
      complaintText: spec.text, actor: 'ravi.kumar',
    });

    await q(pool, `
      INSERT INTO service.work_item (job_card_id, line_no, work_item_type, description, status)
      VALUES ($1,1,'Diagnosis',$2,'Completed'),
             ($1,2,'Repair',$3,'In Progress')`,
      [jc.job_card_id, `Diagnose: ${spec.text}`, 'Rectify identified fault']);

    // Spread the workshop states across the canonical set.
    const targetStatus = spec.ageHours > 48 ? 'Awaiting Parts'
                       : spec.ageHours > 20 ? 'Repairing'
                       : 'Under Diagnosis';
    await changeStatus(pool, {
      jobCardId: jc.job_card_id, toStatus: 'Under Diagnosis', actor: 'kumar.s',
    });
    if (targetStatus !== 'Under Diagnosis') {
      await changeStatus(pool, { jobCardId: jc.job_card_id, toStatus: 'Repairing', actor: 'kumar.s' });
    }
    if (targetStatus === 'Awaiting Parts') {
      await changeStatus(pool, {
        jobCardId: jc.job_card_id, toStatus: 'Awaiting Parts', actor: 'meena.s',
        reason: 'Controller not in stock at Chennai',
      });
      await q(pool, `
        INSERT INTO service.vor_status (job_card_id, vehicle_off_road, promised_availability_date,
                                        backorder_ref, expedite_status, escalation_owner)
        VALUES ($1,true, CURRENT_DATE + 3,'BO-2026-0042','Expedited','Regional Parts Manager')`,
        [jc.job_card_id]);
    }
  }

  // --- PM jobs in progress, including one ready for QC ---
  const pmCandidates = await many<any>(pool, `
    SELECT o.pm_obligation_id, o.vehicle_id, o.pm_level, o.plan_version_id,
           pv.checklist_version_id, v.vin, v.current_odometer_km
    FROM pm.pm_obligation o
    JOIN pm.pm_plan_version pv ON pv.plan_version_id = o.plan_version_id
    JOIN master.vehicle v ON v.vehicle_id = o.vehicle_id
    WHERE o.status IN ('Due','Overdue') AND pv.checklist_version_id IS NOT NULL
    ORDER BY o.pm_obligation_id LIMIT 6`);

  for (let idx = 0; idx < pmCandidates.length; idx++) {
    const ob = pmCandidates[idx];
    const seNo = await nextDocumentNo(pool, 'SE', 6);
    const se = await one<any>(pool, `
      INSERT INTO service.service_event
        (service_event_no, vehicle_id, event_type, source_channel, status, created_by, sla_id)
      VALUES ($1,$2,'PM','System','In Progress','ravi.kumar',
        (SELECT sla_id FROM service.sla_master WHERE service_type='PM' LIMIT 1))
      RETURNING *`, [seNo, ob.vehicle_id]);

    const jc = await createJobCard(pool, {
      serviceEventId: se.service_event_id, vehicleId: ob.vehicle_id,
      serviceCentreId: centreByCode['SC-CHN'], jobType: 'PM',
      technicianId: chennaiTechs[idx % chennaiTechs.length]?.technician_id,
      complaintText: `Scheduled ${ob.pm_level} preventive maintenance`, actor: 'ravi.kumar',
    });

    const wi = await one<any>(pool, `
      INSERT INTO service.work_item (job_card_id, line_no, work_item_type, description,
                                     source_entity_type, source_entity_id, status)
      VALUES ($1,1,'PM',$2,'PMObligation',$3,'In Progress') RETURNING work_item_id`,
      [jc.job_card_id, `${ob.pm_level} preventive maintenance`, ob.pm_obligation_id]);

    await q(pool, `
      INSERT INTO pm.pm_execution
        (work_item_id, job_card_id, pm_obligation_id, frozen_plan_version_id, frozen_checklist_version_id)
      VALUES ($1,$2,$3,$4,$5)`,
      [wi.work_item_id, jc.job_card_id, ob.pm_obligation_id, ob.plan_version_id, ob.checklist_version_id]);

    await q(pool, `
      UPDATE pm.pm_obligation SET status='Under Service' WHERE pm_obligation_id = $1`,
      [ob.pm_obligation_id]);

    await changeStatus(pool, { jobCardId: jc.job_card_id, toStatus: 'Under Diagnosis', actor: 'kumar.s' });
    await changeStatus(pool, { jobCardId: jc.job_card_id, toStatus: 'Repairing', actor: 'kumar.s' });

    // The first three jobs get their checklist filled in, with findings, so the
    // release gate has something real to evaluate.
    if (idx < 3) {
      const items = await many<any>(pool, `
        SELECT ci.item_id, ci.response_mode, ci.min_value, ci.max_value, ci.is_mandatory, ci.code
        FROM pm.checklist_section cs JOIN pm.checklist_item ci ON ci.section_id = cs.section_id
        WHERE cs.checklist_version_id = $1 ORDER BY cs.display_order, ci.display_order`,
        [ob.checklist_version_id]);

      const answers = items.map((it: any, n: number) => {
        // Job 0 is complete and clean, job 1 has an advisory, job 2 fails a brake item.
        if (idx === 2 && it.code === 'BRK-01') {
          return { itemId: it.item_id, responseType: 'Numeric' as const, numericValue: 3.2,
                   photoRef: 'seed://brake-pad-worn.jpg' };
        }
        if (idx === 1 && n === 12) {
          return { itemId: it.item_id, responseType: 'Advisory-Observation' as const,
                   textValue: 'Minor coolant weep at pump housing — monitor at next service.' };
        }
        if (it.response_mode === 'Numeric') {
          const min = Number(it.min_value ?? 0), max = Number(it.max_value ?? 100);
          return { itemId: it.item_id, responseType: 'Numeric' as const,
                   numericValue: Number((min + (max - min) * 0.6).toFixed(1)) };
        }
        return { itemId: it.item_id, responseType: 'OK' as const };
      });

      await recordAnswers(pool, {
        jobCardId: jc.job_card_id, answers,
        technicianId: chennaiTechs[idx % chennaiTechs.length]?.technician_id,
        actor: 'kumar.s',
      });

      // Job 0 is clean and moves to QC so a supervisor has something waiting.
      if (idx === 0) {
        await changeStatus(pool, {
          jobCardId: jc.job_card_id, toStatus: 'Technician Complete', actor: 'kumar.s' });
        await changeStatus(pool, {
          jobCardId: jc.job_card_id, toStatus: 'QC Pending', actor: 'kumar.s' });
      }
    }
  }

  // --- Appointments across today and the coming days (FR-APT-001) ---
  const dueForBooking = await many<any>(pool, `
    SELECT o.pm_obligation_id, o.vehicle_id, o.pm_level, v.vin, v.assigned_service_centre_id
    FROM pm.pm_obligation o
    JOIN master.vehicle v ON v.vehicle_id = o.vehicle_id
    WHERE o.status IN ('Due','Due Soon','Overdue')
    ORDER BY o.pm_obligation_id LIMIT 14`);

  const bays = await many<any>(pool, `
    SELECT bay_id, service_centre_id FROM schedule.service_bay ORDER BY bay_id`);
  const slotHours = [8, 9, 10, 11, 14, 15, 16];

  for (let i = 0; i < dueForBooking.length; i++) {
    const ob = dueForBooking[i];
    const centreId = ob.assigned_service_centre_id ?? centreByCode['SC-CHN'];
    const centreBays = bays.filter(b => b.service_centre_id === centreId);
    if (!centreBays.length) continue;

    // Spread across today (most), tomorrow and the day after.
    const dayOffset = i < 6 ? 0 : i < 10 ? 1 : 2;
    const slot = new Date();
    slot.setDate(slot.getDate() + dayOffset);
    slot.setHours(slotHours[i % slotHours.length], 0, 0, 0);
    const minutes = ob.pm_level.includes('20K') ? 240 : 120;

    const apptNo = await nextDocumentNo(pool, 'APT', 5);
    await q(pool, `
      INSERT INTO schedule.appointment
        (appointment_no, vehicle_id, pm_obligation_id, service_centre_id, bay_id, technician_id,
         service_type, slot_start, slot_end, estimated_minutes, status, booked_by, request_notes)
      VALUES ($1,$2,$3,$4,$5,$6,'Preventive Maintenance',$7,$8,$9,$10,'ravi.kumar',$11)`,
      [apptNo, ob.vehicle_id, ob.pm_obligation_id, centreId,
       centreBays[i % centreBays.length].bay_id,
       techs.filter(t => t.service_centre_id === centreId)[i % Math.max(1,
         techs.filter(t => t.service_centre_id === centreId).length)]?.technician_id ?? null,
       slot, new Date(slot.getTime() + minutes * 60000), minutes,
       dayOffset === 0 && i % 4 === 0 ? 'In Progress' : 'Scheduled',
       `Scheduled ${ob.pm_level} service`]);

    await q(pool, `
      UPDATE pm.pm_obligation SET status = 'Scheduled'
      WHERE pm_obligation_id = $1 AND status IN ('Due','Due Soon','Overdue')`,
      [ob.pm_obligation_id]);
  }

  // --- A closed PM so history and KPIs are not empty ---
  const closedCandidate = await one<any>(pool, `
    SELECT o.pm_obligation_id, o.vehicle_id, o.pm_level, o.plan_version_id, pv.checklist_version_id
    FROM pm.pm_obligation o JOIN pm.pm_plan_version pv ON pv.plan_version_id = o.plan_version_id
    WHERE o.status LIKE 'Completed%' AND pv.checklist_version_id IS NOT NULL LIMIT 1`);

  if (closedCandidate) {
    const seNo = await nextDocumentNo(pool, 'SE', 6);
    const start = new Date(Date.now() - 12 * 86_400_000);
    const end = new Date(Date.now() - 12 * 86_400_000 + 6 * 3_600_000);
    const se = await one<any>(pool, `
      INSERT INTO service.service_event
        (service_event_no, vehicle_id, event_type, source_channel, status,
         customer_visible_start, customer_visible_end, created_by)
      VALUES ($1,$2,'PM','System','Closed',$3,$4,'ravi.kumar') RETURNING *`,
      [seNo, closedCandidate.vehicle_id, start, end]);

    const jcNo = await nextDocumentNo(pool, 'JC', 5);
    const jc = await one<any>(pool, `
      INSERT INTO service.job_card
        (job_card_no, service_event_id, vehicle_id, service_centre_id, job_type, status,
         opened_utc, accepted_utc, started_utc, technician_complete_utc, qc_utc, released_utc, closed_utc,
         created_by)
      VALUES ($1,$2,$3,$4,'PM','Closed',$5,$5,$5,$6,$6,$6,$6,'ravi.kumar') RETURNING *`,
      [jcNo, se.service_event_id, closedCandidate.vehicle_id, centreByCode['SC-CHN'], start, end]);

    await q(pool, `
      INSERT INTO quality.vehicle_release
        (job_card_id, service_event_id, vehicle_id, release_type, released_by_user_id,
         road_test_done, released_at, remarks)
      VALUES ($1,$2,$3,'Standard',
              (SELECT user_id FROM security.application_user WHERE username='priya.n'),
              true,$4,'PM completed and released after road test')`,
      [jc.job_card_id, se.service_event_id, closedCandidate.vehicle_id, end]);
  }

  // --- A closed breakdown pair that triggers the repeat-failure rule ---
  const repeatVehicle = created[40 % created.length];
  const first = new Date(Date.now() - 20 * 86_400_000);
  const second = new Date(Date.now() - 6 * 86_400_000);

  for (const [when, label] of [[first, 'first'], [second, 'repeat']] as const) {
    const seNo = await nextDocumentNo(pool, 'SE', 6);
    const se = await one<any>(pool, `
      INSERT INTO service.service_event
        (service_event_no, vehicle_id, event_type, source_channel, priority, status,
         customer_visible_start, customer_visible_end, final_diagnosis, root_cause_code,
         corrective_action_code, created_by, ftf_result, is_repeat)
      VALUES ($1,$2,'Breakdown','CallCentre','P2','Closed',$3,$4,
              'HV fuse failure caused by connector resistance','RC-COMPONENT','CA-REPLACE',
              'vijay.r',$5,$6)
      RETURNING *`,
      [seNo, repeatVehicle.vehicleId, when, new Date(when.getTime() + 8 * 3_600_000),
       label === 'first' ? 'Fail' : 'Pass', label === 'repeat']);

    await q(pool, `
      INSERT INTO service.breakdown_event
        (service_event_id, vehicle_id, stopped_actual_utc, reported_utc, accepted_utc,
         restored_operable_utc, released_utc, closed_utc, reported_by, location_text,
         mobility, complaint_code, complaint_text, priority, disposition)
      VALUES ($1,$2,$3,$3,$4,$5,$5,$5,'Driver (Customer)','Chennai',
              'Limited movement','CMP-WARNLAMP','HV system warning lamp illuminated.','P2','ServiceCentre')`,
      [se.service_event_id, repeatVehicle.vehicleId, when,
       new Date(when.getTime() + 30 * 60_000), new Date(when.getTime() + 8 * 3_600_000)]);

    if (label === 'repeat') {
      const prior = await one<any>(pool, `
        SELECT service_event_id FROM service.service_event
        WHERE vehicle_id = $1 AND event_type='Breakdown' AND status='Closed'
        ORDER BY customer_visible_start LIMIT 1`, [repeatVehicle.vehicleId]);
      const rule = await one<any>(pool, `SELECT rule_id, version_no FROM service.repeat_failure_rule LIMIT 1`);
      await q(pool, `
        UPDATE service.service_event SET prior_service_event_id = $1 WHERE service_event_id = $2`,
        [prior.service_event_id, se.service_event_id]);
      await q(pool, `
        INSERT INTO service.repeat_failure_match
          (current_service_event_id, prior_service_event_id, vehicle_id, rule_id, rule_version,
           matched_attributes, day_delta, match_result)
        VALUES ($1,$2,$3,$4,$5,'complaint_code,subsystem',14,true)`,
        [se.service_event_id, prior.service_event_id, repeatVehicle.vehicleId,
         rule.rule_id, rule.version_no]);
    }
  }

  // --- One vehicle off-hire so the exclusion path is visible ---
  const offHireVehicle = created[55 % created.length];
  const offHire = await one<any>(pool, `
    INSERT INTO uptime.off_hire_record
      (vehicle_id, reason_code, evidence_ref, requested_by, approved_by, start_utc, expected_return_utc)
    VALUES ($1,'OFF_HIRE','EMAIL-ABC-2026-0431','fleet.abc','vijay.r',
            now() - interval '9 days', now() + interval '20 days')
    RETURNING off_hire_id`, [offHireVehicle.vehicleId]);
  await transition(pool, {
    vehicleId: offHireVehicle.vehicleId, reasonCode: 'OFF_HIRE', sourceType: 'OffHire',
    sourceEntityId: offHire.off_hire_id, ruleId: 'BL-AVL-011', actor: 'vijay.r',
    startUtc: new Date(Date.now() - 9 * 86_400_000),
    reason: 'Customer seasonal off-hire, evidence on file',
  });

  // --- An estimate awaiting customer approval ---
  const awaitingJob = await one<any>(pool, `
    SELECT jc.job_card_id, jc.service_event_id FROM service.job_card jc
    WHERE jc.status = 'Repairing' ORDER BY jc.job_card_id LIMIT 1`);
  if (awaitingJob) {
    const estNo = await nextDocumentNo(pool, 'EST', 5);
    const est = await one<any>(pool, `
      INSERT INTO commercial.estimate
        (estimate_no, service_event_id, job_card_id, revision_no, total_amount, valid_to,
         sent_at, decision, notes)
      VALUES ($1,$2,$3,1,35800, CURRENT_DATE + 7, now(),'Pending',
              'Replacement of HV fuse and coolant top-up')
      RETURNING estimate_id`,
      [estNo, awaitingJob.service_event_id, awaitingJob.job_card_id]);
    await q(pool, `
      INSERT INTO commercial.estimate_line (estimate_id, line_type, item_ref, description, quantity, rate, amount, coverage_split)
      VALUES ($1,'Part','HVF-100','HV Fuse 100A',1,4200,4200,'Customer'),
             ($1,'Part','CLNT-5L','Battery coolant 5L',2,1850,3700,'Customer'),
             ($1,'Labour','DIAG-HV','High-voltage diagnostic',1.5,1200,1800,'Customer'),
             ($1,'Labour','REP-CTRL','Controller access and refit',3,1200,3600,'Customer'),
             ($1,'External',NULL,'Recovery to workshop',1,22500,22500,'Customer')`,
      [est.estimate_id]);
    await changeStatus(pool, {
      jobCardId: awaitingJob.job_card_id, toStatus: 'Awaiting Customer Approval',
      actor: 'ravi.kumar', reason: 'Estimate sent to customer for approval',
    });
  }
}

// Run directly from the command line: node src/scripts/seed-demo.ts
const invokedDirectly = process.argv[1] && process.argv[1].endsWith('seed-demo.ts');
if (invokedDirectly) {
  seedDemo()
    .then(async () => { await pool.end(); process.exit(0); })
    .catch(async (e) => { console.error('Seed failed:', e); await pool.end(); process.exit(1); });
}
