import { api, qs } from '../api.js';
import {
  h, pill, table, fmtNum, fmtKm, fmtDate, fmtDateTime, ago, durationHrs,
  cardOf, field, select, modal, toast, showApiError, clear,
} from '../ui.js';
import { setPageTitle, reference, can, hasRole } from '../app.js';

/* ===================== Service events ===================== */

export async function serviceEventsView({ params }) {
  setPageTitle('Service Events', 'One customer-visible occurrence; may own several job cards (FR-SE-001)');

  const wrap = h('div', {});
  const results = h('div', {});
  const statusSel = select([{ value: 'Open', label: 'Open' }, 'In Progress', 'Closed',
    { value: '', label: 'All' }], params.get('status') ?? 'Open');
  const typeSel = select([{ value: '', label: 'All types' }, 'PM', 'Breakdown', 'Accident',
    'Campaign', 'Inspection', 'General Service', 'Warranty'], params.get('eventType') ?? '');

  async function load() {
    results.replaceChildren(h('div', { class: 'spin' }));
    const rows = await api.get('/api/v1/service-events' + qs({
      status: statusSel.value, eventType: typeSel.value, limit: 200 }));
    results.replaceChildren(cardOf(`${rows.length} service event${rows.length === 1 ? '' : 's'}`,
      table([
        { label: 'Event', render: r => h('span', { class: 'mono' }, r.service_event_no) },
        { label: 'Type', render: r => pill(r.event_type, r.event_type === 'Breakdown' ? 'p-red' : 'p-blue') },
        { label: 'Vehicle', render: r => h('a', { href: `#/vehicles/${r.vin}` }, r.registration_no || r.vin) },
        { label: 'Customer', key: 'customer_name' },
        { label: 'Priority', render: r => r.priority ? pill(r.priority) : '—' },
        { label: 'Opened', render: r => fmtDateTime(r.customer_visible_start) },
        { label: 'Job cards', num: true, key: 'job_card_count' },
        { label: 'Latest job', render: r => r.latest_job_status ? pill(r.latest_job_status) : '—' },
        { label: 'Repeat', render: r => r.is_repeat ? pill('Repeat', 'p-red') : '—' },
        { label: 'Status', render: r => pill(r.status) },
      ], rows, { empty: 'No service events match.' })));
  }

  statusSel.addEventListener('change', load);
  typeSel.addEventListener('change', load);
  wrap.appendChild(h('div', { class: 'filters' },
    field('Status', statusSel), field('Type', typeSel),
    h('button', { class: 'btn btn-primary', onclick: load }, 'Apply')));
  wrap.appendChild(results);
  await load();
  return wrap;
}

/* ===================== Job card list ===================== */

export async function jobCardsView({ params }) {
  setPageTitle('Job Cards', 'Workshop execution — one location per job card (FR-JC-009)');

  const ref = await reference();
  const wrap = h('div', {});
  const results = h('div', {});

  const statusSel = select([{ value: 'Open', label: 'All open' },
    'Open', 'Assigned', 'Under Diagnosis', 'Repairing', 'Awaiting Parts',
    'Awaiting Customer Approval', 'Technician Complete', 'QC Pending',
    { value: 'Closed', label: 'Closed' }], params.get('status') ?? 'Open');
  const centreSel = select([{ value: '', label: 'All service centres' },
    ...ref.serviceCentres.map(c => ({ value: c.service_centre_id, label: c.name }))],
    params.get('serviceCentreId') ?? '');

  async function load() {
    results.replaceChildren(h('div', { class: 'spin' }));
    const rows = await api.get('/api/v1/job-cards' + qs({
      status: statusSel.value, serviceCentreId: centreSel.value, limit: 200 }));

    const byStatus = {};
    for (const r of rows) byStatus[r.status] = (byStatus[r.status] ?? 0) + 1;

    results.replaceChildren(
      h('div', { style: 'display:flex;gap:7px;flex-wrap:wrap;margin-bottom:14px' },
        Object.entries(byStatus).sort((a, b) => b[1] - a[1]).map(([s, n]) =>
          h('span', { class: 'pill p-grey', style: 'cursor:pointer',
            onclick: () => { statusSel.value = s; load(); } }, `${s}: ${n}`))),
      cardOf(`${rows.length} job card${rows.length === 1 ? '' : 's'}`,
        table([
          { label: 'Job card', render: r => h('a', { href: `#/job-cards/${r.job_card_id}` },
              h('span', { class: 'mono' }, r.job_card_no)) },
          { label: 'Type', render: r => pill(r.event_type, r.event_type === 'Breakdown' ? 'p-red' : 'p-blue') },
          { label: 'Vehicle', render: r => h('div', {},
              h('a', { href: `#/vehicles/${r.vin}` }, r.registration_no || r.vin),
              h('div', { class: 'small muted' }, r.customer_name)) },
          { label: 'Priority', render: r => r.priority ? pill(r.priority) : '—' },
          { label: 'Centre / bay', render: r => h('div', {},
              h('div', {}, r.service_centre_name ?? '—'),
              h('div', { class: 'small muted' }, r.bay_code ?? '')) },
          { label: 'Technician', key: 'technician_name' },
          { label: 'Work items', num: true, render: r => `${r.work_items_done}/${r.work_items}` },
          { label: 'Opened', render: r => ago(r.opened_utc) },
          { label: 'Status', render: r => pill(r.status) },
        ], rows, {
          empty: 'No job cards match.',
          onRow: r => { location.hash = `#/job-cards/${r.job_card_id}`; },
        })));
  }

  statusSel.addEventListener('change', load);
  centreSel.addEventListener('change', load);
  wrap.appendChild(h('div', { class: 'filters' },
    field('Status', statusSel), field('Service centre', centreSel),
    h('button', { class: 'btn btn-primary', onclick: load }, 'Apply')));
  wrap.appendChild(results);
  await load();
  return wrap;
}

/* ===================== Job card detail ===================== */

export async function jobCardView({ match }) {
  const id = Number(match[1]);
  const root = h('div', {});

  async function refresh() {
    const d = await api.get(`/api/v1/job-cards/${id}`);
    const jc = d.jobCard;
    setPageTitle(`Job Card ${jc.job_card_no}`,
      `${jc.event_type} · ${jc.registration_no || jc.vin} · ${jc.service_centre_name ?? ''}`);
    clear(root).appendChild(renderJobCard(d, refresh));
  }
  await refresh();
  return root;
}

function renderJobCard(d, refresh) {
  const jc = d.jobCard;
  const readOnly = ['Closed', 'Cancelled'].includes(jc.status);

  // ---- header ----
  const header = h('div', { class: 'card', style: 'margin-bottom:14px' },
    h('div', { class: 'card-body' },
      h('div', { style: 'display:flex;gap:16px;align-items:flex-start;flex-wrap:wrap' },
        h('div', { style: 'flex:1;min-width:250px' },
          h('div', { style: 'display:flex;gap:9px;align-items:center;flex-wrap:wrap' },
            h('h2', { style: 'margin:0;font-size:19px' }, jc.job_card_no),
            pill(jc.status),
            jc.priority ? pill(jc.priority) : null,
            jc.location_type !== 'Workshop' ? pill(jc.location_type, 'p-purple') : null),
          h('div', { class: 'small muted', style: 'margin-top:5px' },
            h('a', { href: `#/vehicles/${jc.vin}` }, jc.registration_no || jc.vin),
            ` · ${jc.variant_name} · ${jc.customer_name}`),
          h('div', { class: 'small muted' },
            `Service event ${jc.service_event_no} · opened ${fmtDateTime(jc.opened_utc)}`),
          jc.complaint_text
            ? h('div', { style: 'margin-top:8px;padding:9px 11px;background:var(--bg);border-radius:7px' },
                h('div', { class: 'small muted' }, 'Complaint / reason'),
                h('div', {}, jc.complaint_text))
            : null,
          jc.transferred_from_job_card_id
            ? h('div', { class: 'small', style: 'margin-top:6px;color:var(--purple)' },
                `Transferred from job card #${jc.transferred_from_job_card_id}: ${jc.transfer_reason ?? ''}`)
            : null),
        h('div', { style: 'display:flex;gap:20px;flex-wrap:wrap' },
          h('div', {}, h('div', { class: 'small muted' }, 'Technician'),
            h('div', { style: 'font-weight:620' }, jc.technician_name ?? 'Unassigned')),
          h('div', {}, h('div', { class: 'small muted' }, 'Bay'),
            h('div', { style: 'font-weight:620' }, jc.bay_code ?? '—')),
          h('div', {}, h('div', { class: 'small muted' }, 'Odometer at open'),
            h('div', { style: 'font-weight:620' }, fmtKm(jc.odometer_at_open))))),
      h('div', { style: 'display:flex;gap:8px;margin-top:14px;flex-wrap:wrap;border-top:1px solid var(--line-2);padding-top:13px' },
        ...transitionButtons(d, refresh),
        h('div', { class: 'spacer' }),
        !readOnly && can('jobcard.transition')
          ? h('button', { class: 'btn btn-sm', onclick: () => assignModal(d, refresh) }, 'Assign / reassign')
          : null,
        !readOnly && jc.location_type === 'Roadside'
          ? h('button', { class: 'btn btn-sm', onclick: () => transferModal(d, refresh) }, 'Transfer to workshop')
          : null,
        h('a', { class: 'btn btn-sm', href: `#/qc?job=${jc.job_card_id}` }, 'Release gate'))));

  // ---- tabs ----
  const TABS = [
    ['Work Items', () => workItemsTab(d, refresh)],
    ['Checklist', () => checklistTab(d, refresh)],
    ['Parts', () => partsTab(d, refresh)],
    ['Labour', () => labourTab(d)],
    ['Defects', () => defectsTab(d)],
    ['Diagnosis & Closure', () => closureTab(d, refresh)],
    ['History', () => historyTab(d)],
  ];
  const panel = h('div', { style: 'margin-top:14px' });
  const tabBar = h('div', { class: 'tabs' });
  const startTab = d.checklist ? 1 : 0;
  TABS.forEach(([label, fn], i) => {
    const btn = h('button', { class: i === startTab ? 'active' : '' }, label);
    btn.addEventListener('click', () => {
      tabBar.querySelectorAll('button').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      panel.replaceChildren(fn());
    });
    tabBar.appendChild(btn);
  });
  panel.appendChild(TABS[startTab][1]());

  return h('div', {}, header, h('div', { class: 'card' }, tabBar), panel);
}

function transitionButtons(d, refresh) {
  const jc = d.jobCard;
  if (!can('jobcard.transition')) return [];
  const allowed = d.allowedTransitions ?? [];
  const PRIMARY = ['Under Diagnosis', 'Repairing', 'Technician Complete', 'QC Pending'];
  const NEEDS_REASON = ['Cancelled', 'Reopened', 'On Hold', 'Transferred', 'Awaiting Parts',
    'Awaiting Customer Approval', 'Awaiting Warranty Decision', 'Awaiting Internal Authorization'];

  return allowed.filter(s => s !== 'Transferred' && s !== 'Split').map(status =>
    h('button', {
      class: `btn btn-sm ${PRIMARY.includes(status) ? 'btn-primary' : ''}`,
      onclick: async () => {
        if (NEEDS_REASON.includes(status)) return statusReasonModal(jc, status, refresh);
        try {
          await api.patch(`/api/v1/job-cards/${jc.job_card_id}/status`, { status });
          toast(`Job moved to ${status}.`, 'ok');
          refresh();
        } catch (e) { showApiError(e); }
      },
    }, `→ ${status}`));
}

function statusReasonModal(jc, status, refresh) {
  const input = h('textarea', { placeholder: 'Reason…' });
  modal({
    title: `Move job to “${status}”`,
    body: h('div', {},
      h('div', { class: 'banner banner-blue' }, h('div', { class: 'small' },
        status.startsWith('Awaiting')
          ? 'A structured clock pause is opened with this status and the vehicle availability reason is updated. Status alone never pauses a clock (BL-CLK-001).'
          : 'The reason is recorded in the job history and audit trail.')),
      field('Reason', input, { required: true })),
    actions: [
      { label: 'Cancel', onClick: () => true },
      { label: 'Confirm', class: 'btn-primary', onClick: async () => {
          if (!input.value.trim()) { toast('A reason is required.', 'err'); return false; }
          try {
            await api.patch(`/api/v1/job-cards/${jc.job_card_id}/status`,
              { status, reason: input.value.trim() });
            toast(`Job moved to ${status}.`, 'ok'); refresh(); return true;
          } catch (e) { showApiError(e); return false; }
        } },
    ],
  });
}

async function assignModal(d, refresh) {
  const jc = d.jobCard;
  const techs = await api.get('/api/v1/technicians' + qs({ serviceCentreId: jc.service_centre_id }));
  const techSel = select([{ value: '', label: 'Unassigned' },
    ...techs.map(t => ({ value: t.technician_id,
      label: `${t.name}${t.skills?.includes('HV_BATTERY') ? ' · HV authorised' : ''}` }))],
    jc.technician_id ?? '');
  const reason = h('textarea', { placeholder: 'Reason for assignment or reassignment…' });

  modal({
    title: 'Assign technician',
    body: h('div', {},
      h('div', { class: 'banner banner-blue' }, h('div', { class: 'small' },
        'High-voltage work can only be assigned to a technician with a valid, unexpired HV ' +
        'authorisation (BL-SVC-007). Previous assignments are preserved with reason and timestamp.')),
      field('Technician', techSel),
      field('Reason', reason, { required: true })),
    actions: [
      { label: 'Cancel', onClick: () => true },
      { label: 'Assign', class: 'btn-primary', onClick: async () => {
          if (!reason.value.trim()) { toast('A reason is required.', 'err'); return false; }
          try {
            await api.post(`/api/v1/job-cards/${jc.job_card_id}/assign`, {
              technicianId: techSel.value ? Number(techSel.value) : null,
              reason: reason.value.trim(),
            });
            toast('Assignment updated.', 'ok'); refresh(); return true;
          } catch (e) { showApiError(e); return false; }
        } },
    ],
  });
}

async function transferModal(d, refresh) {
  const ref = await reference();
  const centreSel = select(ref.serviceCentres.filter(c => c.centre_type !== 'Mobile')
    .map(c => ({ value: c.service_centre_id, label: c.name })), '');
  const reason = h('textarea', { placeholder: 'Why is the vehicle moving to a workshop?' });
  modal({
    title: 'Transfer to workshop',
    body: h('div', {},
      h('div', { class: 'banner banner-blue' }, h('div', { class: 'small' },
        'A new linked job card is created under the same service event. This job keeps its own ' +
        'parts, labour and history — nothing is overwritten (BL-JC-010).')),
      field('Destination service centre', centreSel, { required: true }),
      field('Reason', reason, { required: true })),
    actions: [
      { label: 'Cancel', onClick: () => true },
      { label: 'Transfer', class: 'btn-primary', onClick: async () => {
          if (!reason.value.trim()) { toast('A reason is required.', 'err'); return false; }
          try {
            const next = await api.post(`/api/v1/job-cards/${d.jobCard.job_card_id}/transfer`, {
              serviceCentreId: Number(centreSel.value), reason: reason.value.trim(),
            });
            toast(`Created ${next.job_card_no}.`, 'ok');
            location.hash = `#/job-cards/${next.job_card_id}`;
            return true;
          } catch (e) { showApiError(e); return false; }
        } },
    ],
  });
}

/* ---------------- tabs ---------------- */

function workItemsTab(d, refresh) {
  const jc = d.jobCard;
  const readOnly = ['Closed', 'Cancelled'].includes(jc.status);
  return cardOf('Work Items',
    table([
      { label: '#', num: true, key: 'line_no' },
      { label: 'Type', render: r => pill(r.work_item_type, 'p-grey') },
      { label: 'Description', key: 'description' },
      { label: 'SRT', render: r => r.srt_minutes ? `${r.srt_minutes} min` : '—' },
      { label: 'Started', render: r => fmtDateTime(r.started_utc) },
      { label: 'Completed', render: r => fmtDateTime(r.completed_utc) },
      { label: 'Status', render: r => pill(r.status) },
      { label: '', render: r => readOnly || r.status === 'Completed' ? '—'
          : h('button', { class: 'btn btn-sm', onclick: async () => {
              try {
                await api.patch(`/api/v1/work-items/${r.work_item_id}`, {
                  status: r.status === 'Not Started' ? 'In Progress' : 'Completed' });
                refresh();
              } catch (e) { showApiError(e); }
            } }, r.status === 'Not Started' ? 'Start' : 'Complete') },
    ], d.workItems, { empty: 'No work items on this job card.' }),
    readOnly ? null : h('button', { class: 'btn btn-sm', onclick: () => addWorkItemModal(jc, refresh) },
      '+ Add work item'));
}

function addWorkItemModal(jc, refresh) {
  const typeSel = select(['Repair', 'Diagnosis', 'Part Replacement', 'Inspection', 'Software', 'Other'], 'Repair');
  const desc = h('input', { type: 'text', placeholder: 'What needs doing?' });
  modal({
    title: 'Add work item',
    body: h('div', {}, field('Type', typeSel, { required: true }), field('Description', desc, { required: true })),
    actions: [
      { label: 'Cancel', onClick: () => true },
      { label: 'Add', class: 'btn-primary', onClick: async () => {
          if (!desc.value.trim()) { toast('A description is required.', 'err'); return false; }
          try {
            await api.post(`/api/v1/job-cards/${jc.job_card_id}/work-items`, {
              workItemType: typeSel.value, description: desc.value.trim() });
            toast('Work item added.', 'ok'); refresh(); return true;
          } catch (e) { showApiError(e); return false; }
        } },
    ],
  });
}

/** The checklist runner — the technician's main screen (FR-UX-002). */
function checklistTab(d, refresh) {
  const c = d.checklist;
  const jc = d.jobCard;
  if (!c) {
    return cardOf('Checklist', h('div', { class: 'empty' },
      'No PM checklist is attached to this job card. Checklists attach to PM work items ' +
      'and are frozen at the version effective when the job was created (CHK-004).'));
  }
  const readOnly = ['Closed', 'Cancelled'].includes(jc.status);

  const progressBar = h('div', { class: 'bar', style: 'flex:1' },
    h('span', { style: `width:${(c.progress.mandatoryAnswered / Math.max(1, c.progress.mandatoryTotal)) * 100}%` }));
  const progressText = h('div', { class: 'small muted' },
    `${c.progress.mandatoryAnswered} of ${c.progress.mandatoryTotal} mandatory items answered ` +
    `· ${c.progress.answered}/${c.progress.total} total`);

  const pending = new Map();   // itemId -> answer
  const saveBtn = h('button', { class: 'btn btn-primary', disabled: true }, 'Save responses');

  function markPending(itemId, answer) {
    pending.set(itemId, answer);
    saveBtn.disabled = false;
    saveBtn.textContent = `Save ${pending.size} response${pending.size === 1 ? '' : 's'}`;
  }

  saveBtn.addEventListener('click', async () => {
    saveBtn.disabled = true; saveBtn.textContent = 'Saving…';
    try {
      const res = await api.post(`/api/v1/job-cards/${jc.job_card_id}/checklist-results`,
        { answers: [...pending.values()] });
      const rejected = res.outcomes.filter(o => !o.accepted);
      const defects = res.outcomes.filter(o => o.defectNo);
      if (rejected.length) {
        toast(`${rejected.length} response(s) rejected: ${rejected[0].message}`, 'err');
      }
      if (defects.length) {
        toast(`${defects.length} defect(s) raised: ${defects.map(x => x.defectNo).join(', ')}`, '');
      }
      if (!rejected.length && !defects.length) toast('Responses saved.', 'ok');
      refresh();
    } catch (e) { showApiError(e); saveBtn.disabled = false; }
  });

  const sections = c.sections.map(sec => {
    const answered = sec.items.filter(i => i.answer).length;
    return h('div', { class: 'chk-section' },
      h('h4', {},
        h('span', {}, sec.name),
        h('span', { class: 'spacer', style: 'flex:1' }),
        h('span', { class: 'small muted' }, `${answered}/${sec.items.length}`)),
      sec.items.map(item => checklistItemRow(item, readOnly, markPending)));
  });

  return h('div', {},
    h('div', { class: 'card', style: 'margin-bottom:14px' },
      h('div', { class: 'card-body' },
        h('div', { style: 'display:flex;gap:12px;align-items:center;flex-wrap:wrap' },
          h('div', {},
            h('div', { style: 'font-weight:650' }, c.templateName),
            h('div', { class: 'small muted' },
              `${c.templateCode} · version ${c.versionNo} (frozen for this job)`)),
          h('div', { style: 'flex:1;min-width:160px' }, progressBar, progressText),
          readOnly ? pill('Read-only', 'p-grey') : saveBtn))),
    h('div', { class: 'card' }, sections));
}

function checklistItemRow(item, readOnly, markPending) {
  const a = item.answer;
  const row = h('div', { class: `chk-item ${a ? (a.responseType === 'Not OK' ? 'fail' : 'done') : ''}` });

  const outOfRange = a && a.numericValue != null &&
    ((item.minValue != null && Number(a.numericValue) < Number(item.minValue)) ||
     (item.maxValue != null && Number(a.numericValue) > Number(item.maxValue)));

  row.appendChild(h('div', { class: 'chk-desc' },
    h('div', {}, item.description,
      item.isMandatory ? h('span', { style: 'color:var(--red)' }, ' *') : null),
    h('div', { class: 'code' }, item.code,
      item.unit ? ` · ${item.minValue ?? '−'}–${item.maxValue ?? '−'} ${item.unit}` : '',
      item.blocksReleaseOnFail ? ' · blocks release on failure' : ''),
    a ? h('div', { class: 'small', style: outOfRange ? 'color:var(--red)' : 'color:var(--ink-3)' },
        `${a.responseType}${a.numericValue != null ? `: ${a.numericValue}${item.unit ?? ''}` : ''}` +
        `${outOfRange ? ' — outside limits' : ''}${a.textValue ? ` — ${a.textValue}` : ''}` +
        `${a.naReason ? ` — ${a.naReason}` : ''}`)
      : null,
    item.recommendedPart
      ? h('div', { class: 'small muted' },
          `Suggested part: ${item.recommendedPart.partNo} × ${item.recommendedPart.qty ?? 1}`)
      : null));

  if (readOnly) {
    row.appendChild(h('div', { class: 'chk-actions' }, a ? pill(a.responseType) : h('span', { class: 'muted' }, '—')));
    return row;
  }

  const actions = h('div', { class: 'chk-actions' });

  if (item.responseMode === 'Numeric') {
    const input = h('input', {
      type: 'number', step: '0.1', placeholder: item.unit ?? 'value',
      value: a?.numericValue ?? '',
    });
    input.addEventListener('change', () => {
      if (input.value === '') return;
      markPending(item.itemId, {
        itemId: item.itemId, responseType: 'Numeric', numericValue: Number(input.value),
      });
      const bad = (item.minValue != null && Number(input.value) < Number(item.minValue)) ||
                  (item.maxValue != null && Number(input.value) > Number(item.maxValue));
      input.style.borderColor = bad ? 'var(--red)' : 'var(--green)';
    });
    actions.appendChild(input);
    if (item.unit) actions.appendChild(h('span', { class: 'small muted' }, item.unit));
  }

  const seg = h('div', { class: 'seg' });
  const buttons = [
    ['OK', 'OK', 'on-ok'],
    ['Not OK', 'Not OK', 'on-fail'],
    ['Advisory', 'Advisory-Observation', 'on-adv'],
    ['N/A', 'Not Applicable', 'on-na'],
  ];
  for (const [label, value, cls] of buttons) {
    const b = h('button', { class: a?.responseType === value ? cls : '' }, label);
    b.addEventListener('click', () => {
      seg.querySelectorAll('button').forEach(x => x.className = '');
      b.className = cls;
      if (value === 'Not Applicable' && (item.isConditional || item.isMandatory)) {
        const reason = prompt('A reason is required when marking this item Not Applicable (BL-CHK-011):');
        if (!reason) { b.className = ''; return; }
        markPending(item.itemId, { itemId: item.itemId, responseType: value, naReason: reason });
        return;
      }
      if (value === 'Advisory-Observation' || value === 'Not OK') {
        const note = prompt(value === 'Not OK'
          ? 'Describe the failure (this creates a linked defect):'
          : 'Describe the observation (creates a deferred, non-blocking defect):');
        markPending(item.itemId, { itemId: item.itemId, responseType: value, textValue: note || null });
        return;
      }
      markPending(item.itemId, { itemId: item.itemId, responseType: value });
    });
    seg.appendChild(b);
  }
  actions.appendChild(seg);
  row.appendChild(actions);
  return row;
}

function partsTab(d, refresh) {
  const jc = d.jobCard;
  const readOnly = ['Closed', 'Cancelled'].includes(jc.status);
  return cardOf('Parts',
    table([
      { label: 'Part No.', render: r => h('span', { class: 'mono' }, r.part_no) },
      { label: 'Description', key: 'description' },
      { label: 'Qty', num: true, render: r => `${fmtNum(r.quantity)} ${r.uom}` },
      { label: 'Source', key: 'source' },
      { label: 'Old serial', render: r => r.old_serial_no
          ? h('span', { class: 'mono small' }, r.old_serial_no) : '—' },
      { label: 'New serial', render: r => r.new_serial_no
          ? h('span', { class: 'mono small' }, r.new_serial_no) : '—' },
      { label: 'Warranty', render: r => r.is_warranty ? pill('Yes', 'p-blue') : '—' },
      { label: 'Status', render: r => pill(r.status) },
    ], d.parts, { empty: 'No parts recorded on this job.' }),
    readOnly ? null : h('button', { class: 'btn btn-sm', onclick: () => addPartModal(d, refresh) },
      '+ Add part'));
}

async function addPartModal(d, refresh) {
  const jc = d.jobCard;
  const search = h('input', { type: 'text', placeholder: 'Search applicable parts…' });
  const partSel = select([{ value: '', label: 'Loading…' }], '');
  const qty = h('input', { type: 'number', value: 1, min: 0.01, step: 0.01 });
  const oldSerial = h('input', { type: 'text', placeholder: 'Removed component serial' });
  const newSerial = h('input', { type: 'text', placeholder: 'Fitted component serial' });
  const warranty = h('input', { type: 'checkbox' });
  const serialNote = h('div', { class: 'small muted' });
  let parts = [];

  async function loadParts() {
    const list = await api.get('/api/v1/parts/applicable' + qs({
      vin: jc.vin, search: search.value.trim() }));
    parts = list;
    partSel.replaceChildren(
      h('option', { value: '' }, list.length ? 'Select a part…' : 'No applicable parts found'),
      ...list.map(p => h('option', { value: p.part_id },
        `${p.part_no} — ${p.description}${p.is_serial_controlled ? ' (serialised)' : ''}`)));
    updateSerialNote();
  }
  function updateSerialNote() {
    const p = parts.find(x => String(x.part_id) === partSel.value);
    const need = p?.is_serial_controlled;
    serialNote.textContent = need
      ? 'This part is serial-controlled: the fitted serial number is mandatory (BL-SP-003). ' +
        'Recording the removed serial closes the old fitment and opens the new one (BL-SP-004).'
      : '';
    newSerial.parentElement.style.display = need ? '' : 'none';
    oldSerial.parentElement.style.display = need ? '' : 'none';
  }
  search.addEventListener('change', loadParts);
  partSel.addEventListener('change', updateSerialNote);
  await loadParts();

  modal({
    title: 'Add part',
    body: h('div', {},
      h('div', { class: 'banner banner-blue' }, h('div', { class: 'small' },
        'Only parts approved for this vehicle variant are listed. Applicability is validated again ' +
        'on the server before issue (BL-SP-001 / SPM-004).')),
      field('Search', search),
      field('Part', partSel, { required: true }),
      field('Quantity', qty, { required: true }),
      field('Removed serial number', oldSerial),
      field('Fitted serial number', newSerial),
      h('label', { style: 'display:flex;gap:8px;align-items:center;font-size:13px' },
        warranty, 'Warranty claim'),
      serialNote),
    actions: [
      { label: 'Cancel', onClick: () => true },
      { label: 'Add part', class: 'btn-primary', onClick: async () => {
          if (!partSel.value) { toast('Select a part.', 'err'); return false; }
          try {
            await api.post(`/api/v1/job-cards/${jc.job_card_id}/parts`, {
              partId: Number(partSel.value), quantity: Number(qty.value),
              oldSerialNo: oldSerial.value.trim() || null,
              newSerialNo: newSerial.value.trim() || null,
              isWarranty: warranty.checked,
            });
            toast('Part recorded.', 'ok'); refresh(); return true;
          } catch (e) { showApiError(e); return false; }
        } },
    ],
  });
}

function labourTab(d) {
  return cardOf('Labour',
    table([
      { label: 'Technician', key: 'technician_name' },
      { label: 'Activity', key: 'activity' },
      { label: 'Start', render: r => fmtDateTime(r.start_utc) },
      { label: 'End', render: r => fmtDateTime(r.end_utc) },
      { label: 'Hours', num: true, render: r => r.hours ? fmtNum(r.hours, 2) : '—' },
    ], d.labour, { empty: 'No labour recorded.' }));
}

function defectsTab(d) {
  return cardOf('Defects on this job',
    table([
      { label: 'Defect', render: r => h('span', { class: 'mono' }, r.defect_no) },
      { label: 'Severity', render: r => pill(r.severity) },
      { label: 'Subsystem', key: 'subsystem' },
      { label: 'Description', render: r => h('div', { style: 'max-width:440px' }, r.description) },
      { label: 'Blocks release', render: r => r.blocks_release ? pill('Yes', 'p-red') : 'No' },
      { label: 'Status', render: r => pill(r.status) },
    ], d.defects, { empty: 'No defects raised on this job.' }));
}

function closureTab(d, refresh) {
  const jc = d.jobCard;
  const isBreakdown = jc.event_type === 'Breakdown';
  const diag = h('textarea', { value: jc.final_diagnosis ?? '', placeholder: 'What was actually wrong?' });
  const rootSel = h('select', {});
  const actionSel = h('select', {});
  const dispSel = select([{ value: '', label: 'Normal closure' },
    { value: 'NoFaultFound', label: 'No Fault Found' },
    { value: 'UnableToReproduce', label: 'Unable to Reproduce' }], jc.closure_disposition ?? '');

  reference().then(ref => {
    const roots = ref.failureCodes.filter(f => f.code_type === 'RootCause');
    const actions = ref.failureCodes.filter(f => f.code_type === 'CorrectiveAction');
    rootSel.replaceChildren(h('option', { value: '' }, 'Select root cause…'),
      ...roots.map(r => h('option', { value: r.code, selected: r.code === jc.root_cause_code },
        `${r.code} — ${r.description}`)));
    actionSel.replaceChildren(h('option', { value: '' }, 'Select corrective action…'),
      ...actions.map(r => h('option', { value: r.code, selected: r.code === jc.corrective_action_code },
        `${r.code} — ${r.description}`)));
  });

  return cardOf('Diagnosis & Closure', h('div', { class: 'card-body' },
    isBreakdown
      ? h('div', { class: 'banner banner-amber' },
          h('span', {}, '⚠'),
          h('div', {},
            h('b', {}, 'Breakdown closure requires final diagnosis, root cause and corrective action. '),
            h('span', { class: 'small' },
              'Release is blocked until these are recorded, unless an authorised No-Fault-Found ' +
              'disposition is used with evidence (BL-BD-013).')))
      : null,
    field('Final diagnosis', diag),
    h('div', { class: 'grid g2' },
      field('Root cause', rootSel), field('Corrective action', actionSel)),
    field('Closure disposition', dispSel),
    h('button', { class: 'btn btn-primary', onclick: async () => {
        try {
          await api.patch(`/api/v1/service-events/${jc.service_event_id}/closure`, {
            finalDiagnosis: diag.value.trim() || null,
            rootCauseCode: rootSel.value || null,
            correctiveActionCode: actionSel.value || null,
            closureDisposition: dispSel.value || null,
          });
          toast('Closure details saved.', 'ok'); refresh();
        } catch (e) { showApiError(e); }
      } }, 'Save closure details')));
}

function historyTab(d) {
  return h('div', { class: 'grid g2' },
    cardOf('Status history', h('div', { class: 'card-body' },
      h('div', { class: 'timeline' },
        d.statusHistory.length
          ? d.statusHistory.map(s => h('div', { class: 'tl-item' },
              h('div', {}, s.from_status ? `${s.from_status} → ` : '', h('b', {}, s.to_status)),
              h('div', { class: 'small muted' },
                `${fmtDateTime(s.occurred_at)} · ${s.actor}`,
                s.rule_id ? ` · ${s.rule_id}` : ''),
              s.reason ? h('div', { class: 'small' }, s.reason) : null))
          : h('div', { class: 'muted' }, 'No status changes recorded.')))),
    cardOf('Clock pauses',
      table([
        { label: 'Reason', key: 'pause_reason' },
        { label: 'From', render: r => fmtDateTime(r.start_utc) },
        { label: 'To', render: r => r.end_utc ? fmtDateTime(r.end_utc) : pill('Running', 'p-blue') },
        { label: 'Accountable', key: 'accountable_party' },
        { label: 'Excluded from net', render: r => r.exclude_from_net ? '✓' : '—' },
      ], d.pauses, { empty: 'No clock pauses recorded.' }),
      h('span', { class: 'small muted' }, 'Explicit intervals — status alone never pauses a clock (BL-CLK-001)')));
}
