/**
 * Repeat-failure detection and First-Time-Fix classification.
 *
 * Implements Document 02 BL-BD-014..016, BL-KPI-FTF-001, BL-KPI-RBR-001
 * and Document 04 §33.4. Both KPIs are derived from persisted match rows
 * so the numerator and denominator can be reproduced and explained, rather
 * than recomputed by ad-hoc report logic.
 */

import { q, one, many, notify } from '../lib/db.ts';
import type { Db } from '../lib/db.ts';

/**
 * BL-BD-014/015. When a breakdown service event closes, look back for a
 * qualifying prior event on the same VIN inside the configured day/km window
 * matching on the configured keys. A match marks the *current* event as a
 * repeat and fails first-time-fix for the *prior* event.
 */
export async function evaluateRepeatFailure(
  db: Db, serviceEventId: number, actor = 'system',
): Promise<{ isRepeat: boolean; priorServiceEventId: number | null; ruleCode: string | null }> {
  const rule = await one<any>(db, `
    SELECT * FROM service.repeat_failure_rule
    WHERE status = 'Active' AND effective_from <= CURRENT_DATE
    ORDER BY effective_from DESC LIMIT 1`);
  if (!rule) return { isRepeat: false, priorServiceEventId: null, ruleCode: null };

  const current = await one<any>(db, `
    SELECT se.*, be.complaint_code, be.breakdown_id,
           v.current_odometer_km,
           (SELECT d.subsystem FROM service.defect d
             WHERE d.origin_job_card_id IN (
               SELECT job_card_id FROM service.job_card WHERE service_event_id = se.service_event_id)
             ORDER BY d.defect_id LIMIT 1) AS subsystem
    FROM service.service_event se
    LEFT JOIN service.breakdown_event be ON be.service_event_id = se.service_event_id
    JOIN master.vehicle v ON v.vehicle_id = se.vehicle_id
    WHERE se.service_event_id = $1`, [serviceEventId]);
  if (!current || current.event_type !== 'Breakdown') {
    return { isRepeat: false, priorServiceEventId: null, ruleCode: rule.code };
  }

  const matchKeys: string[] = rule.match_keys ?? [];
  const conditions: string[] = [];
  const params: unknown[] = [current.vehicle_id, serviceEventId, rule.day_window];

  if (matchKeys.includes('complaint_code') && current.complaint_code) {
    params.push(current.complaint_code);
    conditions.push(`be.complaint_code = $${params.length}`);
  }
  if (matchKeys.includes('subsystem') && current.subsystem) {
    params.push(current.subsystem);
    conditions.push(`EXISTS (SELECT 1 FROM service.job_card jc2
                              JOIN service.defect d2 ON d2.origin_job_card_id = jc2.job_card_id
                              WHERE jc2.service_event_id = se.service_event_id
                                AND d2.subsystem = $${params.length})`);
  }

  // With no usable match key there is nothing deterministic to compare.
  if (!conditions.length) {
    return { isRepeat: false, priorServiceEventId: null, ruleCode: rule.code };
  }

  const prior = await one<any>(db, `
    SELECT se.service_event_id, se.customer_visible_end, be.complaint_code
    FROM service.service_event se
    LEFT JOIN service.breakdown_event be ON be.service_event_id = se.service_event_id
    WHERE se.vehicle_id = $1
      AND se.service_event_id <> $2
      AND se.event_type = 'Breakdown'
      AND se.status = 'Closed'
      AND se.closure_disposition IS DISTINCT FROM 'NoFaultFound'
      AND se.customer_visible_end >= (now() - ($3 || ' days')::interval)
      AND (${conditions.join(' OR ')})
    ORDER BY se.customer_visible_end DESC
    LIMIT 1`, params);

  if (!prior) {
    // No qualifying repeat: the prior fix held, so this event passes FTF.
    await q(db, `
      UPDATE service.service_event SET ftf_result = 'Pass' WHERE service_event_id = $1`,
      [serviceEventId]);
    return { isRepeat: false, priorServiceEventId: null, ruleCode: rule.code };
  }

  const dayDelta = Math.floor(
    (Date.now() - new Date(prior.customer_visible_end).getTime()) / 86_400_000);

  await q(db, `
    INSERT INTO service.repeat_failure_match
      (current_service_event_id, prior_service_event_id, vehicle_id, rule_id, rule_version,
       matched_attributes, day_delta, match_result)
    VALUES ($1,$2,$3,$4,$5,$6,$7,true)`,
    [serviceEventId, prior.service_event_id, current.vehicle_id, rule.rule_id, rule.version_no,
     matchKeys.join(','), dayDelta]);

  await q(db, `
    UPDATE service.service_event
    SET is_repeat = true, prior_service_event_id = $1, ftf_result = 'Pass'
    WHERE service_event_id = $2`, [prior.service_event_id, serviceEventId]);

  // BL-KPI-FTF-001: the earlier event did not achieve a first-time fix.
  await q(db, `
    UPDATE service.service_event SET ftf_result = 'Fail' WHERE service_event_id = $1`,
    [prior.service_event_id]);

  await notify(db, {
    alertType: 'REPEAT_BREAKDOWN', severity: 'Warning',
    title: 'Repeat breakdown detected',
    body: `A qualifying repeat occurred ${dayDelta} day(s) after the previous event ` +
          `under rule ${rule.code}.`,
    entityType: 'ServiceEvent', entityId: serviceEventId, vehicleId: current.vehicle_id,
  });

  return { isRepeat: true, priorServiceEventId: prior.service_event_id, ruleCode: rule.code };
}

/**
 * First-Time Fix and Repeat Breakdown Rate over a period.
 * BL-KPI-FTF-001 / BL-KPI-RBR-001 — both use the same eligible denominator
 * so an event is never counted inconsistently between the two.
 */
export async function reliabilityKpis(db: Db, fromUtc: Date, toUtc: Date, serviceCentreId?: number | null) {
  const rows = await many<any>(db, `
    SELECT
      count(*) FILTER (WHERE se.ftf_eligible)::int                          AS eligible_closed,
      count(*) FILTER (WHERE se.ftf_eligible AND se.ftf_result = 'Pass')::int AS ftf_pass,
      count(*) FILTER (WHERE se.ftf_eligible AND se.is_repeat)::int         AS repeats
    FROM service.service_event se
    WHERE se.event_type = 'Breakdown'
      AND se.status = 'Closed'
      AND se.customer_visible_end BETWEEN $1 AND $2
      AND se.closure_disposition IS DISTINCT FROM 'NoFaultFound'
      AND ($3::bigint IS NULL OR EXISTS (
            SELECT 1 FROM service.job_card jc
            WHERE jc.service_event_id = se.service_event_id AND jc.service_centre_id = $3))`,
    [fromUtc, toUtc, serviceCentreId ?? null]);

  const r = rows[0] ?? { eligible_closed: 0, ftf_pass: 0, repeats: 0 };
  const denom = Number(r.eligible_closed) || 0;
  return {
    eligibleClosed: denom,
    firstTimeFixPct: denom ? Number(((Number(r.ftf_pass) / denom) * 100).toFixed(1)) : null,
    repeatBreakdownPct: denom ? Number(((Number(r.repeats) / denom) * 100).toFixed(1)) : null,
    repeatCount: Number(r.repeats),
  };
}

/**
 * Mean time to restore (BL-KPI: Time to Restore / MTTR).
 * Start is the actual stoppage timestamp where telematics established one,
 * otherwise the reported time (BL-TS-002). Accident events are excluded from
 * product reliability MTTR by default.
 */
export async function mttr(db: Db, fromUtc: Date, toUtc: Date) {
  const r = await one<any>(db, `
    SELECT
      avg(EXTRACT(EPOCH FROM (be.restored_operable_utc
            - COALESCE(be.stopped_actual_utc, be.reported_utc))))/3600.0 AS gross_hours,
      count(*)::int AS n
    FROM service.breakdown_event be
    JOIN service.service_event se ON se.service_event_id = be.service_event_id
    WHERE be.restored_operable_utc IS NOT NULL
      AND be.restored_operable_utc BETWEEN $1 AND $2
      AND se.event_type = 'Breakdown'`, [fromUtc, toUtc]);

  return {
    sampleSize: Number(r?.n ?? 0),
    mttrHours: r?.gross_hours != null ? Number(Number(r.gross_hours).toFixed(1)) : null,
  };
}
