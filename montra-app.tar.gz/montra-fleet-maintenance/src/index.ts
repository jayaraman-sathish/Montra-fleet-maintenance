/**
 * Montra Fleet Maintenance, Breakdown & Uptime Management System
 * Application entry point.
 *
 * Serves the REST API defined in Document 04 §25 and the single-page web
 * client from the same origin, so the whole system deploys as one service.
 */

import * as http from 'node:http';
import * as path from 'node:path';
import * as fs from 'node:fs';
import { fileURLToPath } from 'node:url';

import { Router, HttpError, sendJson, readBody, serveStatic, newCorrelationId } from './lib/http.ts';
import type { Ctx } from './lib/http.ts';
import { pool } from './lib/db.ts';
import { PgError } from './lib/pgclient.ts';

import { authRoutes } from './routes/auth.ts';
import { vehicleRoutes } from './routes/vehicles.ts';
import { pmRoutes } from './routes/pm.ts';
import { serviceRoutes } from './routes/service.ts';
import { qcRoutes } from './routes/qc.ts';
import { dashboardRoutes, integrationRoutes } from './routes/dashboard.ts';
import { startWorkers } from './workers.ts';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const WEB_ROOT = path.resolve(__dirname, '../web');
const PORT = Number(process.env.PORT ?? 3000);

const routers: Router[] = [
  authRoutes, vehicleRoutes, pmRoutes, serviceRoutes, qcRoutes,
  dashboardRoutes, integrationRoutes,
];

const server = http.createServer(async (req, res) => {
  const correlationId = newCorrelationId();
  res.setHeader('X-Correlation-Id', correlationId);
  // Baseline security headers (Doc 03 §11).
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'same-origin');

  const url = new URL(req.url ?? '/', `http://${req.headers.host ?? 'localhost'}`);
  const pathname = url.pathname;

  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': process.env.CORS_ORIGIN ?? '*',
      'Access-Control-Allow-Methods': 'GET,POST,PATCH,PUT,DELETE,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Api-Key',
    });
    return res.end();
  }

  if (pathname === '/health' || pathname === '/api/health') {
    try {
      await pool.query('SELECT 1');
      return sendJson(res, 200, { status: 'ok', database: 'connected', time: new Date().toISOString() });
    } catch (e: any) {
      return sendJson(res, 503, { status: 'degraded', database: 'unavailable', error: e.message });
    }
  }

  if (pathname.startsWith('/api/')) {
    const ctx: Ctx = {
      req, res, params: {}, query: url.searchParams, body: undefined, correlationId,
    };
    try {
      if (['POST', 'PATCH', 'PUT'].includes(req.method ?? '')) ctx.body = await readBody(req);

      for (const router of routers) {
        if (await router.handle(ctx, pathname)) return;
      }
      return sendJson(res, 404, {
        error: { code: 'NOT_FOUND', message: `No route matches ${req.method} ${pathname}.`, correlationId },
      });
    } catch (err: any) {
      return handleError(err, res, correlationId, `${req.method} ${pathname}`);
    }
  }

  // Static SPA
  if (fs.existsSync(WEB_ROOT) && serveStatic(WEB_ROOT, pathname, res)) return;
  res.writeHead(404, { 'Content-Type': 'text/plain' });
  res.end('Not found');
});

function handleError(err: any, res: http.ServerResponse, correlationId: string, where: string) {
  if (res.writableEnded) return;

  if (err instanceof HttpError) {
    return sendJson(res, err.status, {
      error: { code: err.code, message: err.message, details: err.details, correlationId },
    });
  }

  if (err instanceof PgError) {
    // Translate the constraint violations users can actually cause.
    if (err.code === '23505') {
      const friendly = err.constraint?.includes('vin')
        ? 'A vehicle with that VIN already exists. VIN uniquely identifies each vehicle (BR-01 / BL-VEH-001).'
        : err.constraint?.includes('ux_ledger_open_per_vehicle')
        ? 'This vehicle already has an open availability interval. Close it before opening another (UPM-001).'
        : 'That record already exists.';
      return sendJson(res, 409, {
        error: { code: 'DUPLICATE', message: friendly, constraint: err.constraint, correlationId },
      });
    }
    if (err.code === '23503') {
      return sendJson(res, 400, {
        error: { code: 'INVALID_REFERENCE',
                 message: 'A referenced record does not exist.', detail: err.detail, correlationId },
      });
    }
    if (err.code === '23514') {
      return sendJson(res, 400, {
        error: { code: 'CONSTRAINT_VIOLATION',
                 message: `That value is not permitted by the "${err.constraint}" rule.`, correlationId },
      });
    }
    console.error(`[${correlationId}] ${where} PgError ${err.code}: ${err.message}`);
    return sendJson(res, 500, {
      error: { code: 'DATABASE_ERROR', message: 'A database error occurred.', correlationId },
    });
  }

  console.error(`[${correlationId}] ${where} failed:`, err);
  return sendJson(res, 500, {
    error: { code: 'INTERNAL_ERROR', message: 'An unexpected error occurred.', correlationId },
  });
}

process.on('unhandledRejection', (r) => console.error('Unhandled rejection:', r));
process.on('SIGTERM', async () => {
  console.log('SIGTERM received — shutting down.');
  server.close();
  await pool.end();
  process.exit(0);
});

async function bootstrap() {
  if (process.env.MIGRATE_ON_START === 'true') {
    try {
      const { migrateIfNeeded } = await import('./scripts/migrate.ts');
      await migrateIfNeeded();
    } catch (e) {
      console.error('[migrate] startup migration failed:', e);
      // The server still starts so /health can report the problem.
    }
  }

  server.listen(PORT, () => {
    const routeCount = routers.reduce((n, r) => n + r.allRoutes.length, 0);
    console.log(`Montra Fleet Maintenance listening on port ${PORT}`);
    console.log(`  ${routeCount} API routes registered`);
    console.log(`  web client: ${fs.existsSync(WEB_ROOT) ? WEB_ROOT : 'not found'}`);
    if (process.env.DISABLE_WORKERS !== 'true') startWorkers();
  });
}

bootstrap();
