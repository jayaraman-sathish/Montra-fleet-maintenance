/**
 * Authentication, authorisation and row-level data scope.
 *
 * Implements Document 01 FR-ORG-002/003 and FR-AUTH-001, and Document 03
 * §11: authorisation is always role + data scope + action, enforced
 * server-side. UI visibility is never the control.
 *
 * Passwords use scrypt (node:crypto) and sessions use HMAC-SHA256 signed
 * tokens, because no external crypto library is available in this build
 * environment.
 */

import * as crypto from 'node:crypto';
import { one, many } from './db.ts';
import type { Db } from './db.ts';
import { pool } from './db.ts';
import { unauthorized, forbidden } from './http.ts';
import type { AuthUser, Ctx } from './http.ts';

const SECRET = process.env.AUTH_SECRET
  ?? (process.env.NODE_ENV === 'production'
      ? (() => { throw new Error('AUTH_SECRET must be set in production'); })()
      : 'montra-development-secret-not-for-production');

const TOKEN_TTL_SECONDS = Number(process.env.AUTH_TTL_SECONDS ?? 60 * 60 * 12);

// ---------------------------------------------------------------------
// Password hashing — scrypt
// ---------------------------------------------------------------------

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16);
  const key = crypto.scryptSync(password, salt, 32, { N: 16384, r: 8, p: 1 });
  return `scrypt$16384$8$1$${salt.toString('base64')}$${key.toString('base64')}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [scheme, N, r, p, saltB64, keyB64] = stored.split('$');
    if (scheme !== 'scrypt') return false;
    const salt = Buffer.from(saltB64, 'base64');
    const expected = Buffer.from(keyB64, 'base64');
    const actual = crypto.scryptSync(password, salt, expected.length,
      { N: Number(N), r: Number(r), p: Number(p) });
    return crypto.timingSafeEqual(expected, actual);
  } catch {
    return false;
  }
}

// ---------------------------------------------------------------------
// Tokens — compact HMAC-signed JSON
// ---------------------------------------------------------------------

function b64url(b: Buffer): string {
  return b.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
function unb64url(s: string): Buffer {
  return Buffer.from(s.replace(/-/g, '+').replace(/_/g, '/'), 'base64');
}

export function issueToken(payload: { userId: number; username: string }): string {
  const header = b64url(Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })));
  const claims = b64url(Buffer.from(JSON.stringify({
    ...payload,
    iat: Math.floor(Date.now() / 1000),
    exp: Math.floor(Date.now() / 1000) + TOKEN_TTL_SECONDS,
  })));
  const sig = b64url(crypto.createHmac('sha256', SECRET).update(`${header}.${claims}`).digest());
  return `${header}.${claims}.${sig}`;
}

export function verifyToken(token: string): { userId: number; username: string } | null {
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [header, claims, sig] = parts;
  const expected = b64url(crypto.createHmac('sha256', SECRET).update(`${header}.${claims}`).digest());
  const a = Buffer.from(sig), b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const payload = JSON.parse(unb64url(claims).toString('utf8'));
    if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) return null;
    return { userId: payload.userId, username: payload.username };
  } catch { return null; }
}

// ---------------------------------------------------------------------
// Loading the authenticated principal with its scopes
// ---------------------------------------------------------------------

export async function loadUser(db: Db, userId: number): Promise<AuthUser | null> {
  const u = await one<any>(db, `
    SELECT user_id, username, display_name, status
    FROM security.application_user WHERE user_id = $1`, [userId]);
  if (!u || u.status !== 'Active') return null;

  const scopeRows = await many<any>(db, `
    SELECT urs.scope_type, urs.scope_node_id, r.code AS role_code
    FROM security.user_role_scope urs
    JOIN security.role r ON r.role_id = urs.role_id
    WHERE urs.user_id = $1
      AND urs.effective_from <= CURRENT_DATE
      AND (urs.effective_to IS NULL OR urs.effective_to >= CURRENT_DATE)`, [userId]);

  const roles = [...new Set(scopeRows.map(r => r.role_code))];

  const permRows = await many<any>(db, `
    SELECT DISTINCT p.action_code
    FROM security.user_role_scope urs
    JOIN security.role_permission rp ON rp.role_id = urs.role_id
    JOIN security.permission p ON p.permission_id = rp.permission_id
    WHERE urs.user_id = $1`, [userId]);

  const isGlobal = scopeRows.some(r => r.scope_type === 'Global');

  return {
    userId: u.user_id,
    username: u.username,
    displayName: u.display_name,
    roles,
    permissions: new Set(permRows.map(r => r.action_code)),
    scopes: scopeRows.map(r => ({ scopeType: r.scope_type, scopeNodeId: r.scope_node_id })),
    organisationIds: scopeRows.filter(r => r.scope_type === 'Organisation' && r.scope_node_id)
                              .map(r => Number(r.scope_node_id)),
    serviceCentreIds: scopeRows.filter(r => r.scope_type === 'ServiceCentre' && r.scope_node_id)
                               .map(r => Number(r.scope_node_id)),
    isGlobal,
  };
}

/** Middleware: populate ctx.user from the Authorization header or cookie. */
export async function authenticate(ctx: Ctx): Promise<void> {
  const header = ctx.req.headers.authorization;
  let token: string | undefined;
  if (header?.startsWith('Bearer ')) token = header.slice(7);
  else {
    const cookie = ctx.req.headers.cookie ?? '';
    const m = cookie.match(/(?:^|;\s*)montra_session=([^;]+)/);
    if (m) token = decodeURIComponent(m[1]);
  }
  if (!token) throw unauthorized();

  const claims = verifyToken(token);
  if (!claims) throw unauthorized('Your session has expired. Please sign in again.');

  const user = await loadUser(pool, claims.userId);
  if (!user) throw unauthorized('This account is no longer active.');
  ctx.user = user;
}

/** Middleware factory: require one of the listed roles. */
export function requireRole(...roles: string[]) {
  return async (ctx: Ctx) => {
    if (!ctx.user) throw unauthorized();
    if (ctx.user.isGlobal && ctx.user.roles.includes('MASTER_DATA_ADMIN')) return;
    if (!roles.some(r => ctx.user!.roles.includes(r))) {
      throw forbidden(
        `This action requires the ${roles.join(' or ')} role. ` +
        `You are signed in as ${ctx.user.roles.join(', ') || 'a user with no assigned role'}.`,
        { requiredRoles: roles, yourRoles: ctx.user.roles });
    }
  };
}

/**
 * Routine operational permission check (role → permission grant).
 *
 * This is the everyday control: may this role open a job card, book an
 * appointment, issue a part. Privileged and exceptional actions use
 * assertAuthorised below, which additionally resolves the FR-AUTH-001
 * authorisation matrix with its maker-checker and segregation rules.
 */
export function assertPermission(user: AuthUser, actionCode: string): void {
  if (user.permissions.has(actionCode)) return;
  throw forbidden(
    `Your role does not include "${actionCode}". ` +
    `You are signed in as ${user.roles.join(', ') || 'a user with no assigned role'}.`,
    { actionCode, yourRoles: user.roles });
}

/**
 * FR-AUTH-001. Check the authorisation matrix for a privileged action.
 * Every action described as "authorised" in the requirements resolves to a
 * role/action row here — there is no generic unrestricted override
 * (BL-SEC-008).
 *
 * Use this only for privileged or exceptional actions. Routine operational
 * actions use assertPermission: an action absent from the matrix is treated
 * as performable by nobody, which is correct for overrides but would
 * otherwise block normal work.
 */
export async function assertAuthorised(db: Db, user: AuthUser, actionCode: string): Promise<void> {
  const rows = await many<any>(db, `
    SELECT * FROM security.authorization_policy
    WHERE action_code = $1 AND effect = 'Allow'
      AND effective_from <= CURRENT_DATE
      AND (effective_to IS NULL OR effective_to >= CURRENT_DATE)`, [actionCode]);

  if (!rows.length) {
    throw forbidden(
      `No authorisation policy is configured for "${actionCode}", so it cannot be performed ` +
      `by anyone (BL-SEC-008).`, { actionCode });
  }
  const allowed = rows.map(r => r.role_code);
  if (!user.roles.some(r => allowed.includes(r))) {
    throw forbidden(
      `"${actionCode}" is restricted to: ${allowed.join(', ')}. ` +
      `Your roles: ${user.roles.join(', ') || 'none'}.`,
      { actionCode, allowedRoles: allowed, yourRoles: user.roles });
  }
}

/**
 * FR-ORG-002. Build a SQL fragment restricting a vehicle query to the user's
 * organisation and service-network scope. Applied server-side to every list,
 * dashboard, report and API response.
 *
 * Returns a clause referencing the supplied vehicle table alias, plus the
 * parameters to append to the caller's parameter array.
 */
export function vehicleScopeClause(
  user: AuthUser, alias = 'v', startIndex = 1,
): { clause: string; params: unknown[] } {
  if (user.isGlobal) return { clause: 'TRUE', params: [] };

  const clauses: string[] = [];
  const params: unknown[] = [];
  let i = startIndex;

  if (user.organisationIds.length) {
    params.push(user.organisationIds);
    clauses.push(`${alias}.organisation_id = ANY($${i++}::bigint[])`);
  }
  if (user.serviceCentreIds.length) {
    params.push(user.serviceCentreIds);
    clauses.push(`${alias}.assigned_service_centre_id = ANY($${i++}::bigint[])`);
  }

  // A user with no scope sees nothing — never everything.
  if (!clauses.length) return { clause: 'FALSE', params: [] };
  return { clause: '(' + clauses.join(' OR ') + ')', params };
}

/**
 * FR-ORG-003 field visibility. Mask or drop sensitive fields according to the
 * audience the user's role belongs to.
 */
export function audienceFor(user: AuthUser): 'OEM' | 'Dealer' | 'Customer' {
  if (user.roles.includes('FLEET_CUSTOMER')) return 'Customer';
  if (user.roles.some(r => ['SC_MANAGER', 'TECHNICIAN', 'STORES', 'QC_SUPERVISOR'].includes(r))) {
    return 'Dealer';
  }
  return 'OEM';
}

export async function applyFieldVisibility<T extends Record<string, any>>(
  db: Db, user: AuthUser, rows: T[], fieldGroups: Record<string, string[]>,
): Promise<T[]> {
  const audience = audienceFor(user);
  const policies = await many<any>(db, `
    SELECT field_group, treatment FROM security.field_visibility_policy WHERE audience = $1`,
    [audience]);
  if (!policies.length) return rows;

  const byGroup = Object.fromEntries(policies.map(p => [p.field_group, p.treatment]));
  return rows.map(row => {
    const out: Record<string, any> = { ...row };
    for (const [group, fields] of Object.entries(fieldGroups)) {
      const treatment = byGroup[group];
      if (treatment === 'Hide') for (const f of fields) delete out[f];
      else if (treatment === 'Mask') for (const f of fields) if (f in out) out[f] = null;
    }
    return out as T;
  });
}
