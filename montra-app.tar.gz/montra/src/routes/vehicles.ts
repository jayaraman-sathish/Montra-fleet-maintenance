/**
 * Vehicle master and Vehicle 360 endpoints.
 * Doc 01 §12 (Vehicle 360), FR-VEH-001..005, FR-AVL-*, Doc 04 §25.
 * Every query is constrained by the caller's row-level scope (FR-ORG-002).
 */

import { Router, notFound, badRequest } from '../lib/http.ts';
import type { Ctx } from '../lib/http.ts';
import { pool, one, many, q } from '../lib/db.ts';
import { authenticate, vehicleScopeClause, assertAuthorised, applyFieldVisibility } from '../lib/auth.ts';
import { availabilitySummary, currentState, transition, correctInterval } from '../domain/availability.ts';
import { correctUsage } from '../domain/usage.ts';
import { evaluateDueState } from '../domain/pm.ts';

export const vehicleRoutes = new Router();
vehicleRoutes.use(authenticate);

/** GET /api/v1/vehicles — scoped, filtered, paginated list. */
vehicleRoutes.get('/api/v1/vehicles', async (ctx: Ctx) => {
  const scope = vehicleScopeClause(ctx.user!, 'v', 1);
  const params: unknown[] = [...scope.params];
  const where: string[] = [scope.clause];

  const search = ctx.query.get('search');
  if (search) {
    params.push(`%${search}%`);
    where.push(`(v.vin ILIKE $${params.length} OR v.registration_no ILIKE $${params.length}
                 OR v.fleet_asset_no ILIKE $${params.length})`);
  }
  const status = ctx.query.get('availabilityState');
  if (status) { params.push(status); where.push(`v.current_availability_state = $${params.length}`); }

  const centre = ctx.query.get('serviceCentreId');
  if (centre) { params.push(Number(centre)); where.push(`v.assigned_service_centre_id = $${params.length}`); }

  const pmStatus = ctx.query.get('pmStatus');
  if (pmStatus) {
    params.push(pmStatus);
    where.push(`EXISTS (SELECT 1 FROM pm.pm_obligation o
                        WHERE o.vehicle_id = v.vehicle_id AND o.status = $${params.length})`);
  }

  const limit = Math.min(Number(ctx.query.get('limit') ?? 50), 200);
  const offset = Number(ctx.query.get('offset') ?? 0);
  params.push(limit, offset);

  const rows = await many<any>(pool, `
    SELECT v.vehicle_id, v.vin, v.registration_no, v.current_odometer_km, v.current_operating_hours,
           v.usage_updated_at, v.usage_is_stale, v.current_availability_state, v.lifecycle_status,
           vv.code AS variant_code, vv.name AS variant_name, vv.image_url,
           vm.name AS model_name, pf.name AS family_name, cat.code AS category_code,
           o.name AS customer_name, sc.name AS service_centre_name, sc.service_centre_id,
           (SELECT o2.status FROM pm.pm_obligation o2
             WHERE o2.vehicle_id = v.vehicle_id
               AND o2.status IN ('Upcoming','Due Soon','Due','Overdue','Scheduled','Under Service')
             ORDER BY CASE o2.status WHEN 'Overdue' THEN 4 WHEN 'Due' THEN 3
                                     WHEN 'Due Soon' THEN 2 ELSE 1 END DESC LIMIT 1) AS pm_status,
           (SELECT count(*) FROM service.defect d
             WHERE d.vehicle_id = v.vehicle_id AND d.status IN ('Open','Under Action'))::int AS open_defects
    FROM master.vehicle v
    JOIN master.vehicle_variant vv ON vv.variant_id = v.variant_id
    JOIN master.vehicle_model vm ON vm.model_id = vv.model_id
    JOIN master.product_family pf ON pf.family_id = vm.family_id
    JOIN master.vehicle_category cat ON cat.category_id = pf.category_id
    JOIN org.organisation o ON o.organisation_id = v.organisation_id
    LEFT JOIN master.service_centre sc ON sc.service_centre_id = v.assigned_service_centre_id
    WHERE ${where.join(' AND ')}
    ORDER BY v.vin
    LIMIT $${params.length - 1} OFFSET $${params.length}`, params);

  const countParams = params.slice(0, params.length - 2);
  const total = await one<any>(pool, `
    SELECT count(*)::int AS n FROM master.vehicle v WHERE ${where.join(' AND ')}`, countParams);

  return { total: Number(total?.n ?? 0), limit, offset, rows };
});

/** GET /api/v1/vehicles/:vin/360 — the consolidated maintenance view. */
vehicleRoutes.get('/api/v1/vehicles/:vin/360', async (ctx: Ctx) => {
  const scope = vehicleScopeClause(ctx.user!, 'v', 2);
  const vehicle = await one<any>(pool, `
    SELECT v.*, vv.code AS variant_code, vv.name AS variant_name, vv.image_url,
           vv.battery_capacity_kwh, vv.battery_configuration, vv.motor_type, vv.transmission,
           vv.axle_configuration, vv.confirmation_status AS variant_confirmation,
           vm.name AS model_name, vm.code AS model_code, pf.name AS family_name,
           cat.code AS category_code, cat.name AS category_name,
           o.name AS customer_name, o.organisation_id,
           dep.name AS depot_name,
           sc.name AS service_centre_name, sc.service_centre_id
    FROM master.vehicle v
    JOIN master.vehicle_variant vv ON vv.variant_id = v.variant_id
    JOIN master.vehicle_model vm ON vm.model_id = vv.model_id
    JOIN master.product_family pf ON pf.family_id = vm.family_id
    JOIN master.vehicle_category cat ON cat.category_id = pf.category_id
    JOIN org.organisation o ON o.organisation_id = v.organisation_id
    LEFT JOIN org.organisation_node dep ON dep.node_id = v.depot_node_id
    LEFT JOIN master.service_centre sc ON sc.service_centre_id = v.assigned_service_centre_id
    WHERE v.vin = $1 AND ${scope.clause}`, [ctx.params.vin, ...scope.params]);

  if (!vehicle) throw notFound(`Vehicle ${ctx.params.vin} was not found, or is outside your access scope.`);
  const vid = vehicle.vehicle_id;

  const [obligations, components, defects, history, documents, ledger, openEvents,
         campaigns, firmware, entitlements, telematics, warrantyClaims] = await Promise.all([
    many<any>(pool, `
      SELECT o.*, pv.pm_level AS plan_level, p.code AS plan_code
      FROM pm.pm_obligation o
      JOIN pm.pm_plan_version pv ON pv.plan_version_id = o.plan_version_id
      JOIN pm.pm_plan p ON p.plan_id = pv.plan_id
      WHERE o.vehicle_id = $1 ORDER BY o.cycle_no DESC LIMIT 30`, [vid]),
    many<any>(pool, `
      SELECT c.*, ct.display_name, ct.category AS component_category, ct.is_hv
      FROM master.vehicle_component c
      LEFT JOIN master.component_type ct ON ct.component_type = c.component_type
      WHERE c.vehicle_id = $1
      ORDER BY c.is_active DESC, COALESCE(ct.display_order, 100), c.position_label NULLS FIRST, c.installed_on DESC`, [vid]),
    many<any>(pool, `
      SELECT * FROM service.defect WHERE vehicle_id = $1
      ORDER BY CASE status WHEN 'Open' THEN 1 WHEN 'Under Action' THEN 2
                           WHEN 'Deferred' THEN 3 ELSE 4 END, opened_date DESC LIMIT 50`, [vid]),
    many<any>(pool, `
      SELECT se.service_event_id, se.service_event_no, se.event_type, se.status,
             se.customer_visible_start, se.customer_visible_end, se.priority,
             se.is_repeat, se.ftf_result,
             jc.job_card_id, jc.job_card_no, jc.status AS job_status, sc.name AS centre_name
      FROM service.service_event se
      LEFT JOIN service.job_card jc ON jc.service_event_id = se.service_event_id
      LEFT JOIN master.service_centre sc ON sc.service_centre_id = jc.service_centre_id
      WHERE se.vehicle_id = $1
      ORDER BY se.customer_visible_start DESC LIMIT 40`, [vid]),
    many<any>(pool, `SELECT * FROM campaign.vehicle_document WHERE vehicle_id = $1 ORDER BY expiry_date`, [vid]),
    many<any>(pool, `
      SELECT l.*, r.is_down, r.planned_class
      FROM uptime.vehicle_status_ledger l
      LEFT JOIN uptime.vehicle_status_reason r ON r.reason_code = l.reason_code
      WHERE l.vehicle_id = $1 AND l.availability_eligible = true
      ORDER BY l.start_utc DESC LIMIT 25`, [vid]),
    many<any>(pool, `
      SELECT se.service_event_no, se.event_type, se.status, se.priority
      FROM service.service_event se
      WHERE se.vehicle_id = $1 AND se.status NOT IN ('Closed','Cancelled')`, [vid]),
    many<any>(pool, `
      SELECT c.code, c.name, c.classification, c.mandatory_by_date, cv.status
      FROM campaign.campaign_vehicle cv JOIN campaign.campaign c ON c.campaign_id = cv.campaign_id
      WHERE cv.vehicle_id = $1`, [vid]),
    many<any>(pool, `SELECT * FROM campaign.firmware_baseline WHERE vehicle_id = $1`, [vid]),
    many<any>(pool, `
      SELECT e.*, c.contract_no, c.contract_type, c.end_date, c.start_date,
             c.free_services_total, c.labour_cover_pct, c.parts_cover_pct
      FROM commercial.entitlement e JOIN commercial.contract c ON c.contract_id = e.contract_id
      WHERE e.vehicle_id = $1 AND e.status = 'Active'`, [vid]),
    // Telematics: newest first, seven days of history for the trend.
    many<any>(pool, `
      SELECT odometer_km, operating_hours, source_timestamp_utc, vehicle_status,
             latitude, longitude, soc_pct, soh_pct, dtc_summary, accepted, rejection_reason
      FROM integration.telematics_transaction
      WHERE vehicle_id = $1 AND source_timestamp_utc > now() - INTERVAL '8 days'
      ORDER BY source_timestamp_utc DESC LIMIT 60`, [vid]),
    many<any>(pool, `
      SELECT we.evaluation_id, we.claim_no, we.result, we.reason, we.approver, we.decided_at,
             we.created_at, jc.job_card_no, jc.job_card_id, se.event_type,
             wr.name AS rule_name
      FROM commercial.warranty_evaluation we
      JOIN service.job_card jc ON jc.job_card_id = we.job_card_id
      JOIN service.service_event se ON se.service_event_id = jc.service_event_id
      LEFT JOIN commercial.warranty_rule wr ON wr.warranty_rule_id = we.warranty_rule_id
      WHERE se.vehicle_id = $1 AND we.claim_no IS NOT NULL
      ORDER BY we.created_at DESC LIMIT 50`, [vid]),
  ]);

  // Re-evaluate the live due position for display without persisting.
  const openObligations = obligations
    .filter(o => ['Upcoming', 'Due Soon', 'Due', 'Overdue', 'Scheduled', 'Under Service'].includes(o.status))
    .map(o => ({
      ...o,
      liveEvaluation: evaluateDueState({
        targetKm: o.target_km, targetDate: o.target_date, targetHours: o.target_hours,
        dueSoonKm: o.due_soon_km, dueSoonDays: o.due_soon_days, dueSoonHours: o.due_soon_hours,
        toleranceKm: o.tolerance_km, toleranceDays: o.tolerance_days, toleranceHours: o.tolerance_hours,
        currentKm: Number(vehicle.current_odometer_km ?? 0),
        currentHours: Number(vehicle.current_operating_hours ?? 0),
        isEstimated: vehicle.usage_is_stale,
      }),
    }));

  const now = new Date();
  const thirtyDaysAgo = new Date(now.getTime() - 30 * 86_400_000);
  const availability = await availabilitySummary(pool, vid, thirtyDaysAgo, now);
  const current = await currentState(pool, vid);

  // FR-ORG-003 field visibility by audience.
  const [visibleDefects] = await Promise.all([
    applyFieldVisibility(pool, ctx.user!, defects, { RootCause: ['closure_action'] }),
  ]);

  // ------------------------------------------------------------------
  // Active alerts. Derived on read from the same rows the tabs show, so
  // the panel can never disagree with the detail behind it.
  // ------------------------------------------------------------------
  const alerts: Array<{ level: string; text: string; at: string | null; href?: string }> = [];

  /** Dates in alert text read as prose, not as ISO stamps. */
  const onDate = (v: any) => v
    ? new Date(v).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })
    : '';

  for (const o of openObligations) {
    const ev = (o as any).liveEvaluation;
    if (!ev) continue;
    if (ev.state === 'Overdue') {
      const t = ev.triggers.find((x: any) => x.status === 'Overdue') ?? ev.triggers[0];
      alerts.push({
        level: 'critical',
        text: `${o.pm_level} overdue — ${Math.abs(Math.round(t?.remaining ?? 0))} ${t?.unit ?? ''} past target`,
        at: vehicle.usage_updated_at,
      });
    } else if (ev.state === 'Due' || ev.state === 'Due Soon') {
      const t = ev.triggers.find((x: any) => x.status === ev.state) ?? ev.triggers[0];
      alerts.push({
        level: 'warning',
        text: `${o.pm_level} ${ev.state.toLowerCase()} — ${Math.round(t?.remaining ?? 0)} ${t?.unit ?? ''} remaining`,
        at: vehicle.usage_updated_at,
      });
    }
  }
  for (const doc of documents) {
    if (doc.renewal_status === 'Expired') {
      alerts.push({ level: 'critical', text: `${doc.document_type} expired on ${onDate(doc.expiry_date)}`, at: doc.expiry_date });
    } else if (doc.renewal_status === 'Due Soon') {
      alerts.push({ level: 'warning', text: `${doc.document_type} expires ${onDate(doc.expiry_date)}`, at: doc.expiry_date });
    }
  }
  for (const c of campaigns) {
    if (c.status !== 'Completed' && c.status !== 'Not Applicable') {
      alerts.push({
        level: c.classification === 'Safety' ? 'critical' : 'info',
        text: `${c.classification === 'Safety' ? 'Safety recall' : 'Campaign'} ${c.code} — ${c.name}`,
        at: c.mandatory_by_date,
      });
    }
  }
  for (const d of defects) {
    if (d.blocks_release && ['Open', 'Under Action'].includes(d.status)) {
      alerts.push({ level: 'critical', text: `${d.defect_no} blocks release — ${d.description}`, at: d.opened_date });
    }
  }
  if (vehicle.usage_is_stale) {
    alerts.push({
      level: 'warning',
      text: 'Telematics feed is stale — usage figures are estimated (BL-USG-006)',
      at: vehicle.usage_updated_at,
    });
  }
  const severityRank: Record<string, number> = { critical: 0, warning: 1, info: 2 };
  alerts.sort((a, b) => (severityRank[a.level] ?? 3) - (severityRank[b.level] ?? 3));

  const latestTelematics = telematics.find(t => t.accepted) ?? telematics[0] ?? null;

  return {
    vehicle: {
      vehicleId: vehicle.vehicle_id, vin: vehicle.vin, registrationNo: vehicle.registration_no,
      fleetAssetNo: vehicle.fleet_asset_no,
      category: vehicle.category_name, family: vehicle.family_name,
      model: vehicle.model_name, variant: vehicle.variant_name, variantCode: vehicle.variant_code,
      variantConfirmation: vehicle.variant_confirmation,
      batteryCapacityKwh: vehicle.battery_capacity_kwh,
      batteryConfiguration: vehicle.battery_configuration,
      motorType: vehicle.motor_type, transmission: vehicle.transmission,
      axleConfiguration: vehicle.axle_configuration,
      customer: vehicle.customer_name, depot: vehicle.depot_name,
      serviceCentre: vehicle.service_centre_name, serviceCentreId: vehicle.service_centre_id,
      manufactureDate: vehicle.manufacture_date, commissioningDate: vehicle.commissioning_date,
      warrantyStart: vehicle.warranty_start, warrantyEnd: vehicle.warranty_end,
      warrantyKmLimit: vehicle.warranty_km_limit,
      odometerKm: Number(vehicle.current_odometer_km ?? 0),
      operatingHours: Number(vehicle.current_operating_hours ?? 0),
      usageSource: vehicle.usage_source, usageUpdatedAt: vehicle.usage_updated_at,
      usageIsStale: vehicle.usage_is_stale,
      availabilityState: vehicle.current_availability_state,
      lifecycleStatus: vehicle.lifecycle_status,
      imageUrl: vehicle.image_url,
    },
    currentState: current,
    availability,
    pmObligations: obligations,
    openObligations,
    components,
    defects: visibleDefects,
    serviceHistory: history,
    openServiceEvents: openEvents,
    documents,
    availabilityLedger: ledger,
    campaigns,
    firmware,
    entitlements,
    telematics: {
      latest: latestTelematics,
      history: telematics.filter(t => t.accepted).slice().reverse(),
      deviceId: vehicle.telematics_device_id,
      isOnline: !vehicle.usage_is_stale,
    },
    warrantyClaims,
    alerts,
  };
});

/** GET /api/v1/vehicles/:vin/availability?from=&to= */
vehicleRoutes.get('/api/v1/vehicles/:vin/availability', async (ctx: Ctx) => {
  const scope = vehicleScopeClause(ctx.user!, 'v', 2);
  const v = await one<any>(pool, `
    SELECT v.vehicle_id FROM master.vehicle v WHERE v.vin = $1 AND ${scope.clause}`,
    [ctx.params.vin, ...scope.params]);
  if (!v) throw notFound('Vehicle not found or outside your scope.');

  const to = ctx.query.get('to') ? new Date(ctx.query.get('to')!) : new Date();
  const from = ctx.query.get('from')
    ? new Date(ctx.query.get('from')!)
    : new Date(to.getTime() - 90 * 86_400_000);

  const summary = await availabilitySummary(pool, v.vehicle_id, from, to);
  const intervals = await many<any>(pool, `
    SELECT l.*, r.is_down, r.planned_class, r.category
    FROM uptime.vehicle_status_ledger l
    LEFT JOIN uptime.vehicle_status_reason r ON r.reason_code = l.reason_code
    WHERE l.vehicle_id = $1 AND l.start_utc < $3 AND COALESCE(l.end_utc, now()) > $2
    ORDER BY l.start_utc DESC`, [v.vehicle_id, from, to]);

  return { ...summary, intervals };
});

/** POST /api/v1/vehicles/:vin/usage — authorised manual correction (BL-VEH-006). */
vehicleRoutes.post('/api/v1/vehicles/:vin/usage', async (ctx: Ctx) => {
  await assertAuthorised(pool, ctx.user!, 'usage.correct');
  const { odometerKm, operatingHours, reason, evidenceRef } = ctx.body ?? {};
  if (!reason) throw badRequest('A reason is required for a usage correction (BL-VEH-006).');
  if (odometerKm == null && operatingHours == null) {
    throw badRequest('Provide an odometer reading, operating hours, or both.');
  }

  const v = await one<any>(pool, `SELECT vehicle_id FROM master.vehicle WHERE vin = $1`, [ctx.params.vin]);
  if (!v) throw notFound('Vehicle not found.');

  await correctUsage(pool, {
    vehicleId: v.vehicle_id, odometerKm, operatingHours,
    reason, actor: ctx.user!.username, evidenceRef,
  });
  return { ok: true };
});

/** POST /api/v1/vehicles/:vin/availability/transitions — controlled transition or correction. */
vehicleRoutes.post('/api/v1/vehicles/:vin/availability/transitions', async (ctx: Ctx) => {
  await assertAuthorised(pool, ctx.user!, 'availability.correct');
  const { reasonCode, startUtc, reason, correctLedgerId, newEndUtc } = ctx.body ?? {};
  const v = await one<any>(pool, `SELECT vehicle_id FROM master.vehicle WHERE vin = $1`, [ctx.params.vin]);
  if (!v) throw notFound('Vehicle not found.');
  if (!reason) throw badRequest('A reason is required (BL-AVL-015).');

  if (correctLedgerId) {
    const id = await correctInterval(pool, {
      ledgerId: Number(correctLedgerId),
      newReasonCode: reasonCode, newEndUtc: newEndUtc ? new Date(newEndUtc) : undefined,
      actor: ctx.user!.username, reason,
    });
    return { correctedLedgerId: id };
  }

  const id = await transition(pool, {
    vehicleId: v.vehicle_id, reasonCode, sourceType: 'ManualCorrection',
    ruleId: 'BL-AVL-014', actor: ctx.user!.username, reason,
    startUtc: startUtc ? new Date(startUtc) : undefined,
  });
  return { ledgerId: id, applied: id !== null };
});

/** POST /api/v1/vehicles/:vin/off-hire — privileged (FR-AVL-005, BL-OFF-001). */
vehicleRoutes.post('/api/v1/vehicles/:vin/off-hire', async (ctx: Ctx) => {
  await assertAuthorised(pool, ctx.user!, 'offhire.set');
  const { reasonCode, evidenceRef, expectedReturnUtc, requestedBy } = ctx.body ?? {};
  if (!evidenceRef || !expectedReturnUtc) {
    throw badRequest(
      'Off-hire requires supporting evidence and an expected return date (FR-AVL-005 / BL-OFF-001).');
  }
  const v = await one<any>(pool, `SELECT vehicle_id FROM master.vehicle WHERE vin = $1`, [ctx.params.vin]);
  if (!v) throw notFound('Vehicle not found.');

  const rec = await one<any>(pool, `
    INSERT INTO uptime.off_hire_record
      (vehicle_id, reason_code, evidence_ref, requested_by, approved_by, start_utc, expected_return_utc)
    VALUES ($1,$2,$3,$4,$5, now(), $6) RETURNING *`,
    [v.vehicle_id, reasonCode ?? 'OFF_HIRE', evidenceRef,
     requestedBy ?? ctx.user!.username, ctx.user!.username, expectedReturnUtc]);

  await transition(pool, {
    vehicleId: v.vehicle_id, reasonCode: 'OFF_HIRE', sourceType: 'OffHire',
    sourceEntityId: rec.off_hire_id, ruleId: 'BL-AVL-011', actor: ctx.user!.username,
    reason: `Off-hire approved, expected return ${expectedReturnUtc}`,
  });

  return rec;
});

/** POST /api/v1/off-hire/:id/recommission — return to service with inspection. */
vehicleRoutes.post('/api/v1/off-hire/:id/recommission', async (ctx: Ctx) => {
  await assertAuthorised(pool, ctx.user!, 'offhire.set');
  const rec = await one<any>(pool, `
    UPDATE uptime.off_hire_record SET end_utc = now(), status = 'Returned'
    WHERE off_hire_id = $1 RETURNING *`, [Number(ctx.params.id)]);
  if (!rec) throw notFound('Off-hire record not found.');

  await transition(pool, {
    vehicleId: rec.vehicle_id, reasonCode: 'IN_SERVICE', sourceType: 'OffHire',
    sourceEntityId: rec.off_hire_id, ruleId: 'BL-AVL-001', actor: ctx.user!.username,
    reason: 'Recommissioned after off-hire',
  });
  return rec;
});

/** GET /api/v1/vehicles/:vin/components */
vehicleRoutes.get('/api/v1/vehicles/:vin/components', async (ctx: Ctx) => {
  const v = await one<any>(pool, `SELECT vehicle_id FROM master.vehicle WHERE vin = $1`, [ctx.params.vin]);
  if (!v) throw notFound('Vehicle not found.');
  return many(pool, `
    SELECT * FROM master.vehicle_component WHERE vehicle_id = $1
    ORDER BY is_active DESC, installed_on DESC`, [v.vehicle_id]);
});
