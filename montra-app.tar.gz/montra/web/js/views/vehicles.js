import { api, qs } from '../api.js';
import { h, pill, table, fmtNum, fmtKm, fmtDateTime, ago, field, select, cardOf } from '../ui.js';
import { setPageTitle, reference } from '../app.js';

export async function vehiclesView({ params }) {
  setPageTitle('Vehicles', 'VIN-level vehicle master and maintenance 360° view');

  const ref = await reference();
  const filters = {
    search: params.get('search') ?? '',
    pmStatus: params.get('pmStatus') ?? '',
    availabilityState: params.get('availabilityState') ?? '',
    serviceCentreId: params.get('serviceCentreId') ?? '',
  };

  const container = h('div', {});
  const results = h('div', {});

  const searchInput = h('input', { type: 'text', value: filters.search, placeholder: 'VIN or registration…' });
  const pmSel = select(
    [{ value: '', label: 'All PM statuses' }, 'Upcoming', 'Due Soon', 'Due', 'Overdue', 'Scheduled', 'Under Service'],
    filters.pmStatus);
  const availSel = select(
    [{ value: '', label: 'All states' },
     ...ref.availabilityReasons.map(r => r.availability_state).filter((v, i, a) => a.indexOf(v) === i)],
    filters.availabilityState);
  const centreSel = select(
    [{ value: '', label: 'All service centres' },
     ...ref.serviceCentres.map(c => ({ value: c.service_centre_id, label: c.name }))],
    filters.serviceCentreId);

  async function load() {
    results.replaceChildren(h('div', { class: 'spin' }, 'Loading vehicles…'));
    const query = qs({
      search: searchInput.value.trim(),
      pmStatus: pmSel.value, availabilityState: availSel.value,
      serviceCentreId: centreSel.value, limit: 100,
    });
    const data = await api.get('/api/v1/vehicles' + query);

    results.replaceChildren(cardOf(
      `${fmtNum(data.total)} vehicle${data.total === 1 ? '' : 's'}`,
      table([
        { label: 'Vehicle No. / VIN', render: r => h('div', {},
            h('a', { href: `#/vehicles/${r.vin}` }, r.registration_no || r.vin),
            h('div', { class: 'small muted mono' }, r.vin)) },
        { label: 'Model / Variant', render: r => h('div', {},
            h('div', {}, r.model_name),
            h('div', { class: 'small muted' }, r.variant_name)) },
        { label: 'Customer', key: 'customer_name' },
        { label: 'Service Centre', key: 'service_centre_name' },
        { label: 'Odometer', num: true, render: r => h('div', {},
            h('div', {}, fmtKm(r.current_odometer_km)),
            r.usage_is_stale
              ? h('div', { class: 'small', style: 'color:var(--amber)' }, 'stale feed')
              : h('div', { class: 'small muted' }, ago(r.usage_updated_at))) },
        { label: 'PM Status', render: r => pill(r.pm_status) },
        { label: 'Availability', render: r => pill(r.current_availability_state) },
        { label: 'Defects', num: true, render: r => r.open_defects
            ? h('span', { class: 'pill p-amber' }, String(r.open_defects)) : h('span', { class: 'muted' }, '—') },
      ], data.rows, {
        empty: 'No vehicles match these filters.',
        onRow: r => { location.hash = `#/vehicles/${r.vin}`; },
      })));
  }

  const apply = () => { load(); };
  searchInput.addEventListener('keydown', e => { if (e.key === 'Enter') apply(); });
  for (const s of [pmSel, availSel, centreSel]) s.addEventListener('change', apply);

  container.appendChild(h('div', { class: 'filters' },
    field('Search', searchInput),
    field('PM status', pmSel),
    field('Availability', availSel),
    field('Service centre', centreSel),
    h('button', { class: 'btn btn-primary', onclick: apply }, 'Apply'),
    h('button', {
      class: 'btn', onclick: () => {
        searchInput.value = ''; pmSel.value = ''; availSel.value = ''; centreSel.value = ''; apply();
      },
    }, 'Reset')));
  container.appendChild(results);

  await load();
  return container;
}
