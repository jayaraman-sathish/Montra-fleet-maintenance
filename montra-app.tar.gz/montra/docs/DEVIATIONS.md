# Deviations from the FINAL v3.0 baseline

Every deviation below is a **technology** deviation. No business requirement,
business rule, status value or KPI definition has been changed, dropped or
reinterpreted.

---

## 1. Database: PostgreSQL instead of Microsoft SQL Server

**Baseline:** Document 03 ADR-001 and Document 04 specify Microsoft SQL Server.

**Reason:** the target hosting platform (Render) provides PostgreSQL only.

**Impact:** none on business semantics. Document 04 §1 already anticipates this:
*"exact physical datatypes and indexes may be refined during detailed design
without changing the approved business semantics."*

### Type mapping

| SQL Server (Doc 04) | PostgreSQL (this build) |
|---|---|
| `BIGINT IDENTITY` | `BIGSERIAL` |
| `NVARCHAR(n)` / `NVARCHAR(MAX)` | `TEXT` |
| `DATETIME2` | `TIMESTAMPTZ` (all timestamps stored UTC) |
| `DATE` | `DATE` |
| `DECIMAL(p,s)` | `NUMERIC(p,s)` |
| `BIT` | `BOOLEAN` |
| `ROWVERSION` | `BIGINT row_version`, incremented on update |
| `NVARCHAR` JSON columns | `JSONB` |
| Table-valued list columns | native `TEXT[]` / `INT[]` arrays |
| Filtered unique index | partial unique index (`WHERE …`) |

### Naming

Document 04 uses PascalCase (`VehicleStatusLedger.AttributionParty`). This build
uses snake_case (`uptime.vehicle_status_ledger.attribution_party`), which is the
PostgreSQL convention. The mapping is mechanical: split on case boundaries and
lowercase. Schema names are unchanged.

### Schema-by-schema

All twelve schemas from Document 04 §3 exist with the specified purpose:

| Schema | Tables | Document 04 reference |
|---|---|---|
| `org` | 3 | §5 Organisation and data scope |
| `security` | 7 | §5, §33.3 authorisation policy |
| `master` | 14 | §6 vehicle, component, parts, technician |
| `uptime` | 3 | §6, §33.1 availability ledger |
| `pm` | 11 | §7, §8 obligations and checklists |
| `schedule` | 5 | §11 capacity, appointments, SRT |
| `service` | 18 | §9, §12, §13, §16 execution and SLA |
| `commercial` | 7 | §14 warranty, contract, estimate, cost |
| `quality` | 5 | §8 QC, concession, release |
| `campaign` | 4 | §15 campaign, documents, firmware |
| `integration` | 5 | §26 inbound, telematics, errors, offline |
| `audit` | 3 | §19 audit, status and approval history |

---

## 2. Application stack: Node.js instead of ASP.NET Core

**Baseline:** Document 03 ADR-001 specifies ASP.NET Core / .NET.

**Reason:** the build environment had no access to the .NET SDK (Microsoft's
package repositories were unreachable), so .NET code could not be compiled or
tested. Untested code was judged a worse deliverable than working code in a
near-equivalent runtime.

**What is preserved:**

- the modular-monolith structure of Document 03 §5 — `src/domain/` mirrors the
  domain table one-for-one
- REST paths exactly as catalogued in Document 04 §25
  (`GET /api/v1/vehicles/{vin}/360`, `POST /api/v1/job-cards/{id}/release`, …)
- the error envelope of Document 04 §24: `code`, `message`, `correlationId`,
  field errors, retryability
- server-side authorisation as role + data scope + action (Document 03 §11)
- background workers for PM evaluation and SLA clocks (Document 03 §15)

**Porting note for the production .NET build:** the files in `src/domain/` are
the specification made executable. Each function carries its rule identifiers.
Porting is a translation exercise, not a redesign — `evaluateDueState` becomes a
C# method with the same signature and the same branch order.

---

## 3. Web client: standard-library JavaScript instead of Angular

**Baseline:** Document 03 specifies Angular with a PWA offline capability.

**Reason:** the npm registry was unreachable from the build environment, so
Angular could not be installed. The client is written with ES modules, the DOM
API and `fetch`.

**What is preserved:** the screen inventory, the role-specific landing
workspaces (FR-UX-001), checklist section progress and autosave semantics
(FR-UX-002), global search and filters (FR-UX-003).

**What is not yet built:** offline execution (FR-OFF-001). The server side is
ready for it — `integration.offline_operation` exists, checklist results carry a
`client_operation_id`, and `POST /api/v1/job-cards/{id}/checklist-results` is
idempotent per (job, item) — but there is no service worker or local queue in
the client. This is the main functional gap against Phase 1 and should be the
first item in the production client build.

---

## 4. Items requiring Montra confirmation before production use

These are carried forward from the baseline's own open-decisions registers
(Document 02 §24.11, Document 05 §20) and are **configuration, not code**:

| Configured value in this build | Status |
|---|---|
| PM intervals (20,000 km / 6 months for Rhino; 10,000 km for EVIATOR; 5,000 km for Super Auto; 250 hours for E-27) | Illustrative — Document 1.1 §12 requires Montra-approved schedules |
| Checklist numeric limits (brake lining 5–30 mm, air pressure 7–12 bar, SoH 80–100%) | Illustrative — Document 1.1 §5 is explicit that these must come from approved service manuals |
| Defect severity to release-blocking mapping | Illustrative — Document 02 §21 lists this as an open decision |
| SLA targets (P1 30 min response / 8 h restore) | Illustrative — Document 05 §20 |
| Repeat-failure window (30 days / 2,000 km, matching complaint code and subsystem) | Illustrative — Document 02 §24.11 |
| Vehicle models Rhino 2838 EV and E-Tractor E-45 | Loaded as **Placeholder**, and correctly blocked from configuration publication by BL-CFG-002 |

The system is built so that all of these are data, not code. Changing them
requires no software release, which is what Document 1.1 §2 asks for.
