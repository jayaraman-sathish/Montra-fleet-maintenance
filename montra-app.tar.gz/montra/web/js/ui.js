/** Small DOM and formatting helpers — no framework, no build step. */

export function h(tag, attrs = {}, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k === 'html') el.innerHTML = v;
    else if (k === 'text') el.textContent = v;
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2), v);
    else if (k === 'dataset') Object.assign(el.dataset, v);
    else if (v === true) el.setAttribute(k, '');
    else el.setAttribute(k, v);
  }
  for (const c of children.flat(3)) {
    if (c === null || c === undefined || c === false) continue;
    el.appendChild(c instanceof Node ? c : document.createTextNode(String(c)));
  }
  return el;
}

export const esc = (s) => String(s ?? '').replace(/[&<>"']/g,
  c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); return node; }

/* ---------------- formatting ---------------- */

export function fmtNum(v, digits = 0) {
  if (v === null || v === undefined || v === '') return '—';
  const n = Number(v);
  if (!Number.isFinite(n)) return '—';
  return n.toLocaleString('en-IN', { minimumFractionDigits: digits, maximumFractionDigits: digits });
}
export function fmtKm(v) { return v === null || v === undefined ? '—' : `${fmtNum(v)} km`; }
export function fmtHours(v) { return v === null || v === undefined ? '—' : `${fmtNum(v)} hrs`; }
export function fmtMoney(v) { return v === null || v === undefined ? '—' : `₹ ${fmtNum(v, 2)}`; }

export function fmtDate(v) {
  if (!v) return '—';
  const d = new Date(v);
  if (isNaN(d)) return String(v);
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}
export function fmtDateTime(v) {
  if (!v) return '—';
  const d = new Date(v);
  if (isNaN(d)) return String(v);
  return d.toLocaleString('en-GB', {
    day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', hour12: false });
}
export function fmtTime(v) {
  if (!v) return '—';
  const d = new Date(v);
  return isNaN(d) ? '—' : d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', hour12: false });
}
export function ago(v) {
  if (!v) return '—';
  const ms = Date.now() - new Date(v).getTime();
  const m = Math.floor(ms / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m} min ago`;
  const hrs = Math.floor(m / 60);
  if (hrs < 24) return `${hrs} hr${hrs === 1 ? '' : 's'} ago`;
  const d = Math.floor(hrs / 24);
  return `${d} day${d === 1 ? '' : 's'} ago`;
}
export function durationHrs(hours) {
  if (hours === null || hours === undefined) return '—';
  const n = Number(hours);
  if (n < 24) return `${n.toFixed(1)} h`;
  const d = Math.floor(n / 24), r = Math.round(n % 24);
  return `${d}d ${r}h`;
}

/* ---------------- status pills ---------------- */

const PILL = {
  // PM obligation
  'Upcoming': 'p-grey', 'Due Soon': 'p-amber', 'Due': 'p-amber', 'Overdue': 'p-red',
  'Scheduled': 'p-blue', 'Under Service': 'p-blue',
  'Completed On Time': 'p-green', 'Completed Within Tolerance': 'p-green',
  'Completed Late': 'p-amber', 'Skipped-Authorised': 'p-grey',
  'Superseded': 'p-grey', 'Cancelled': 'p-grey',
  // Job card
  'Open': 'p-grey', 'Assigned': 'p-blue', 'Under Diagnosis': 'p-blue', 'Repairing': 'p-blue',
  'Awaiting Parts': 'p-amber', 'Awaiting Customer Approval': 'p-amber',
  'Awaiting Warranty Decision': 'p-amber', 'Awaiting Internal Authorization': 'p-amber',
  'Awaiting Insurance': 'p-amber', 'Technician Complete': 'p-purple', 'QC Pending': 'p-purple',
  'Completed': 'p-green', 'Closed': 'p-green', 'On Hold': 'p-grey',
  'Transferred': 'p-grey', 'Split': 'p-grey', 'Reopened': 'p-amber',
  // Priority
  'P1': 'p-red', 'P2': 'p-amber', 'P3': 'p-blue',
  // Severity
  'Critical': 'p-red', 'Major': 'p-amber', 'Minor': 'p-grey',
  // Availability
  'In Service': 'p-green', 'Idle': 'p-grey', 'Off Hire/Suspended': 'p-purple', 'Retired': 'p-grey',
  // Defect
  'Deferred': 'p-amber', 'Under Action': 'p-blue', 'Retest/Verification': 'p-purple',
  // Documents / general
  'Valid': 'p-green', 'Expired': 'p-red', 'Not Applicable': 'p-grey',
  'Active': 'p-green', 'Inactive': 'p-grey', 'Pending': 'p-amber', 'Approved': 'p-green',
  'Rejected': 'p-red', 'Confirmed': 'p-green', 'Placeholder': 'p-amber',
  'No Show': 'p-red', 'In Progress': 'p-blue', 'Not Started': 'p-grey',
  'Pass': 'p-green', 'Fail': 'p-red',
};

export function pill(text, override) {
  if (text === null || text === undefined || text === '') return h('span', { class: 'muted' }, '—');
  let cls = override ?? PILL[text];
  if (!cls) cls = String(text).startsWith('Down-') ? 'p-red' : 'p-grey';
  return h('span', { class: `pill ${cls}` }, text);
}

/* ---------------- table builder ---------------- */

export function table(columns, rows, opts = {}) {
  const thead = h('thead', {}, h('tr', {},
    columns.map(c => h('th', { class: c.num ? 'num' : null }, c.label))));
  const tbody = h('tbody', {});

  if (!rows.length) {
    tbody.appendChild(h('tr', {}, h('td', { colspan: columns.length },
      h('div', { class: 'empty' }, opts.empty ?? 'Nothing to show.'))));
  } else {
    for (const r of rows) {
      const tr = h('tr', { class: opts.onRow ? 'clickable' : null });
      if (opts.onRow) tr.addEventListener('click', () => opts.onRow(r));
      for (const c of columns) {
        const v = c.render ? c.render(r) : r[c.key];
        tr.appendChild(h('td', { class: c.num ? 'num' : null },
          v instanceof Node ? v : (v === null || v === undefined || v === '' ? '—' : String(v))));
      }
      tbody.appendChild(tr);
    }
  }
  return h('div', { class: 'table-wrap' }, h('table', { class: 'data' }, thead, tbody));
}

/* ---------------- toasts, modals, confirms ---------------- */

export function toast(message, kind = '') {
  const wrap = document.getElementById('toasts');
  const t = h('div', { class: `toast ${kind}` }, message);
  wrap.appendChild(t);
  setTimeout(() => { t.style.opacity = '0'; setTimeout(() => t.remove(), 250); }, kind === 'err' ? 6500 : 3500);
}

export function modal({ title, body, actions = [], width }) {
  const back = h('div', { class: 'modal-back' });
  const box = h('div', { class: 'modal', style: width ? `max-width:${width}px` : null });
  const close = () => back.remove();

  box.appendChild(h('div', { class: 'modal-head' },
    h('h3', {}, title),
    h('div', { class: 'spacer' }),
    h('button', { class: 'btn btn-ghost btn-sm', onclick: close }, '✕')));
  box.appendChild(h('div', { class: 'modal-body' }, body));
  if (actions.length) {
    box.appendChild(h('div', { class: 'modal-foot' },
      actions.map(a => h('button', {
        class: `btn ${a.class ?? ''}`,
        onclick: async (ev) => {
          const btn = ev.currentTarget;
          btn.disabled = true;
          try { const r = await a.onClick(close); if (r !== false) close(); }
          finally { btn.disabled = false; }
        },
      }, a.label))));
  }
  back.appendChild(box);
  back.addEventListener('click', e => { if (e.target === back) close(); });
  document.body.appendChild(back);
  const first = box.querySelector('input,select,textarea');
  if (first) first.focus();
  return { close, box };
}

export function field(label, control, opts = {}) {
  return h('div', { class: 'field' },
    h('label', {}, label, opts.required ? h('span', { class: 'req' }, ' *') : null),
    control,
    opts.hint ? h('div', { class: 'small muted', style: 'margin-top:4px' }, opts.hint) : null);
}

export function select(options, value, attrs = {}) {
  return h('select', attrs,
    options.map(o => {
      const val = typeof o === 'object' ? o.value : o;
      const lab = typeof o === 'object' ? o.label : o;
      return h('option', { value: val, selected: String(val) === String(value ?? '') }, lab);
    }));
}

/** Render an ApiError in a readable way, including rule references. */
export function showApiError(err) {
  if (!err) return;
  let msg = err.message ?? String(err);
  const d = err.details;
  if (d?.blockers?.length) {
    msg += '\n' + d.blockers.map(b => `• ${b.message}`).join('\n');
  } else if (d?.ruleId) {
    msg += ` (${d.ruleId})`;
  }
  toast(msg, 'err');
  console.warn('API error', err);
}

export function spinner(text = 'Loading…') { return h('div', { class: 'spin' }, text); }

export function cardOf(title, bodyNode, headExtra) {
  return h('div', { class: 'card' },
    h('div', { class: 'card-head' }, h('h3', {}, title), h('div', { class: 'spacer' }), headExtra ?? null),
    h('div', { class: 'card-body flush' }, bodyNode));
}
