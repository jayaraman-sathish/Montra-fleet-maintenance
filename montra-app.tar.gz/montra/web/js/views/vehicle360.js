/**
 * Vehicle 360 — the vehicle master file.
 *
 * Layout follows the Audree design reference: an identity header carrying the
 * live usage tiles, then ten tabs covering the whole record. Everything shown
 * comes from one /360 call so the tabs can never disagree with each other.
 */

import { api } from '../api.js';
import {
  h, pill, table, fmtNum, fmtKm, fmtHours, fmtDate, fmtDateTime, durationHrs,
  cardOf, field, select, modal, toast, showApiError,
} from '../ui.js';
import { setPageTitle, can, reference } from '../app.js';
import { bookModal } from './pm.js';

export async function vehicle360View({ match }) {
  const vin = decodeURIComponent(match[1]);
  const d = await api.get(`/api/v1/vehicles/${encodeURIComponent(vin)}/360`);
  const v = d.vehicle;

  setPageTitle(v.registrationNo || v.vin, `${variantLabel(v)} · ${v.customer}`);

  const panel = h('div', { style: 'margin-top:14px' });
  const tabBar = h('div', { class: 'tabs' });

  const TABS = [
    ['Overview', () => overviewTab(d, go)],
    ['Components', () => componentsTab(d)],
    ['PM Obligations', () => pmTab(d)],
    ['Service History', () => historyTab(d)],
    ['Defects', () => defectsTab(d)],
    ['Documents', () => documentsTab(d)],
    ['Telematics', () => telematicsTab(d)],
    ['Warranty & Entitlements', () => warrantyTab(d)],
    ['Campaigns', () => campaignsTab(d)],
    ['Uptime History', () => uptimeTab(d)],
  ];

  /** Switch to a tab by name — used by the overview quick actions. */
  function go(label) {
    const i = TABS.findIndex(t => t[0] === label);
    if (i < 0) return;
    tabBar.querySelectorAll('button').forEach((b, n) => b.classList.toggle('active', n === i));
    panel.replaceChildren(TABS[i][1]());
    panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  TABS.forEach(([label, fn], i) => {
    const btn = h('button', { class: i === 0 ? 'active' : '' }, label);
    btn.addEventListener('click', () => {
      tabBar.querySelectorAll('button').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      panel.replaceChildren(fn());
    });
    tabBar.appendChild(btn);
  });
  panel.appendChild(TABS[0][1]());

  return h('div', {}, vehicleHeader(d), h('div', { class: 'card' }, tabBar), panel);
}

/* ===================================================================
   Header
   =================================================================== */

function vehicleHeader(d) {
  const v = d.vehicle;
  const t = d.telematics ?? {};
  const soc = t.latest?.soc_pct;
  const state = v.availabilityState ?? 'Unknown';

  const photo = h('div', { class: 'veh-photo' },
    v.imageUrl
      ? h('img', { src: v.imageUrl, alt: v.model, onerror: (e) => { e.target.remove(); } })
      : h('span', { class: 'veh-photo-glyph' }, '🚚'));

  const actions = h('div', { class: 'veh-actions' },
    moreActionsMenu(d),
    can('jobcard.create')
      ? h('button', { class: 'btn btn-primary', onclick: () => createServiceEventModal(d) },
          'Create Service Event')
      : null,
    can('appointment.book')
      ? h('button', { class: 'btn', onclick: () => scheduleAppointment(d) },
          '🗓 Schedule Appointment')
      : null);

  const identity = h('div', { class: 'veh-identity' },
    h('div', { class: 'veh-title' },
      h('h2', {}, v.registrationNo || v.vin),
      pill(v.lifecycleStatus),
      state !== 'In Service' ? pill(state) : null,
      v.variantConfirmation === 'Placeholder' ? pill('Placeholder model', 'p-amber') : null),
    h('div', { class: 'veh-meta' },
      metaItem('Model', variantLabel(v)),
      metaItem('VIN', v.vin, true),
      metaItem('Customer', v.customer),
      metaItem('Depot', v.depot ?? '—'),
      metaItem('Assigned Service Centre', v.serviceCentre ?? '—')));

  const tiles = h('div', { class: 'veh-tiles' },
    tile('🧭', 'Odometer', fmtKm(v.odometerKm),
      v.usageIsStale ? 'estimated — feed stale' : `as of ${fmtDate(v.usageUpdatedAt)}`, v.usageIsStale),
    tile('⏱', 'Operating Hours', fmtHours(v.operatingHours), `as of ${fmtDate(v.usageUpdatedAt)}`),
    tile('🔋', 'Battery SoC', soc !== null && soc !== undefined ? `${Math.round(soc)}%` : '—',
      t.latest?.soh_pct ? `SoH ${Math.round(t.latest.soh_pct)}%` : 'from telematics'),
    tile('📶', 'Last Telematics Update',
      t.latest ? fmtDateTime(t.latest.source_timestamp_utc) : '—',
      null, false,
      pill(t.isOnline ? 'Online' : 'Offline', t.isOnline ? 'p-green' : 'p-grey')));

  return h('div', { class: 'card veh-head' },
    h('div', { class: 'card-body' },
      h('div', { class: 'veh-head-top' }, photo, identity, actions),
      tiles));
}

/**
 * Variant names in the master data already carry the model name, so printing
 * both reads as a stutter ("Rhino 5538 EV Rhino 5538 EV 4x2"). Show the
 * variant alone when it already contains the model.
 */
function variantLabel(v) {
  if (!v.variant) return v.model ?? '—';
  if (!v.model) return v.variant;
  return v.variant.startsWith(v.model) ? v.variant : `${v.model} ${v.variant}`;
}

function metaItem(label, value, mono) {
  return h('span', { class: 'veh-meta-item' },
    h('span', { class: 'muted' }, `${label}: `),
    h('span', { class: mono ? 'mono' : null }, value));
}

function tile(icon, label, value, note, warn, badge) {
  return h('div', { class: 'veh-tile' },
    h('div', { class: 'veh-tile-icon' }, icon),
    h('div', { style: 'min-width:0' },
      h('div', { class: 'small muted' }, label),
      h('div', { class: 'veh-tile-value' }, value),
      note ? h('div', { class: 'small', style: warn ? 'color:var(--amber)' : 'color:var(--ink-3)' }, note) : null,
      badge ?? null));
}

function moreActionsMenu(d) {
  const items = [
    ['Add a defect', () => addDefectModal(d), 'defect.create'],
    ['Log a breakdown (RSA)', () => logBreakdownModal(d), 'breakdown.create'],
    ['Place off hire', () => offHireModal(d), null],
    ['Correct a usage reading', () => usageModal(d), null],
  ];

  const menu = h('div', { class: 'menu-pop', hidden: true },
    items.map(([label, fn]) =>
      h('button', { class: 'menu-item', onclick: () => { menu.hidden = true; fn(); } }, label)));

  const wrap = h('div', { class: 'menu-wrap' },
    h('button', {
      class: 'btn btn-ghost',
      onclick: (e) => { e.stopPropagation(); menu.hidden = !menu.hidden; },
    }, 'More Actions ▾'),
    menu);

  // Close on any outside click. The listener detaches itself once the menu
  // leaves the document, so navigating between vehicles does not stack them up.
  const onDocClick = () => {
    if (!wrap.isConnected) { document.removeEventListener('click', onDocClick); return; }
    menu.hidden = true;
  };
  document.addEventListener('click', onDocClick);
  return wrap;
}

/* ===================================================================
   Overview
   =================================================================== */

function overviewTab(d, go) {
  const v = d.vehicle;
  const state = v.availabilityState ?? 'Unknown';
  const isDown = state.startsWith('Down');

  const info = cardOf('Vehicle Information', h('div', { class: 'card-body' },
    h('div', { class: 'kv' },
      kv('Vehicle No.', v.registrationNo), kv('VIN', h('span', { class: 'mono' }, v.vin)),
      kv('Model', v.model), kv('Variant', v.variant),
      kv('Vehicle Category', v.category), kv('Product Family', v.family),
      kv('Manufacture Date', fmtDate(v.manufactureDate)),
      kv('Commissioned', fmtDate(v.commissioningDate)),
      kv('Battery', v.batteryCapacityKwh
        ? `${v.batteryCapacityKwh} kWh ${v.batteryConfiguration ?? ''}`.trim() : '—'),
      kv('Motor', v.motorType ?? '—'),
      kv('Axle Configuration', v.axleConfiguration ?? '—'),
      kv('Ownership', v.customer ? 'Customer Owned' : '—'),
      kv('Customer', v.customer), kv('Depot', v.depot ?? '—'),
      kv('Assigned Service Centre', v.serviceCentre ?? '—'),
      kv('Status', pill(v.lifecycleStatus)))));

  const openOb = d.openObligations[0];
  const status = cardOf('Current Status', h('div', { class: 'card-body' },
    h('div', { class: `state-banner ${isDown ? 'is-down' : 'is-up'}` },
      h('div', { class: 'state-glyph' }, isDown ? '🛠' : '🚚'),
      h('div', {},
        h('div', { class: 'state-title' }, state),
        d.currentState
          ? h('div', { class: 'small muted' }, `Since ${fmtDateTime(d.currentState.start_utc)}`)
          : null)),
    h('div', { class: 'kv' },
      kv('Availability Status', isDown ? 'Unavailable' : 'Available'),
      kv('Last Service Event', d.serviceHistory[0]
        ? h('span', { class: 'mono' }, d.serviceHistory[0].service_event_no) : '—'),
      kv('Last Job Card', d.serviceHistory.find(s => s.job_card_no)
        ? h('a', { href: `#/job-cards/${d.serviceHistory.find(s => s.job_card_no).job_card_id}` },
            d.serviceHistory.find(s => s.job_card_no).job_card_no)
        : '—'),
      kv('Last PM Service', lastCompletedPm(d)),
      kv('Next PM Due', openOb
        ? [openOb.pm_level,
           openOb.target_date ? fmtDate(openOb.target_date) : null,
           openOb.target_km ? `(${fmtKm(openOb.target_km)})` : null].filter(Boolean).join(' · ')
        : 'No open obligation'),
      kv('Uptime (last 30 days)',
        d.availability.availabilityPct !== null ? `${d.availability.availabilityPct}%` : '—'),
      kv('Off Hire', state === 'Down-OffHire' ? pill('Yes', 'p-amber') : 'No'))));

  const docs = cardOf('Compliance & Documents',
    h('div', { class: 'card-body' },
      d.documents.length
        ? h('div', { class: 'kv' },
            d.documents.flatMap(doc => [
              h('div', {}, doc.document_type),
              h('div', {},
                h('span', { class: `dot ${docDot(doc.renewal_status)}` }),
                doc.expiry_date
                  ? h('span', { class: 'small' }, `Valid to ${fmtDate(doc.expiry_date)}`)
                  : h('span', { class: 'small muted' }, doc.renewal_status)),
            ]))
        : h('div', { class: 'empty' }, 'No documents recorded.')),
    h('button', { class: 'btn btn-ghost btn-sm', onclick: () => go('Documents') }, 'View All'));

  // --- second row -------------------------------------------------
  const t = d.telematics ?? {};
  const l = t.latest;
  const snapshot = cardOf('Telematics Snapshot',
    h('div', { class: 'card-body' },
      h('div', { class: 'live-row' },
        h('span', { class: `dot ${t.isOnline ? 'dot-green' : 'dot-grey'}` }),
        h('span', { class: 'small' }, t.isOnline ? 'Live' : 'Stale feed'),
        h('span', { class: 'small muted', style: 'margin-left:auto' },
          l ? `Last updated ${fmtDateTime(l.source_timestamp_utc)}` : 'No readings')),
      l
        ? h('div', { class: 'kv', style: 'margin-top:10px' },
            kv('Odometer', fmtKm(l.odometer_km)),
            kv('Operating Hours', fmtHours(l.operating_hours)),
            kv('Battery SoC', l.soc_pct !== null ? `${Math.round(l.soc_pct)}%` : '—'),
            kv('Vehicle Status', pill(l.vehicle_status)),
            kv('Location', l.latitude
              ? `${Number(l.latitude).toFixed(4)}, ${Number(l.longitude).toFixed(4)}` : '—'),
            kv('DTC Summary', l.dtc_summary
              ? pill(l.dtc_summary, 'p-red') : pill('0 Active DTC', 'p-green')))
        : h('div', { class: 'empty' }, 'No telematics readings in the last eight days.')),
    h('button', { class: 'btn btn-ghost btn-sm', onclick: () => go('Telematics') }, 'View Telematics'));

  const alerts = cardOf('Active Alerts',
    h('div', { class: 'card-body' },
      d.alerts.length
        ? h('div', { class: 'alert-list' },
            d.alerts.slice(0, 6).map(a => h('div', { class: 'alert-row' },
              h('span', { class: `alert-icon a-${a.level}` },
                a.level === 'critical' ? '!' : a.level === 'warning' ? '▲' : 'i'),
              h('div', { style: 'min-width:0' },
                h('div', { class: 'alert-text' }, a.text),
                a.at ? h('div', { class: 'small muted' }, fmtDate(a.at)) : null))))
        : h('div', { class: 'empty' }, 'Nothing needs attention on this vehicle.')),
    d.alerts.length > 6 ? h('span', { class: 'small muted' }, `${d.alerts.length} in total`) : null);

  const quick = cardOf('Quick Actions', h('div', { class: 'card-body' },
    h('div', { class: 'quick-grid' },
      quickAction('📄', 'Create Service Event', 'blue', () => createServiceEventModal(d)),
      quickAction('🗓', 'Schedule Appointment', 'green', () => scheduleAppointment(d)),
      quickAction('⚠', 'Log Breakdown (RSA)', 'red', () => logBreakdownModal(d)),
      quickAction('🔧', 'Correct Usage Reading', 'amber', () => usageModal(d)),
      quickAction('🕒', 'View Service History', 'grey', () => go('Service History')),
      quickAction('📁', 'Manage Documents', 'purple', () => go('Documents')),
      quickAction('🔀', 'Add Defect', 'grey', () => addDefectModal(d)),
      quickAction('⏸', 'Place Off Hire', 'red', () => offHireModal(d)))));

  return h('div', {},
    h('div', { class: 'grid g3' }, info, status, docs),
    h('div', { style: 'height:14px' }),
    h('div', { class: 'grid g3' }, snapshot, alerts, quick));
}

function quickAction(icon, label, tone, onClick) {
  return h('button', { class: `quick q-${tone}`, onclick: onClick },
    h('span', { class: 'quick-icon' }, icon), h('span', {}, label));
}

function docDot(status) {
  return status === 'Valid' ? 'dot-green'
       : status === 'Due Soon' ? 'dot-amber'
       : status === 'Expired' ? 'dot-red' : 'dot-grey';
}

function lastCompletedPm(d) {
  const done = d.pmObligations.find(o => o.actual_completion_date);
  if (!done) return '—';
  return `${fmtDate(done.actual_completion_date)} (${done.pm_level})`;
}

function kv(label, value) {
  return [h('div', {}, label), h('div', {}, value instanceof Node ? value : (value ?? '—'))];
}

/* ===================================================================
   Components — master / detail
   =================================================================== */

function componentsTab(d) {
  const rows = d.components;
  const detail = h('div', { class: 'card' });
  let selected = rows[0] ?? null;

  const search = h('input', { type: 'search', placeholder: 'Search by component, part no., serial no…' });
  const categories = [...new Set(rows.map(r => r.component_category).filter(Boolean))];
  const catSel = select([{ value: '', label: 'All Categories' },
    ...categories.map(c => ({ value: c, label: c }))], '');

  const listBody = h('div', {});

  function draw() {
    const term = search.value.trim().toLowerCase();
    const cat = catSel.value;
    const filtered = rows.filter(r => {
      if (cat && r.component_category !== cat) return false;
      if (!term) return true;
      return [r.display_name, r.component_type, r.part_no, r.serial_no, r.position_label]
        .some(x => String(x ?? '').toLowerCase().includes(term));
    });

    listBody.replaceChildren(table([
      { label: '#', num: true, render: (r) => String(filtered.indexOf(r) + 1) },
      { label: 'Component', render: r => h('div', {},
          h('div', {}, r.display_name ?? r.component_type),
          r.position_label ? h('div', { class: 'small muted' }, r.position_label) : null) },
      { label: 'Part No.', render: r => h('span', { class: 'mono' }, r.part_no ?? '—') },
      { label: 'Serial No.', render: r => h('span', { class: 'mono' }, r.serial_no) },
      { label: 'Installed On', render: r => fmtDate(r.installed_on) },
      { label: 'Status', render: r => pill(r.condition_status) },
      { label: 'Action', render: r => h('a', {
          href: '#', onclick: (e) => { e.preventDefault(); selected = r; paint(); } }, 'View') },
    ], filtered, {
      empty: 'No components match this filter.',
      onRow: r => { selected = r; paint(); },
    }));
  }

  function paint() {
    draw();
    detail.replaceChildren(...componentDetail(selected, d).childNodes);
  }

  search.addEventListener('input', draw);
  catSel.addEventListener('change', draw);

  const list = h('div', { class: 'card' },
    h('div', { class: 'card-head' },
      h('h3', {}, 'Installed Components'),
      h('div', { class: 'spacer' }),
      h('span', { class: 'small muted' }, `${rows.length} fitments`)),
    h('div', { class: 'filter-bar' }, search, catSel),
    h('div', { class: 'card-body flush' }, listBody));

  paint();
  return h('div', { class: 'split-2' }, list, detail);
}

function componentDetail(c, d) {
  if (!c) {
    return h('div', {},
      h('div', { class: 'card-head' }, h('h3', {}, 'Component Details')),
      h('div', { class: 'card-body' }, h('div', { class: 'empty' }, 'Select a component to see its detail.')));
  }

  // Specification is stored as an ordered [{label, value}] list; older rows
  // may still hold a plain object, so both shapes are accepted.
  const spec = c.specification ?? [];
  const specRows = Array.isArray(spec)
    ? spec.map(x => [x.label, x.value])
    : Object.entries(spec);

  const warrantyText = c.warranty_end
    ? `to ${fmtDate(c.warranty_end)}${c.warranty_km_limit ? ` / ${fmtKm(c.warranty_km_limit)}` : ''}`
    : '—';

  const related = d.serviceHistory.filter(s => s.job_card_no).slice(0, 5);

  return h('div', {},
    h('div', { class: 'card-head' },
      h('h3', {}, 'Component Details'),
      h('div', { class: 'spacer' }),
      c.is_hv ? pill('High voltage', 'p-amber') : null),
    h('div', { class: 'card-body' },
      h('div', { class: 'comp-head' },
        h('div', { class: 'comp-thumb' }, c.is_hv ? '⚡' : '⚙'),
        h('div', {},
          h('div', { class: 'comp-name' }, c.display_name ?? c.component_type, ' ', pill(c.condition_status)),
          h('div', { class: 'small muted' }, c.component_category ?? 'Component'))),

      h('div', { class: 'kv', style: 'margin-top:12px' },
        kv('Part No.', h('span', { class: 'mono' }, c.part_no ?? '—')),
        kv('Serial No.', h('span', { class: 'mono' }, c.serial_no)),
        kv('Position', c.position_label ?? '—'),
        kv('Installed On', fmtDate(c.installed_on)),
        kv('At Odometer', fmtKm(c.installed_odometer_km)),
        kv('Warranty', warrantyText),
        kv('Supplier', c.supplier ?? '—'),
        kv('Removed On', c.removed_on ? fmtDate(c.removed_on) : '—')),

      specRows.length
        ? h('div', { style: 'margin-top:14px' },
            h('h4', { class: 'sub-head' }, 'Specification'),
            h('table', { class: 'mini' },
              h('tbody', {}, specRows.map(([k, val]) =>
                h('tr', {}, h('td', {}, k), h('td', {}, String(val || '—')))))))
        : null,

      h('div', { style: 'margin-top:14px' },
        h('h4', { class: 'sub-head' }, 'Service Information'),
        h('table', { class: 'mini' },
          h('tbody', {},
            miniRow('Last Inspection', fmtDate(c.last_inspection_date)),
            miniRow('Next Inspection', fmtDate(c.next_inspection_date)),
            miniRow('Vehicle Operating Hours', fmtHours(d.vehicle.operatingHours)),
            miniRow('Fault Count', String(c.fault_count ?? 0)),
            miniRow('Health Status', pill(c.health_status ?? 'Good',
              c.health_status === 'Faulty' ? 'p-red'
              : c.health_status === 'Degraded' ? 'p-amber'
              : c.health_status === 'Monitor' ? 'p-amber' : 'p-green')),
            miniRow('Fitment Status', pill(c.is_active ? 'Active' : 'Removed'))))),

      h('div', { style: 'margin-top:14px' },
        h('h4', { class: 'sub-head' }, 'Related Service History'),
        related.length
          ? h('table', { class: 'mini' }, h('tbody', {}, related.map(s =>
              h('tr', {},
                h('td', {}, fmtDate(s.customer_visible_start)),
                h('td', {}, h('a', { href: `#/job-cards/${s.job_card_id}` }, s.job_card_no)),
                h('td', {}, s.event_type),
                h('td', {}, pill(s.status))))))
          : h('div', { class: 'small muted' }, 'No job cards recorded against this vehicle yet.'))));
}

function miniRow(label, value) {
  return h('tr', {}, h('td', {}, label),
    h('td', {}, value instanceof Node ? value : (value ?? '—')));
}

/* ===================================================================
   PM Obligations
   =================================================================== */

function pmTab(d) {
  const all = d.pmObligations;
  const open = d.openObligations;
  const now = new Date();
  const in30 = new Date(now.getTime() + 30 * 86_400_000);

  const overdue = open.filter(o => o.liveEvaluation?.state === 'Overdue').length;
  const next30 = open.filter(o => o.target_date && new Date(o.target_date) <= in30
                                  && o.liveEvaluation?.state !== 'Overdue').length;
  const completed = all.filter(o => o.actual_completion_date).length;

  const stats = h('div', { class: 'stat-row' },
    stat('🗂', 'Total Obligations', all.length, 'blue'),
    stat('📅', 'Due (Next 30 Days)', next30, 'amber'),
    stat('⛔', 'Overdue', overdue, 'red'),
    stat('✅', 'Completed', completed, 'green'));

  function obligationBlock(o) {
    const triggerRows = (o.liveEvaluation?.triggers ?? []).map(t => {
      const target = t.triggerType === 'KM' ? fmtKm(o.target_km)
                   : t.triggerType === 'Calendar' ? fmtDate(o.target_date)
                   : fmtHours(o.target_hours);
      return h('tr', {},
        h('td', {}, t.triggerType),
        h('td', {}, target),
        h('td', { class: 'num' }, `${fmtNum(t.remaining)} ${t.unit}`),
        h('td', {}, pill(t.status)));
    });

    const head = h('thead', {}, h('tr', {},
      h('th', {}, 'Trigger'), h('th', {}, 'Target'),
      h('th', { class: 'num' }, 'Remaining'), h('th', {}, 'Status')));

    return h('div', { style: 'margin-bottom:14px' },
      h('div', { style: 'display:flex;gap:9px;align-items:center;margin-bottom:8px' },
        h('b', {}, `${o.pm_level} · cycle ${o.cycle_no}`),
        pill(o.status),
        o.is_estimated ? pill('Estimated', 'p-amber') : null),
      h('div', { class: 'table-wrap' },
        h('table', { class: 'data' }, head, h('tbody', {}, triggerRows))),
      h('div', { class: 'small muted', style: 'margin-top:6px' },
        `Driving trigger: ${o.liveEvaluation?.drivingTrigger ?? '—'} — the earliest threshold ` +
        `reached determines PM status (BL-PM-005..008).`));
  }

  const liveCard = open.length
    ? cardOf('Open obligation — live evaluation',
        h('div', { class: 'card-body' }, open.map(obligationBlock)),
        can('appointment.book')
          ? h('button', { class: 'btn btn-primary btn-sm', onclick: () => scheduleAppointment(d) },
              'Schedule Appointment')
          : null)
    : null;

  const history = cardOf('PM Obligation Register',
    table([
      { label: '#', num: true, render: r => String(r.cycle_no) },
      { label: 'PM Plan', key: 'plan_code' },
      { label: 'PM Level', key: 'pm_level' },
      { label: 'Trigger', render: r => r.liveEvaluation?.drivingTrigger
          ?? (r.target_km ? 'Odometer' : r.target_hours ? 'Hours' : 'Time') },
      { label: 'Due (Odo/Hrs/Date)', render: r => [
          r.target_km ? fmtKm(r.target_km) : null,
          r.target_hours ? fmtHours(r.target_hours) : null,
          r.target_date ? fmtDate(r.target_date) : null,
        ].filter(Boolean).join(' / ') || '—' },
      { label: 'Status', render: r => pill(r.outcome ?? r.status) },
      { label: 'Last Completed', render: r => r.actual_completion_date
          ? fmtDate(r.actual_completion_date) : '—' },
      { label: 'Variance', num: true, render: r => r.variance_days !== null && r.variance_days !== undefined
          ? `${r.variance_days > 0 ? '+' : ''}${r.variance_days} d` : '—' },
    ], all, { empty: 'No PM obligations.' }),
    h('span', { class: 'small muted' },
      'Obligations are persisted per cycle and never overwritten (FR-PMO-001).'));

  return h('div', {}, stats, h('div', { style: 'height:14px' }),
    liveCard, liveCard ? h('div', { style: 'height:14px' }) : null, history);
}

function stat(icon, label, value, tone) {
  return h('div', { class: `stat s-${tone}` },
    h('div', { class: 'stat-icon' }, icon),
    h('div', {},
      h('div', { class: 'stat-value' }, String(value)),
      h('div', { class: 'small muted' }, label)));
}

/* ===================================================================
   Service history
   =================================================================== */

function historyTab(d) {
  const rows = d.serviceHistory;
  const search = h('input', { type: 'search', placeholder: 'Search job card, service event…' });
  const typeSel = select([{ value: '', label: 'All Types' },
    ...[...new Set(rows.map(r => r.event_type))].map(t => ({ value: t, label: t }))], '');
  const from = h('input', { type: 'date' });
  const to = h('input', { type: 'date' });
  const reset = h('button', { class: 'btn btn-ghost btn-sm' }, 'Reset');
  const body = h('div', {});

  function draw() {
    const term = search.value.trim().toLowerCase();
    const filtered = rows.filter(r => {
      if (typeSel.value && r.event_type !== typeSel.value) return false;
      if (from.value && r.customer_visible_start
          && String(r.customer_visible_start).slice(0, 10) < from.value) return false;
      if (to.value && r.customer_visible_start
          && String(r.customer_visible_start).slice(0, 10) > to.value) return false;
      if (!term) return true;
      return [r.service_event_no, r.job_card_no, r.event_type, r.centre_name]
        .some(x => String(x ?? '').toLowerCase().includes(term));
    });

    body.replaceChildren(table([
      { label: 'Job Card No.', render: r => r.job_card_no
          ? h('a', { href: `#/job-cards/${r.job_card_id}` }, r.job_card_no)
          : h('span', { class: 'muted' }, '—') },
      { label: 'Service Event', render: r => h('span', { class: 'mono small' }, r.service_event_no) },
      { label: 'Service Type', key: 'event_type' },
      { label: 'Open Date', render: r => fmtDate(r.customer_visible_start) },
      { label: 'Close Date', render: r => r.customer_visible_end ? fmtDate(r.customer_visible_end) : '—' },
      { label: 'Centre', key: 'centre_name' },
      { label: 'Repeat', render: r => r.is_repeat ? pill('Repeat', 'p-red') : '—' },
      { label: 'First-Time Fix', render: r => r.ftf_result ? pill(r.ftf_result) : '—' },
      { label: 'Status', render: r => pill(r.status) },
    ], filtered, { empty: 'No service history matches this filter.' }));
  }

  [search, typeSel, from, to].forEach(el => el.addEventListener('input', draw));
  [typeSel, from, to].forEach(el => el.addEventListener('change', draw));
  reset.addEventListener('click', () => {
    search.value = ''; typeSel.value = ''; from.value = ''; to.value = ''; draw();
  });

  draw();
  return h('div', { class: 'card' },
    h('div', { class: 'card-head' }, h('h3', {}, 'Service History'),
      h('div', { class: 'spacer' }),
      h('span', { class: 'small muted' }, `${rows.length} events`)),
    h('div', { class: 'filter-bar' }, search, typeSel,
      h('span', { class: 'small muted' }, 'From'), from,
      h('span', { class: 'small muted' }, 'To'), to, reset),
    h('div', { class: 'card-body flush' }, body));
}

/* ===================================================================
   Defects
   =================================================================== */

function defectsTab(d) {
  const rows = d.defects;
  const statusSel = select([{ value: '', label: 'All Status' },
    'Open', 'Under Action', 'Deferred', 'Closed'], '');
  const sevSel = select([{ value: '', label: 'All Criticality' },
    'Critical', 'Major', 'Minor'], '');
  const search = h('input', { type: 'search', placeholder: 'Search by defect description…' });
  const body = h('div', {});

  function draw() {
    const term = search.value.trim().toLowerCase();
    const filtered = rows.filter(r => {
      if (statusSel.value && r.status !== statusSel.value) return false;
      if (sevSel.value && r.severity !== sevSel.value) return false;
      if (!term) return true;
      return [r.defect_no, r.description, r.subsystem]
        .some(x => String(x ?? '').toLowerCase().includes(term));
    });

    body.replaceChildren(table([
      { label: 'Defect ID', render: r => h('span', { class: 'mono' }, r.defect_no) },
      { label: 'Description', render: r => h('div', { style: 'max-width:360px' }, r.description) },
      { label: 'Category', key: 'subsystem' },
      { label: 'Criticality', render: r => pill(r.severity) },
      { label: 'Reported On', render: r => fmtDate(r.opened_date) },
      { label: 'Due By', render: r => [r.due_by_date ? fmtDate(r.due_by_date) : null,
          r.due_by_km ? fmtKm(r.due_by_km) : null].filter(Boolean).join(' / ') || '—' },
      { label: 'Blocks Release', render: r => r.blocks_release ? pill('Yes', 'p-red') : 'No' },
      { label: 'Carried Fwd', render: r => r.carried_forward ? '✓' : '—' },
      { label: 'Status', render: r => pill(r.status) },
    ], filtered, { empty: 'No defects match this filter.' }));
  }

  search.addEventListener('input', draw);
  [statusSel, sevSel].forEach(el => el.addEventListener('change', draw));
  draw();

  return h('div', { class: 'card' },
    h('div', { class: 'card-head' }, h('h3', {}, 'Defects (VIN-owned)'),
      h('div', { class: 'spacer' }),
      h('button', { class: 'btn btn-primary btn-sm', onclick: () => addDefectModal(d) }, '+ Add Defect')),
    h('div', { class: 'filter-bar' }, statusSel, sevSel, search),
    h('div', { class: 'card-body flush' }, body),
    h('div', { class: 'card-foot small muted' },
      'Deferred defects stay with the vehicle and attach to later service (BL-DEF-001).'));
}

/* ===================================================================
   Documents
   =================================================================== */

function documentsTab(d) {
  return cardOf('Vehicle Documents',
    table([
      { label: '#', num: true, render: r => String(d.documents.indexOf(r) + 1) },
      { label: 'Document Name', render: r => documentLabel(r.document_type) },
      { label: 'Category', key: 'document_category' },
      { label: 'Number', render: r => h('span', { class: 'mono small' }, r.document_no ?? '—') },
      { label: 'Issuing Authority', key: 'issuing_authority' },
      { label: 'Uploaded On', render: r => fmtDate(r.uploaded_on ?? r.issue_date) },
      { label: 'Expiry Date', render: r => r.expiry_date ? fmtDate(r.expiry_date) : 'N/A' },
      { label: 'Status', render: r => pill(r.renewal_status) },
    ], d.documents, { empty: 'No documents recorded.' }),
    h('span', { class: 'small muted' },
      'Expiry drives the compliance alerts on the overview (FR-DOC-001).'));
}

function documentLabel(type) {
  const NAMES = {
    RC: 'Registration Certificate (RC)', Insurance: 'Insurance Certificate',
    PUC: 'PUC Certificate', Fitness: 'Fitness Certificate', Permit: 'Permit',
    Tax: 'Road Tax Receipt',
  };
  return NAMES[type] ?? type;
}

/* ===================================================================
   Telematics
   =================================================================== */

function telematicsTab(d) {
  const t = d.telematics ?? {};
  const l = t.latest;
  const history = t.history ?? [];

  const live = cardOf('Live Vehicle Data',
    h('div', { class: 'card-body' },
      h('div', { class: 'live-row' },
        h('span', { class: `dot ${t.isOnline ? 'dot-green' : 'dot-grey'}` }),
        h('span', { class: 'small' }, t.isOnline ? 'Online' : 'Offline'),
        h('span', { class: 'small muted', style: 'margin-left:auto' },
          l ? `Last update ${fmtDateTime(l.source_timestamp_utc)}` : 'No readings')),
      l
        ? h('div', { class: 'live-grid' },
            liveBox('Odometer', fmtKm(l.odometer_km)),
            liveBox('Operating Hours', fmtHours(l.operating_hours)),
            liveBox('Battery SoC', l.soc_pct !== null ? `${Math.round(l.soc_pct)}%` : '—'),
            liveBox('Battery SoH', l.soh_pct !== null ? `${Math.round(l.soh_pct)}%` : '—'),
            liveBox('Vehicle Status', l.vehicle_status ?? '—'),
            liveBox('Location', l.latitude
              ? `${Number(l.latitude).toFixed(4)}, ${Number(l.longitude).toFixed(4)}` : '—'),
            liveBox('DTC', l.dtc_summary ?? '0 Active'),
            liveBox('Device', t.deviceId ?? '—'))
        : h('div', { class: 'empty' }, 'No accepted telematics readings in the last eight days.')),
    h('span', { class: 'small muted' }, 'Source of record for usage (BL-USG-001..007)'));

  const chart = cardOf('Telematics History (last 7 days)',
    h('div', { class: 'card-body' },
      history.length >= 2
        ? h('div', {},
            sparkChart(history, r => r.odometer_km === null || r.odometer_km === undefined
              ? null : Number(r.odometer_km), 'Odometer (km)', 'var(--blue)'),
            h('div', { style: 'height:16px' }),
            sparkChart(history, r => r.soc_pct === null || r.soc_pct === undefined
              ? null : Number(r.soc_pct), 'Battery state of charge (%)', 'var(--green)'))
        : h('div', { class: 'empty' }, 'Not enough history to draw a trend.')));

  const log = cardOf('Reading Log',
    table([
      { label: 'Timestamp', render: r => fmtDateTime(r.source_timestamp_utc) },
      { label: 'Odometer', num: true, render: r => fmtKm(r.odometer_km) },
      { label: 'Hours', num: true, render: r => fmtHours(r.operating_hours) },
      { label: 'SoC', num: true, render: r => r.soc_pct !== null ? `${Math.round(r.soc_pct)}%` : '—' },
      { label: 'Status', render: r => pill(r.vehicle_status) },
      { label: 'Accepted', render: r => r.accepted
          ? pill('Accepted', 'p-green')
          : pill(r.rejection_reason ?? 'Rejected', 'p-red') },
    ], history.slice().reverse().slice(0, 25), { empty: 'No readings.' }));

  return h('div', {},
    h('div', { class: 'grid g2' }, live, chart),
    h('div', { style: 'height:14px' }), log);
}

function liveBox(label, value) {
  return h('div', { class: 'live-box' },
    h('div', { class: 'small muted' }, label),
    h('div', { class: 'live-value' }, value));
}

/**
 * Minimal inline SVG line chart. Drawn by hand rather than pulled from a
 * charting library: this build has no third-party dependencies.
 */
function sparkChart(allRows, pick, label, colour) {
  const W = 620, H = 140, PAD_L = 52, PAD_B = 22, PAD_T = 10, PAD_R = 10;

  // Not every reading carries every metric — a feed may report odometer but
  // no state of charge. Plot only the readings that actually have this one,
  // rather than letting a missing value read as zero.
  const rows = allRows.filter(r => {
    const raw = pick(r);
    return raw !== null && raw !== undefined && Number.isFinite(raw);
  });
  const values = rows.map(pick);
  if (values.length < 2) return h('div', { class: 'small muted' }, `${label}: not enough data.`);

  const min = Math.min(...values), max = Math.max(...values);
  const span = max - min || 1;
  const x = i => PAD_L + (i / (values.length - 1)) * (W - PAD_L - PAD_R);
  const y = val => PAD_T + (1 - (val - min) / span) * (H - PAD_T - PAD_B);

  const svgNS = 'http://www.w3.org/2000/svg';
  const el = (tag, attrs) => {
    const n = document.createElementNS(svgNS, tag);
    for (const [k, val] of Object.entries(attrs)) n.setAttribute(k, String(val));
    return n;
  };

  const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, class: 'spark', role: 'img' });
  svg.setAttribute('aria-label', label);

  // horizontal guides and value labels
  for (let g = 0; g <= 3; g++) {
    const val = min + (span * g) / 3;
    const yy = y(val);
    svg.appendChild(el('line', {
      x1: PAD_L, x2: W - PAD_R, y1: yy, y2: yy, stroke: 'var(--line)', 'stroke-width': 1,
    }));
    const txt = el('text', { x: PAD_L - 8, y: yy + 4, 'text-anchor': 'end', class: 'spark-label' });
    txt.textContent = Math.round(val).toLocaleString('en-IN');
    svg.appendChild(txt);
  }

  const points = values.map((val, i) => `${x(i)},${y(val)}`).join(' ');
  svg.appendChild(el('polyline', {
    points, fill: 'none', stroke: colour, 'stroke-width': 2,
    'stroke-linejoin': 'round', 'stroke-linecap': 'round',
  }));
  svg.appendChild(el('polygon', {
    points: `${PAD_L},${H - PAD_B} ${points} ${W - PAD_R},${H - PAD_B}`,
    fill: colour, opacity: 0.08,
  }));

  // date ticks at either end
  const first = rows[0]?.source_timestamp_utc, last = rows[rows.length - 1]?.source_timestamp_utc;
  const t1 = el('text', { x: PAD_L, y: H - 6, class: 'spark-label' });
  t1.textContent = fmtDate(first);
  const t2 = el('text', { x: W - PAD_R, y: H - 6, 'text-anchor': 'end', class: 'spark-label' });
  t2.textContent = fmtDate(last);
  svg.appendChild(t1); svg.appendChild(t2);

  return h('div', {},
    h('div', { class: 'small muted', style: 'margin-bottom:4px' }, label),
    svg);
}

/* ===================================================================
   Warranty & entitlements
   =================================================================== */

function warrantyTab(d) {
  const v = d.vehicle;
  const claims = d.warrantyClaims ?? [];

  const inDate = v.warrantyEnd && new Date(v.warrantyEnd) > new Date();
  const inKm = !v.warrantyKmLimit || v.odometerKm < v.warrantyKmLimit;
  const kmPct = v.warrantyKmLimit
    ? Math.min(100, Math.round((v.odometerKm / v.warrantyKmLimit) * 100)) : null;

  const cover = cardOf('Warranty Coverage', h('div', { class: 'card-body' },
    h('div', { class: 'cover-head' },
      h('span', { class: 'cover-glyph' }, '🛡'),
      h('div', {},
        pill(inDate && inKm ? 'Active' : 'Expired', inDate && inKm ? 'p-green' : 'p-red'),
        h('div', { class: 'small', style: 'margin-top:4px' },
          v.warrantyEnd ? `Valid till ${fmtDate(v.warrantyEnd)}` : 'No vehicle warranty recorded'),
        v.warrantyKmLimit
          ? h('div', { class: 'small muted' }, `3 years / ${fmtKm(v.warrantyKmLimit)}`) : null)),
    kmPct !== null
      ? h('div', { style: 'margin-top:12px' },
          h('div', { class: 'bar' }, h('span', {
            style: `width:${kmPct}%;background:${kmPct > 90 ? 'var(--red)' : 'var(--blue)'}`,
          })),
          h('div', { class: 'small muted', style: 'margin-top:5px' },
            `${fmtKm(v.odometerKm)} of ${fmtKm(v.warrantyKmLimit)} used (${kmPct}%)`))
      : null));

  const ent = d.entitlements[0];
  const consumed = d.entitlements.reduce((n, e) => n + Number(e.consumed_quantity ?? 0), 0);
  const total = d.entitlements.reduce((n, e) => n + Number(e.total_quantity ?? 0), 0);

  const amc = cardOf('AMC / Service Entitlement', h('div', { class: 'card-body' },
    ent
      ? h('div', {},
          h('div', { class: 'cover-head' },
            h('span', { class: 'cover-glyph' }, '📄'),
            h('div', {},
              pill('Active', 'p-green'),
              h('div', { class: 'small', style: 'margin-top:4px' },
                `${ent.contract_type} · ${ent.contract_no}`),
              h('div', { class: 'small muted' }, `Ends ${fmtDate(ent.end_date)}`))),
          h('div', { class: 'small', style: 'margin-top:12px' },
            `Free services: ${consumed} of ${total} used`),
          total
            ? h('div', { class: 'bar', style: 'margin-top:5px' }, h('span', {
                style: `width:${Math.min(100, Math.round((consumed / total) * 100))}%;background:var(--green)`,
              }))
            : null)
      : h('div', { class: 'empty' }, 'No active contract or AMC entitlement for this vehicle.')));

  const byResult = claims.reduce((acc, c) => {
    acc.total++;
    if (c.result === 'Eligible' || c.result === 'Goodwill') acc.approved++;
    else if (c.result === 'Approval Required') acc.pending++;
    else if (c.result === 'Not Eligible' || c.result === 'Rejected') acc.rejected++;
    return acc;
  }, { total: 0, approved: 0, pending: 0, rejected: 0 });

  const summary = cardOf('Claims Summary', h('div', { class: 'card-body' },
    h('div', { class: 'claim-grid' },
      claimBox('Total Claims', byResult.total, 'blue'),
      claimBox('Approved', byResult.approved, 'green'),
      claimBox('Pending', byResult.pending, 'amber'),
      claimBox('Rejected', byResult.rejected, 'red'))));

  const history = cardOf('Warranty / Claim History',
    table([
      { label: 'Claim No.', render: r => h('span', { class: 'mono' }, r.claim_no) },
      { label: 'Job Card No.', render: r => h('a', { href: `#/job-cards/${r.job_card_id}` }, r.job_card_no) },
      { label: 'Service Type', key: 'event_type' },
      { label: 'Rule', render: r => r.rule_name ?? '—' },
      { label: 'Submitted On', render: r => fmtDate(r.created_at) },
      { label: 'Decided', render: r => r.decided_at ? fmtDate(r.decided_at) : '—' },
      { label: 'Reason', render: r => h('div', { style: 'max-width:320px' }, r.reason ?? '—') },
      { label: 'Status', render: r => pill(r.result,
          ['Eligible', 'Goodwill'].includes(r.result) ? 'p-green'
          : r.result === 'Approval Required' ? 'p-amber' : 'p-red') },
    ], claims, { empty: 'No warranty claims raised for this vehicle.' }));

  const fw = cardOf('Firmware Baseline',
    table([
      { label: 'ECU / Module', key: 'ecu_module' },
      { label: 'Current Version', render: r => h('span', { class: 'mono' }, r.current_version ?? '—') },
      { label: 'Target Version', render: r => h('span', { class: 'mono' }, r.target_version ?? '—') },
      { label: 'Up to Date', render: r => r.current_version === r.target_version
          ? pill('Yes', 'p-green') : pill('Update available', 'p-amber') },
      { label: 'Last Updated', render: r => fmtDate(r.last_updated_on) },
      { label: 'Method', key: 'update_method' },
    ], d.firmware, { empty: 'No firmware baseline recorded.' }));

  return h('div', {},
    h('div', { class: 'grid g3' }, cover, amc, summary),
    h('div', { style: 'height:14px' }), history,
    h('div', { style: 'height:14px' }), fw);
}

function claimBox(label, value, tone) {
  return h('div', { class: `claim c-${tone}` },
    h('div', { class: 'claim-value' }, String(value)),
    h('div', { class: 'small muted' }, label));
}

/* ===================================================================
   Campaigns
   =================================================================== */

function campaignsTab(d) {
  const rows = d.campaigns;
  const applicable = rows.filter(r => r.status !== 'Not Applicable').length;
  const completed = rows.filter(r => r.status === 'Completed').length;
  const pending = rows.filter(r => !['Completed', 'Not Applicable'].includes(r.status)).length;

  const stats = h('div', { class: 'stat-row' },
    stat('📣', 'Total Campaigns', rows.length, 'blue'),
    stat('✔', 'Applicable', applicable, 'green'),
    stat('✅', 'Completed', completed, 'green'),
    stat('⏳', 'Pending', pending, 'amber'));

  const tbl = cardOf('Campaigns & Recalls',
    table([
      { label: 'Campaign ID', render: r => h('span', { class: 'mono' }, r.code) },
      { label: 'Campaign Name', key: 'name' },
      { label: 'Type', render: r => pill(r.classification,
          r.classification === 'Safety' ? 'p-red' : 'p-blue') },
      { label: 'Due Date', render: r => fmtDate(r.mandatory_by_date) },
      { label: 'Status', render: r => pill(r.status) },
    ], rows, { empty: 'No campaigns apply to this vehicle.' }),
    h('span', { class: 'small muted' },
      'A safety recall blocks release until it is closed (BL-CMP-004).'));

  return h('div', {}, stats, h('div', { style: 'height:14px' }), tbl);
}

/* ===================================================================
   Uptime history
   =================================================================== */

function uptimeTab(d) {
  const a = d.availability;
  const summary = h('div', { class: 'card-body' },
    h('div', { style: 'display:flex;gap:26px;flex-wrap:wrap;margin-bottom:14px' },
      h('div', {}, h('div', { class: 'small muted' }, 'Availability (30 days)'),
        h('div', { style: 'font-size:22px;font-weight:700' },
          a.availabilityPct !== null ? `${a.availabilityPct}%` : '—')),
      h('div', {}, h('div', { class: 'small muted' }, 'Up time'),
        h('div', { style: 'font-size:22px;font-weight:700' }, durationHrs(a.upSeconds / 3600))),
      h('div', {}, h('div', { class: 'small muted' }, 'Down time'),
        h('div', { style: 'font-size:22px;font-weight:700' }, durationHrs(a.downSeconds / 3600))),
      h('div', {}, h('div', { class: 'small muted' }, 'Excluded (off-hire)'),
        h('div', { style: 'font-size:22px;font-weight:700' }, durationHrs(a.excludedSeconds / 3600)))),
    a.breakdown.length
      ? h('div', {}, a.breakdown.map(b => h('div', {
          style: 'display:grid;grid-template-columns:220px 1fr 80px;gap:10px;align-items:center;margin-bottom:8px',
        },
          h('div', { class: 'small' }, b.state),
          h('div', { class: 'bar' }, h('span', {
            style: `width:${Math.min(100, (b.seconds / Math.max(1, a.totalSeconds)) * 100)}%;` +
                   `background:${b.isDown ? 'var(--red)' : 'var(--green)'}`,
          })),
          h('div', { class: 'small', style: 'text-align:right' }, durationHrs(b.hours)))))
      : null);

  const ledger = table([
    { label: 'State', render: r => pill(r.availability_state) },
    { label: 'Reason', render: r => h('span', { class: 'small mono' }, r.reason_code ?? '—') },
    { label: 'From', render: r => fmtDateTime(r.start_utc) },
    { label: 'To', render: r => r.end_utc ? fmtDateTime(r.end_utc) : h('span', { class: 'pill p-blue' }, 'Open') },
    { label: 'Duration', render: r => r.gross_seconds ? durationHrs(r.gross_seconds / 3600) : '—' },
    { label: 'Attribution', key: 'attribution_party' },
    { label: 'Source', key: 'source_type' },
    { label: 'Rule', render: r => h('span', { class: 'small mono muted' }, r.transition_rule_id ?? '—') },
  ], d.availabilityLedger, { empty: 'No availability intervals recorded.' });

  return h('div', {},
    cardOf('Availability Summary', summary),
    h('div', { style: 'height:14px' }),
    cardOf('Vehicle Status Ledger', ledger,
      h('span', { class: 'small muted' }, 'Authoritative source for uptime KPIs (FR-AVL-001)')));
}

/* ===================================================================
   Actions
   =================================================================== */

function reload() { window.dispatchEvent(new HashChangeEvent('hashchange')); }

function createServiceEventModal(d) {
  const v = d.vehicle;
  const openOb = d.openObligations[0];

  const typeSel = select([
    ...(openOb ? [{ value: 'PM', label: `Preventive Maintenance — ${openOb.pm_level}` }] : []),
    { value: 'Breakdown', label: 'Breakdown / unscheduled repair' },
  ], openOb ? 'PM' : 'Breakdown');

  const complaint = h('textarea', { placeholder: 'What is the customer reporting?' });
  const mobility = select(['Immobilized', 'Limited movement', 'Mobile'], 'Limited movement');
  const bdBlock = h('div', {}, field('Complaint', complaint, { required: true }),
    field('Mobility', mobility, { required: true,
      hint: 'Immobilised opens at P1, limited movement P2, mobile P3 (BL-BD-002..004).' }));

  function sync() { bdBlock.hidden = typeSel.value !== 'Breakdown'; }
  typeSel.addEventListener('change', sync);

  const m = modal({
    title: `Create service event — ${v.registrationNo || v.vin}`,
    width: 560,
    body: h('div', {},
      field('Event type', typeSel, { required: true }),
      bdBlock,
      openOb
        ? h('div', { class: 'banner banner-blue' },
            h('div', {}, h('b', {}, `${openOb.pm_level} is open on this vehicle. `),
              h('span', { class: 'small' },
                'Opening it here creates the job card against the persisted obligation, ' +
                'so the cycle is never lost (FR-PMO-001).')))
        : null),
    actions: [{
      label: 'Create', class: 'btn-primary',
      onClick: async () => {
        try {
          if (typeSel.value === 'PM') {
            const r = await api.post('/api/v1/service-events/pm', {
              pmObligationId: openOb.pm_obligation_id,
              serviceCentreId: v.serviceCentreId,
            });
            toast(`Job card ${r.jobCard?.job_card_no ?? ''} opened.`, 'ok');
            if (r.jobCard) location.hash = `#/job-cards/${r.jobCard.job_card_id}`;
          } else {
            if (!complaint.value.trim()) { toast('A complaint description is required.', 'err'); return false; }
            const r = await api.post('/api/v1/breakdowns', {
              vin: v.vin, complaintText: complaint.value.trim(),
              mobility: mobility.value, reportedBy: 'Vehicle master file',
            });
            toast(`Breakdown ${r.serviceEvent?.service_event_no ?? ''} logged.`, 'ok');
            reload();
          }
        } catch (e) { showApiError(e); return false; }
      },
    }],
  });
  sync();
  return m;
}

async function scheduleAppointment(d) {
  const openOb = d.openObligations[0];
  if (!openOb) {
    toast('There is no open PM obligation to book against. Open a service event instead.', 'err');
    return;
  }
  const ref = await reference();
  bookModal({
    ...openOb,
    vin: d.vehicle.vin,
    registration_no: d.vehicle.registrationNo,
    service_centre_id: d.vehicle.serviceCentreId,
  }, ref, reload);
}

function addDefectModal(d) {
  const sev = select(['Critical', 'Major', 'Minor'], 'Major');
  const sub = h('input', { placeholder: 'e.g. Powertrain, Brakes, HVAC' });
  const desc = h('textarea', { placeholder: 'Describe the defect…' });
  const blocks = h('input', { type: 'checkbox', checked: true });
  const dueDate = h('input', { type: 'date' });

  modal({
    title: `Add defect — ${d.vehicle.registrationNo || d.vehicle.vin}`,
    width: 520,
    body: h('div', {},
      field('Criticality', sev, { required: true }),
      field('Category / subsystem', sub),
      field('Description', desc, { required: true }),
      field('Due by', dueDate, { hint: 'Optional. Deferred defects carry forward with the VIN (BL-DEF-001).' }),
      h('label', { class: 'check' }, blocks, ' Blocks release until closed')),
    actions: [{
      label: 'Add defect', class: 'btn-primary',
      onClick: async () => {
        if (!desc.value.trim()) { toast('A description is required.', 'err'); return false; }
        try {
          await api.post('/api/v1/defects', {
            vin: d.vehicle.vin, severity: sev.value, subsystem: sub.value || null,
            description: desc.value.trim(), blocksRelease: blocks.checked,
            dueByDate: dueDate.value || null,
          });
          toast('Defect recorded against the vehicle.', 'ok');
          reload();
        } catch (e) { showApiError(e); return false; }
      },
    }],
  });
}

function logBreakdownModal(d) {
  const complaint = h('textarea', { placeholder: 'What has happened?' });
  const mobility = select(['Immobilized', 'Limited movement', 'Mobile'], 'Immobilized');
  const where = h('input', { placeholder: 'Location description' });
  const phone = h('input', { placeholder: 'Contact number' });

  modal({
    title: `Log breakdown — ${d.vehicle.registrationNo || d.vehicle.vin}`,
    width: 520,
    body: h('div', {},
      field('Complaint', complaint, { required: true }),
      field('Mobility', mobility, { required: true,
        hint: 'Priority and the RSA clock follow from this (BL-BD-002..004).' }),
      field('Location', where),
      field('Contact', phone)),
    actions: [{
      label: 'Log breakdown', class: 'btn-primary',
      onClick: async () => {
        if (!complaint.value.trim()) { toast('A complaint description is required.', 'err'); return false; }
        try {
          const r = await api.post('/api/v1/breakdowns', {
            vin: d.vehicle.vin, complaintText: complaint.value.trim(),
            mobility: mobility.value, locationText: where.value || null,
            contactPhone: phone.value || null, reportedBy: 'Vehicle master file',
          });
          toast(`Breakdown ${r.serviceEvent?.service_event_no ?? ''} logged.`, 'ok');
          reload();
        } catch (e) { showApiError(e); return false; }
      },
    }],
  });
}

function offHireModal(d) {
  const evidence = h('input', { placeholder: 'Customer instruction reference' });
  const ret = h('input', { type: 'date', value: new Date(Date.now() + 14 * 86400000).toISOString().slice(0, 10) });

  modal({
    title: `Place off hire — ${d.vehicle.registrationNo || d.vehicle.vin}`,
    width: 500,
    body: h('div', {},
      h('div', { class: 'banner banner-amber' },
        h('span', {}, '⚠'),
        h('div', { class: 'small' },
          'Off-hire time is excluded from uptime KPIs, so it needs evidence and an ' +
          'expected return date before it can be approved (FR-AVL-005 / BL-OFF-001).')),
      field('Evidence reference', evidence, { required: true }),
      field('Expected return', ret, { required: true })),
    actions: [{
      label: 'Place off hire', class: 'btn-primary',
      onClick: async () => {
        if (!evidence.value.trim()) { toast('Evidence is required.', 'err'); return false; }
        try {
          await api.post(`/api/v1/vehicles/${encodeURIComponent(d.vehicle.vin)}/off-hire`, {
            evidenceRef: evidence.value.trim(),
            expectedReturnUtc: new Date(ret.value).toISOString(),
          });
          toast('Vehicle placed off hire.', 'ok');
          reload();
        } catch (e) { showApiError(e); return false; }
      },
    }],
  });
}

function usageModal(d) {
  const km = h('input', { type: 'number', value: Math.round(d.vehicle.odometerKm), min: 0 });
  const hrs = h('input', { type: 'number', value: Math.round(d.vehicle.operatingHours), min: 0 });
  const reason = h('textarea', { placeholder: 'Why is the reading being corrected?' });
  const evidence = h('input', { placeholder: 'Photograph, work order or ticket reference' });

  modal({
    title: `Correct usage reading — ${d.vehicle.registrationNo || d.vehicle.vin}`,
    width: 500,
    body: h('div', {},
      h('div', { class: 'banner banner-amber' },
        h('span', {}, '⚠'),
        h('div', { class: 'small' },
          'Usage drives every PM due calculation, so a manual correction is an audited, ' +
          'authorised action and always needs a reason (BL-VEH-006).')),
      field('Odometer (km)', km),
      field('Operating hours', hrs),
      field('Reason', reason, { required: true }),
      field('Evidence reference', evidence)),
    actions: [{
      label: 'Record correction', class: 'btn-primary',
      onClick: async () => {
        if (!reason.value.trim()) { toast('A reason is required for a usage correction.', 'err'); return false; }
        try {
          await api.post(`/api/v1/vehicles/${encodeURIComponent(d.vehicle.vin)}/usage`, {
            odometerKm: Number(km.value), operatingHours: Number(hrs.value),
            reason: reason.value.trim(), evidenceRef: evidence.value || null,
          });
          toast('Usage corrected; PM obligations re-evaluated.', 'ok');
          reload();
        } catch (e) { showApiError(e); return false; }
      },
    }],
  });
}
