import { api, qs } from '../api.js';
import {
  h, pill, table, fmtNum, fmtKm, fmtDate, cardOf, field, select, modal, toast, showApiError,
} from '../ui.js';
import { setPageTitle, reference, can } from '../app.js';

export async function pmView({ params }) {
  setPageTitle('Preventive Maintenance', 'Persisted PM obligations — one per VIN, level and cycle (FR-PMO-001)');

  const ref = await reference();
  const wrap = h('div', {});
  const results = h('div', {});

  const statusSel = select(
    [{ value: 'Open', label: 'All open' }, 'Overdue', 'Due', 'Due Soon', 'Upcoming',
     'Scheduled', 'Under Service', { value: 'Completed', label: 'Completed' },
     { value: 'All', label: 'Everything' }],
    params.get('status') ?? 'Open');
  const centreSel = select(
    [{ value: '', label: 'All service centres' },
     ...ref.serviceCentres.map(c => ({ value: c.service_centre_id, label: c.name }))],
    params.get('serviceCentreId') ?? '');
  const vinInput = h('input', { type: 'text', placeholder: 'VIN or registration' });

  const counters = h('div', { class: 'grid g4', style: 'margin-bottom:14px' });

  async function load() {
    results.replaceChildren(h('div', { class: 'spin' }, 'Loading obligations…'));
    const data = await api.get('/api/v1/pm/obligations' + qs({
      status: statusSel.value, serviceCentreId: centreSel.value,
      vin: vinInput.value.trim(), limit: 200,
    }));

    const c = data.statusCounts ?? {};
    counters.replaceChildren(
      counterTile('Overdue', c['Overdue'] ?? 0, 'i-red', '⏰'),
      counterTile('Due', c['Due'] ?? 0, 'i-amber', '📌'),
      counterTile('Due Soon', c['Due Soon'] ?? 0, 'i-amber', '🔜'),
      counterTile('Upcoming', c['Upcoming'] ?? 0, 'i-blue', '📅'));

    results.replaceChildren(cardOf(
      `${fmtNum(data.total)} obligation${data.total === 1 ? '' : 's'}`,
      table([
        { label: 'Vehicle', render: r => h('div', {},
            h('a', { href: `#/vehicles/${r.vin}` }, r.registration_no || r.vin),
            h('div', { class: 'small muted' }, r.variant_name)) },
        { label: 'Customer', key: 'customer_name' },
        { label: 'PM level', render: r => h('div', {},
            h('div', {}, r.pm_level),
            h('div', { class: 'small muted' }, `cycle ${r.cycle_no} · ${r.plan_code}`)) },
        { label: 'Trigger', render: r => r.driving_trigger ?? '—' },
        { label: 'Target', render: r => h('div', {},
            r.target_km ? h('div', {}, fmtKm(r.target_km)) : null,
            r.target_date ? h('div', { class: 'small muted' }, fmtDate(r.target_date)) : null,
            r.target_hours ? h('div', { class: 'small muted' }, `${fmtNum(r.target_hours)} hrs`) : null) },
        { label: 'Current', num: true, render: r => h('div', {},
            h('div', {}, fmtKm(r.current_odometer_km)),
            r.usage_is_stale ? h('div', { class: 'small', style: 'color:var(--amber)' }, 'estimated') : null) },
        { label: 'Remaining', num: true, render: r => {
            if (r.target_km == null) return '—';
            const rem = Number(r.target_km) - Number(r.current_odometer_km ?? 0);
            return h('span', { style: rem < 0 ? 'color:var(--red);font-weight:600' : '' },
              `${fmtNum(rem)} km`);
          } },
        { label: 'Status', render: r => pill(r.status) },
        { label: '', render: r => r.appointment_no
            ? h('span', { class: 'small muted' }, `Booked ${fmtDate(r.slot_start)}`)
            : (['Due', 'Overdue', 'Due Soon'].includes(r.status) && can('appointment.book')
                ? h('button', {
                    class: 'btn btn-sm btn-primary',
                    onclick: (e) => { e.stopPropagation(); bookModal(r, ref, load); },
                  }, 'Schedule')
                : '—') },
      ], data.rows, { empty: 'No obligations match these filters.' })));
  }

  function counterTile(label, n, cls, icon) {
    return h('div', { class: 'tile', onclick: () => { statusSel.value = label; load(); } },
      h('div', { class: `tico ${cls}` }, icon),
      h('div', { class: 'tbody' },
        h('div', { class: 'tlabel' }, label),
        h('div', { class: 'tvalue' }, fmtNum(n))));
  }

  const apply = () => load();
  for (const s of [statusSel, centreSel]) s.addEventListener('change', apply);
  vinInput.addEventListener('keydown', e => { if (e.key === 'Enter') apply(); });

  wrap.appendChild(h('div', { class: 'filters' },
    field('Status', statusSel), field('Service centre', centreSel), field('Vehicle', vinInput),
    h('button', { class: 'btn btn-primary', onclick: apply }, 'Apply'),
    h('div', { class: 'spacer' }),
    h('a', { class: 'btn', href: '#/appointments' }, 'Capacity & appointments')));
  wrap.appendChild(counters);
  wrap.appendChild(results);

  await load();
  return wrap;
}

/** Appointment booking, validated against bay and technician capacity (CAP-001). */
export function bookModal(obligation, ref, onDone) {
  const centreSel = select(ref.serviceCentres.filter(c => c.centre_type !== 'Mobile')
    .map(c => ({ value: c.service_centre_id, label: c.name })), obligation.service_centre_id);
  const dateInput = h('input', { type: 'date', value: new Date(Date.now() + 86400000).toISOString().slice(0, 10) });
  const timeSel = select(['08:00', '09:00', '10:00', '11:00', '12:00', '14:00', '15:00', '16:00'], '09:00');
  const baySel = select([{ value: '', label: 'Any available bay' }], '');
  const techSel = select([{ value: '', label: 'Assign later' }], '');
  const minutes = h('input', { type: 'number', value: 240, min: 30, step: 15 });
  const notes = h('textarea', { placeholder: 'Notes for the workshop…' });
  const capacityNote = h('div', { class: 'small muted' }, 'Select a centre and date to see capacity.');

  async function loadCapacity() {
    try {
      const cap = await api.get(
        `/api/v1/service-centres/${centreSel.value}/capacity?date=${dateInput.value}`);
      baySel.replaceChildren(
        h('option', { value: '' }, 'Any available bay'),
        ...cap.bays.map(b => h('option', { value: b.bayId },
          `${b.bayCode} — ${b.utilisationPct}% booked`)));
      techSel.replaceChildren(
        h('option', { value: '' }, 'Assign later'),
        ...cap.technicians.filter(t => t.is_available).map(t => h('option', { value: t.technician_id },
          `${t.name} — ${Math.round(t.booked_minutes / 60)}h booked${t.skills.includes('HV_BATTERY') ? ' · HV' : ''}`)));
      capacityNote.textContent = cap.isWorkingDay
        ? `${cap.bays.length} bays, ${cap.technicians.filter(t => t.is_available).length} technicians available. ` +
          `${cap.appointments.length} appointment(s) already booked.`
        : '⚠ This service centre is closed on the selected date under its business calendar.';
      capacityNote.style.color = cap.isWorkingDay ? '' : 'var(--amber)';
    } catch (e) { capacityNote.textContent = 'Could not load capacity.'; }
  }
  centreSel.addEventListener('change', loadCapacity);
  dateInput.addEventListener('change', loadCapacity);
  loadCapacity();

  modal({
    title: `Schedule ${obligation.pm_level} — ${obligation.registration_no || obligation.vin}`,
    body: h('div', {},
      h('div', { class: 'banner banner-blue' },
        h('div', {},
          h('b', {}, 'Scheduling does not close the PM obligation. '),
          h('span', { class: 'small' },
            'The obligation stays open and returns to the due queue on a no-show (BL-PM-011 / FR-APT-003).'))),
      field('Service centre', centreSel, { required: true }),
      h('div', { class: 'grid g2' },
        field('Date', dateInput, { required: true }),
        field('Start time', timeSel, { required: true })),
      h('div', { class: 'grid g2' },
        field('Bay', baySel), field('Technician', techSel)),
      field('Estimated duration (minutes)', minutes,
        { hint: 'Pre-filled from the Standard Repair Time master (FR-APT-002).' }),
      field('Notes', notes),
      capacityNote),
    actions: [
      { label: 'Cancel', onClick: () => true },
      {
        label: 'Book appointment', class: 'btn-primary',
        onClick: async () => {
          try {
            await api.post('/api/v1/appointments', {
              vin: obligation.vin,
              pmObligationId: obligation.pm_obligation_id,
              serviceCentreId: Number(centreSel.value),
              bayId: baySel.value ? Number(baySel.value) : null,
              technicianId: techSel.value ? Number(techSel.value) : null,
              serviceType: 'Preventive Maintenance',
              slotStart: new Date(`${dateInput.value}T${timeSel.value}:00`).toISOString(),
              estimatedMinutes: Number(minutes.value),
              requestNotes: notes.value.trim() || null,
            });
            toast('Appointment booked.', 'ok');
            onDone?.();
            return true;
          } catch (e) { showApiError(e); return false; }
        },
      },
    ],
  });
}
