import { api, qs } from '../api.js';
import { h, pill, table, fmtNum, fmtDateTime, ago, cardOf, field, select, clear } from '../ui.js';
import { setPageTitle, reference, state } from '../app.js';

export async function adminView() {
  setPageTitle('Administration', 'Configuration readiness, integrations, audit and master data');

  const panel = h('div', { style: 'margin-top:14px' });
  const TABS = [
    ['Configuration readiness', configTab],
    ['Integration health', integrationTab],
    ['Master data', masterTab],
    ['Audit trail', auditTab],
    ['Access & scope', accessTab],
  ];
  const tabBar = h('div', { class: 'tabs' });
  TABS.forEach(([label, fn], i) => {
    const btn = h('button', { class: i === 0 ? 'active' : '' }, label);
    btn.addEventListener('click', async () => {
      tabBar.querySelectorAll('button').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      panel.replaceChildren(h('div', { class: 'spin' }));
      panel.replaceChildren(await fn());
    });
    tabBar.appendChild(btn);
  });
  panel.replaceChildren(await TABS[0][1]());
  return h('div', {}, h('div', { class: 'card' }, tabBar), panel);
}

async function configTab() {
  const d = await api.get('/api/v1/configuration/readiness');
  return h('div', {},
    h('div', { class: 'banner banner-blue' },
      h('span', {}, 'ℹ'),
      h('div', {},
        h('b', {}, 'Publication gate. '),
        h('span', { class: 'small' }, d.rule))),
    h('div', { class: 'grid g2' },
      cardOf(`Placeholder models (${d.placeholderModels.length})`,
        table([
          { label: 'Model', render: r => h('div', {},
              h('div', {}, r.model_name),
              h('div', { class: 'small muted mono' }, r.model_code)) },
          { label: 'Model status', render: r => pill(r.confirmation_status) },
          { label: 'Variant', key: 'variant_name' },
          { label: 'Variant status', render: r => pill(r.variant_status) },
          { label: 'Vehicles', num: true, key: 'vehicles' },
        ], d.placeholderModels, { empty: 'Every model and variant is confirmed.' }),
        h('span', { class: 'small muted' }, 'CFG-001 / BL-CFG-001')),
      cardOf(`Blocked configuration (${d.blockedConfiguration.length})`,
        table([
          { label: 'Type', key: 'config_type' },
          { label: 'Code', render: r => h('span', { class: 'mono small' }, r.config_code) },
          { label: 'Referenced model', render: r => h('span', { class: 'mono small' }, r.model_code) },
          { label: 'Status', render: r => pill(r.approval_status) },
        ], d.blockedConfiguration, { empty: 'No configuration is blocked from publication.' }),
        h('span', { class: 'small muted' }, 'CFG-003'))));
}

async function integrationTab() {
  const d = await api.get('/api/v1/integration/health');
  return h('div', {},
    d.staleVehicles
      ? h('div', { class: 'banner banner-amber' },
          h('span', {}, '⚠'),
          h('div', {},
            h('b', {}, `${d.staleVehicles} vehicle(s) have a stale telematics feed. `),
            h('span', { class: 'small' },
              'PM due status for those vehicles is calculated from projected usage and marked ' +
              'estimated (BL-USG-003/004).')))
      : null,
    h('div', { class: 'grid g2' },
      cardOf('Connector health',
        table([
          { label: 'Connector', key: 'connector_name' },
          { label: 'Last success', render: r => r.last_success_at
              ? h('div', {}, h('div', {}, fmtDateTime(r.last_success_at)),
                  h('div', { class: 'small muted' }, ago(r.last_success_at)))
              : '—' },
          { label: 'Queue depth', num: true, key: 'queue_depth' },
          { label: 'Status', render: r => pill(r.status) },
        ], d.connectors, { empty: 'No connectors have reported yet.' })),
      cardOf(`Open integration errors (${d.openErrors.length})`,
        table([
          { label: 'Source', key: 'source_system' },
          { label: 'Interface', key: 'interface_name' },
          { label: 'Type', key: 'error_type' },
          { label: 'Message', render: r => h('div', { style: 'max-width:340px' }, r.error_message) },
          { label: 'When', render: r => ago(r.created_at) },
          { label: 'Status', render: r => pill(r.status) },
        ], d.openErrors, { empty: 'No open integration errors.' }))),
    h('div', { style: 'height:14px' }),
    cardOf('Recent telematics events',
      table([
        { label: 'VIN', render: r => h('span', { class: 'mono small' }, r.vin) },
        { label: 'Odometer', num: true, render: r => r.odometer_km ? fmtNum(r.odometer_km) : '—' },
        { label: 'Source timestamp', render: r => fmtDateTime(r.source_timestamp_utc) },
        { label: 'Received', render: r => ago(r.received_at) },
        { label: 'Accepted', render: r => r.accepted ? pill('Accepted', 'p-green') : pill('Quarantined', 'p-red') },
        { label: 'Reason', render: r => r.rejection_reason
            ? h('div', { class: 'small', style: 'max-width:420px;color:var(--red)' }, r.rejection_reason)
            : '—' },
      ], d.recentTelematics, { empty: 'No telematics events received.' }),
      h('span', { class: 'small muted' },
        'Unknown VINs and implausible readings are quarantined, never auto-applied (Doc 04 §27)')));
}

async function masterTab() {
  const ref = await reference();
  return h('div', { class: 'grid g2' },
    cardOf(`Vehicle variants (${ref.variants.length})`,
      table([
        { label: 'Category', key: 'category_code' },
        { label: 'Family', key: 'family_name' },
        { label: 'Model', key: 'model_name' },
        { label: 'Variant', key: 'name' },
        { label: 'Code', render: r => h('span', { class: 'mono small' }, r.code) },
        { label: 'Status', render: r => pill(r.confirmation_status) },
      ], ref.variants, {})),
    h('div', {},
      cardOf(`Service centres (${ref.serviceCentres.length})`,
        table([
          { label: 'Code', render: r => h('span', { class: 'mono small' }, r.code) },
          { label: 'Name', key: 'name' },
          { label: 'Type', key: 'centre_type' },
          { label: 'City', key: 'city' },
          { label: 'Capabilities', render: r => h('div', { style: 'display:flex;gap:3px;flex-wrap:wrap' },
              (r.capabilities ?? []).map(c => h('span', { class: 'pill p-grey', style: 'font-size:10px' }, c))) },
        ], ref.serviceCentres, {})),
      h('div', { style: 'height:14px' }),
      cardOf(`SLA master (${ref.slas.length})`,
        table([
          { label: 'Code', render: r => h('span', { class: 'mono small' }, r.code) },
          { label: 'Service type', key: 'service_type' },
          { label: 'Priority', render: r => r.priority ? pill(r.priority) : '—' },
          { label: 'Response', render: r => r.response_minutes ? `${r.response_minutes} min` : '—' },
          { label: 'Restore', render: r => r.restore_minutes ? `${Math.round(r.restore_minutes / 60)} h` : '—' },
        ], ref.slas, {}))));
}

async function auditTab() {
  const wrap = h('div', {});
  const results = h('div', {});
  const typeSel = select([{ value: '', label: 'All entity types' },
    'Vehicle', 'JobCard', 'PMObligation', 'ServiceEvent', 'Appointment', 'PartUsage',
    'VehicleRelease', 'Concession', 'VehicleStatusLedger', 'ApplicationUser', 'Defect'], '');

  async function load() {
    results.replaceChildren(h('div', { class: 'spin' }));
    const rows = await api.get('/api/v1/audit' + qs({ entityType: typeSel.value, limit: 200 }));
    results.replaceChildren(cardOf(`${rows.length} audit event${rows.length === 1 ? '' : 's'}`,
      table([
        { label: 'When', render: r => fmtDateTime(r.occurred_at) },
        { label: 'Entity', render: r => h('div', {},
            h('div', {}, r.entity_type),
            h('div', { class: 'small muted' }, r.entity_id ? `#${r.entity_id}` : '')) },
        { label: 'Action', render: r => h('span', { class: 'pill p-grey' }, r.action) },
        { label: 'Actor', key: 'actor' },
        { label: 'Reason', render: r => h('div', { style: 'max-width:380px' }, r.reason ?? '—') },
        { label: 'Detail', render: r => r.after_value
            ? h('details', {}, h('summary', { class: 'small' }, 'view'),
                h('pre', { class: 'small mono', style: 'white-space:pre-wrap;margin:6px 0 0' },
                  JSON.stringify(r.after_value, null, 1)))
            : '—' },
      ], rows, { empty: 'No audit events.' }),
      h('span', { class: 'small muted' }, 'Append-only; not deletable through the application (BL-SEC-009/010)')));
  }
  typeSel.addEventListener('change', load);
  wrap.appendChild(h('div', { class: 'filters' }, field('Entity type', typeSel),
    h('button', { class: 'btn btn-primary', onclick: load }, 'Refresh')));
  wrap.appendChild(results);
  await load();
  return wrap;
}

async function accessTab() {
  const u = state.user;
  return h('div', { class: 'grid g2' },
    cardOf('Your access', h('div', { class: 'card-body' },
      h('div', { class: 'kv' },
        h('div', {}, 'User'), h('div', {}, `${u.displayName} (${u.username})`),
        h('div', {}, 'Roles'), h('div', {}, h('div', { style: 'display:flex;gap:4px;flex-wrap:wrap' },
          u.roles.map(r => h('span', { class: 'pill p-blue' }, r)))),
        h('div', {}, 'Scope'), h('div', {},
          u.isGlobal ? pill('Global', 'p-purple')
            : h('span', {}, `${u.serviceCentreIds.length} service centre(s), ` +
                `${u.organisationIds.length} organisation(s)`)),
        h('div', {}, 'Permissions'), h('div', {},
          h('div', { style: 'display:flex;gap:3px;flex-wrap:wrap' },
            u.permissions.map(p => h('span', { class: 'pill p-grey', style: 'font-size:10px' }, p))))),
      h('div', { class: 'small muted', style: 'margin-top:12px' },
        'Every list, dashboard and API response is filtered by this scope on the server. ' +
        'Hiding controls in the interface is never the access control (FR-ORG-002, Doc 03 §11).'))),
    cardOf('Authorisation model', h('div', { class: 'card-body' },
      h('p', { class: 'small' },
        'Privileged actions resolve to a named role in the authorisation matrix. There is no generic ' +
        'unrestricted override (BL-SEC-008). Actions currently governed:'),
      table([
        { label: 'Action', key: 'a' }, { label: 'Control', key: 'c' },
      ], [
        { a: 'config.publish', c: 'Maker-checker; creator may not self-approve' },
        { a: 'breakdown.downgrade_p1', c: 'Reason mandatory; audited' },
        { a: 'usage.correct', c: 'Reason and evidence mandatory; source retained' },
        { a: 'offhire.set', c: 'Evidence and expected return mandatory' },
        { a: 'pm.override_next', c: 'Reason mandatory; audited' },
        { a: 'concession.approve', c: 'Expiry and follow-up mandatory' },
        { a: 'qc.release', c: 'Repairer may not release (segregation of duties)' },
        { a: 'qc.remote', c: 'Evidence mandatory; field-service exception only' },
        { a: 'jobcard.reopen', c: 'Reason mandatory; prior closure preserved' },
        { a: 'availability.correct', c: 'Correction creates a replacement interval, never a delete' },
      ], {}))));
}
