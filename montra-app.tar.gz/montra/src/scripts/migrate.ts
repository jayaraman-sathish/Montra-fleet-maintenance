/**
 * Idempotent startup migration.
 *
 * On a fresh database (no `master.vehicle` table) this applies the schema and
 * reference seed, and optionally the demo data. On an existing database it
 * does nothing. Controlled by environment variables so a production deployment
 * can disable it entirely:
 *
 *   MIGRATE_ON_START=true   apply schema + reference data if missing
 *   SEED_DEMO_DATA=true     also load the demonstration fleet
 */

import * as fs from 'node:fs';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';
import { pool, one } from '../lib/db.ts';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_DIR = path.resolve(__dirname, '../../db');

export async function isInitialised(): Promise<boolean> {
  try {
    const r = await one<any>(pool, `
      SELECT to_regclass('master.vehicle') IS NOT NULL AS present`);
    return !!r?.present;
  } catch {
    return false;
  }
}

export async function migrateIfNeeded(): Promise<{ applied: boolean; seeded: boolean }> {
  if (await isInitialised()) {
    console.log('[migrate] database already initialised — nothing to do');
    return { applied: false, seeded: false };
  }

  console.log('[migrate] empty database detected — applying schema and reference data');
  for (const f of ['01_schema.sql', '02_seed_reference.sql']) {
    const sql = fs.readFileSync(path.join(DB_DIR, f), 'utf8');
    await pool.runScript(sql);
    console.log(`[migrate] applied ${f}`);
  }

  let seeded = false;
  if (process.env.SEED_DEMO_DATA === 'true') {
    console.log('[migrate] loading demonstration data…');
    await import('./seed-demo-run.ts');
    seeded = true;
  }

  return { applied: true, seeded };
}
