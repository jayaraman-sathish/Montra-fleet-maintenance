import { api } from '../api.js';
import {
  h, pill, table, fmtNum, fmtKm, fmtHours, fmtDate, fmtDateTime, ago, durationHrs,
  cardOf, field, select, modal, toast, showApiError,
} from '../ui.js';
import { setPageTitle, can, reference } from '../app.js';

export async function vehicle360View({ match }) {
  const vin = decodeURIComponent(match[1]);
  const d = await api.get(`/api/v1/vehicles/${encodeURIComponent(vin)}/360`);
  const v = d.vehicle;

  setPageTitle(v.registrationNo || v.vin, `${v.model} · ${v.variant} · ${v.customer}`);

  // ---------------- header ----------------
  const header = h('div', { class: 'card', style: 'margin-bottom:14px' },
    h('div', { class: 'card-body' },
      h('div', { style: 'display:flex;gap:18px;align-items:flex-start;flex-wrap:wrap' },
        h('div', { style: 'flex:1;min-width:260px' },
          h('div', { style: 'display:flex;align-items:center;gap:10px;flex-wrap:wrap' },
            h('h2', { style: 'margin:0;font-size:22px' }, v.registrationNo || v.vin),
            pill(v.availabilityState),
            v.variantConfirmation === 'Placeholder'
              ? pill('Placeholder model', 'p-amber') : null),
          h('div', { class: 'small muted', style: 'margin-top:6px' },
            h('span', { class: 'mono' }, v.vin), ' · ', v.category, ' · ', v.model, ' ', v.variant),
          h('div', { class: 'small muted', style: 'margin-top:3px' },
            `Customer: ${v.customer}`, v.depot ? ` · Depot: ${v.depot}` : '',
            v.serviceCentre ? ` · Service centre: ${v.serviceCentre}` : '')),
        h('div', { style: 'display:flex;gap:22px;flex-wrap:wrap' },
          metric('Odometer', fmtKm(v.odometerKm),
            v.usageIsStale ? 'stale feed' : ago(v.usageUpdatedAt), v.usageIsStale),
          metric('Operating hours', fmtHours(v.operatingHours), v.usageSource),
          metric('Availability (30d)',
            d.availability.availabilityPct !== null ? `${d.availability.availabilityPct}%` : '—',
            `${durationHrs(d.availability.downHours ?? d.availability.downSeconds / 3600)} down`),
          metric('Open defects', String(d.defects.filter(x => ['Open', 'Under Action'].includes(x.status)).length),
            `${d.defects.filter(x => x.status === 'Deferred').length} deferred`)))));

  function metric(label, value, note, warn) {
    return h('div', {},
      h('div', { class: 'small muted' }, label),
      h('div', { style: 'font-size:19px;font-weight:680;margin-top:2px' }, value),
      note ? h('div', { class: 'small', style: warn ? 'color:var(--amber)' : 'color:var(--ink-3)' }, note) : null);
  }

  // ---------------- tabs ----------------
  const TABS = [
    ['Overview', overviewTab],
    ['Components', componentsTab],
    ['PM Obligations', pmTab],
    ['Service History', historyTab],
    ['Defects', defectsTab],
    ['Documents', documentsTab],
    ['Uptime History', uptimeTab],
    ['Warranty & Entitlements', warrantyTab],
    ['Campaigns', campaignsTab],
  ];

  const panel = h('div', { style: 'margin-top:14px' });
  const tabBar = h('div', { class: 'tabs' });

  TABS.forEach(([label, fn], i) => {
    const btn = h('button', { class: i === 0 ? 'active' : '' }, label);
    btn.addEventListener('click', () => {
      tabBar.querySelectorAll('button').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      panel.replaceChildren(fn(d));
    });
    tabBar.appendChild(btn);
  });
  panel.appendChild(TABS[0][1](d));

  return h('div', {}, header, h('div', { class: 'card' }, tabBar), panel);
}

/* ---------------- tabs ---------------- */

function overviewTab(d) {
  const v = d.vehicle;
  const info = cardOf('Vehicle Information', h('div', { class: 'card-body' },
    h('div', { class: 'kv' },
      kv('Vehicle No.', v.registrationNo), kv('VIN', h('span', { class: 'mono' }, v.vin)),
      kv('Model', v.model), kv('Variant', v.variant),
      kv('Category', v.category), kv('Family', v.family),
      kv('Battery', v.batteryCapacityKwh ? `${v.batteryCapacityKwh} kWh ${v.batteryConfiguration ?? ''}` : '—'),
      kv('Motor', v.motorType), kv('Transmission', v.transmission ?? '—'),
      kv('Axle config', v.axleConfiguration ?? '—'),
      kv('Customer', v.customer), kv('Depot', v.depot ?? '—'),
      kv('Service centre', v.serviceCentre ?? '—'),
      kv('Commissioned', fmtDate(v.commissioningDate)),
      kv('Warranty', v.warrantyEnd
        ? `to ${fmtDate(v.warrantyEnd)} / ${fmtNum(v.warrantyKmLimit)} km` : '—'),
      kv('Status', pill(v.lifecycleStatus)))));

  const openOb = d.openObligations[0];
  const status = cardOf('Current Status', h('div', { class: 'card-body' },
    h('div', { style: 'display:flex;align-items:center;gap:12px;margin-bottom:14px;padding:12px;background:var(--bg);border-radius:8px' },
      h('div', { style: 'font-size:26px' }, v.availabilityState.startsWith('Down') ? '🛠' : '🚚'),
      h('div', {},
        h('div', { style: 'font-weight:650' }, v.availabilityState),
        d.currentState
          ? h('div', { class: 'small muted' }, `Since ${fmtDateTime(d.currentState.start_utc)}`)
          : null)),
    h('div', { class: 'kv' },
      kv('Next PM', openOb
        ? h('span', {}, openOb.pm_level, ' ', pill(openOb.status))
        : 'No open obligation'),
      kv('Next PM target', openOb
        ? [openOb.target_km ? fmtKm(openOb.target_km) : null,
           openOb.target_date ? fmtDate(openOb.target_date) : null].filter(Boolean).join(' / ')
        : '—'),
      kv('Driving trigger', openOb?.liveEvaluation?.drivingTrigger ?? '—'),
      kv('Remaining', openOb?.liveEvaluation
        ? openOb.liveEvaluation.triggers.map(t =>
            `${fmtNum(t.remaining)} ${t.unit}`).join(' · ')
        : '—'),
      kv('Open service events', d.openServiceEvents.length
        ? d.openServiceEvents.map(e => e.service_event_no).join(', ') : 'None'),
      kv('Usage source', `${v.usageSource}${v.usageIsStale ? ' (stale)' : ''}`))));

  const docs = cardOf('Compliance & Documents', h('div', { class: 'card-body' },
    d.documents.length
      ? h('div', { class: 'kv' },
          d.documents.flatMap(doc => [
            h('div', {}, doc.document_type),
            h('div', {}, pill(doc.renewal_status), ' ',
              h('span', { class: 'small muted' }, doc.expiry_date ? `to ${fmtDate(doc.expiry_date)}` : '')),
          ]))
      : h('div', { class: 'muted' }, 'No documents recorded.')));

  return h('div', { class: 'grid g3' }, info, status, docs);
}

function kv(label, value) {
  return [h('div', {}, label), h('div', {}, value instanceof Node ? value : (value ?? '—'))];
}

function componentsTab(d) {
  return cardOf('Installed Components',
    table([
      { label: 'Component', key: 'component_type' },
      { label: 'Part No.', render: r => h('span', { class: 'mono' }, r.part_no ?? '—') },
      { label: 'Serial No.', render: r => h('span', { class: 'mono' }, r.serial_no) },
      { label: 'Installed', render: r => fmtDate(r.installed_on) },
      { label: 'At odometer', num: true, render: r => fmtKm(r.installed_odometer_km) },
      { label: 'Removed', render: r => r.removed_on ? fmtDate(r.removed_on) : '—' },
      { label: 'Warranty to', render: r => fmtDate(r.warranty_end) },
      { label: 'Status', render: r => pill(r.condition_status) },
    ], d.components, { empty: 'No serialised components recorded for this vehicle.' }));
}

function pmTab(d) {
  const open = d.openObligations;
  const all = d.pmObligations;

  function obligationBlock(o) {
    const triggerRows = (o.liveEvaluation?.triggers ?? []).map(t => {
      const target = t.triggerType === 'KM' ? fmtKm(o.target_km)
                   : t.triggerType === 'Calendar' ? fmtDate(o.target_date)
                   : fmtHours(o.target_hours);
      return h('tr', {},
        h('td', {}, t.triggerType),
        h('td', {}, target),
        h('td', { class: 'num' }, `${fmtNum(t.remaining)} ${t.unit}`),
        h('td', {}, pill(t.status)));
    });

    const head = h('thead', {}, h('tr', {},
      h('th', {}, 'Trigger'), h('th', {}, 'Target'),
      h('th', { class: 'num' }, 'Remaining'), h('th', {}, 'Status')));

    return h('div', { style: 'margin-bottom:14px' },
      h('div', { style: 'display:flex;gap:9px;align-items:center;margin-bottom:8px' },
        h('b', {}, `${o.pm_level} · cycle ${o.cycle_no}`),
        pill(o.status),
        o.is_estimated ? pill('Estimated', 'p-amber') : null),
      h('div', { class: 'table-wrap' },
        h('table', { class: 'data' }, head, h('tbody', {}, triggerRows))),
      h('div', { class: 'small muted', style: 'margin-top:6px' },
        `Driving trigger: ${o.liveEvaluation?.drivingTrigger ?? '—'} — the earliest threshold ` +
        `reached determines PM status (BL-PM-005..008).`));
  }

  const liveCard = open.length
    ? cardOf('Open obligation — live evaluation',
        h('div', { class: 'card-body' }, open.map(obligationBlock)))
    : null;

  const history = cardOf('All PM obligations',
    table([
      { label: 'Cycle', num: true, key: 'cycle_no' },
      { label: 'PM level', key: 'pm_level' },
      { label: 'Plan', key: 'plan_code' },
      { label: 'Target km', num: true, render: r => fmtKm(r.target_km) },
      { label: 'Target date', render: r => fmtDate(r.target_date) },
      { label: 'Actual km', num: true, render: r => fmtKm(r.actual_completion_km) },
      { label: 'Completed', render: r => fmtDate(r.actual_completion_date) },
      { label: 'Variance', num: true, render: r => r.variance_days !== null && r.variance_days !== undefined
          ? `${r.variance_days > 0 ? '+' : ''}${r.variance_days} d` : '—' },
      { label: 'Status / outcome', render: r => pill(r.outcome ?? r.status) },
    ], d.pmObligations, { empty: 'No PM obligations.' }));

  return h('div', {}, liveCard, liveCard ? h('div', { style: 'height:14px' }) : null, history);
}

function historyTab(d) {
  return cardOf('Service History',
    table([
      { label: 'Service event', render: r => h('div', {},
          h('span', { class: 'mono' }, r.service_event_no),
          h('div', { class: 'small muted' }, r.event_type)) },
      { label: 'Started', render: r => fmtDateTime(r.customer_visible_start) },
      { label: 'Closed', render: r => fmtDateTime(r.customer_visible_end) },
      { label: 'Priority', render: r => r.priority ? pill(r.priority) : '—' },
      { label: 'Job card', render: r => r.job_card_no
          ? h('a', { href: `#/job-cards/${r.job_card_id}` }, r.job_card_no) : '—' },
      { label: 'Centre', key: 'centre_name' },
      { label: 'Repeat', render: r => r.is_repeat ? pill('Repeat', 'p-red') : '—' },
      { label: 'First-time fix', render: r => r.ftf_result ? pill(r.ftf_result) : '—' },
      { label: 'Status', render: r => pill(r.status) },
    ], d.serviceHistory, { empty: 'No service history for this vehicle.' }));
}

function defectsTab(d) {
  return cardOf('Defects (VIN-owned)',
    table([
      { label: 'Defect', render: r => h('span', { class: 'mono' }, r.defect_no) },
      { label: 'Severity', render: r => pill(r.severity) },
      { label: 'Subsystem', key: 'subsystem' },
      { label: 'Description', render: r => h('div', { style: 'max-width:420px' }, r.description) },
      { label: 'Opened', render: r => fmtDate(r.opened_date) },
      { label: 'Due by', render: r => [r.due_by_date ? fmtDate(r.due_by_date) : null,
          r.due_by_km ? fmtKm(r.due_by_km) : null].filter(Boolean).join(' / ') || '—' },
      { label: 'Blocks release', render: r => r.blocks_release ? pill('Yes', 'p-red') : 'No' },
      { label: 'Carried fwd', render: r => r.carried_forward ? '✓' : '—' },
      { label: 'Status', render: r => pill(r.status) },
    ], d.defects, { empty: 'No defects recorded.' }),
    h('span', { class: 'small muted' },
      'Deferred defects stay with the vehicle and attach to later service (BL-DEF-001).'));
}

function documentsTab(d) {
  return cardOf('Statutory Documents',
    table([
      { label: 'Document', key: 'document_type' },
      { label: 'Number', render: r => h('span', { class: 'mono' }, r.document_no ?? '—') },
      { label: 'Authority', key: 'issuing_authority' },
      { label: 'Issued', render: r => fmtDate(r.issue_date) },
      { label: 'Expires', render: r => fmtDate(r.expiry_date) },
      { label: 'Status', render: r => pill(r.renewal_status) },
    ], d.documents, { empty: 'No documents recorded.' }));
}

function uptimeTab(d) {
  const a = d.availability;
  const summary = h('div', { class: 'card-body' },
    h('div', { style: 'display:flex;gap:26px;flex-wrap:wrap;margin-bottom:14px' },
      h('div', {}, h('div', { class: 'small muted' }, 'Availability (30 days)'),
        h('div', { style: 'font-size:22px;font-weight:700' },
          a.availabilityPct !== null ? `${a.availabilityPct}%` : '—')),
      h('div', {}, h('div', { class: 'small muted' }, 'Up time'),
        h('div', { style: 'font-size:22px;font-weight:700' }, durationHrs(a.upSeconds / 3600))),
      h('div', {}, h('div', { class: 'small muted' }, 'Down time'),
        h('div', { style: 'font-size:22px;font-weight:700' }, durationHrs(a.downSeconds / 3600))),
      h('div', {}, h('div', { class: 'small muted' }, 'Excluded (off-hire)'),
        h('div', { style: 'font-size:22px;font-weight:700' }, durationHrs(a.excludedSeconds / 3600)))),
    a.breakdown.length
      ? h('div', {}, a.breakdown.map(b => h('div', {
          style: 'display:grid;grid-template-columns:220px 1fr 80px;gap:10px;align-items:center;margin-bottom:8px',
        },
          h('div', { class: 'small' }, b.state),
          h('div', { class: 'bar' }, h('span', {
            style: `width:${Math.min(100, (b.seconds / Math.max(1, a.totalSeconds)) * 100)}%;` +
                   `background:${b.isDown ? 'var(--red)' : 'var(--green)'}`,
          })),
          h('div', { class: 'small', style: 'text-align:right' }, durationHrs(b.hours)))))
      : null);

  const ledger = table([
    { label: 'State', render: r => pill(r.availability_state) },
    { label: 'Reason', render: r => h('span', { class: 'small mono' }, r.reason_code ?? '—') },
    { label: 'From', render: r => fmtDateTime(r.start_utc) },
    { label: 'To', render: r => r.end_utc ? fmtDateTime(r.end_utc) : h('span', { class: 'pill p-blue' }, 'Open') },
    { label: 'Duration', render: r => r.gross_seconds ? durationHrs(r.gross_seconds / 3600) : '—' },
    { label: 'Attribution', key: 'attribution_party' },
    { label: 'Source', key: 'source_type' },
    { label: 'Rule', render: r => h('span', { class: 'small mono muted' }, r.transition_rule_id ?? '—') },
  ], d.availabilityLedger, { empty: 'No availability intervals recorded.' });

  return h('div', {},
    cardOf('Availability summary', summary),
    h('div', { style: 'height:14px' }),
    cardOf('Vehicle Status Ledger', ledger,
      h('span', { class: 'small muted' }, 'Authoritative source for uptime KPIs (FR-AVL-001)')));
}

function warrantyTab(d) {
  const v = d.vehicle;
  const cover = cardOf('Warranty coverage', h('div', { class: 'card-body' },
    h('div', { class: 'kv' },
      kv('Vehicle warranty start', fmtDate(v.warrantyStart)),
      kv('Vehicle warranty end', fmtDate(v.warrantyEnd)),
      kv('Kilometre limit', v.warrantyKmLimit ? fmtKm(v.warrantyKmLimit) : '—'),
      kv('Current odometer', fmtKm(v.odometerKm)),
      kv('Within limits', v.warrantyEnd && new Date(v.warrantyEnd) > new Date()
          && (!v.warrantyKmLimit || v.odometerKm < v.warrantyKmLimit)
        ? pill('Yes', 'p-green') : pill('No', 'p-red')))));

  const ent = cardOf('Contract / AMC entitlements',
    table([
      { label: 'Contract', key: 'contract_no' },
      { label: 'Type', key: 'contract_type' },
      { label: 'Entitlement', key: 'entitlement_type' },
      { label: 'Total', num: true, key: 'total_quantity' },
      { label: 'Consumed', num: true, key: 'consumed_quantity' },
      { label: 'Remaining', num: true, render: r => fmtNum((r.total_quantity ?? 0) - (r.consumed_quantity ?? 0)) },
      { label: 'Ends', render: r => fmtDate(r.end_date) },
    ], d.entitlements, { empty: 'No active contract or AMC entitlement for this vehicle.' }));

  const fw = cardOf('Firmware baseline',
    table([
      { label: 'ECU / module', key: 'ecu_module' },
      { label: 'Current version', render: r => h('span', { class: 'mono' }, r.current_version ?? '—') },
      { label: 'Target version', render: r => h('span', { class: 'mono' }, r.target_version ?? '—') },
      { label: 'Up to date', render: r => r.current_version === r.target_version
          ? pill('Yes', 'p-green') : pill('Update available', 'p-amber') },
      { label: 'Last updated', render: r => fmtDate(r.last_updated_on) },
      { label: 'Method', key: 'update_method' },
    ], d.firmware, { empty: 'No firmware baseline recorded.' }));

  return h('div', {}, h('div', { class: 'grid g2' }, cover, ent),
    h('div', { style: 'height:14px' }), fw);
}

function campaignsTab(d) {
  return cardOf('Campaigns & recalls',
    table([
      { label: 'Code', render: r => h('span', { class: 'mono' }, r.code) },
      { label: 'Campaign', key: 'name' },
      { label: 'Classification', render: r => pill(r.classification, r.classification === 'Safety' ? 'p-red' : 'p-blue') },
      { label: 'Mandatory by', render: r => fmtDate(r.mandatory_by_date) },
      { label: 'Status', render: r => pill(r.status) },
    ], d.campaigns, { empty: 'No campaigns apply to this vehicle.' }));
}
