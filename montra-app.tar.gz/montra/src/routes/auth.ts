/**
 * Authentication endpoints.
 */

import { Router, badRequest, unauthorized } from '../lib/http.ts';
import type { Ctx } from '../lib/http.ts';
import { pool, one, audit } from '../lib/db.ts';
import { verifyPassword, issueToken, authenticate, loadUser } from '../lib/auth.ts';

export const authRoutes = new Router();

authRoutes.post('/api/v1/auth/login', async (ctx: Ctx) => {
  const { username, password } = ctx.body ?? {};
  if (!username || !password) throw badRequest('Username and password are required.');

  const user = await one<any>(pool, `
    SELECT user_id, username, display_name, password_hash, status
    FROM security.application_user WHERE lower(username) = lower($1)`, [username]);

  if (!user || user.status !== 'Active' || !verifyPassword(password, user.password_hash)) {
    await audit(pool, {
      entityType: 'ApplicationUser', entityId: user?.user_id ?? null,
      action: 'LOGIN_FAILED', actor: String(username),
      reason: !user ? 'unknown user' : user.status !== 'Active' ? 'inactive' : 'bad password',
    });
    throw unauthorized('That username and password combination was not recognised.');
  }

  const token = issueToken({ userId: user.user_id, username: user.username });
  const principal = await loadUser(pool, user.user_id);

  await audit(pool, {
    entityType: 'ApplicationUser', entityId: user.user_id,
    action: 'LOGIN', actor: user.username,
  });

  ctx.res.setHeader('Set-Cookie',
    `montra_session=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=43200` +
    (process.env.NODE_ENV === 'production' ? '; Secure' : ''));

  return {
    token,
    user: {
      userId: principal!.userId,
      username: principal!.username,
      displayName: principal!.displayName,
      roles: principal!.roles,
      permissions: [...principal!.permissions],
      isGlobal: principal!.isGlobal,
      serviceCentreIds: principal!.serviceCentreIds,
      organisationIds: principal!.organisationIds,
    },
  };
});

authRoutes.post('/api/v1/auth/logout', async (ctx: Ctx) => {
  ctx.res.setHeader('Set-Cookie', 'montra_session=; Path=/; HttpOnly; Max-Age=0');
  return { ok: true };
});

authRoutes.get('/api/v1/auth/me', async (ctx: Ctx) => {
  const u = ctx.user!;
  return {
    userId: u.userId, username: u.username, displayName: u.displayName,
    roles: u.roles, permissions: [...u.permissions], isGlobal: u.isGlobal,
    serviceCentreIds: u.serviceCentreIds, organisationIds: u.organisationIds,
  };
}, authenticate);
