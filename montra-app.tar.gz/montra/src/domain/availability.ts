/**
 * Vehicle availability / downtime ledger.
 *
 * Implements Document 01 FR-AVL-001..005 and Document 02 §24.1
 * (BL-AVL-001..015). The ledger — not job-card timestamps — is the
 * authoritative source for uptime, downtime and availability KPIs
 * (Doc 03 §19, Doc 04 §6).
 *
 * Invariants:
 *   - exactly one open interval per VIN at any time (UPM-001, enforced by
 *     a partial unique index in the schema)
 *   - intervals are never deleted; corrections create a replacement
 *     interval linked to the original (BL-AVL-015)
 *   - every transition records the BL-AVL rule that caused it
 */

import { q, one, many, recordStatus, audit } from '../lib/db.ts';
import type { Db } from '../lib/db.ts';

export type AvailabilityState =
  | 'In Service' | 'Idle' | 'Off Hire/Suspended'
  | 'Down-PM' | 'Down-Breakdown' | 'Down-Awaiting Parts'
  | 'Down-Awaiting Customer Approval' | 'Down-Awaiting Warranty Decision'
  | 'Down-Awaiting Internal Authorization' | 'Down-Accident'
  | 'Down-Compliance' | 'Down-Charging Infrastructure' | 'Retired';

export interface TransitionInput {
  vehicleId: number;
  reasonCode: string;
  sourceType: 'Breakdown' | 'ServiceEvent' | 'JobCard' | 'Telematics'
            | 'Compliance' | 'OffHire' | 'ManualCorrection' | 'Commissioning';
  sourceEntityId?: number | null;
  ruleId: string;                 // e.g. 'BL-AVL-002'
  startUtc?: Date;
  attributionParty?: string | null;
  actor: string;
  reason?: string | null;
}

/** Current open interval for a vehicle, if any. */
export async function currentState(db: Db, vehicleId: number) {
  return one<any>(db, `
    SELECT l.*, r.is_down, r.planned_class, r.include_in_availability
    FROM uptime.vehicle_status_ledger l
    LEFT JOIN uptime.vehicle_status_reason r ON r.reason_code = l.reason_code
    WHERE l.vehicle_id = $1 AND l.end_utc IS NULL`, [vehicleId]);
}

/**
 * Close the vehicle's open interval and open a new one.
 *
 * BL-AVL-014 precedence: a lower-precedence source (for example a telematics
 * derived state) will not displace a higher-precedence one (an approved
 * breakdown stoppage). The attempt is recorded and the call returns null.
 */
export async function transition(db: Db, input: TransitionInput): Promise<number | null> {
  const startUtc = input.startUtc ?? new Date();

  const reason = await one<any>(db, `
    SELECT * FROM uptime.vehicle_status_reason WHERE reason_code = $1`, [input.reasonCode]);
  if (!reason) throw new Error(`Unknown availability reason code: ${input.reasonCode}`);

  const open = await currentState(db, input.vehicleId);

  // Already in this state — nothing to do.
  if (open && open.availability_state === reason.availability_state
      && open.reason_code === input.reasonCode) {
    return open.ledger_id;
  }

  // BL-AVL-014 source precedence:
  //   safety/breakdown stoppage evidence > approved transactional state
  //   > authorised manual correction > derived display state
  //
  // Precedence is a property of the SOURCE, not of the reason code. A
  // transactional source must always be able to progress or close the state
  // it owns — a job card returning a vehicle to service, or moving from
  // Awaiting Parts back to Repairing, is not a competing claim.
  //
  // Only telematics-derived transitions are suppressed, and only while an
  // approved transactional interval is open. This is also BL-AVL-013:
  // inactivity alone never makes a vehicle Down.
  const DERIVED_SOURCES = new Set(['Telematics']);
  const TRANSACTIONAL_SOURCES = new Set([
    'Breakdown', 'ServiceEvent', 'JobCard', 'OffHire', 'Compliance', 'Commissioning',
  ]);

  if (open && DERIVED_SOURCES.has(input.sourceType) && TRANSACTIONAL_SOURCES.has(open.source_type)) {
    await audit(db, {
      entityType: 'VehicleStatusLedger', entityId: open.ledger_id,
      action: 'TRANSITION_SUPPRESSED', actor: input.actor,
      reason: `${input.ruleId}: a ${input.sourceType}-derived state does not displace the ` +
              `approved ${open.source_type} state "${open.availability_state}" (BL-AVL-014).`,
    });
    return null;
  }

  if (open) {
    const grossSeconds = Math.max(
      0, Math.floor((startUtc.getTime() - new Date(open.start_utc).getTime()) / 1000));
    const pausedSeconds = await pausedSecondsFor(db, open.ledger_id);
    await q(db, `
      UPDATE uptime.vehicle_status_ledger
      SET end_utc = $1, gross_seconds = $2, net_seconds = $3
      WHERE ledger_id = $4`,
      [startUtc, grossSeconds, Math.max(0, grossSeconds - pausedSeconds), open.ledger_id]);
  }

  const row = await one<any>(db, `
    INSERT INTO uptime.vehicle_status_ledger
      (vehicle_id, availability_state, reason_code, start_utc, source_type, source_entity_id,
       transition_rule_id, precedence_rank, attribution_party, availability_eligible, created_by)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)
    RETURNING ledger_id`,
    [input.vehicleId, reason.availability_state, input.reasonCode, startUtc,
     input.sourceType, input.sourceEntityId ?? null, input.ruleId,
     reason.source_precedence,
     input.attributionParty ?? reason.default_attribution,
     reason.include_in_availability, input.actor]);

  // Vehicle carries a cached current state for list performance (Doc 04 §6).
  await q(db, `
    UPDATE master.vehicle SET current_availability_state = $1, updated_at = now()
    WHERE vehicle_id = $2`, [reason.availability_state, input.vehicleId]);

  await recordStatus(db, {
    entityType: 'Vehicle', entityId: input.vehicleId,
    from: open?.availability_state ?? null, to: reason.availability_state,
    actor: input.actor, reason: input.reason ?? null, ruleId: input.ruleId,
  });

  return row.ledger_id;
}

async function pausedSecondsFor(db: Db, ledgerId: number): Promise<number> {
  const r = await one<any>(db, `
    SELECT COALESCE(SUM(EXTRACT(EPOCH FROM (COALESCE(end_utc, now()) - start_utc))),0)::bigint AS s
    FROM service.clock_pause
    WHERE ledger_id = $1 AND exclude_from_net = true`, [ledgerId]);
  return Number(r?.s ?? 0);
}

/**
 * BL-AVL-015. Correct a historical interval without deleting it: the original
 * is closed and superseded by a replacement that links back to it.
 */
export async function correctInterval(db: Db, input: {
  ledgerId: number; newReasonCode?: string; newStartUtc?: Date; newEndUtc?: Date;
  actor: string; reason: string; evidenceRef?: string;
}): Promise<number> {
  const original = await one<any>(db, `
    SELECT * FROM uptime.vehicle_status_ledger WHERE ledger_id = $1`, [input.ledgerId]);
  if (!original) throw new Error('Ledger interval not found');

  const reasonCode = input.newReasonCode ?? original.reason_code;
  const reason = await one<any>(db, `
    SELECT * FROM uptime.vehicle_status_reason WHERE reason_code = $1`, [reasonCode]);

  const startUtc = input.newStartUtc ?? new Date(original.start_utc);
  const endUtc = input.newEndUtc ?? (original.end_utc ? new Date(original.end_utc) : null);

  // The original row is retained and marked ineligible rather than removed.
  await q(db, `
    UPDATE uptime.vehicle_status_ledger
    SET availability_eligible = false, end_utc = COALESCE(end_utc, now())
    WHERE ledger_id = $1`, [input.ledgerId]);

  const gross = endUtc
    ? Math.max(0, Math.floor((endUtc.getTime() - startUtc.getTime()) / 1000)) : null;

  const replacement = await one<any>(db, `
    INSERT INTO uptime.vehicle_status_ledger
      (vehicle_id, availability_state, reason_code, start_utc, end_utc, source_type,
       source_entity_id, transition_rule_id, precedence_rank, correction_of_ledger_id,
       attribution_party, gross_seconds, availability_eligible, created_by)
    VALUES ($1,$2,$3,$4,$5,'ManualCorrection',$6,'BL-AVL-015',$7,$8,$9,$10,true,$11)
    RETURNING ledger_id`,
    [original.vehicle_id, reason.availability_state, reasonCode, startUtc, endUtc,
     original.source_entity_id, reason.source_precedence, input.ledgerId,
     original.attribution_party, gross, input.actor]);

  await audit(db, {
    entityType: 'VehicleStatusLedger', entityId: input.ledgerId,
    action: 'CORRECT', actor: input.actor, reason: input.reason,
    before: { state: original.availability_state, start: original.start_utc, end: original.end_utc },
    after: { state: reason.availability_state, start: startUtc, end: endUtc,
             replacementLedgerId: replacement.ledger_id, evidence: input.evidenceRef ?? null },
  });

  return replacement.ledger_id;
}

/** Availability summary for a vehicle over a window (FR-AVL-004). */
export async function availabilitySummary(db: Db, vehicleId: number, fromUtc: Date, toUtc: Date) {
  const rows = await many<any>(db, `
    SELECT l.availability_state, l.reason_code, l.attribution_party,
           r.is_down, r.planned_class,
           SUM(EXTRACT(EPOCH FROM (
                LEAST(COALESCE(l.end_utc, $3::timestamptz), $3::timestamptz)
              - GREATEST(l.start_utc, $2::timestamptz))))::bigint AS seconds
    FROM uptime.vehicle_status_ledger l
    LEFT JOIN uptime.vehicle_status_reason r ON r.reason_code = l.reason_code
    WHERE l.vehicle_id = $1
      AND l.availability_eligible = true
      AND l.start_utc < $3::timestamptz
      AND COALESCE(l.end_utc, $3::timestamptz) > $2::timestamptz
    GROUP BY 1,2,3,4,5`, [vehicleId, fromUtc, toUtc]);

  const totalSeconds = Math.max(1, Math.floor((toUtc.getTime() - fromUtc.getTime()) / 1000));
  let upSeconds = 0, downSeconds = 0, excludedSeconds = 0;

  for (const r of rows) {
    const s = Number(r.seconds ?? 0);
    if (r.reason_code === 'OFF_HIRE' || r.reason_code === 'RETIRED') excludedSeconds += s;
    else if (r.is_down) downSeconds += s;
    else upSeconds += s;
  }

  const denominator = Math.max(1, totalSeconds - excludedSeconds);
  return {
    fromUtc, toUtc,
    totalSeconds, upSeconds, downSeconds, excludedSeconds,
    availabilityPct: Number(((upSeconds / denominator) * 100).toFixed(2)),
    breakdown: rows.map(r => ({
      state: r.availability_state, reasonCode: r.reason_code,
      attribution: r.attribution_party, plannedClass: r.planned_class,
      isDown: r.is_down, seconds: Number(r.seconds ?? 0),
      hours: Number((Number(r.seconds ?? 0) / 3600).toFixed(1)),
    })),
  };
}

/**
 * Map a job-card status change to the availability state it implies.
 * BL-AVL-002, 004, 005, 006, 007 — returns null when the status has no
 * availability consequence.
 */
export function reasonForJobStatus(status: string, jobType: string): { reasonCode: string; ruleId: string } | null {
  switch (status) {
    case 'Under Diagnosis':
    case 'Repairing':
      return jobType === 'PM'
        ? { reasonCode: 'DOWN_PM', ruleId: 'BL-AVL-002' }
        : { reasonCode: 'DOWN_BREAKDOWN', ruleId: 'BL-AVL-003' };
    case 'Awaiting Parts':
      return { reasonCode: 'DOWN_PARTS', ruleId: 'BL-AVL-004' };
    case 'Awaiting Customer Approval':
      return { reasonCode: 'DOWN_CUST_APPR', ruleId: 'BL-AVL-005' };
    case 'Awaiting Warranty Decision':
      return { reasonCode: 'DOWN_WAR_DEC', ruleId: 'BL-AVL-006' };
    case 'Awaiting Internal Authorization':
      return { reasonCode: 'DOWN_INT_AUTH', ruleId: 'BL-AVL-007' };
    case 'Awaiting Insurance':
      return { reasonCode: 'DOWN_ACCIDENT', ruleId: 'BL-AVL-008' };
    default:
      return null;
  }
}
