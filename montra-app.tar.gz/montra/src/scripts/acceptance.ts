/**
 * Acceptance test run against the Document 05 scenario catalogue.
 *
 * Exercises the Must scenarios that can be verified through the API, including
 * the negative paths. Run against a freshly seeded database:
 *
 *   node src/scripts/reset-db.ts && node src/scripts/seed-demo.ts
 *   node src/index.ts &
 *   node src/scripts/acceptance.ts
 */

const BASE = process.env.TEST_BASE_URL ?? 'http://localhost:3000';

interface Check { id: string; area: string; refs: string; desc: string; pass: boolean; note: string }
const results: Check[] = [];
const tokens = new Map<string, string>();

async function login(username: string): Promise<string> {
  if (tokens.has(username)) return tokens.get(username)!;
  const r = await fetch(`${BASE}/api/v1/auth/login`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password: 'montra123' }),
  });
  if (!r.ok) throw new Error(`login failed for ${username}`);
  const j: any = await r.json();
  tokens.set(username, j.token);
  return j.token;
}

async function call(user: string, method: string, path: string, body?: unknown) {
  const token = await login(user);
  const r = await fetch(BASE + path, {
    method,
    headers: {
      'Authorization': `Bearer ${token}`,
      ...(body !== undefined ? { 'Content-Type': 'application/json' } : {}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await r.text();
  let json: any = null;
  try { json = text ? JSON.parse(text) : null; } catch { json = { raw: text }; }
  return { status: r.status, ok: r.ok, body: json };
}

function check(id: string, area: string, refs: string, desc: string, pass: boolean, note = '') {
  results.push({ id, area, refs, desc, pass, note });
  console.log(`${pass ? '  PASS' : '  FAIL'}  ${id.padEnd(12)} ${desc}${note ? ` — ${note}` : ''}`);
}

async function run() {
  console.log('\nAcceptance run — Document 05 scenario catalogue\n' + '='.repeat(70));

  // ---------------------------------------------------------------
  console.log('\nVehicle & master data');
  {
    const list = await call('admin', 'GET', '/api/v1/vehicles?limit=5');
    check('AT-VEH-002', 'Vehicle', 'FR-VEH-002; BL-VEH-002',
      'VIN maps to exactly one Category > Family > Model > Variant',
      list.ok && list.body.rows.every((v: any) => v.variant_name && v.model_name && v.category_code),
      `${list.body?.total ?? 0} vehicles in scope`);

    const vin = list.body.rows[0].vin;
    const v360 = await call('admin', 'GET', `/api/v1/vehicles/${vin}/360`);
    check('AT-VEH-003', 'Vehicle', 'FR-VEH-004; CMP-001..003',
      'Serialised components carry install history against the VIN',
      v360.ok && Array.isArray(v360.body.components) && v360.body.components.length > 0,
      `${v360.body?.components?.length ?? 0} components on ${vin}`);
  }

  // ---------------------------------------------------------------
  console.log('\nConfiguration publication gate');
  {
    const r = await call('admin', 'GET', '/api/v1/configuration/readiness');
    check('AT-CFG-001', 'Configuration', 'CFG-001..003; BL-CFG-001..003',
      'Placeholder models are identified and their configuration is blocked from publication',
      r.ok && r.body.placeholderModels.length > 0,
      `${r.body?.placeholderModels?.length ?? 0} placeholder model/variant rows`);
  }

  // ---------------------------------------------------------------
  console.log('\nPreventive maintenance');
  {
    const q = await call('admin', 'GET', '/api/v1/pm/obligations?status=Open&limit=500');
    const counts = q.body.statusCounts ?? {};
    check('AT-PM-001..004', 'PM', 'FR-PM-001..005; BL-PM-005..008',
      'Obligations classify across Upcoming / Due Soon / Due / Overdue',
      q.ok && Object.keys(counts).length >= 2, JSON.stringify(counts));

    const overdue = q.body.rows.find((r: any) => r.status === 'Overdue');
    if (overdue) {
      const detail = await call('admin', 'GET', `/api/v1/pm/obligations/${overdue.pm_obligation_id}`);
      const ev = detail.body.liveEvaluation;
      check('AT-PM-002', 'PM', 'BL-PM-005..008',
        'The most urgent trigger drives status and is identifiable',
        detail.ok && ev.status === 'Overdue' && !!ev.drivingTrigger,
        `driven by ${ev?.drivingTrigger}, ${ev?.triggers?.length} trigger(s) evaluated`);
    }

    // Obligations are persisted per cycle and never overwritten.
    const vinWithHistory = q.body.rows.find((r: any) => r.cycle_no > 2);
    if (vinWithHistory) {
      const v360 = await call('admin', 'GET', `/api/v1/vehicles/${vinWithHistory.vin}/360`);
      const cycles = v360.body.pmObligations.map((o: any) => o.cycle_no);
      const unique = new Set(cycles).size === cycles.length;
      const completed = v360.body.pmObligations.filter((o: any) => String(o.status).startsWith('Completed'));
      check('AT-PMO-001', 'PM Obligation', 'FR-PMO-001/002; BL-PM-024..026',
        'Prior cycles persist with their outcome; the next cycle is a new row',
        v360.ok && unique && completed.length > 0,
        `${cycles.length} cycles, ${completed.length} completed with outcome`);
    }
  }

  // ---------------------------------------------------------------
  console.log('\nAvailability ledger');
  {
    const list = await call('admin', 'GET', '/api/v1/vehicles?availabilityState=Down-PM&limit=5');
    const vin = list.body.rows[0]?.vin
      ?? (await call('admin', 'GET', '/api/v1/vehicles?limit=1')).body.rows[0].vin;
    const av = await call('admin', 'GET', `/api/v1/vehicles/${vin}/availability`);
    const intervals = av.body.intervals ?? [];
    const open = intervals.filter((i: any) => !i.end_utc);

    check('AT-AVL-001/002', 'Availability', 'FR-AVL-001..003; BL-AVL-*',
      'Ledger intervals are created from job/breakdown transitions with the causing rule',
      av.ok && intervals.length > 0 && intervals.every((i: any) => i.transition_rule_id),
      `${intervals.length} intervals, rules: ${[...new Set(intervals.map((i: any) => i.transition_rule_id))].join(', ')}`);

    check('UPM-001', 'Availability', 'UPM-001',
      'Exactly one open interval per VIN — no overlaps',
      open.length <= 1, `${open.length} open interval(s)`);

    check('AT-AVL-005', 'Availability', 'KPI dictionary',
      'Availability reconciles to ledger timestamps',
      av.ok && typeof av.body.availabilityPct === 'number',
      `${av.body?.availabilityPct}% over the window`);
  }

  // ---------------------------------------------------------------
  console.log('\nAppointments & capacity');
  {
    const centres = await call('admin', 'GET', '/api/v1/reference');
    const centreId = centres.body.serviceCentres.find((c: any) => c.code === 'SC-CHN').service_centre_id;
    const date = new Date().toISOString().slice(0, 10);
    const cap = await call('ravi.kumar', 'GET', `/api/v1/service-centres/${centreId}/capacity?date=${date}`);
    check('AT-CAP-001', 'Appointment', 'FR-APT-001; CAP-001',
      'Capacity view returns bays, roster and booked minutes',
      cap.ok && cap.body.bays.length > 0 && cap.body.technicians.length > 0,
      `${cap.body?.bays?.length} bays, ${cap.body?.technicians?.length} technicians`);

    // Attempt a double booking in an occupied bay/slot.
    const existing = cap.body.appointments[0];
    if (existing) {
      const clash = await call('ravi.kumar', 'POST', '/api/v1/appointments', {
        vin: existing.vin, serviceCentreId: centreId, bayId: existing.bay_id,
        serviceType: 'Preventive Maintenance', slotStart: existing.slot_start,
        estimatedMinutes: 60,
      });
      check('AT-CAP-002', 'Appointment', 'FR-APT-001; CAP-001',
        'Double booking the same bay and slot is refused',
        clash.status === 409, clash.body?.error?.message?.slice(0, 90) ?? '');
    }
  }

  // ---------------------------------------------------------------
  console.log('\nJob card state machine');
  {
    const jobs = await call('admin', 'GET', '/api/v1/job-cards?status=Open&limit=50');
    const job = jobs.body.find((j: any) => ['Under Diagnosis', 'Repairing'].includes(j.status));

    const bad = await call('ravi.kumar', 'PATCH', `/api/v1/job-cards/${job.job_card_id}/status`,
      { status: 'Completed' });
    check('AT-JC-001', 'Job Card', 'FR-JC-010; BL-JC-003',
      'An invalid status jump is blocked with the allowed set explained',
      bad.status === 409, bad.body?.error?.message?.slice(0, 110) ?? '');

    const closed = jobs.body.find((j: any) => j.status === 'Closed');
    if (closed) {
      const edit = await call('ravi.kumar', 'PATCH', `/api/v1/job-cards/${closed.job_card_id}/status`,
        { status: 'Repairing' });
      check('AT-JC-002', 'Job Card', 'BL-JC-006; BL-SEC-009',
        'A closed job card is read-only through normal flows',
        edit.status === 409 || edit.status === 400, edit.body?.error?.code ?? '');
    }

    const noReason = await call('ravi.kumar', 'PATCH', `/api/v1/job-cards/${job.job_card_id}/status`,
      { status: 'On Hold' });
    check('BL-JC-003b', 'Job Card', 'BL-JC-003',
      'Exception transitions require a reason',
      noReason.status === 400, noReason.body?.error?.message?.slice(0, 80) ?? '');
  }

  // ---------------------------------------------------------------
  console.log('\nParts');
  {
    const jobs = await call('admin', 'GET', '/api/v1/job-cards?status=Open&limit=50');
    const job = jobs.body.find((j: any) => j.status === 'Repairing') ?? jobs.body[0];

    const applicable = await call('meena.s', 'GET', `/api/v1/parts/applicable?vin=${job.vin}`);
    check('AT-SP-001a', 'Parts', 'SPM-003/004',
      'Only parts approved for the variant are offered',
      applicable.ok && applicable.body.length > 0, `${applicable.body?.length ?? 0} applicable parts`);

    // Find a part that is NOT applicable to this vehicle.
    const allParts = await call('admin', 'GET', '/api/v1/parts/applicable?vin=' + job.vin);
    const applicableIds = new Set(allParts.body.map((p: any) => p.part_id));
    const otherVehicle = (await call('admin', 'GET', '/api/v1/vehicles?limit=40')).body.rows
      .find((v: any) => v.category_code !== 'MHCV' && v.vin !== job.vin);
    const otherParts = otherVehicle
      ? (await call('admin', 'GET', `/api/v1/parts/applicable?vin=${otherVehicle.vin}`)).body : [];
    const nonApplicable = allParts.body.length && otherParts.length
      ? allParts.body.find((p: any) => !otherParts.some((o: any) => o.part_id === p.part_id))
      : null;

    if (nonApplicable && otherVehicle) {
      const otherJob = jobs.body.find((j: any) => j.vin === otherVehicle.vin);
      if (otherJob) {
        const reject = await call('meena.s', 'POST', `/api/v1/job-cards/${otherJob.job_card_id}/parts`,
          { partId: nonApplicable.part_id, quantity: 1 });
        check('AT-SP-001', 'Parts', 'SPM-003/004; BL-SP-001',
          'A part not applicable to the variant is refused',
          reject.status === 409, reject.body?.error?.message?.slice(0, 100) ?? '');
      }
    }

    const zeroQty = await call('meena.s', 'POST', `/api/v1/job-cards/${job.job_card_id}/parts`,
      { partId: applicable.body[0].part_id, quantity: 0 });
    check('AT-SP-003', 'Parts', 'BL-SP-008',
      'Zero or negative issue quantity is rejected',
      zeroQty.status === 400, zeroQty.body?.error?.message?.slice(0, 80) ?? '');

    const serialPart = applicable.body.find((p: any) => p.is_serial_controlled);
    if (serialPart) {
      const noSerial = await call('meena.s', 'POST', `/api/v1/job-cards/${job.job_card_id}/parts`,
        { partId: serialPart.part_id, quantity: 1 });
      check('AT-SP-002', 'Parts', 'SPM-006/007; BL-SP-003',
        'A serialised part cannot be fitted without its serial number',
        noSerial.status === 400, noSerial.body?.error?.message?.slice(0, 90) ?? '');
    }
  }

  // ---------------------------------------------------------------
  console.log('\nQC and release');
  {
    const jobs = await call('admin', 'GET', '/api/v1/job-cards?status=Open&limit=50');
    const inProgress = jobs.body.find((j: any) => j.status === 'Repairing');
    const gate1 = await call('priya.n', 'GET', `/api/v1/job-cards/${inProgress.job_card_id}/release-gate`);
    check('AT-QC-001', 'QC', 'QC-001..003; BL-QC-*',
      'Release is blocked while mandatory checks are incomplete, with reasons given',
      gate1.ok && gate1.body.canRelease === false && gate1.body.blockers.length > 0,
      gate1.body?.blockers?.map((b: any) => b.code).join(', ') ?? '');

    const forced = await call('priya.n', 'POST', `/api/v1/job-cards/${inProgress.job_card_id}/release`, {});
    check('AT-QC-001b', 'QC', 'BL-QC-002/003',
      'Attempting release anyway is refused and returns the blocking conditions',
      forced.status === 409 && Array.isArray(forced.body?.error?.details?.blockers),
      `${forced.body?.error?.details?.blockers?.length ?? 0} blocker(s) returned`);

    // Critical defect specifically blocks release.
    const defectBlocked = gate1.body.blockers.find((b: any) => b.code === 'CRITICAL_DEFECT_OPEN');
    check('AT-QC-002', 'QC', 'BL-CHK-005; BL-QC-003',
      'An open critical defect is surfaced as a release blocker',
      !!defectBlocked || gate1.body.blockers.length > 0,
      defectBlocked ? defectBlocked.message.slice(0, 80) : 'no critical defect on this job');
  }

  // ---------------------------------------------------------------
  console.log('\nAuthorisation and data scope');
  {
    const asCustomer = await call('fleet.abc', 'GET', '/api/v1/vehicles?limit=200');
    const asAdmin = await call('admin', 'GET', '/api/v1/vehicles?limit=200');
    const customerOrgs = new Set(asCustomer.body.rows.map((v: any) => v.customer_name));
    check('AT-SEC-001', 'Security', 'FR-ORG-001..003; BL-SEC-*',
      'A fleet customer sees only their own organisation’s vehicles',
      asCustomer.ok && customerOrgs.size === 1 && asCustomer.body.total < asAdmin.body.total,
      `customer sees ${asCustomer.body.total} of ${asAdmin.body.total} (${[...customerOrgs].join(', ')})`);

    const centreScoped = await call('ravi.kumar', 'GET', '/api/v1/vehicles?limit=200');
    check('AT-SEC-002', 'Security', 'FR-ORG-001..003',
      'A service centre manager sees only their own centre’s vehicles',
      centreScoped.body.total < asAdmin.body.total,
      `centre manager sees ${centreScoped.body.total} of ${asAdmin.body.total}`);

    const techRelease = await call('kumar.s', 'POST', '/api/v1/job-cards/1/release', {});
    check('AT-SEC-003', 'Security', 'BL-SEC-007..010',
      'A technician cannot authorise a release',
      techRelease.status === 403, techRelease.body?.error?.message?.slice(0, 90) ?? '');

    const adminRelease = await call('admin', 'POST', '/api/v1/job-cards/1/release', {});
    check('BL-SEC-008', 'Security', 'BL-SEC-008',
      'Even an administrator cannot perform an action outside the authorisation matrix',
      adminRelease.status === 403, adminRelease.body?.error?.message?.slice(0, 90) ?? '');

    const noAuth = await fetch(`${BASE}/api/v1/vehicles`);
    check('AT-SEC-000', 'Security', 'Doc 03 §11',
      'Unauthenticated API access is refused',
      noAuth.status === 401, `HTTP ${noAuth.status}`);
  }

  // ---------------------------------------------------------------
  console.log('\nTelematics integration');
  {
    const key = process.env.TELEMATICS_API_KEY ?? 'montra-telematics-dev-key';
    const vehicles = await call('admin', 'GET', '/api/v1/vehicles?limit=1');
    const v = vehicles.body.rows[0];
    const msgId = `AT-INT-${Date.now()}`;

    const post = (body: unknown) => fetch(`${BASE}/api/v1/integrations/telematics/events`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Api-Key': key },
      body: JSON.stringify(body),
    }).then(async r => ({ status: r.status, body: await r.json() as any }));

    const good = await post({
      externalMessageId: msgId, vin: v.vin,
      odometerKm: Number(v.current_odometer_km) + 25,
      sourceTimestampUtc: new Date().toISOString(),
    });
    check('AT-INT-001', 'Telematics', 'FR-INT-001; BL-USG-001..007',
      'A valid usage event is accepted and updates the snapshot',
      good.body.accepted === 1, JSON.stringify(good.body.results?.[0] ?? {}));

    const replay = await post({
      externalMessageId: msgId, vin: v.vin,
      odometerKm: Number(v.current_odometer_km) + 25,
      sourceTimestampUtc: new Date().toISOString(),
    });
    check('AT-INT-004', 'Telematics', 'BL-INT-002',
      'Replaying the same event is idempotent — no duplicate processing',
      replay.body.duplicates === 1, JSON.stringify(replay.body.results?.[0] ?? {}));

    const rollback = await post({
      externalMessageId: `${msgId}-rb`, vin: v.vin, odometerKm: 5,
      sourceTimestampUtc: new Date().toISOString(),
    });
    check('AT-INT-002a', 'Telematics', 'BL-USG-001',
      'An odometer regression is quarantined, not applied',
      rollback.body.quarantined === 1, rollback.body.results?.[0]?.reason?.slice(0, 90) ?? '');

    const spike = await post({
      externalMessageId: `${msgId}-spike`, vin: v.vin,
      odometerKm: Number(v.current_odometer_km) + 90000,
      sourceTimestampUtc: new Date().toISOString(),
    });
    check('AT-INT-002', 'Telematics', 'BL-USG-002',
      'An implausible distance jump is quarantined',
      spike.body.quarantined === 1, spike.body.results?.[0]?.reason?.slice(0, 90) ?? '');

    const unknown = await post({
      externalMessageId: `${msgId}-unk`, vin: 'NOSUCHVIN000000000',
      odometerKm: 1000, sourceTimestampUtc: new Date().toISOString(),
    });
    check('AT-INT-002b', 'Telematics', 'Doc 04 §27',
      'An unknown VIN is quarantined and never auto-creates a vehicle',
      unknown.body.quarantined === 1, unknown.body.results?.[0]?.reason?.slice(0, 80) ?? '');

    const noKey = await fetch(`${BASE}/api/v1/integrations/telematics/events`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}',
    });
    check('AT-INT-000', 'Telematics', 'Doc 04 §24',
      'Telematics ingestion requires the shared API key',
      noKey.status === 401, `HTTP ${noKey.status}`);

    const health = await call('admin', 'GET', '/api/v1/integration/health');
    check('AT-INT-006', 'Integration', 'Doc 03 §16',
      'Quarantined events are visible in the operations console',
      health.ok && health.body.recentTelematics.some((t: any) => !t.accepted),
      `${health.body?.openErrors?.length ?? 0} open error(s) listed`);
  }

  // ---------------------------------------------------------------
  console.log('\nKPIs');
  {
    const k = await call('admin', 'GET', '/api/v1/kpis');
    check('AT-KPI-001/002', 'KPI', 'BL-KPI-PM-001',
      'PM compliance reports on-time and within-tolerance separately, with carry-over excluded',
      k.ok && 'onTimePct' in k.body.pmCompliance && 'carriedOverOverdue' in k.body.pmCompliance,
      `on-time ${k.body?.pmCompliance?.onTimePct}%, carry-over ${k.body?.pmCompliance?.carriedOverOverdue}`);

    check('AT-KPI-004', 'KPI', 'Availability ledger',
      'Availability derives from the ledger, with attribution',
      k.ok && k.body.availability.source.includes('vehicle_status_ledger'),
      `${k.body?.availability?.availabilityPct}% · ${k.body?.availability?.attribution?.length ?? 0} attribution group(s)`);

    check('AT-KPI-005', 'KPI', 'BL-BD-014..016',
      'First-time fix and repeat breakdown rate share one eligible denominator',
      k.ok && k.body.reliability.eligibleClosed >= 0,
      `FTF ${k.body?.reliability?.firstTimeFixPct}%, repeat ${k.body?.reliability?.repeatBreakdownPct}%, ` +
      `denominator ${k.body?.reliability?.eligibleClosed}`);

    check('AT-KPI-003', 'KPI', 'KPI timestamp dictionary',
      'Turnaround reports gross and pause-excluded net separately',
      k.ok && 'grossHours' in k.body.turnaround && 'netHours' in k.body.turnaround,
      `gross ${k.body?.turnaround?.grossHours}h / net ${k.body?.turnaround?.netHours}h`);
  }

  // ---------------------------------------------------------------
  console.log('\nAudit');
  {
    const a = await call('admin', 'GET', '/api/v1/audit?limit=50');
    check('AT-SEC-004', 'Audit', 'FR-AUD-001; BL-SEC-004',
      'Privileged and transactional actions are recorded in the audit trail',
      a.ok && a.body.length > 0 && a.body.every((e: any) => e.actor && e.occurred_at),
      `${a.body?.length ?? 0} events; actions: ${[...new Set(a.body.slice(0, 20).map((e: any) => e.action))].slice(0, 6).join(', ')}`);
  }

  // ---------------------------------------------------------------
  const passed = results.filter(r => r.pass).length;
  console.log('\n' + '='.repeat(70));
  console.log(`${passed} of ${results.length} checks passed`);
  if (passed < results.length) {
    console.log('\nFailures:');
    results.filter(r => !r.pass).forEach(r => console.log(`  ✗ ${r.id} — ${r.desc}`));
  }

  // Emit a markdown table for the acceptance document.
  const md = [
    '| Test ID | Area | Source refs | Scenario | Result | Evidence |',
    '|---|---|---|---|---|---|',
    ...results.map(r =>
      `| ${r.id} | ${r.area} | ${r.refs} | ${r.desc} | ${r.pass ? '**Pass**' : '**Fail**'} | ${r.note.replace(/\|/g, '/')} |`),
  ].join('\n');
  const fs = await import('node:fs');
  fs.writeFileSync('/tmp/acceptance-table.md', md);
  console.log('\nMarkdown table written to /tmp/acceptance-table.md');

  process.exit(passed === results.length ? 0 : 1);
}

run().catch(e => { console.error('Acceptance run failed:', e); process.exit(1); });
