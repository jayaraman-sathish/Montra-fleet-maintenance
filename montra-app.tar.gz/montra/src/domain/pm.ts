/**
 * Preventive maintenance domain rules.
 *
 * Implements Document 02 FINAL v3.0:
 *   BL-PM-001..004   plan assignment
 *   BL-PM-005..010   due-state calculation (earliest trigger wins)
 *   BL-PM-019..023   next-PM calculation
 *   BL-PM-024..029   persisted obligations, early/late completion, off-hire
 *   BL-USG-004       estimated status when usage data is stale
 * and Document 01 FR-PM-001..013, FR-PMO-001/002.
 */

import { q, one, many, recordStatus, notify } from '../lib/db.ts';
import type { Db } from '../lib/db.ts';

export type PmStatus =
  | 'Upcoming' | 'Due Soon' | 'Due' | 'Overdue' | 'Scheduled' | 'Under Service'
  | 'Completed On Time' | 'Completed Within Tolerance' | 'Completed Late'
  | 'Skipped-Authorised' | 'Superseded' | 'Cancelled';

/** Open (not yet completed) obligation statuses. */
export const OPEN_PM_STATUSES: PmStatus[] = [
  'Upcoming', 'Due Soon', 'Due', 'Overdue', 'Scheduled', 'Under Service',
];

/** Urgency ordering — BL-PM-005..008: the most urgent trigger sets the status. */
const URGENCY: Record<string, number> = {
  'Upcoming': 0, 'Due Soon': 1, 'Due': 2, 'Overdue': 3,
};

export interface TriggerEvaluation {
  triggerType: 'KM' | 'Calendar' | 'Hours';
  status: 'Upcoming' | 'Due Soon' | 'Due' | 'Overdue';
  remaining: number;        // km, days or hours still to run (negative when past due)
  unit: string;
}

export interface DueEvaluation {
  status: 'Upcoming' | 'Due Soon' | 'Due' | 'Overdue';
  drivingTrigger: string;
  triggers: TriggerEvaluation[];
  isEstimated: boolean;
}

const MS_PER_DAY = 86_400_000;

function daysBetween(from: Date, to: Date): number {
  return Math.floor((to.getTime() - from.getTime()) / MS_PER_DAY);
}

/**
 * BL-PM-005..008. Evaluate every configured trigger on an obligation against
 * current usage and return the most urgent resulting status.
 *
 * A trigger is Due when its target is reached, Overdue once target+tolerance
 * is passed, and Due Soon inside the configured advance threshold.
 */
export function evaluateDueState(input: {
  targetKm?: number | null; targetDate?: string | null; targetHours?: number | null;
  dueSoonKm?: number | null; dueSoonDays?: number | null; dueSoonHours?: number | null;
  toleranceKm?: number | null; toleranceDays?: number | null; toleranceHours?: number | null;
  currentKm: number; currentHours: number; asOf?: Date;
  isEstimated?: boolean;
}): DueEvaluation {
  const asOf = input.asOf ?? new Date();
  const triggers: TriggerEvaluation[] = [];

  const classify = (
    remaining: number, dueSoon: number, tolerance: number,
  ): 'Upcoming' | 'Due Soon' | 'Due' | 'Overdue' => {
    if (remaining < -tolerance) return 'Overdue';   // BL-PM-008
    if (remaining <= 0) return 'Due';               // BL-PM-007
    if (remaining <= dueSoon) return 'Due Soon';    // BL-PM-006
    return 'Upcoming';                              // BL-PM-005
  };

  if (input.targetKm != null) {
    const remaining = Number(input.targetKm) - input.currentKm;
    triggers.push({
      triggerType: 'KM',
      status: classify(remaining, Number(input.dueSoonKm ?? 0), Number(input.toleranceKm ?? 0)),
      remaining, unit: 'km',
    });
  }

  if (input.targetDate) {
    const target = new Date(input.targetDate + 'T00:00:00Z');
    const remaining = daysBetween(asOf, target);
    triggers.push({
      triggerType: 'Calendar',
      status: classify(remaining, Number(input.dueSoonDays ?? 0), Number(input.toleranceDays ?? 0)),
      remaining, unit: 'days',
    });
  }

  if (input.targetHours != null) {
    const remaining = Number(input.targetHours) - input.currentHours;
    triggers.push({
      triggerType: 'Hours',
      status: classify(remaining, Number(input.dueSoonHours ?? 0), Number(input.toleranceHours ?? 0)),
      remaining, unit: 'hrs',
    });
  }

  if (!triggers.length) {
    return { status: 'Upcoming', drivingTrigger: 'None', triggers: [], isEstimated: !!input.isEstimated };
  }

  // Most urgent status wins; ties broken by the trigger closest to its target.
  let winner = triggers[0];
  for (const t of triggers) {
    if (URGENCY[t.status] > URGENCY[winner.status]) winner = t;
    else if (URGENCY[t.status] === URGENCY[winner.status] && t.remaining < winner.remaining) winner = t;
  }

  return {
    status: winner.status,
    drivingTrigger: winner.triggerType,
    triggers,
    isEstimated: !!input.isEstimated,
  };
}

/**
 * Re-evaluate every open PM obligation for a vehicle and persist any change.
 * Called after a trusted usage update (Doc 03 §15) and by the daily worker.
 *
 * BL-PM-009: an active PM job overlays "Under Service" but the underlying
 * due/overdue state is preserved for reporting, so obligations already in
 * Scheduled/Under Service are not re-flagged here.
 */
export async function reevaluateObligations(
  db: Db, vehicleId: number, actor = 'system',
): Promise<{ changed: number; statuses: Record<string, number> }> {
  const vehicle = await one<any>(db, `
    SELECT vehicle_id, current_odometer_km, current_operating_hours, usage_is_stale, lifecycle_status
    FROM master.vehicle WHERE vehicle_id = $1`, [vehicleId]);
  if (!vehicle) return { changed: 0, statuses: {} };

  // BL-AVL-012: retired vehicles generate no further obligations.
  if (vehicle.lifecycle_status === 'Retired' || vehicle.lifecycle_status === 'Disposed') {
    return { changed: 0, statuses: {} };
  }

  const obligations = await many<any>(db, `
    SELECT * FROM pm.pm_obligation
    WHERE vehicle_id = $1 AND status IN ('Upcoming','Due Soon','Due','Overdue')`, [vehicleId]);

  let changed = 0;
  const statuses: Record<string, number> = {};

  for (const o of obligations) {
    const evalResult = evaluateDueState({
      targetKm: o.target_km, targetDate: o.target_date, targetHours: o.target_hours,
      dueSoonKm: o.due_soon_km, dueSoonDays: o.due_soon_days, dueSoonHours: o.due_soon_hours,
      toleranceKm: o.tolerance_km, toleranceDays: o.tolerance_days, toleranceHours: o.tolerance_hours,
      currentKm: Number(vehicle.current_odometer_km ?? 0),
      currentHours: Number(vehicle.current_operating_hours ?? 0),
      isEstimated: vehicle.usage_is_stale,
    });

    statuses[evalResult.status] = (statuses[evalResult.status] ?? 0) + 1;

    if (evalResult.status !== o.status
        || evalResult.drivingTrigger !== o.driving_trigger
        || evalResult.isEstimated !== o.is_estimated) {
      await q(db, `
        UPDATE pm.pm_obligation
        SET status = $1, driving_trigger = $2, is_estimated = $3,
            updated_at = now(), row_version = row_version + 1
        WHERE pm_obligation_id = $4`,
        [evalResult.status, evalResult.drivingTrigger, evalResult.isEstimated, o.pm_obligation_id]);

      await recordStatus(db, {
        entityType: 'PMObligation', entityId: o.pm_obligation_id,
        from: o.status, to: evalResult.status, actor,
        ruleId: evalResult.status === 'Overdue' ? 'BL-PM-008'
              : evalResult.status === 'Due' ? 'BL-PM-007'
              : evalResult.status === 'Due Soon' ? 'BL-PM-006' : 'BL-PM-005',
      });

      // BL-ALR-001..003 alerting on escalating states
      if (evalResult.status !== o.status && ['Due Soon', 'Due', 'Overdue'].includes(evalResult.status)) {
        await notify(db, {
          alertType: evalResult.status === 'Overdue' ? 'PM_OVERDUE'
                   : evalResult.status === 'Due' ? 'PM_DUE' : 'PM_DUE_SOON',
          severity: evalResult.status === 'Overdue' ? 'Critical' : 'Warning',
          title: `PM ${evalResult.status.toLowerCase()} — ${o.pm_level}`,
          body: `Driven by ${evalResult.drivingTrigger} trigger.`,
          entityType: 'PMObligation', entityId: o.pm_obligation_id, vehicleId,
        });
      }
      changed++;
    }
  }

  return { changed, statuses };
}

/**
 * Create the opening PM obligation for a vehicle (cycle 1 of its plan ladder),
 * or the next obligation after a completion.
 *
 * BL-PM-024: obligations are persisted per cycle and never overwritten.
 * BL-PM-027: on early completion the original km ladder stays anchored unless
 *            the plan's trigger is explicitly configured ActualCompletion.
 */
export async function createObligation(db: Db, input: {
  vehicleId: number;
  planVersionId: number;
  cycleNo: number;
  baselineKm: number;            // km the interval is measured from
  baselineDate: Date;            // date the interval is measured from
  baselineHours: number;
  createdSource?: string;
}): Promise<number> {
  const planVersion = await one<any>(db, `
    SELECT pv.*, p.code AS plan_code
    FROM pm.pm_plan_version pv JOIN pm.pm_plan p ON p.plan_id = pv.plan_id
    WHERE pv.plan_version_id = $1`, [input.planVersionId]);
  if (!planVersion) throw new Error(`PM plan version ${input.planVersionId} not found`);

  const triggers = await many<any>(db, `
    SELECT * FROM pm.pm_plan_trigger WHERE plan_version_id = $1`, [input.planVersionId]);
  if (!triggers.length) {
    // BL-PM-002: never silently default to another plan.
    throw new Error(`PM plan version ${input.planVersionId} has no configured triggers`);
  }

  let targetKm: number | null = null, targetHours: number | null = null, targetDate: string | null = null;
  let dueSoonKm: number | null = null, dueSoonDays: number | null = null, dueSoonHours: number | null = null;
  let tolKm: number | null = null, tolDays: number | null = null, tolHours: number | null = null;

  for (const t of triggers) {
    const interval = Number(t.interval_value);
    if (t.trigger_type === 'KM') {
      targetKm = input.baselineKm + interval;
      dueSoonKm = Number(t.due_soon_threshold);
      tolKm = Number(t.tolerance);
    } else if (t.trigger_type === 'Hours') {
      targetHours = input.baselineHours + interval;
      dueSoonHours = Number(t.due_soon_threshold);
      tolHours = Number(t.tolerance);
    } else if (t.trigger_type === 'Calendar') {
      const d = new Date(input.baselineDate);
      d.setUTCMonth(d.getUTCMonth() + interval);   // interval is in months
      targetDate = d.toISOString().slice(0, 10);
      dueSoonDays = Number(t.due_soon_threshold);
      tolDays = Number(t.tolerance);
    }
  }

  const existing = await one<any>(db, `
    SELECT pm_obligation_id FROM pm.pm_obligation
    WHERE vehicle_id = $1 AND plan_version_id = $2 AND cycle_no = $3`,
    [input.vehicleId, input.planVersionId, input.cycleNo]);
  if (existing) return existing.pm_obligation_id;

  const row = await one<any>(db, `
    INSERT INTO pm.pm_obligation
      (vehicle_id, plan_version_id, pm_level, cycle_no,
       target_km, target_date, target_hours,
       due_soon_km, due_soon_days, due_soon_hours,
       tolerance_km, tolerance_days, tolerance_hours,
       status, created_source)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,'Upcoming',$14)
    RETURNING pm_obligation_id`,
    [input.vehicleId, input.planVersionId, planVersion.pm_level, input.cycleNo,
     targetKm, targetDate, targetHours,
     dueSoonKm, dueSoonDays, dueSoonHours,
     tolKm, tolDays, tolHours,
     input.createdSource ?? 'System']);

  return row.pm_obligation_id;
}

/**
 * Close a completed obligation and generate the next one.
 *
 * BL-PM-019  next PM is calculated only after successful closure
 * BL-PM-020  the completed level determines the next level via the plan ladder
 * BL-PM-021  late completion follows the configured anchor policy
 * FR-PMO-002 outcome is classified and the prior obligation is preserved
 */
export async function completeObligation(db: Db, input: {
  pmObligationId: number;
  jobCardId: number;
  actualKm: number;
  actualHours: number;
  actualDate?: Date;
  actor: string;
}): Promise<{ outcome: string; nextObligationId: number | null }> {
  const actualDate = input.actualDate ?? new Date();
  const o = await one<any>(db, `SELECT * FROM pm.pm_obligation WHERE pm_obligation_id = $1`,
    [input.pmObligationId]);
  if (!o) throw new Error('PM obligation not found');

  // --- Classify the outcome (FR-PMO-002) ---
  let outcome: PmStatus = 'Completed On Time';
  const overBy: number[] = [];

  if (o.target_km != null && input.actualKm > Number(o.target_km)) {
    overBy.push(input.actualKm - Number(o.target_km) - Number(o.tolerance_km ?? 0));
  }
  if (o.target_date) {
    const target = new Date(o.target_date + 'T00:00:00Z');
    const lateDays = daysBetween(target, actualDate);
    if (lateDays > 0) overBy.push(lateDays - Number(o.tolerance_days ?? 0));
  }
  if (o.target_hours != null && input.actualHours > Number(o.target_hours)) {
    overBy.push(input.actualHours - Number(o.target_hours) - Number(o.tolerance_hours ?? 0));
  }

  const wasLate = o.target_km != null ? input.actualKm > Number(o.target_km) : false;
  const wasLateDate = o.target_date ? daysBetween(new Date(o.target_date + 'T00:00:00Z'), actualDate) > 0 : false;

  if (overBy.some(v => v > 0)) outcome = 'Completed Late';
  else if (wasLate || wasLateDate) outcome = 'Completed Within Tolerance';

  const varianceKm = o.target_km != null ? input.actualKm - Number(o.target_km) : null;
  const varianceDays = o.target_date
    ? daysBetween(new Date(o.target_date + 'T00:00:00Z'), actualDate) : null;

  await q(db, `
    UPDATE pm.pm_obligation
    SET status = $1, outcome = $1,
        actual_completion_km = $2, actual_completion_date = $3, actual_completion_hours = $4,
        variance_km = $5, variance_days = $6, completed_job_card_id = $7,
        updated_at = now(), row_version = row_version + 1
    WHERE pm_obligation_id = $8`,
    [outcome, input.actualKm, actualDate.toISOString().slice(0, 10), input.actualHours,
     varianceKm, varianceDays, input.jobCardId, input.pmObligationId]);

  await recordStatus(db, {
    entityType: 'PMObligation', entityId: input.pmObligationId,
    from: o.status, to: outcome, actor: input.actor, ruleId: 'BL-PM-019',
  });

  // --- Generate the next obligation (BL-PM-020) ---
  const planVersion = await one<any>(db, `
    SELECT * FROM pm.pm_plan_version WHERE plan_version_id = $1`, [o.plan_version_id]);

  const nextPlanVersionId = planVersion?.next_plan_version_id ?? o.plan_version_id;
  const nextTriggers = await many<any>(db, `
    SELECT * FROM pm.pm_plan_trigger WHERE plan_version_id = $1`, [nextPlanVersionId]);
  if (!nextTriggers.length) return { outcome, nextObligationId: null };

  // BL-PM-021 / BL-PM-027 anchor policy: the km ladder normally stays anchored
  // to the original schedule so early or late work does not shift the series.
  const kmTrigger = nextTriggers.find((t: any) => t.trigger_type === 'KM');
  const anchorOnActual = kmTrigger?.anchor_policy === 'ActualCompletion';

  const baselineKm = anchorOnActual
    ? input.actualKm
    : (o.target_km != null ? Number(o.target_km) : input.actualKm);
  const baselineDate = anchorOnActual
    ? actualDate
    : (o.target_date ? new Date(o.target_date + 'T00:00:00Z') : actualDate);

  const nextCycle = Number(o.cycle_no) + 1;
  const nextObligationId = await createObligation(db, {
    vehicleId: o.vehicle_id,
    planVersionId: nextPlanVersionId,
    cycleNo: nextCycle,
    baselineKm,
    baselineDate,
    baselineHours: anchorOnActual
      ? input.actualHours
      : (o.target_hours != null ? Number(o.target_hours) : input.actualHours),
    createdSource: 'PM Completion',
  });

  await reevaluateObligations(db, o.vehicle_id, input.actor);
  return { outcome, nextObligationId };
}

/**
 * BL-PM-001/002: resolve the PM plan applicable to a vehicle.
 * Returns null rather than falling back to another model's plan; callers
 * surface this as "PM Configuration Missing".
 */
export async function resolvePlanForVehicle(db: Db, vehicleId: number): Promise<any | null> {
  return one<any>(db, `
    SELECT pv.*
    FROM master.vehicle v
    JOIN pm.pm_plan_version pv
      ON (pv.variant_id = v.variant_id
          OR pv.model_id = (SELECT model_id FROM master.vehicle_variant WHERE variant_id = v.variant_id))
    WHERE v.vehicle_id = $1
      AND pv.approval_status = 'Published'
      AND pv.effective_from <= CURRENT_DATE
      AND (pv.effective_to IS NULL OR pv.effective_to >= CURRENT_DATE)
    ORDER BY pv.sequence_no ASC, pv.effective_from DESC
    LIMIT 1`, [vehicleId]);
}
