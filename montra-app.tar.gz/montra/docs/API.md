# REST API

Paths follow Document 04 §25. All responses are JSON. Errors use the
Document 04 §24 envelope:

```json
{ "error": { "code": "CONFLICT", "message": "…", "details": { "ruleId": "BL-QC-003" },
             "correlationId": "…" } }
```

Authenticate with `Authorization: Bearer <token>` from `POST /api/v1/auth/login`,
or the `montra_session` cookie the same endpoint sets.

Every response is filtered by the caller's organisation and service-network
scope (FR-ORG-002). Two users calling the same path see different rows.

## Authentication
| Method | Path |
|---|---|
| POST | `/api/v1/auth/login` |
| POST | `/api/v1/auth/logout` |
| GET | `/api/v1/auth/me` |

## Vehicles
| Method | Path | Notes |
|---|---|---|
| GET | `/api/v1/vehicles` | filters: `search`, `pmStatus`, `availabilityState`, `serviceCentreId` |
| GET | `/api/v1/vehicles/{vin}/360` | the consolidated maintenance view (Doc 01 §12) |
| GET | `/api/v1/vehicles/{vin}/availability` | ledger intervals and summary |
| GET | `/api/v1/vehicles/{vin}/components` | serialised fitment history |
| POST | `/api/v1/vehicles/{vin}/usage` | authorised odometer correction (BL-VEH-006) |
| POST | `/api/v1/vehicles/{vin}/availability/transitions` | controlled transition or BL-AVL-015 correction |
| POST | `/api/v1/vehicles/{vin}/off-hire` | privileged; evidence and expected return required |
| POST | `/api/v1/off-hire/{id}/recommission` | return to service |

## Preventive maintenance
| Method | Path | Notes |
|---|---|---|
| GET | `/api/v1/pm/obligations` | the due queue with status counts |
| GET | `/api/v1/pm/obligations/{id}` | includes a live per-trigger evaluation |
| POST | `/api/v1/pm/obligations/{id}/reevaluate` | |
| GET | `/api/v1/pm/forecast` | forward demand by week and centre (FR-APT-004) |

## Scheduling
| Method | Path | Notes |
|---|---|---|
| GET | `/api/v1/service-centres/{id}/capacity` | bays, roster, booked minutes, calendar |
| GET | `/api/v1/appointments` | |
| POST | `/api/v1/appointments` | capacity-validated (CAP-001) |
| POST | `/api/v1/appointments/{id}/no-show` | obligation returns to the due queue |
| POST | `/api/v1/appointments/{id}/cancel` | |

## Service execution
| Method | Path | Notes |
|---|---|---|
| GET | `/api/v1/service-events` · `/api/v1/service-events/{id}` | |
| PATCH | `/api/v1/service-events/{id}/closure` | diagnosis, root cause, corrective action |
| POST | `/api/v1/breakdowns` | intake; priority derives from mobility |
| POST | `/api/v1/breakdowns/{id}/triage` | dispatch; P1 downgrade is privileged |
| POST | `/api/v1/service-events/pm` | open a PM job from an obligation |
| GET | `/api/v1/job-cards` · `/api/v1/job-cards/{id}` | |
| PATCH | `/api/v1/job-cards/{id}/status` | canonical transitions only (BL-JC-003) |
| POST | `/api/v1/job-cards/{id}/assign` | validates HV authorisation (BL-SVC-007) |
| POST | `/api/v1/job-cards/{id}/transfer` | roadside → workshop (BL-JC-010) |
| POST | `/api/v1/job-cards/{id}/work-items` · PATCH `/api/v1/work-items/{id}` | |
| GET | `/api/v1/job-cards/{id}/checklist` | frozen version for this job |
| POST | `/api/v1/job-cards/{id}/checklist-results` | idempotent per (job, item) |
| POST | `/api/v1/job-cards/{id}/parts` | applicability, serial and quantity rules |
| POST | `/api/v1/job-cards/{id}/labour` | |
| GET | `/api/v1/parts/applicable?vin=` | SPM-004 |
| POST | `/api/v1/defects` · PATCH `/api/v1/defects/{id}` | VIN-owned |

## Quality and release
| Method | Path | Notes |
|---|---|---|
| GET | `/api/v1/job-cards/{id}/release-gate` | every blocker, with its rule |
| GET | `/api/v1/job-cards/{id}/qc-checklist` | |
| POST | `/api/v1/job-cards/{id}/qc` | record QC results |
| POST | `/api/v1/job-cards/{id}/release` | enforces BL-QC-002/003/006 |
| POST | `/api/v1/concessions` · GET `/api/v1/concessions` | expiry and follow-up mandatory |
| GET | `/api/v1/releases` | release register |

## Insight and administration
| Method | Path |
|---|---|
| GET | `/api/v1/dashboard` |
| GET | `/api/v1/kpis` |
| GET | `/api/v1/reference` |
| GET | `/api/v1/notifications` · POST `/api/v1/notifications/{id}/acknowledge` |
| GET | `/api/v1/configuration/readiness` |
| GET | `/api/v1/integration/health` |
| GET | `/api/v1/audit` |
| GET | `/api/v1/technicians` |
| GET | `/health` |

## Telematics ingestion

`POST /api/v1/integrations/telematics/events` — authenticated with the
`X-Api-Key` header, not a user session. Accepts one event or an array.

```json
{ "externalMessageId": "unique-per-event",
  "vin": "MT7T2036001000",
  "odometerKm": 48520,
  "operatingHours": 3120,
  "sourceTimestampUtc": "2026-09-11T08:15:00Z",
  "socPct": 78, "sohPct": 96 }
```

`externalMessageId` is the idempotency key: replaying an event is a no-op.
Unknown VINs, odometer regressions and implausible jumps are quarantined and
surface in `/api/v1/integration/health` — they never silently update a vehicle.
