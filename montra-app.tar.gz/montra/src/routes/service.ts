/**
 * Service execution endpoints — service events, breakdowns, job cards,
 * work items, checklist execution, defects and parts.
 * FR-SE-001, FR-BD-*, FR-JC-*, BL-JC-*, BL-CHK-*, BL-SP-*.
 */

import { Router, notFound, badRequest, conflict, forbidden } from '../lib/http.ts';
import type { Ctx } from '../lib/http.ts';
import { pool, one, many, q, audit, recordStatus, notify, nextDocumentNo } from '../lib/db.ts';
import { authenticate, vehicleScopeClause, assertAuthorised, assertPermission } from '../lib/auth.ts';
import {
  createJobCard, changeStatus, reassign, transferToWorkshop,
  checkTechnicianAuthorised, JOB_STATUSES, ALLOWED_TRANSITIONS,
} from '../domain/jobcard.ts';
import { getChecklistForJob, recordAnswers, attachDeferredDefects } from '../domain/checklist.ts';
import { transition } from '../domain/availability.ts';
import { resolvePlanForVehicle } from '../domain/pm.ts';

export const serviceRoutes = new Router();
serviceRoutes.use(authenticate);

// ---------------------------------------------------------------------
// Service events
// ---------------------------------------------------------------------

serviceRoutes.get('/api/v1/service-events', async (ctx: Ctx) => {
  const scope = vehicleScopeClause(ctx.user!, 'v', 1);
  const params: unknown[] = [...scope.params];
  const where = [scope.clause];

  const status = ctx.query.get('status');
  if (status === 'Open') where.push(`se.status NOT IN ('Closed','Cancelled')`);
  else if (status) { params.push(status); where.push(`se.status = $${params.length}`); }

  const type = ctx.query.get('eventType');
  if (type) { params.push(type); where.push(`se.event_type = $${params.length}`); }

  const limit = Math.min(Number(ctx.query.get('limit') ?? 100), 500);
  params.push(limit);

  return many(pool, `
    SELECT se.*, v.vin, v.registration_no, org.name AS customer_name,
           (SELECT count(*) FROM service.job_card jc
             WHERE jc.service_event_id = se.service_event_id)::int AS job_card_count,
           (SELECT jc.status FROM service.job_card jc
             WHERE jc.service_event_id = se.service_event_id
             ORDER BY jc.job_card_id DESC LIMIT 1) AS latest_job_status
    FROM service.service_event se
    JOIN master.vehicle v ON v.vehicle_id = se.vehicle_id
    JOIN org.organisation org ON org.organisation_id = v.organisation_id
    WHERE ${where.join(' AND ')}
    ORDER BY se.customer_visible_start DESC
    LIMIT $${params.length}`, params);
});

serviceRoutes.get('/api/v1/service-events/:id', async (ctx: Ctx) => {
  const id = Number(ctx.params.id);
  const se = await one<any>(pool, `
    SELECT se.*, v.vin, v.registration_no, v.current_odometer_km,
           org.name AS customer_name, vv.name AS variant_name
    FROM service.service_event se
    JOIN master.vehicle v ON v.vehicle_id = se.vehicle_id
    JOIN master.vehicle_variant vv ON vv.variant_id = v.variant_id
    JOIN org.organisation org ON org.organisation_id = v.organisation_id
    WHERE se.service_event_id = $1`, [id]);
  if (!se) throw notFound('Service event not found.');

  const [jobCards, breakdown, sla, pauses] = await Promise.all([
    many<any>(pool, `
      SELECT jc.*, sc.name AS service_centre_name, t.name AS technician_name,
             (SELECT count(*) FROM service.work_item wi WHERE wi.job_card_id = jc.job_card_id)::int AS work_item_count
      FROM service.job_card jc
      LEFT JOIN master.service_centre sc ON sc.service_centre_id = jc.service_centre_id
      LEFT JOIN master.technician t ON t.technician_id = jc.technician_id
      WHERE jc.service_event_id = $1 ORDER BY jc.job_card_id`, [id]),
    one<any>(pool, `SELECT * FROM service.breakdown_event WHERE service_event_id = $1`, [id]),
    one<any>(pool, `
      SELECT s.* FROM service.sla_master s WHERE s.sla_id = (
        SELECT sla_id FROM service.service_event WHERE service_event_id = $1)`, [id]),
    many<any>(pool, `
      SELECT * FROM service.clock_pause WHERE service_event_id = $1 ORDER BY start_utc`, [id]),
  ]);

  return { serviceEvent: se, jobCards, breakdown, sla, pauses };
});

// ---------------------------------------------------------------------
// Breakdown intake and triage — FR-BD-001..009
// ---------------------------------------------------------------------

serviceRoutes.post('/api/v1/breakdowns', async (ctx: Ctx) => {
  assertPermission(ctx.user!, 'breakdown.create');

  const {
    vin, reportedBy, contactPhone, locationText, latitude, longitude,
    mobility, complaintCode, complaintText, warningIndicator, dtcSummary,
    breakdownType, stoppedActualUtc, reportedUtc,
  } = ctx.body ?? {};

  if (!vin || !complaintText || !mobility) {
    throw badRequest('Vehicle, complaint description and mobility status are required (FR-BD-002).');
  }

  const vehicle = await one<any>(pool, `SELECT * FROM master.vehicle WHERE vin = $1`, [vin]);
  if (!vehicle) throw notFound(`Vehicle ${vin} was not found.`);

  // BL-BD-002/003/004: priority derives from mobility unless triage changes it.
  const priority = mobility === 'Immobilized' ? 'P1'
                 : mobility === 'Limited movement' ? 'P2' : 'P3';

  const result = await pool.transaction(async (tx) => {
    const seNo = await nextDocumentNo(tx, 'SE', 6);
    const se = await one<any>(tx, `
      INSERT INTO service.service_event
        (service_event_no, vehicle_id, event_type, source_channel, priority, status, created_by,
         sla_id)
      VALUES ($1,$2,'Breakdown',$3,$4,'Open',$5,
        (SELECT sla_id FROM service.sla_master
          WHERE service_type='Breakdown' AND priority=$4 AND status='Active' LIMIT 1))
      RETURNING *`,
      [seNo, vehicle.vehicle_id, 'Portal', priority, ctx.user!.username]);

    const bd = await one<any>(tx, `
      INSERT INTO service.breakdown_event
        (service_event_id, vehicle_id, stopped_actual_utc, reported_utc, reported_by, contact_phone,
         location_text, latitude, longitude, mobility, complaint_code, complaint_text,
         warning_indicator, dtc_summary, priority, breakdown_type)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16)
      RETURNING *`,
      [se.service_event_id, vehicle.vehicle_id,
       stoppedActualUtc ? new Date(stoppedActualUtc) : null,
       reportedUtc ? new Date(reportedUtc) : new Date(),
       reportedBy ?? ctx.user!.displayName, contactPhone ?? null, locationText ?? null,
       latitude ?? null, longitude ?? null, mobility, complaintCode ?? null, complaintText,
       warningIndicator ?? null, dtcSummary ?? null, priority, breakdownType ?? null]);

    // BL-AVL-003: downtime starts from the actual stoppage where known.
    if (mobility === 'Immobilized') {
      await transition(tx, {
        vehicleId: vehicle.vehicle_id, reasonCode: 'DOWN_BREAKDOWN',
        sourceType: 'Breakdown', sourceEntityId: bd.breakdown_id, ruleId: 'BL-AVL-003',
        actor: ctx.user!.username,
        startUtc: stoppedActualUtc ? new Date(stoppedActualUtc) : undefined,
        reason: `Breakdown ${seNo}: ${complaintText}`,
      });
    }

    await notify(tx, {
      alertType: priority === 'P1' ? 'P1_BREAKDOWN' : 'BREAKDOWN_CREATED',
      severity: priority === 'P1' ? 'Critical' : 'Warning',
      title: `${priority} breakdown reported — ${vehicle.vin}`,
      body: complaintText,
      entityType: 'ServiceEvent', entityId: se.service_event_id,
      vehicleId: vehicle.vehicle_id, serviceCentreId: vehicle.assigned_service_centre_id,
    });

    await audit(tx, {
      entityType: 'ServiceEvent', entityId: se.service_event_id, action: 'CREATE_BREAKDOWN',
      actor: ctx.user!.username, after: { serviceEventNo: seNo, priority, mobility },
    });

    return { serviceEvent: se, breakdown: bd };
  });

  return result;
});

/** POST /api/v1/breakdowns/:id/triage — FR-BD-006, BL-BD-005. */
serviceRoutes.post('/api/v1/breakdowns/:id/triage', async (ctx: Ctx) => {
  assertPermission(ctx.user!, 'breakdown.triage');
  const { priority, disposition, reason, assignServiceCentreId, assignTechnicianId } = ctx.body ?? {};

  const bd = await one<any>(pool, `
    SELECT be.*, se.service_event_no FROM service.breakdown_event be
    JOIN service.service_event se ON se.service_event_id = be.service_event_id
    WHERE be.breakdown_id = $1`, [Number(ctx.params.id)]);
  if (!bd) throw notFound('Breakdown not found.');

  // BL-BD-002: downgrading a P1 is a privileged, reasoned, audited action.
  if (bd.priority === 'P1' && priority && priority !== 'P1') {
    if (!reason) throw badRequest('A reason is required to downgrade a P1 breakdown (BL-BD-005).');
    await assertAuthorised(pool, ctx.user!, 'breakdown.downgrade_p1');
  }

  const updated = await one<any>(pool, `
    UPDATE service.breakdown_event
    SET priority = COALESCE($2, priority), disposition = COALESCE($3, disposition),
        priority_reason = COALESCE($4, priority_reason),
        triaged_by = $5, triaged_at = now(),
        accepted_utc = COALESCE(accepted_utc, now()),
        assigned_utc = CASE WHEN $6::bigint IS NOT NULL THEN now() ELSE assigned_utc END
    WHERE breakdown_id = $1 RETURNING *`,
    [bd.breakdown_id, priority ?? null, disposition ?? null, reason ?? null,
     ctx.user!.username, assignTechnicianId ?? null]);

  if (priority && priority !== bd.priority) {
    await q(pool, `
      UPDATE service.service_event SET priority = $2,
             sla_id = (SELECT sla_id FROM service.sla_master
                        WHERE service_type='Breakdown' AND priority=$2 AND status='Active' LIMIT 1)
      WHERE service_event_id = $1`, [bd.service_event_id, priority]);
    await audit(pool, {
      entityType: 'BreakdownEvent', entityId: bd.breakdown_id, action: 'PRIORITY_CHANGE',
      actor: ctx.user!.username, reason,
      before: { priority: bd.priority }, after: { priority },
    });
  }

  // Physical intervention creates a job card (BL-BD-009).
  let jobCard = null;
  if (disposition && disposition !== 'RemoteResolution') {
    const vehicle = await one<any>(pool, `
      SELECT * FROM master.vehicle WHERE vehicle_id = $1`, [bd.vehicle_id]);

    jobCard = await createJobCard(pool, {
      serviceEventId: bd.service_event_id,
      vehicleId: bd.vehicle_id,
      serviceCentreId: assignServiceCentreId ?? vehicle.assigned_service_centre_id,
      locationType: disposition === 'MobileTechnician' ? 'Roadside' : 'Workshop',
      jobType: 'Breakdown',
      technicianId: assignTechnicianId ?? null,
      complaintText: bd.complaint_text,
      actor: ctx.user!.username,
    });
    await attachDeferredDefects(pool, jobCard.job_card_id, bd.vehicle_id);
    await q(pool, `
      UPDATE service.service_event SET status = 'In Progress' WHERE service_event_id = $1`,
      [bd.service_event_id]);
  }

  return { breakdown: updated, jobCard };
});

// ---------------------------------------------------------------------
// PM service event + job card creation
// ---------------------------------------------------------------------

/** POST /api/v1/service-events/pm — open a PM service event from an obligation. */
serviceRoutes.post('/api/v1/service-events/pm', async (ctx: Ctx) => {
  assertPermission(ctx.user!, 'jobcard.create');
  const { pmObligationId, serviceCentreId, technicianId, bayId } = ctx.body ?? {};
  if (!pmObligationId) throw badRequest('A PM obligation is required.');

  const ob = await one<any>(pool, `
    SELECT o.*, v.vin, v.vehicle_id, v.assigned_service_centre_id, v.current_odometer_km,
           pv.checklist_version_id, pv.pm_level
    FROM pm.pm_obligation o
    JOIN master.vehicle v ON v.vehicle_id = o.vehicle_id
    JOIN pm.pm_plan_version pv ON pv.plan_version_id = o.plan_version_id
    WHERE o.pm_obligation_id = $1`, [Number(pmObligationId)]);
  if (!ob) throw notFound('PM obligation not found.');

  if (!ob.checklist_version_id) {
    // BL-PM-002 / exception rules: never substitute an unrelated checklist.
    throw conflict(
      `No checklist is published for PM level ${ob.pm_level} on this vehicle. ` +
      `Publish the checklist before executing this PM (Doc 02 §18: Missing Checklist).`,
      { ruleId: 'BL-CHK-001' });
  }

  // BL-PM-012: only one active job card per obligation.
  const active = await one<any>(pool, `
    SELECT jc.job_card_no FROM pm.pm_execution pe
    JOIN service.job_card jc ON jc.job_card_id = pe.job_card_id
    WHERE pe.pm_obligation_id = $1 AND jc.status NOT IN ('Closed','Cancelled')`,
    [Number(pmObligationId)]);
  if (active) {
    throw conflict(`Job card ${active.job_card_no} is already open for this PM obligation (BL-PM-012).`);
  }

  return pool.transaction(async (tx) => {
    const seNo = await nextDocumentNo(tx, 'SE', 6);
    const se = await one<any>(tx, `
      INSERT INTO service.service_event
        (service_event_no, vehicle_id, event_type, source_channel, status, created_by, sla_id)
      VALUES ($1,$2,'PM','System','In Progress',$3,
        (SELECT sla_id FROM service.sla_master WHERE service_type='PM' AND status='Active' LIMIT 1))
      RETURNING *`, [seNo, ob.vehicle_id, ctx.user!.username]);

    const jc = await createJobCard(tx, {
      serviceEventId: se.service_event_id,
      vehicleId: ob.vehicle_id,
      serviceCentreId: serviceCentreId ?? ob.assigned_service_centre_id,
      jobType: 'PM',
      bayId: bayId ?? null,
      technicianId: technicianId ?? null,
      complaintText: `Scheduled ${ob.pm_level} preventive maintenance`,
      actor: ctx.user!.username,
    });

    const wi = await one<any>(tx, `
      INSERT INTO service.work_item (job_card_id, line_no, work_item_type, description,
                                     source_entity_type, source_entity_id, status)
      VALUES ($1,1,'PM',$2,'PMObligation',$3,'Not Started')
      RETURNING work_item_id`,
      [jc.job_card_id, `${ob.pm_level} preventive maintenance`, ob.pm_obligation_id]);

    // BL-PM-013 / CHK-004: freeze the plan and checklist version onto the job.
    await q(tx, `
      INSERT INTO pm.pm_execution
        (work_item_id, job_card_id, pm_obligation_id, frozen_plan_version_id, frozen_checklist_version_id)
      VALUES ($1,$2,$3,$4,$5)`,
      [wi.work_item_id, jc.job_card_id, ob.pm_obligation_id, ob.plan_version_id, ob.checklist_version_id]);

    await q(tx, `
      UPDATE pm.pm_obligation SET status = 'Under Service', updated_at = now()
      WHERE pm_obligation_id = $1`, [ob.pm_obligation_id]);
    await recordStatus(tx, {
      entityType: 'PMObligation', entityId: ob.pm_obligation_id,
      to: 'Under Service', actor: ctx.user!.username, ruleId: 'BL-PM-009',
    });

    await attachDeferredDefects(tx, jc.job_card_id, ob.vehicle_id);
    return { serviceEvent: se, jobCard: jc };
  });
});

// ---------------------------------------------------------------------
// Job cards
// ---------------------------------------------------------------------

serviceRoutes.get('/api/v1/job-cards', async (ctx: Ctx) => {
  const scope = vehicleScopeClause(ctx.user!, 'v', 1);
  const params: unknown[] = [...scope.params];
  const where = [scope.clause];

  const status = ctx.query.get('status');
  if (status === 'Open') where.push(`jc.status NOT IN ('Closed','Cancelled')`);
  else if (status) { params.push(status); where.push(`jc.status = $${params.length}`); }

  const centre = ctx.query.get('serviceCentreId');
  if (centre) { params.push(Number(centre)); where.push(`jc.service_centre_id = $${params.length}`); }

  const tech = ctx.query.get('technicianId');
  if (tech) { params.push(Number(tech)); where.push(`jc.technician_id = $${params.length}`); }

  const limit = Math.min(Number(ctx.query.get('limit') ?? 100), 500);
  params.push(limit);

  return many(pool, `
    SELECT jc.*, v.vin, v.registration_no, org.name AS customer_name,
           se.service_event_no, se.event_type, se.priority,
           sc.name AS service_centre_name, t.name AS technician_name, b.bay_code,
           (SELECT count(*) FROM service.work_item wi
             WHERE wi.job_card_id = jc.job_card_id)::int AS work_items,
           (SELECT count(*) FROM service.work_item wi
             WHERE wi.job_card_id = jc.job_card_id AND wi.status = 'Completed')::int AS work_items_done
    FROM service.job_card jc
    JOIN master.vehicle v ON v.vehicle_id = jc.vehicle_id
    JOIN org.organisation org ON org.organisation_id = v.organisation_id
    JOIN service.service_event se ON se.service_event_id = jc.service_event_id
    LEFT JOIN master.service_centre sc ON sc.service_centre_id = jc.service_centre_id
    LEFT JOIN master.technician t ON t.technician_id = jc.technician_id
    LEFT JOIN schedule.service_bay b ON b.bay_id = jc.bay_id
    WHERE ${where.join(' AND ')}
    ORDER BY jc.opened_utc DESC
    LIMIT $${params.length}`, params);
});

serviceRoutes.get('/api/v1/job-cards/:id', async (ctx: Ctx) => {
  const id = Number(ctx.params.id);
  const jc = await one<any>(pool, `
    SELECT jc.*, v.vin, v.registration_no, v.current_odometer_km, v.current_operating_hours,
           vv.name AS variant_name, org.name AS customer_name,
           se.service_event_no, se.event_type, se.priority, se.final_diagnosis,
           se.root_cause_code, se.corrective_action_code, se.closure_disposition,
           sc.name AS service_centre_name, t.name AS technician_name, b.bay_code
    FROM service.job_card jc
    JOIN master.vehicle v ON v.vehicle_id = jc.vehicle_id
    JOIN master.vehicle_variant vv ON vv.variant_id = v.variant_id
    JOIN org.organisation org ON org.organisation_id = v.organisation_id
    JOIN service.service_event se ON se.service_event_id = jc.service_event_id
    LEFT JOIN master.service_centre sc ON sc.service_centre_id = jc.service_centre_id
    LEFT JOIN master.technician t ON t.technician_id = jc.technician_id
    LEFT JOIN schedule.service_bay b ON b.bay_id = jc.bay_id
    WHERE jc.job_card_id = $1`, [id]);
  if (!jc) throw notFound('Job card not found.');

  const [workItems, parts, labour, defects, activity, pauses, checklist] = await Promise.all([
    many<any>(pool, `SELECT * FROM service.work_item WHERE job_card_id = $1 ORDER BY line_no`, [id]),
    many<any>(pool, `
      SELECT pu.*, p.part_no, p.description, p.is_serial_controlled
      FROM service.part_usage pu JOIN master.part_master p ON p.part_id = pu.part_id
      WHERE pu.job_card_id = $1 ORDER BY pu.part_usage_id`, [id]),
    many<any>(pool, `
      SELECT l.*, t.name AS technician_name FROM service.labour l
      JOIN master.technician t ON t.technician_id = l.technician_id
      WHERE l.job_card_id = $1 ORDER BY l.start_utc`, [id]),
    many<any>(pool, `
      SELECT * FROM service.defect WHERE origin_job_card_id = $1 OR defect_id IN (
        SELECT source_entity_id FROM service.work_item
        WHERE job_card_id = $1 AND source_entity_type = 'Defect')
      ORDER BY severity, defect_id`, [id]),
    many<any>(pool, `
      SELECT * FROM audit.status_history
      WHERE entity_type = 'JobCard' AND entity_id = $1 ORDER BY occurred_at`, [id]),
    many<any>(pool, `SELECT * FROM service.clock_pause WHERE job_card_id = $1 ORDER BY start_utc`, [id]),
    getChecklistForJob(pool, id),
  ]);

  return {
    jobCard: jc, workItems, parts, labour, defects, statusHistory: activity, pauses, checklist,
    allowedTransitions: ALLOWED_TRANSITIONS[jc.status as keyof typeof ALLOWED_TRANSITIONS] ?? [],
  };
});

/** PATCH /api/v1/job-cards/:id/status — controlled transition (BL-JC-003). */
serviceRoutes.patch('/api/v1/job-cards/:id/status', async (ctx: Ctx) => {
  const { status, reason, force } = ctx.body ?? {};
  if (!status) throw badRequest('A target status is required.');
  if (!JOB_STATUSES.includes(status)) {
    throw badRequest(`"${status}" is not a recognised job card status.`,
      { allowed: JOB_STATUSES });
  }
  if (force) await assertAuthorised(pool, ctx.user!, 'jobcard.reopen');

  try {
    return await changeStatus(pool, {
      jobCardId: Number(ctx.params.id), toStatus: status,
      actor: ctx.user!.username, reason, force,
    });
  } catch (e: any) {
    if (e.code === 'INVALID_TRANSITION') throw conflict(e.message, { ruleId: 'BL-JC-003' });
    if (e.code === 'REASON_REQUIRED') throw badRequest(e.message);
    throw e;
  }
});

/** POST /api/v1/job-cards/:id/assign — with HV authorisation check. */
serviceRoutes.post('/api/v1/job-cards/:id/assign', async (ctx: Ctx) => {
  const { technicianId, serviceCentreId, reason } = ctx.body ?? {};
  if (!reason) throw badRequest('A reason is required for assignment or reassignment (BL-SVC-005).');
  try {
    return await reassign(pool, {
      jobCardId: Number(ctx.params.id), toTechnicianId: technicianId ?? null,
      toServiceCentreId: serviceCentreId ?? null, reason, actor: ctx.user!.username,
    });
  } catch (e: any) {
    if (e.code === 'TECHNICIAN_NOT_AUTHORISED') throw forbidden(e.message, { ruleId: 'BL-SVC-007' });
    throw e;
  }
});

/** POST /api/v1/job-cards/:id/transfer — roadside to workshop (BL-JC-010). */
serviceRoutes.post('/api/v1/job-cards/:id/transfer', async (ctx: Ctx) => {
  const { serviceCentreId, reason } = ctx.body ?? {};
  if (!serviceCentreId || !reason) throw badRequest('Destination service centre and reason are required.');
  return transferToWorkshop(pool, {
    jobCardId: Number(ctx.params.id), toServiceCentreId: Number(serviceCentreId),
    reason, actor: ctx.user!.username,
  });
});

/** POST /api/v1/job-cards/:id/work-items */
serviceRoutes.post('/api/v1/job-cards/:id/work-items', async (ctx: Ctx) => {
  const { workItemType, description, srtId } = ctx.body ?? {};
  if (!workItemType || !description) throw badRequest('Work item type and description are required.');
  const id = Number(ctx.params.id);
  const maxLine = await one<any>(pool, `
    SELECT COALESCE(max(line_no),0) AS n FROM service.work_item WHERE job_card_id = $1`, [id]);
  const srt = srtId ? await one<any>(pool, `
    SELECT standard_minutes FROM schedule.standard_repair_time WHERE srt_id = $1`, [Number(srtId)]) : null;

  return one(pool, `
    INSERT INTO service.work_item (job_card_id, line_no, work_item_type, description, srt_id, srt_minutes)
    VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
    [id, Number(maxLine.n) + 1, workItemType, description, srtId ?? null,
     srt?.standard_minutes ?? null]);
});

serviceRoutes.patch('/api/v1/work-items/:id', async (ctx: Ctx) => {
  const { status } = ctx.body ?? {};
  return one(pool, `
    UPDATE service.work_item
    SET status = COALESCE($2, status),
        started_utc = CASE WHEN $2 = 'In Progress' THEN COALESCE(started_utc, now()) ELSE started_utc END,
        completed_utc = CASE WHEN $2 = 'Completed' THEN now() ELSE completed_utc END
    WHERE work_item_id = $1 RETURNING *`, [Number(ctx.params.id), status ?? null]);
});

// ---------------------------------------------------------------------
// Checklist execution — BL-CHK-*
// ---------------------------------------------------------------------

serviceRoutes.get('/api/v1/job-cards/:id/checklist', async (ctx: Ctx) => {
  const c = await getChecklistForJob(pool, Number(ctx.params.id));
  if (!c) throw notFound('No checklist is attached to this job card.');
  return c;
});

serviceRoutes.post('/api/v1/job-cards/:id/checklist-results', async (ctx: Ctx) => {
  const answers = Array.isArray(ctx.body) ? ctx.body : ctx.body?.answers;
  if (!Array.isArray(answers) || !answers.length) {
    throw badRequest('Provide an array of checklist answers.');
  }
  const jc = await one<any>(pool, `
    SELECT technician_id FROM service.job_card WHERE job_card_id = $1`, [Number(ctx.params.id)]);

  try {
    const outcomes = await recordAnswers(pool, {
      jobCardId: Number(ctx.params.id), answers,
      technicianId: jc?.technician_id ?? null, actor: ctx.user!.username,
    });
    const checklist = await getChecklistForJob(pool, Number(ctx.params.id));
    return { outcomes, progress: checklist?.progress };
  } catch (e: any) {
    if (e.code === 'JOB_READ_ONLY') throw conflict(e.message, { ruleId: 'BL-JC-012' });
    throw e;
  }
});

// ---------------------------------------------------------------------
// Defects — BL-DEF-001
// ---------------------------------------------------------------------

serviceRoutes.post('/api/v1/defects', async (ctx: Ctx) => {
  const { vin, jobCardId, severity, subsystem, description, blocksRelease, dueByDate, dueByKm } = ctx.body ?? {};
  if (!vin || !severity || !description) {
    throw badRequest('Vehicle, severity and description are required.');
  }
  const v = await one<any>(pool, `
    SELECT vehicle_id, current_odometer_km FROM master.vehicle WHERE vin = $1`, [vin]);
  if (!v) throw notFound('Vehicle not found.');

  const no = await nextDocumentNo(pool, 'DEF', 4);
  return one(pool, `
    INSERT INTO service.defect
      (defect_no, vehicle_id, origin_job_card_id, severity, subsystem, description,
       blocks_release, opened_odometer_km, due_by_date, due_by_km, responsible_role, status)
    VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'Service Centre','Open') RETURNING *`,
    [no, v.vehicle_id, jobCardId ?? null, severity, subsystem ?? null, description,
     blocksRelease ?? (severity === 'Critical'), v.current_odometer_km,
     dueByDate ?? null, dueByKm ?? null]);
});

serviceRoutes.patch('/api/v1/defects/:id', async (ctx: Ctx) => {
  const { status, closureAction, closedJobCardId } = ctx.body ?? {};
  const d = await one<any>(pool, `
    UPDATE service.defect
    SET status = COALESCE($2, status),
        closure_action = COALESCE($3, closure_action),
        closed_job_card_id = COALESCE($4, closed_job_card_id),
        closed_at = CASE WHEN $2 = 'Closed' THEN now() ELSE closed_at END,
        row_version = row_version + 1
    WHERE defect_id = $1 RETURNING *`,
    [Number(ctx.params.id), status ?? null, closureAction ?? null, closedJobCardId ?? null]);
  if (!d) throw notFound('Defect not found.');
  await audit(pool, {
    entityType: 'Defect', entityId: d.defect_id, action: 'UPDATE',
    actor: ctx.user!.username, after: { status, closureAction },
  });
  return d;
});

// ---------------------------------------------------------------------
// Parts — BL-SP-001..008
// ---------------------------------------------------------------------

/** GET /api/v1/parts/applicable?vin= — SPM-004 applicability validation. */
serviceRoutes.get('/api/v1/parts/applicable', async (ctx: Ctx) => {
  const vin = ctx.query.get('vin');
  const search = ctx.query.get('search');
  if (!vin) throw badRequest('A VIN is required to resolve part applicability.');

  const v = await one<any>(pool, `SELECT variant_id FROM master.vehicle WHERE vin = $1`, [vin]);
  if (!v) throw notFound('Vehicle not found.');

  const params: unknown[] = [v.variant_id];
  let searchClause = '';
  if (search) { params.push(`%${search}%`); searchClause = `AND (p.part_no ILIKE $2 OR p.description ILIKE $2)`; }

  return many(pool, `
    SELECT DISTINCT p.part_id, p.part_no, p.description, p.part_category, p.base_uom,
           p.is_serial_controlled, p.is_batch_controlled, p.standard_cost,
           p.warranty_return_required, pa.is_universal
    FROM master.part_master p
    JOIN master.part_applicability pa ON pa.part_id = p.part_id
    WHERE p.status = 'Active'
      AND (pa.is_universal = true OR pa.variant_id = $1)
      AND pa.effective_from <= CURRENT_DATE
      AND (pa.effective_to IS NULL OR pa.effective_to >= CURRENT_DATE)
      ${searchClause}
    ORDER BY p.part_category, p.part_no
    LIMIT 200`, params);
});

/** POST /api/v1/job-cards/:id/parts — applicability + serial + quantity rules. */
serviceRoutes.post('/api/v1/job-cards/:id/parts', async (ctx: Ctx) => {
  if (!ctx.user!.permissions.has('parts.issue')) {
    assertPermission(ctx.user!, 'jobcard.execute');
  }

  const { partId, quantity, workItemId, source, oldSerialNo, newSerialNo, batchNo, isWarranty } = ctx.body ?? {};
  const jobCardId = Number(ctx.params.id);

  if (!partId) throw badRequest('A part is required.');
  // BL-SP-008: quantity must be positive.
  if (!(Number(quantity) > 0)) {
    throw badRequest('Part quantity must be greater than zero (BL-SP-008).');
  }

  const jc = await one<any>(pool, `
    SELECT jc.*, v.variant_id, v.vin FROM service.job_card jc
    JOIN master.vehicle v ON v.vehicle_id = jc.vehicle_id
    WHERE jc.job_card_id = $1`, [jobCardId]);
  if (!jc) throw notFound('Job card not found.');
  if (['Closed', 'Cancelled'].includes(jc.status)) {
    throw conflict(`Job ${jc.job_card_no} is ${jc.status.toLowerCase()} and cannot be edited (BL-JC-012).`);
  }

  const part = await one<any>(pool, `SELECT * FROM master.part_master WHERE part_id = $1`, [Number(partId)]);
  if (!part) throw notFound('Part not found.');
  if (part.status !== 'Active') {
    throw conflict(
      `Part ${part.part_no} is inactive and cannot be issued. ` +
      (part.superseded_by_part_id ? 'Use its approved replacement instead (BL-SP-002).' : ''),
      { ruleId: 'BL-SP-002' });
  }

  // BL-SP-001: applicability is validated before issue.
  const applicable = await one<any>(pool, `
    SELECT 1 FROM master.part_applicability
    WHERE part_id = $1 AND (is_universal = true OR variant_id = $2)
      AND effective_from <= CURRENT_DATE AND (effective_to IS NULL OR effective_to >= CURRENT_DATE)`,
    [Number(partId), jc.variant_id]);
  if (!applicable) {
    throw conflict(
      `Part ${part.part_no} (${part.description}) is not approved for this vehicle variant, ` +
      `so it cannot be issued or fitted (BL-SP-001 / SPM-004).`,
      { ruleId: 'BL-SP-001', partNo: part.part_no, vin: jc.vin });
  }

  // BL-SP-003: serialised parts require a serial number.
  if (part.is_serial_controlled && !newSerialNo) {
    throw badRequest(
      `${part.part_no} is serial-controlled: the new component serial number must be recorded ` +
      `(BL-SP-003 / SPM-007).`, { ruleId: 'BL-SP-003' });
  }

  return pool.transaction(async (tx) => {
    const usage = await one<any>(tx, `
      INSERT INTO service.part_usage
        (job_card_id, work_item_id, part_id, quantity, uom, source, status,
         old_serial_no, new_serial_no, batch_no, is_warranty, unit_cost)
      VALUES ($1,$2,$3,$4,$5,$6,'Issued',$7,$8,$9,$10,$11) RETURNING *`,
      [jobCardId, workItemId ?? null, Number(partId), Number(quantity), part.base_uom,
       source ?? 'Stock', oldSerialNo ?? null, newSerialNo ?? null, batchNo ?? null,
       isWarranty ?? false, part.standard_cost]);

    // BL-SP-004: close the old fitment and open the new one.
    if (part.is_serial_controlled && newSerialNo) {
      if (oldSerialNo) {
        await q(tx, `
          UPDATE master.vehicle_component
          SET is_active = false, removed_on = CURRENT_DATE, removed_job_card_id = $2,
              removed_odometer_km = $3, condition_status = 'Removed',
              removal_reason = 'Replaced during service'
          WHERE vehicle_id = $1 AND serial_no = $4 AND is_active = true`,
          [jc.vehicle_id, jobCardId, jc.odometer_at_open, oldSerialNo]);
      }
      await q(tx, `
        INSERT INTO master.vehicle_component
          (vehicle_id, component_type, part_no, serial_no, installed_on,
           installed_odometer_km, installed_job_card_id, condition_status, is_active)
        VALUES ($1,$2,$3,$4,CURRENT_DATE,$5,$6,'Active',true)`,
        [jc.vehicle_id, part.part_category, part.part_no, newSerialNo,
         jc.odometer_at_open, jobCardId]);
    }

    await audit(tx, {
      entityType: 'PartUsage', entityId: usage.part_usage_id, action: 'ISSUE',
      actor: ctx.user!.username,
      after: { partNo: part.part_no, quantity, oldSerialNo, newSerialNo },
    });
    return usage;
  });
});

/** POST /api/v1/job-cards/:id/labour */
serviceRoutes.post('/api/v1/job-cards/:id/labour', async (ctx: Ctx) => {
  const { technicianId, activity, startUtc, endUtc, hours, workItemId } = ctx.body ?? {};
  if (!technicianId) throw badRequest('A technician is required.');
  return one(pool, `
    INSERT INTO service.labour (job_card_id, work_item_id, technician_id, activity, start_utc, end_utc, hours)
    VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
    [Number(ctx.params.id), workItemId ?? null, Number(technicianId), activity ?? null,
     startUtc ? new Date(startUtc) : new Date(), endUtc ? new Date(endUtc) : null, hours ?? null]);
});

/** PATCH /api/v1/service-events/:id/closure — BL-BD-013 closure content. */
serviceRoutes.patch('/api/v1/service-events/:id/closure', async (ctx: Ctx) => {
  const { finalDiagnosis, rootCauseCode, correctiveActionCode, closureDisposition } = ctx.body ?? {};
  const se = await one<any>(pool, `
    UPDATE service.service_event
    SET final_diagnosis = COALESCE($2, final_diagnosis),
        root_cause_code = COALESCE($3, root_cause_code),
        corrective_action_code = COALESCE($4, corrective_action_code),
        closure_disposition = COALESCE($5, closure_disposition),
        row_version = row_version + 1
    WHERE service_event_id = $1 RETURNING *`,
    [Number(ctx.params.id), finalDiagnosis ?? null, rootCauseCode ?? null,
     correctiveActionCode ?? null, closureDisposition ?? null]);
  if (!se) throw notFound('Service event not found.');
  return se;
});

/** GET /api/v1/technicians?serviceCentreId= */
serviceRoutes.get('/api/v1/technicians', async (ctx: Ctx) => {
  const centre = ctx.query.get('serviceCentreId');
  const params: unknown[] = [];
  let where = `t.status = 'Active'`;
  if (centre) { params.push(Number(centre)); where += ` AND t.service_centre_id = $1`; }
  return many(pool, `
    SELECT t.technician_id, t.name, t.employee_code, t.service_centre_id,
           sc.name AS service_centre_name,
           ARRAY(SELECT ts.skill_code FROM master.technician_skill ts
                  WHERE ts.technician_id = t.technician_id
                    AND (ts.valid_to IS NULL OR ts.valid_to >= CURRENT_DATE)) AS skills
    FROM master.technician t
    JOIN master.service_centre sc ON sc.service_centre_id = t.service_centre_id
    WHERE ${where} ORDER BY t.name`, params);
});
